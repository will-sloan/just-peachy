# S4 — Common Voice bank, physical XVF outputs and unchanged H2 baseline

Run `20260909T002140Z`. Status: **S4_COMPLETE_WITH_LIMITATIONS**. All 24 canonical scenes, two nominal repeats and 48 unchanged-H2 jobs are complete, with zero mandatory omissions. The final validated run manifest and package receipt bind this report to the delivered evidence.

The physical development bank is complete: 24 canonical scenes and two nominal repeats have accepted audio and continuous telemetry. One telemetry-only failure was preserved and replaced by one unchanged retry. The accepted bank recovered **45,747,300 compared microphone samples with zero differences**; all 40 physical passes together recovered **75,470,288 compared samples with zero differences**, zero marker errors and zero callback flags. Only documented boundary padding is outside the exact comparison, and all active payload must be captured. Hardware was restored after every batch, including a separately evidenced exact recovery from an early setter-rounding failure. No RIRs, H2 models, scientific thresholds, firmware or drivers were changed. S5/S6 were not started.

## Completion and scope

| Component | Actual result | Interpretation |
|---|---|---|
| Canonical bank | 24 planned, rendered and structurally validated; 726 seconds | One FLOAT32 four-microphone render per scene |
| Accepted final captures | 24/24; zero payload differences and marker errors | Same frozen scene bytes, owner code and final recipe |
| Extra nominal repeats | 2/2, both PASS | Attempts of scene 01, excluded from bank totals |
| Physical budget | 40/40 passes; 1,198 seconds of active playback | 12 calibration + 1 transport regression + 24 accepted final + 2 repeats + 1 excluded failure |
| Audio/spatial analyses | 24 final cases plus both repeats | Raw evidence retained; fixed scoring rules |
| Ordinary H2 jobs | 48/48 complete; 24 pairs | 44 native summaries plus four derived from verified primary completion evidence; no model reruns |
| Device restoration | PASS, with preserved early exact-recovery receipt | Starting exposed settings and USB width restored; packed input off; handles/lease closed |
| S5 output choice / S6 fusion benefit | Not evaluated | Both output paths preserved for later decisions |

S3's established eight-capture proof, including 12,503,040 compared microphone samples with zero differences, is reused. S4 adds one small tagged transport regression and this bounded bank. The tagged fixture is a transport diagnostic, not a Common Voice scene or speech-quality result. Raw captures from failed or superseded attempts are never silently promoted into the accepted set. Scene 22's all-zero microphone output is verified, but an all-zero input cannot identify unique source-to-capture correspondence: its alignment is explicitly `UNIDENTIFIABLE_ALL_ZERO_INPUT` with a null offset, not an invented timing measurement.

`ACCEPTED_FINAL_CAPTURES.json` selects scenes 01–18 from `hardware/final` and 19–24 from `hardware/final_completion`. The original `final/S4_19` has exact audio recovery but failed mandatory telemetry; it is excluded from final audio/spatial/H2 aggregates. Its retry has identical input bytes, code identity, initialization and hardware recipe. All failed evidence remains in place and is linked by `TELEMETRY_RETRY_RESOLUTION.json`.

## Sources, RIRs and scene coverage

All newly scheduled speech is local **Common Voice 26.0, English**, release `cv-corpus-26.0-2026-06-12`, under `Software Validation from Datasets\Raw Datasets (Not formatted)\Common Voice\…\prepared\en`. This materialization is a self-reported 60+ metadata subset, covering sixties through nineties. It is not a population-balanced conversational sample. The local release README supplies CC0 and identity-use terms; the source adapter preserves byte, transcript and contributor bindings and uses pseudonymous working identities.

Six development contributors supply 23 unique scheduled whole clips, 109.608 seconds of unique dry audio and 64 scheduled utterance instances totaling 300.636 seconds with reuse. No other speech corpus or new download was used. Twenty-four probes were prepared; B4 (`common_voice_en_18838753`, 3.960 seconds) is unused development material. Six separate enrollment candidates are unused, and three additional contributors/nine clips remain downstream reserve. All 413 contributors in the prior local Common Voice protocol were excluded from this new cohort. Reserve roles were frozen before waveform QC and S4 outputs; no enrollment clip became a probe.

The bounded shortlist decoded 40 clips, rejected one for insufficient estimated activity and accepted 39. Native `validated.tsv` rows independently confirmed all 39 selected identities, transcripts, sentence IDs, locale and vote fields. Selected source-byte and decoded-PCM hashes are unique. This establishes the selected bindings, not whole-corpus near-duplicate freedom, biometric identity uniqueness or absence from model pretraining.

The bank uses 17 eligible RIRs from four non-Upper-Loeb settings, at **0.65–4.07 m**. No selected distance exceeds 5 m. RETAKE, early testing, excluded Loeb Caf and the deferred low-table R13 path remain excluded. The two earlier low-table +20° R05 entries retain the user's correction from 100 m to 1.00 m through the existing effective metadata; original acquisition evidence is unchanged. Upper Loeb remains in the canonical library as downstream reserve, but was examined during RIR processing and is not unseen validation of that method. The canonical RIR manifest remains SHA-256 `468b2b306f994937a7d02db611080d38c7a4bcc7dc89ce7dc73d93762380f546`.

Of those 17 selected RIRs, 12 are `EXTRACTED` and five are `EXTRACTED_WITH_LIMITATIONS`, with inherited local frequency intervals below the S2 support rule. They remain eligible for this proof; their limitations are preserved in the scene manifest. Acquisition PASS/REVIEW eligibility does not turn a limited extraction into a fully calibrated broadband response.

The scenes cover nominal/quiet/louder and swapped A→B→A, two voices alone on the same path, whole short replies, long pauses and silent relocation, three partial overlaps, close/separated folded directions, front/rear ambiguity, matched flat/upright and clear/obstructed pairs, near/far competition, localized interference, silence and matched noise controls. Scene 20 has 1.848 seconds of scheduled near/far overlap. Scenes 13/14 also change measured paths/distances, so they cannot isolate angle separation alone. Scene 07 replies last 3.048–3.996 seconds; subsecond yes/no coverage is absent. Synthetic noise is a seeded colored point source convolved through its own RIR, not measured diffuse HVAC. Scenes 23/24 use the identical noise component.

Source QC was numerical plus a visual waveform/envelope review of four calibration clips. Their quiet suffixes were 0.492–1.456 seconds and final-300-ms RMS ranged from −54.33 to −68.06 dBFS; none clipped at the source check. Small pre/post impulses and uncalibrated source-room, microphone, codec and background conditions remain. No auditory or anechoic certification is claimed. Whole-file timing is known; phonetic/word boundaries are not.

## Frozen level and initialization decisions

Each dry source receives one scalar before convolution: estimated active RMS target −24 dBFS, maximum requested boost 12 dB and dry peak cap 0.5 FS. Activity uses 20-ms RMS frames and the larger of −50 dBFS and the frame 95th percentile minus 25 dB. Applied scalars range approximately −8.67 to +5.65 dB. The whole-bank headroom scalar is 1.0; maximum canonical microphone peak is 0.113142 FS. These are numerical levels, not calibrated acoustic SPL. RIRs/per-microphone audio are not normalized, and no second distance law, reverberation, acquisition gain or delay is applied.

The same nominal/−6/+6 dB microphone inputs were compared across the baseline and at most two predeclared headroom alternatives:

| Matched cases 01–03 | O1 rail samples / whole captured samples | O0 rails |
|---|---:|---:|
| Baseline | 320 / 1,521,381 | 0 |
| Limiter power 0.1175 | 41 / 1,521,381 | 0 |
| Limiter plus AGC headroom | 17 / 1,521,381 | 0 |

The chosen final recipe uses `PP_LIMITPLIMIT=0.1175`, `PP_AGCDESIREDLEVEL=0.001125`, `PP_AGCMAXGAIN=62.5` and current `PP_AGCGAIN=62.5` at each independent scene start; time constants remain unchanged. It produced the lowest observed rail count of the two tested alternatives. This finite comparison does not prove a global optimum or eliminate saturation. The full six-scene baseline's 625 rails are a separate denominator and are not compared directly with a three-scene alternative.

O0 receives **one fixed +3 dB host scalar, 1.4125375446227544**; device ASR gain remains 1. O1 host gain remains 1. The O0 scalar was derived before final capture from the largest calibration peak, targeting at most 0.25 FS in that range, without H2 scores. Raw PCM24 outputs remain unchanged.

Across the final 24 captures, O0 has **0 / 11,499,048 rail samples**, maximum raw peak 0.169733 FS and projected fixed-gain peak about 0.240 FS. O1 has **61 / 11,499,048 rail samples** (5.305 per million), in 11 captures, with a maximum contiguous run of seven samples. Estimated support accounting places 34 rails in the first 500 ms of an utterance envelope and 27 later in support. That onset convention is not phonetic or calibrated AGC timing. Independent native-payload decoding verifies that these plateaus already exist in device output; attenuating saved audio would not repair them. O1 remains LIMITED. Nominal O1 rail counts vary across final/repeat1/repeat2: 7, 2 and 4, illustrating limited adaptive repeatability.

![Matched calibration and final output headroom](plots/figure_01_headroom.png)

The proven S3 six-channel order `[0,0,MIC0,MIC1,MIC2,MIC3]`, 48-kHz stereo PCM24 carrier, mic/ref gains 1, `SYS_DELAY=0`, mux order and bit-transparent endpoint selection are retained. The owner resets only between independent scenes, isolates packed input immediately after firmware readiness, reapplies 50 exposed baseline settings plus the frozen recipe and sets current AGC last. No target-speech warmup or between-turn reset is used. Equal static readbacks do not prove identical hidden adaptive history.

## Directions and timing

The original signed manual angles are preserved. Approximately **±5° belongs to the source-position label**, not the XVF accuracy specification, a default scoring tolerance, a calibrated confidence interval or random jitter. The nominal mapping is `native_deg = degrees(acos(-sin(radians(lab_deg))))`, consistent with MIC0 left/MIC3 right. The entire wrapped manual interval is folded into 0–180°; front/rear-equivalent directions remain ambiguous. Coarse sectors are right below 60°, central/ambiguous from 60–120°, and left above 120°. No transform is fitted to improve final scores.

Continuous logging now records all four AEC angles, all four energies and both selected-direction values through one persistent queued-control owner. Requested rate is 20 Hz per field; achieved successful-batch rates are measured, generally about 16 Hz. No-speech NaN is encoded as null plus its reason, distinct from zero and communication failure. Raw replies, sequence, request/response times and host line receipts remain local.

The implemented causal reader uses only already received observations, with separate 250-ms age, transaction-duration, delivery-delay and gap limits. Invalid/missing/old spatial data becomes `spatial_unavailable`; audio/text remain allowed. New USB responses do not prove a new internal DSP frame, and a constant angle does not by itself prove staleness. A beam ID is not a person identity.

Five clocks remain distinct: source schedule; the retained approximately 50-ms RIR convention; recaptured microphone samples; processed-output samples; and host availability. Exact input alignment and actual callback copy-completion evidence map sample intervals into host availability. No angle/energy shift is fitted to expected transitions. A pre-scoring software review found the retained 50 ms was being added twice in one spatial support helper; the helper was corrected and regression-tested before any final spatial scores. The scoring policy and all audio stayed unchanged. Correlation-based output delay is descriptive, not calibrated total device latency, and host callback granularity/internal DSP age remain limitations.

The frozen sustained-acquisition definition requires at least 80% matching causal occupancy over the preceding one second with the freshness gap at most 250 ms. First hits are reported separately; never-acquired and short/censored supports remain in the denominator. In the **51 turns from cases without overlapping speech**, summed callback-quantized active support is 158.397 seconds. Selected-processed indication coverage is **83.75%** and expected-sector occupancy **52.88%**, with sustained matching observed in **33/51** turns. Raw-auto energy-gated coverage is **37.90%**, matching occupancy **23.53%**, and sustained matching is observed in **14/51**. The streams have different validity/energy gates; these numbers do not select a winner.

For completeness, the full-bank aggregation includes all 64 dependent scored turns, including overlapping-source cases: selected-processed coverage **85.45%**, matching occupancy **46.74%**, and sustained acquisition censored in **26/64**. Its observed-only median is **1.216 seconds**, not an all-turn latency. Raw-auto coverage is **39.96%**, occupancy **21.51%**, with **48/64** censored. The non-overlap subset is easier to interpret against a single expected source. These descriptive results support a cautious optional cue with safe invalidation; they do not establish reliable turn-by-turn person tracking or a preferred production beam.

In the nominal A→B→A capture and both repeats, returning A2 never reacquired its expected left sector in selected-processed output: the observed states were right, central or unavailable. An independent replay of raw selected replies reproduced the first-hit and occupancy calculations for all nine nominal turns. This repeat pattern is a direct restriction on using the selector as a reliable turn/identity signal; it is retained rather than corrected using known seats.

![Nominal direction observations and two repeats](plots/figure_03_directions.png)

Digital silence produces zero selected-processed, raw-auto, selected-auto or scanning gated indication, but focused beam 2 has positive energy for 10.354% of its 24.002-second whole capture. Therefore not all beam-energy output is zero on silence. During the 25.800-second noise-only window, selected-processed and raw-auto indications cover 16.157% and 8.417%, respectively; these are noise-associated indications, not proof of speech or a person. The final age-limit gaps occur in that noise-only case, reaching about 397 ms for angles and 458 ms for energy/selected replies, and are masked by the causal policy. Zero reported off-delay can mean the cue was already wrong or unavailable, rather than rapid release. `SPATIAL_FINDINGS.md` retains first-hit, sustained, off-delay, repeat and censoring details.

The excluded scene-19 logger stopped at the bounded two-second elapsed-cycle guard after a 2.214-second gap outside recorded USB calls. All 1,254 USB calls returned successfully, with only documented success/pending statuses and no more than three attempts per field. Pending replies drained during cleanup. A host scheduling/logging/delivery stall is plausible; its exact cause is unproven. The unchanged retry passed. The failed trace remains a measured robustness limit, not evidence to relax freshness gates or conceal missing observations.

## H2 interpretation

All **48 ordinary invocations completed**. Each scene/output used the existing H2 CPU file CLI with accelerated offline pacing, a fresh empty enrollment/session root, explicit 16-kHz mono input and unchanged model/config/source bindings. Conversation state was preserved within a scene; source text, reference activity and seats were never model inputs. One frozen host gain was applied at the adapter, with no per-utterance normalization. Every job has a completion event, exit code zero and zero recorded audio drops, input overflows or capture-reserve failures.

Non-overlap whole-transcript WER/CER uses the existing normalization and reports S/D/I plus reference denominators. Overlap scenes 10, 11, 12 and 20 have LIMITED ordinary transcript scoring; arbitrary concatenation is not used as reliable overlap WER. Silence/noise have empty-reference insertion counts and words per minute. No population confidence interval is inferred from reused clips and six contributors.

| Paired development result | O0, fixed +3 dB | O1, fixed 0 dB |
|---|---:|---:|
| Scored non-overlap scenes | 18 | 18 |
| WER | 72 / 467 = **15.42%** | 91 / 467 = **19.49%** |
| Word substitutions / deletions / insertions | 48 / 18 / 6 | 61 / 25 / 5 |
| CER | 210 / 2,249 = **9.34%** | 241 / 2,249 = **10.72%** |
| Character substitutions / deletions / insertions | 70 / 104 / 36 | 77 / 117 / 47 |
| Silence/noise inserted words | 0 over 56.390875 s | 0 over 56.390875 s |
| Return checks: consistent / inconsistent / unknown | 8 / 8 / 6 | 7 / 11 / 4 |
| Reference turns with multiple clusters | 55 / 60 | 54 / 60 |
| Successful observed embedding calls | 697 | 716 |
| Single-speech hops below the embedding RMS gate | 209 / 906 | 169 / 885 |

The same 467 reference words and 2,249 reference characters underlie both aggregate scores. Empty-reference controls produced 0 words/minute. Independent recomputation reproduced all word/character edit counts and the 48 per-case rows. The observed O0/O1 difference is descriptive for this frozen development bank; it does not establish a general output ranking or complete S5.

Each stream has 22 dependent participant/scene return checks. Unknown includes tied dominant labels, not necessarily missing embedding evidence. Multiple-cluster counts refer to 60 scored reference turns; timing remains LIMITED where qualified alignment is absent or the control has no speech. No reference turn was classified as having no embedding evidence. Exact event/gate checks found zero eligible hops without a decision and zero decisions on ineligible hops. The RMS condition rejected 209 of 906 single-speech hops for O0 and 169 of 885 for O1; gate reasons can overlap, and unlogged rejected model calls remain unknown. These observations retain the substantial continuity/fragmentation limitation instead of substituting known source identities.

![Paired H2 transcript errors and empty-reference controls](plots/figure_02_text.png)

The S3 audit corrected the interpretation of returning-speaker evidence: first/returning A could share a dominant underlying anonymous label while emitted final-transcript labels fragmented. Final labels snapshot the concurrently available speaker state; there is no separate reconciliation stage in this H2 mode. Current scoring distinguishes emitted labels, underlying decision continuity, cluster fragmentation and missing evidence. Empty profiles cannot yield enrolled-name accuracy. Full DER, reconciliation results, rejected embedding-model calls and exact phonetic latency are unavailable when the baseline does not expose them. The 0.002 RMS gate uses a 0.5-second embedding window evaluated every 0.25 seconds; it does not gate ASR, and eligible hop counts are not independent speech seconds. Offline process/session RTF is not live caption latency.

Four original H2 processes exited zero with terminal completion events but left their summary files empty: **S4_18/O1, S4_20/O0, S4_20/O1 and S4_24/O0**. The unchanged CLI returns when a daemon watcher announces completion, before that watcher necessarily finishes its non-atomic summary write. These empty files are consistent with that shutdown window; the exact thread schedules are unobserved. Bounded offline recovery preserved each empty original and failed runner receipt, verified exact journal/console agreement, full input-spool conversion and final transcript rows, then wrote explicitly **derived** summaries from completion-event telemetry and the bound configuration. Thus 44 summaries are native exports and four are reconstructed completion evidence.

The four recoveries respectively verified 116/89/91/95 journal events, 507,127/443,127/443,127/523,127 PCM16 spool samples and 3/2/2/3 final transcript rows. No model was rerun or baseline source/threshold changed. Expected model hashes come from the bound configuration, with validation inferred from completed unchanged constructors; no asset-validation event was invented. The would-be native summary's `elapsed_wall_sec` remains unknown, and the 0.1954375-second unanalyzed speaker short tails remain explicit. The four `H2_SUMMARY_RECOVERY*.json` receipts and recovery READMEs preserve exact provenance, including five V1 and six V2 failure-focused tests. The original CLI export race remains a baseline limitation requiring a separate durable-write/join repair; this comparison includes only the explicitly identified artifact recovery.

The 48 original H2 processes used **666.626 seconds of measured process wall time** in total: 320.719 s for O0 and 345.907 s for O1, each processing 718.6905 s of captured audio. Pooled process RTF was 0.4463 and 0.4813, respectively. These times include process/model startup, execution and export overhead under variable desktop load. They are neither isolated model compute nor live caption latency. Per-job events retain the separately defined first/final text availability and session timing; unavailable timing is not filled from the process wall clock.

## Handoff and remaining decisions

`S3_ISSUE_CLOSURE.json` records **14 issue dispositions: five FIXED, eight IMPLEMENTED WITH MEASURED LIMITATION, one OPTIONAL UNAVAILABLE and zero BLOCKED**. Fixed items are source binding, angle metadata/folding, transport initialization, continuous selected-direction logging and exact float32 restoration. Measured limitations remain in O1 headroom, O0 gate eligibility, causal freshness, timing, direction transitions, H2 continuity, the preserved host-stall retry and H2 export recovery. Optional H2 reconciliation/rejected-call observability is unavailable in this baseline. Each disposition binds its cause confidence, implementation, regression evidence and allowed-use restriction.

`NEXT_PHASE_INPUTS.md` identifies frozen inputs and the separate future S5 output-comparison and S6 fusion questions. Both captured output paths are preserved; the bank does not declare an output winner or cue-fusion benefit. Broader conversational coverage, subsecond replies, absolute-angle calibration, reliably fresh internal DSP timestamps, source dryness and model continuity remain unproven.

The V8 Word workbook was read from Downloads and left unchanged. `WORKBOOK_UPDATE.md` is proposed narrative for human review. The compact handoff contains three readable plots, small metrics/manifests, changed-code/test evidence and member checksums. Raw audio/telemetry, source corpus, models, RIRs and the Word master remain local, located by `LOCAL_ARTIFACT_INDEX.json`.

At the closing resource check (2026-09-09 02:09:07 UTC), elapsed time since the 00:21:40 UTC run start was **1 h 47 min 27 s**, including implementation, analysis and review. Active physical playback was **19:58** and H2 process time **11:06.626**; these are distinct measures. Generated bank/report/source-audit artifacts occupied **1.73 GiB**, below the 5-GiB allowance. The C: WD_BLACK SSD had **72.26 GiB free**, above the retained 50-GiB reserve; the G: Kingston SSD had **449.30 GiB free**. Both SSDs reported Healthy/OK. Validation records a fresh storage/elapsed-time snapshot in `run_manifest.json`; the local `package_receipt.json` gives the exact final elapsed time, ZIP size and SHA-256 after archive creation.

The compact package is `simulation/handoffs/S4_CHATGPT_HANDOFF_20260909T002140Z.zip`. Packaging verifies the unchanged Git tracked state, H2 baseline, canonical RIR library and Word master, all required evidence bindings and every archive member checksum. Hardware is restored, packed input is disabled and owned handles/lease are closed. **Stop at this S4 handoff; S5 and S6 have not started.**
