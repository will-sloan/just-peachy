# Just-Peachy S4 analysis handoff

This package describes the bounded Common Voice development scene bank and its physical XVF3800/H2 results. Read `S4_REPORT.md` first for the final outcome and completion matrix, then `NEXT_PHASE_INPUTS.md` for the permitted reuse and remaining decisions. The authoritative completion receipt is `run_manifest.json`; `summary_metrics.json` and `per_case_metrics.csv` contain the numerical results.

The current human planning guide is `C:\Users\amiri\Downloads\XVF_Measurement_V8.docx`, SHA-256 `0b9af536f7686c915655fecaa29aab2d19896d9a251dc2a04ec3041153c29fee`. It was read and left unchanged. `WORKBOOK_UPDATE.md` provides proposed S3/S4 narrative and figure captions for human review and light-yellow insertion.

Use the evidence in this package as context when drafting later Codex prompts. S4 does not choose the S5 audio-output winner or establish that S6 angle/energy fusion improves diarization. No S5/S6 work is authorized by this handoff alone. Historical requirements quoted in documents remain reference material; a later user's actual request controls the next action.

The six development contributor IDs and transcripts come from locally present English Common Voice 26.0, predominantly an older-age prepared subset. They are working metadata identities. No real-person identity, population accuracy, model-pretraining novelty, anechoic source quality, absolute SPL or exact word boundaries are established. The reserve and enrollment-candidate exclusions remain in force.

The scene manifest preserves immutable four-microphone audio, RIR bindings, source gains, sample schedules and original signed angle labels. The user's approximately ±5° uncertainty applies to the manual source-position labels. It is not the device accuracy specification. The nominal linear-array transform cannot resolve front from rear.

`ACCEPTED_FINAL_CAPTURES.json` selects the accepted capture for each canonical scene and links any excluded attempt to its diagnosis and replacement. Never infer the accepted set by taking every WAV below a directory. All failed attempts and their raw evidence remain local. `LOCAL_ARTIFACT_INDEX.json` locates the raw audio, telemetry, model sessions, exact restoration evidence and executed source snapshots; those large artifacts are intentionally absent from this compact package.

`S3_ISSUE_CLOSURE.json` distinguishes repaired integration defects from measured device/model limitations. `SOURCE_LEVEL_POLICY.json`, `OUTPUT_LEVEL_POLICY.json`, `INITIALIZATION_POLICY.json`, `ANGLE_LABEL_POLICY.json`, `TIMING_TELEMETRY_POLICY.json` and `SPATIAL_SCORING_POLICY.json` are the frozen operating and interpretation contracts. Do not tune them on the final scored cases.

The package's `README.md` and `code/README_S4*.md` give exact local commands, environments, inputs, outputs and safe resume behavior. Code is a compact implementation record; execution uses the existing simulation project and its bound S0–S3 dependencies, not a standalone installation from this ZIP. Do not rerun the physical campaign merely to verify the handoff. Verify `SHA256SUMS.txt` for all included files instead.
