# S4 spatial evidence review

Status: S4_COMPLETE_WITH_LIMITATIONS. The 24-case physical/audio/spatial bank, two nominal repeats and all 48 paired H2 jobs are complete with zero omissions. This component makes no S5 output selection or S6 fusion-benefit claim.

The accepted bank contains 24 final-recipe cases and two separate nominal repeat captures. The complete physical ledger has 40 passes charged at 1,198 s: 39 PASS and one retained telemetry-failed attempt. The accepted S4_19 is the single unchanged retry in `final_completion`; the original `final/S4_19` is excluded. Final, final_completion, repeat1 and repeat2 batch restorations are PASS. Authority: [ACCEPTED_FINAL_CAPTURES.json](<C:/Users/amiri/Documents/GitHub/just-peachy/XVF 3800 Testing/XVF Integration Real World RIRs/simulation/reports/S4/20260909T002140Z/ACCEPTED_FINAL_CAPTURES.json>), [physical_ledger.json](<C:/Users/amiri/Documents/GitHub/just-peachy/XVF 3800 Testing/XVF Integration Real World RIRs/simulation/reports/S4/20260909T002140Z/physical_ledger.json>), [TELEMETRY_RETRY_RESOLUTION.json](<C:/Users/amiri/Documents/GitHub/just-peachy/XVF 3800 Testing/XVF Integration Real World RIRs/simulation/reports/S4/20260909T002140Z/TELEMETRY_RETRY_RESOLUTION.json>).

## Frozen definitions and audit scope

All 26 spatial receipts use the same policy and corrected scorer SHA-256 `4b26135f62851d69a0e1a1af287473e18cec466a2822ede63488d0822a2d5204`. Policy SHA-256 is `d6b94a372c5f020d890db327dcba6bc6a9949c2cc0f0575ef2b2235fc334500b`, serialized by `json.dumps(policy, sort_keys=True)` in UTF-8. The duplicate 50 ms activity shift was fixed and regression-tested before any final spatial score. No thresholds, gains, microphone scenes or physical captures changed for this fix. See [regression_receipt.json](<C:/Users/amiri/Documents/GitHub/just-peachy/XVF 3800 Testing/XVF Integration Real World RIRs/simulation/reports/S4/20260909T002140Z/review_staging/telemetry_spatial_fix/regression_receipt.json>).

The primary clock is copy-complete host availability of recaptured input samples. Absolute scene activity already contains the retained 800-sample (50 ms at 16 kHz) RIR convention once. Native framing adds the measured input offset and startup framing. Separately reported processed-output support adds only the audio-measured O0/O1-to-MIC0 delay. This does not shift telemetry or fit angles to truth. Callback blocks reach 150 ms; maximum whole-capture callback availability gap is 304.198 ms. Sample quantization, source-activity estimation and unknown internal DSP observation time prevent interpreting these numbers as acoustic device latency.

The latest actually received value is usable only under the frozen 250 ms request-duration, response-to-receipt and receipt-age limits. No future interpolation is used. Selected processed direction uses finite selected[0], whose documented no-speech NaN remains null. Selected auto and the four AEC streams additionally require a fresh same-index positive vendor speech-energy value. Thus usable coverage has different gates across streams. Fresh transactions can repeat a semantically wrong direction; age fallback does not detect that without truth.

Coarse sectors are native right <60 degrees, central/ambiguous 60 through 120, and left >120. The nominal lab transform is acos(-sin(lab angle)); manual +/-5 degrees is source-position uncertainty, never device tolerance. Geometry remains front/rear ambiguous and uncalibrated. First hit and sustained acquisition are measured over the first-to-last active-support **envelope**, including its internal pauses; duration coverage and sector occupancy use only the union of estimated active-support intervals. Consequently an envelope hit can occur in a pause even when active-support matching occupancy is zero. Sustained acquisition requires at least 80% matching occupancy over a trailing full second, tested at actual matching angle receipts with maximum observed receipt gap 250 ms. These were frozen definitions, not selected after examining outputs.

## Main denominator: cases without overlapping speech

There are 64 scheduled source turns. The principal table conservatively excludes all 13 turns from the four overlap-limited cases (S4_10, S4_11, S4_12, S4_20), leaving 51 turns with 158.397448 s summed callback-quantized active support. It uses duration-weighted occupancy/coverage, not an average of per-turn percentages. All 64 observation envelopes exceed one second; sustained censoring here is not caused by a sub-one-second envelope. Null acquisitions remain censored in the denominators.

| Stream | Usable gated coverage | Nominal-sector occupancy | First hit | Already matching at onset | Sustained | Acquired-only median sustained s | Held wrong-sector s |
|---|---:|---:|---:|---:|---:|---:|---:|
| selected_processed | 83.75% | 52.88% | 40/51 | 19 | 33/51 | 1.057 | 44.058 |
| selected_auto | 37.90% | 23.68% | 42/51 | 15 | 13/51 | 1.463 | 21.498 |
| raw_auto | 37.90% | 23.53% | 42/51 | 15 | 14/51 | 1.447 | 22.472 |
| focused_1 | 21.45% | 5.29% | 6/51 | 3 | 3/51 | 1.063 | 25.444 |
| focused_2 | 17.71% | 16.32% | 30/51 | 11 | 11/51 | 1.887 | 2.166 |
| scanning | 6.70% | 5.24% | 38/51 | 4 | 0/51 | censored | 2.169 |

Selected_processed has 11/51 first-hit censored and 18/51 sustained censored turns; raw_auto has 9/51 and 37/51 respectively. Their acquired-only first-hit medians are 0.016 s and 0.366 s, but 19 and 15 hits respectively were already matching at onset. These medians are conditional descriptive values, not reliable device reaction-time claims. Summed wrong-sector time is 48.883 s selected_processed and 22.762 s raw_auto; 44.058 s and 22.472 s respectively meet the descriptive unchanged-angle/held criterion. Those durations are not proof of stale DSP state or person identity.

All 51 nonoverlap turns have an observed off-delay endpoint. For selected_processed 37/51 are zero; for raw_auto 50/51 are zero. Median observed off-delay is zero for every stream. The definition stops on unavailable, no-speech **or wrong-sector** state, so zero often means the desired direction was already absent at speech end. It is not evidence of fast, accurate release. Over all 64 turns, only 59 off-delay endpoints are observed and five are censored because another source remains active.

The all-64 diagnostic denominator is 201.898161 s summed per-source support; simultaneous-source support may be counted for each source. Selected_processed coverage/occupancy is 85.45%/46.74%, with first-hit 45/64 and sustained 38/64. Raw_auto is 39.96%/21.51%, with first-hit 50/64 and sustained 16/64. Keep these overlap-limited diagnostics separate from the principal table; a single direction cannot represent both simultaneous sources uniquely.

## Nominal A-B-A repeat curves

All three nominal attempts use identical microphone render SHA-256 `7580276cf4e116a96fee0255cb975418f8d509f1f098087964a9d621f353bfb8` and the same frozen `limiter_and_agc_headroom` recipe. The table is selected_processed only; raw_auto and the other streams remain in the per-case JSON.

| Attempt | Turn | First hit s | Sustained s | Gated coverage | Matching occupancy | Off-delay s |
|---|---|---:|---:|---:|---:|---:|
| final | A1 | 0.021 | 1.013 | 100.00% | 98.81% | 0.036 |
| final | B1 | 2.526 | 3.334 | 99.86% | 41.80% | 0.000 |
| final | A2 | censored | censored | 71.21% | 0.00% | 0.000 |
| repeat1 | A1 | 0.083 | 1.016 | 91.58% | 86.99% | 0.000 |
| repeat1 | B1 | 2.517 | 3.329 | 100.00% | 42.13% | 0.487 |
| repeat1 | A2 | censored | censored | 12.57% | 0.00% | 0.000 |
| repeat2 | A1 | 0.000 | 1.041 | 100.00% | 100.00% | 0.047 |
| repeat2 | B1 | 2.518 | 3.328 | 99.45% | 41.56% | 0.000 |
| repeat2 | A2 | censored | censored | 56.76% | 0.00% | 0.000 |

A1 selected acquisition sustains near 1.01-1.04 s. B1 first hits near 2.517-2.526 s and sustains near 3.328-3.334 s; before that, the selected angle stays in the central sector, not the expected right sector. Returning A2 never reacquires the expected left sector in any of the three attempts. Its usable selected coverage varies from 12.57% to 71.21%, but its matching occupancy remains zero. Raw_auto also never sustains A2 in any nominal attempt; it has brief hits in final and repeat2, and no hit in repeat1. There is repeatability in this failure pattern and variability in indication coverage. Three captures do not establish a distribution of device behavior or identify the hidden adaptive cause.

Independent bounded raw replay, using only JSON receipt timestamps/values and a separate last-receipt integrator with no scorer imports, reproduced all nine selected_processed turn occupancies and first-hit values to tolerance 1e-12. In the three A2 supports it found only right/central/unavailable states, no left states. This checks the reported curve interpretation; it is not an independent truth calibration.

## Silence, noise and telemetry gaps

S4_22 digital silence spans 24.002054 s on the host availability clock. Selected_processed and raw_auto/selected_auto/focused_1/scanning gated indications are zero. **Focused_2 has positive speech-energy-gated indication for 10.3541% (2.4852 s)** of the silent capture. Finite raw angles persist during silence; a finite angle alone is not speech detection. Silence input offset is explicitly unidentifiable, so no source-aligned angle latency is inferred.

S4_23 point-noise-only support spans 25.799773 s. Selected_processed indicates for 16.1566% (4.1684 s); raw_auto/selected_auto for 8.4166% (2.1715 s), focused_1 the same 8.4166%, focused_2 0.1150%, and scanning 0.3549%. These are measured indications on one noise control, not population false-positive rates. S4_24 contains actual speech plus the same noise and must not be scored as a false-speech-only control.

Across the accepted 24 cases, each of the three commands has 11,917 observations (35,751 total); achieved per-field rates range from 16.047 to 16.219 Hz despite the 20 Hz request. All age-limit receipt gaps occur in S4_23: one per field, at most 397.083 ms for AEC angles and 457.736 ms for selected angles. Two angle, three energy and three selected transactions fail normalized timing validity. They are retained and masked, not counted as fresh cues, while the physical capture itself is transport PASS. Adjacent arrays repeat in 7,535/11,893 angle comparisons, 8,907/11,893 energy comparisons and 8,884/11,893 selected comparisons; repeated numeric values do not establish device-frame freshness. The separately excluded S4_19 host-path timeout remains outside these accepted-case denominators.

## Reusable limits

The logger, causal availability adapter and frozen analysis definitions are reusable. Measured direction gaps, held wrong sectors, returning-speaker reacquisition failures and control indications remain limitations. Neither selected_processed's greater gated coverage nor another stream's lower wrong-sector duration is an output/fusion winner: the gates differ and unavailable duration matters. No threshold tuning, H2 modification, production cue default, speaker identity inference, S5 selection or S6 benefit follows from this audit.

Evidence: [spatial_analysis_final.json](<C:/Users/amiri/Documents/GitHub/just-peachy/XVF 3800 Testing/XVF Integration Real World RIRs/simulation/reports/S4/20260909T002140Z/spatial_analysis_final.json>), [spatial_analysis_repeat1.json](<C:/Users/amiri/Documents/GitHub/just-peachy/XVF 3800 Testing/XVF Integration Real World RIRs/simulation/reports/S4/20260909T002140Z/spatial_analysis_repeat1.json>), [spatial_analysis_repeat2.json](<C:/Users/amiri/Documents/GitHub/just-peachy/XVF 3800 Testing/XVF Integration Real World RIRs/simulation/reports/S4/20260909T002140Z/spatial_analysis_repeat2.json>). Completed paired H2 metrics and all four explicitly derived export recoveries are recorded in [summary_metrics.json](<C:/Users/amiri/Documents/GitHub/just-peachy/XVF 3800 Testing/XVF Integration Real World RIRs/simulation/reports/S4/20260909T002140Z/summary_metrics.json>). Any S5 comparison or S6 fusion experiment is a separate phase; these spatial limitations remain.
