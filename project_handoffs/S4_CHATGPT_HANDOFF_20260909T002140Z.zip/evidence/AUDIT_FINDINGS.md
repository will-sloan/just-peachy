# Bounded S3 audit for S4

No H2 source, model, threshold or speaker policy was changed. Ten focused S4 analysis tests passed with Anaconda Python. See `simulation/scripts/README_S4_H2_ANALYSIS.md` for exact reproduction commands and interfaces. `run_audit.py` reads only three selected S3 captures and the two existing paired H2 sessions. All resulting evidence is under this staging folder.

## Output saturation and conversion

Independent extraction of signed PCM24 native words, documented row-major packing and cleared marker bits exactly matches every saved O0 and O1 sample in the selected original ABA1, retry ABA1 and tagged nonspeech cases. The observed rails therefore precede the host WAV converter. They are not a float/integer scaling error introduced by `save_counts` or H2.

| Selected case | O1 rail samples | Runs | Longest run | O0 rails |
|---|---:|---:|---:|---:|
| Original ABA1 | 32 | 7 | 7 samples / 0.4375 ms | 0 |
| Retry ABA1 | 95 | 12 | 12 samples / 0.75 ms | 0 |
| Tagged nonspeech | 4,366 | 4,076 | 4 samples / 0.25 ms | 0 |

The two speech cases have negative-rail plateaus. None falls in the first 0.5 seconds of the scheduled source-file support after the common offset and descriptive output delay; all are within later support. This does not make the signal independent of initial AGC state or establish exact phonetic onsets. First rails occur at decoded-output times 4.22894 and 3.73956 seconds. No stage-internal state is observable enough to identify the precise saturation arithmetic. The nonspeech stress fixture is kept separate from speech conclusions.

The local user guide v3.2.1 section 4.2.6 (printed pages 35–36) says AGCGAIN is the initial/current multiplicative gain, DESIREDLEVEL is target power on the free-running beam, MAXGAIN caps adaptive gain, and AGCONOFF only enables adaptation. Gain still applies when adaptation is off. The guide discourages changing time constants. The command map `control_commands/shf_pp_cmds.yaml` lines 104–124 defines LIMITONOFF and LIMITPLIMIT, whose units are power. A power limiter is not a guaranteed per-sample ceiling at the square root of that value.

Bounded candidates for the root coordinator's calibration, not measured prescriptions:

1. Keep adaptive AGC and all time constants; reduce limiter power 6 dB from 0.47 to `0.47 * 10**(-6/10) = 0.1180586621`. Inspect actual remaining rails and speech level on identical nominal and ±6 dB scenes.
2. Only if the first is insufficient, reduce desired power by 6 dB from 0.0045 to `0.0011303489`, and reduce the frozen maximum/initial multiplicative gains by 6 dB (`125 * 10**(-6/20) = 62.6484042`) while keeping the first limiter change and existing time constants. Report this composite alternative honestly; do not infer individual parameter causality.

These are at most two justified alternatives to the inherited recipe, not an open sweep. The task coordinator must choose from the measured calibration evidence, freeze the exact final recipe, and report any residual O1 limitation. Attenuating a saturated saved WAV cannot restore clipped samples.

## O0 scale and embedding gate

The unchanged `edge_speech_pipeline/audio.py` file reader takes float32, averages channels, then the journal clips/rounds to signed PCM16. S4 explicitly requires mono input, so this averaging is a one-channel identity operation. Reproducing that conversion yields a sample-for-sample match to both actual S3 PCM16 spools.

`runtime.py:360` applies `minimum_rms=0.002` (approximately −53.98 dBFS RMS) to each 0.25-second block before an embedding call, together with speech, no overlap and at least a 0.5-second rolling window. It does not gate ASR. The S3 O0 signal had substantial unused peak headroom and 26 of 90 single-speech hops were below this RMS gate; O1 had 8 of 90. Exact gate reconstruction gives all 64 and 82 observed successful embedding calls, respectively, with zero unexplained eligible or ineligible calls.

A single calibrated O0 host gain is justified as an adapter choice, leaving AEC_ASROUTGAIN at 1 and all scientific thresholds unchanged. Derive the scalar from nominal/±6 dB calibration peaks with a declared headroom margin; apply it once before H2 PCM16 journaling, preserve raw O0, and report any low-level speech still below the unchanged gate. Do not select a scalar from final transcript scores, equalize individual speakers, or call amplified quantization a recovered signal.

## Returning-speaker interpretation

The actual S3 mode is the independent-lane `edge_speech_pipeline` CLI file mode, accelerated by pacing at four times real time. Its `SpeakerTracker` has online cluster updates but no final cluster-merge/reconciliation stage. Other project modules with reconciliation do not establish that this mode uses them. `runtime.py:402` labels each transcript event from the latest concurrently available speaker state, not a word- or utterance-aligned identity. Source-time differences between the last preceding logged decision and final ASR cursor were −1.4 to −1.95 seconds in the paired S3 smoke sessions. This is a log-based association diagnostic; thread interleaving prevents treating the last preceding log line as proof of the exact locked state snapshot in every case.

| Stream | Original emitted final labels | Dominant cluster for A1 / A2 | Clusters represented in A1 / A2 |
|---|---|---|---|
| O0 | Speaker_1, Speaker_4, Speaker_12 | Speaker_1 / Speaker_1 | 2 / 8 |
| O1 | Speaker_2, Speaker_15, Speaker_16 | Speaker_1 / Speaker_1 | 6 / 8 |

The dominant clusters use only complete 0.5-second embedding windows contained within one scheduled source-file interval after the stated common offset. Both streams retain the original A cluster as the most frequent cluster when A returns, while exhibiting substantial fragmentation. Thus the three emitted labels alone overstate the claim that A never reconnects to the original cluster. No DER, enrollment naming accuracy, full identity continuity, or reliable utterance attribution follows from these observations.

S4 now has analysis that keeps original emitted labels, absence of reconciled labels, underlying decision counts, source-window evidence, missing/tied return evidence and fragmentation separate. This is an interpretation/measurement correction with a limitation, not a repaired H2 recognition model. No demonstrated integration defect warrants retuning or changing the concurrent label policy in S4.

## Evidence and remaining S4 use

`S3_OFFLINE_H2_HEADROOM_AUDIT.json` includes consumed native file hashes, exact converter equality, rail runs, and compact H2 gate/continuity findings. `O0_s3_analysis.json` and `O1_s3_analysis.json` preserve fuller event-derived metrics. The latter also contain development-only historical S3 WER/CER calculated with the explicit S4 scoring normalization; they are not a matched final S4 output comparison or an output-selection result.

The coordinator still needs final calibration captures, frozen level policies and all S4 H2 executions. Reuse the parser on those new sessions with actual per-case alignment; retain overlap LIMITED and empty-reference insertion rates. Keep S5 output selection and S6 cue fusion decisions open.
