# S4 source and scene handoff component

The final 24-scene bank genuinely uses **Common Voice 26.0 (`cv-corpus-26.0-2026-06-12`), English**. All newly scheduled speech comes from six contributor IDs that were absent from the existing 413-contributor Common Voice speaker protocol. The adapter excluded all 413 historical IDs, preserving their earlier known/calibration/evaluation assignments.

Actual source directory:

`C:\Users\amiri\Documents\GitHub\just-peachy\Software Validation from Datasets\Raw Datasets (Not formatted)\Common Voice\cv-corpus-26.0-2026-06-12\prepared\en`

The release's local `metadata\original\README.md` identifies the English release, describes `client_id`, `path`, `sentence`, `locale` and optional demographic fields, and supplies CC0 terms with a restriction against determining speakers' identities. Its bytes match the pre-existing materialization receipt. This local materialization was selected using self-reported sixties, seventies, eighties and nineties labels; it is a **60+ metadata subset**, not a population-balanced or conversational-speech sample. Accents remain descriptive self-reports or unknown. No other corpus or downloaded source was used.

## Actual contribution and split

| Item | Final count |
|---|---:|
| Development contributors | 6 |
| Probe clips prepared | 24 |
| Unique probe clips actually scheduled | 23 |
| Unique scheduled dry-audio duration | 109.608 s |
| Scheduled utterance instances across the bank | 64 |
| Total scheduled whole-clip duration, counting reuse | 300.636 s |
| Separate enrollment candidates, unused by S4 | 6 |
| Downstream reserve | 3 contributors / 9 clips |
| Unused development probe | B4, `common_voice_en_18838753` (3.960 s) |

Reserve contributor assignments were frozen before waveform QC and before S4 device/model outputs. Enrollment candidates never become probes; unused B4 remains development material and is not relabeled as reserve. The 39 selected clips have unique source-byte and decoded-PCM hashes. Their contributor, transcript, sentence ID, locale and votes were independently checked against the actual native `validated.tsv`, rather than relying only on its derived SQLite index.

Contributor IDs are working corpus identities, not biometric proof that different accounts belong to different people. The release-independent pseudonym scheme groups the same known contributor ID without identifying a real person. Exact selected-byte/PCM deduplication does not establish whole-corpus near-duplicate freedom. Neither a new local split nor a newly selected contributor establishes absence from model pretraining.

## Preparation, quality and geometry

The bounded shortlist decoded 40 MP3 clips and accepted 39; one failed the minimum estimated activity check. Preparation retains complete transcripts and whole clips, resamples once to mono 16 kHz FLOAT32, and applies the frozen scalar once before convolution. The numerical rule is `min(10^(-24/20)/active_rms, 0.5/peak)`, rejecting a requested RMS boost above 12 dB. Activity uses 20 ms frame RMS with a threshold of the larger of −50 dBFS and the frame 95th percentile minus 25 dB. Peak limiting can leave active RMS below target. The final whole-bank headroom scalar is **1.0**. No RIR or per-microphone normalization, second distance law, extra acquisition gain/delay, source EQ or second reverberation is applied. These are numerical source levels, not calibrated acoustic SPL.

Four initial A/B clips received a visual waveform/envelope review. They had no samples at absolute amplitude ≥0.999, estimated quiet suffixes of 0.492–1.456 s and final 300 ms RMS levels from −54.33 to −68.06 dBFS. Small pre/post impulses remain visible. This is **not an auditory review or an anechoic/dryness certificate**: source room, microphone, codec and possible residual background-voice conditions remain uncalibrated. Quiet suffixes are source-file margins, not measured RT60. Activity ranges remain estimates for preparation/scoring and never enter H2 as truth.

The bank uses 17 eligible RIRs across four non-Upper-Loeb settings, with distances **0.65–4.07 m**. It uses no RETAKE, earlier testing, excluded Loeb Caf, or deferred low-table R13 recording. Every selected signed angle matches its canonical effective source label. The ±5° field describes manual source-position uncertainty, with user-reported authority and `independently_calibrated: false`. The full interval is wrapped/folded under the nominal MIC0-left/MIC3-right transform; device native estimates, validity, nominal error and interval-aware error stay separate. Front/rear ambiguity and uncalibrated geometry remain explicit. There is no default ±5° device-accuracy gate.

## Final scene review and limits

The current bank is `simulation\scene_bank\s4_v2_20260909T002140Z`; its `SCENE_MANIFEST.json` SHA-256 at this handoff review is `06b2157ed59a6ea87282501e67fcf940616ec14e1a213fbb3ff3ef1bf8529a40`. Independent review of all 24 current scene records verified source-to-participant identities, whole-clip lengths, transcripts, eligible paths and separate reserve/enrollment roles. The final manifest records finite FLOAT32 renders, round-trip equality, identical regeneration and the identical noise component in scenes 23/24.

- Scene 20 now has near/distant competing speech: E at 0.65 m and F at 4.07 m, with 1.848 s of scheduled whole-clip overlap. Scheduled overlap is not exact phonetic overlap.
- Scenes 13/14 compare close/separated folded directions **and measured path/distance changes**: 1.00/1.02 m versus 0.80/0.76 m. They cannot isolate angular-separation effects.
- Scene 7 uses complete 3.048–3.996 s replies. Subsecond yes/no behavior is outside this coverage.
- Flat/upright and clear/obstructed pairs preserve their respective measured angle/distance assignments and remain grouped for split claims.
- Upper Loeb stays included as downstream reserve; it was already examined during RIR extraction and is not an unseen test of the RIR method.

The prior review draft remains in `pre_review_archive_2026-09-09T003742.458634_0000`; the final scene-20 WAV is the explicitly bound `S4_20_mic4_review_57e68f8d506b.wav`. Consumers must follow the manifest's canonical path, not infer filenames or revive the superseded draft.

Nine source-adapter regressions and seven geometry regressions passed. `SOURCE_ISSUE_CLOSURE.json` binds the relevant manifests, source QC, native-row verification and review evidence, with FIXED or LIMITED dispositions. This component makes no claim about physical-output quality, H2 scores, an output winner, cue-fusion benefit or overall S4 completion. Exact run commands are in `simulation\scripts\README_S4_SOURCES.md`; root-level S4 documentation governs bank generation and hardware execution.
