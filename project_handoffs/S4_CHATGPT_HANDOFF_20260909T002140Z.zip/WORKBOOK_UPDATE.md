# Proposed V8 workbook update — S3/S4

For human review and light-yellow insertion into the master S3/S4 planning/results sections. The master `XVF_Measurement_V8.docx` in Downloads was not edited. These paragraphs summarize completed run `20260909T002140Z`, status **S4_COMPLETE_WITH_LIMITATIONS**; the detailed evidence, methods and limitations remain in `S4_REPORT.md`, `S3_ISSUE_CLOSURE.json` and the compact handoff. All 24 canonical cases, two nominal repeats and 48 H2 jobs are complete, with zero mandatory omissions.

## Suggested S3 closure paragraph

S4 reused the demonstrated S3 physical transport and closed the necessary integration issues inside a bounded development run. It preserved the six-channel near-end microphone injection, bit-transparent PCM24 transport and simultaneous O0/O1 capture. The continuous logger now records both selected directions as well as all AEC angles and energies, preserving request/response/receipt times and no-speech validity. A causal adapter invalidates missing, late or stale spatial data while audio/text continue. An early decimal/float32 setter round-trip issue was recovered using a bounded adjacent-float input and exact original getter readback; both the failure and recovery are retained. A separate spatial-analysis defect that added the retained 50-ms RIR convention twice was repaired and regression-tested before final scoring. These repairs do not establish an internal DSP timestamp or identical hidden adaptive state.

The manual ±5° uncertainty describes the loudspeaker's entered position label. It is not a device accuracy requirement. Original signed angles and the complete wrapped/folded label interval remain separate from the device observations and scoring policy. The nominal linear-array transform retains front/rear ambiguity.

Four H2 invocations completed inference but left empty summaries during a documented CLI/daemon shutdown window. Their completion journals, console events, full PCM16 input spools and final transcript rows agreed. Explicitly derived summaries were recovered from those primary artifacts after preserving the empty originals and failed receipts: S4_18/O1, S4_20/O0, S4_20/O1 and S4_24/O0. The final evidence therefore has 44 native summaries and four derived summaries. No model rerun or baseline-source change was made. The original export race remains a baseline limitation; successful inference and durable result export are reported separately.

## Suggested S4 bank and execution paragraph

The S4 bank contains 24 deterministic development scenes totaling 12 minutes 6 seconds, using 17 eligible RIRs from four non-Upper-Loeb settings at 0.65–4.07 m. RETAKE, early testing, excluded Loeb Caf and deferred low-table R13 paths remain excluded. The canonical 121-record RIR library was not regenerated; Upper Loeb remains downstream reserve but is not unseen validation of the RIR method.

All speech comes from locally present English Common Voice 26.0, a prepared self-reported 60+ subset. Six development contributor IDs supply 23 unique whole clips and 64 scheduled utterance instances. Separate enrollment candidates and three reserve contributors remain unused. Source and native transcript/identity bindings were checked. Numerical and limited visual source QC do not certify anechoic speech, real-person identities, unseen model pretraining or representative population coverage.

All 24 canonical scenes and two nominal repeats have accepted captures. The 40-pass cap includes 12 calibration passes, one tagged transport regression and one preserved telemetry-only failure followed by an unchanged successful retry. Active playback totaled 19 minutes 58 seconds. The accepted bank recovered 45,747,300 compared microphone samples with zero differences; all physical attempts together recovered 75,470,288 with zero differences, marker errors or callback flags. Digital silence has zero recaptured microphone-channel payload, with its unique source/capture offset explicitly unidentifiable; the processed O0/O1 outputs retain tiny nonzero numerical values. The hardware returned to its starting exposed settings/USB width, with packed input off and owned handles closed.

## Small result table for insertion

| Result | O0 | O1 |
|---|---:|---:|
| Final host input gain | +3 dB, applied once | 0 dB |
| Final raw peak | 0.169733 FS | 1.000000 FS |
| Rail samples, 24 final captures | 0 / 11,499,048 | 61 / 11,499,048 |
| Captures containing rails | 0 / 24 | 11 / 24 |
| Maximum contiguous rail run | 0 samples | 7 samples |
| Completed H2 jobs | 24 | 24 |
| WER, same 18 non-overlap scenes | 72 / 467 = 15.42% | 91 / 467 = 19.49% |
| CER, same 18 non-overlap scenes | 210 / 2,249 = 9.34% | 241 / 2,249 = 10.72% |
| Silence/noise inserted words | 0 | 0 |
| Return checks: consistent / inconsistent / unknown | 8 / 8 / 6 | 7 / 11 / 4 |

Whole-transcript word errors comprise substitutions/deletions/insertions of 48/18/6 for O0 and 61/25/5 for O1. Four overlap scenes retain LIMITED ordinary WER scoring. Return checks are dependent source-window observations and unknown can include tied dominant labels; they are not full diarization error rate. Multiple clusters appeared in 55/60 O0 and 54/60 O1 scored reference turns. The unchanged embedding RMS gate excludes some quiet single-speech hops, while observed eligible/decision bookkeeping agrees exactly. These results identify useful development contrasts and continuity limitations, without choosing an S5 output winner.

The frozen dry-source preparation targets estimated active RMS −24 dBFS with a 12-dB boost cap and 0.5-FS peak cap before convolution; the bank headroom scalar is 1. No RIR/per-microphone normalization or extra distance law was applied. The matched nominal/−6/+6 dB calibration reduced observed O1 rail counts from 320 to 41 to 17 across the baseline and two bounded alternatives, each over 1,521,381 samples. The chosen limiter/AGC recipe retains residual saturation; it is the lowest observed rail count of those alternatives, not a proven optimum. O0 gain was derived from calibration headroom before final capture without H2 scores.

Across 51 turns from scenes without overlapping speech, selected-processed indication coverage is 83.75%, expected coarse-sector occupancy is 52.88%, and sustained matching is observed in 33/51 turns. These are dependent descriptive supports and a nominal coordinate relation, not calibrated direction accuracy or person tracking. Noise-only input produces positive indications, and the final noise-only telemetry gap is invalidated by the 250-ms causal age policy. First hits, sustained acquisition, held/wrong sectors and censored cases are reported separately. Zero off-delay can mean already invalid or wrong, rather than fast release.

Returning A2 never reacquired the expected selected sector in the nominal capture or either repeat. Independent raw-reply analysis reproduced the nominal first-hit/occupancy results. This measured limitation prevents treating a selected beam as a reliable person or turn identity.

The measured 48-process H2 wall time totaled 11 minutes 6.626 seconds, including startup and export overhead rather than pure model compute. At the closing resource review, total task elapsed time was 1 hour 47 minutes 27 seconds, generated artifacts used about 1.73 GiB and C: retained 72.26 GiB free; both SSDs reported Healthy/OK. The validated run manifest and package receipt record the later final timing/storage values. All device restoration checks passed, with the early exact-recovery exception preserved.

## Figure captions

**Figure 1 — Frozen numerical headroom decision and final outputs.** Matched cases 01/02/03 retain identical microphone inputs across three documented recipes. Lower observed rail counts motivated the final recipe; residual O1 rails remain a limitation. O0 uses one fixed host scalar. These level diagnostics do not choose the recognition-output winner.

**Figure 2 — Paired unchanged-H2 development results.** Per-scene and pooled whole-transcript errors use valid non-overlap references. Overlap cases have no ordinary WER claim; silence/noise use empty-reference insertions per minute. The cohort is small and dependent, and the plot does not establish a population ranking or S6 fusion benefit.

**Figure 3 — Nominal A→B→A and two repeats.** Selected-processed and raw-auto directions use actual host receipt/callback availability, with the full folded manual source interval shown for reference. Gaps represent unavailable cues; no future interpolation or truth-fitted timing shift is used. Repeated traces show that equal exposed initialization does not guarantee identical adaptive behavior.

## Planning consequence

S4 supplies frozen, reusable inputs and paired physical outputs for a later S5 comparison, subject to its explicit limitations. A later S6 study must test whether causal angle/energy cues improve the unchanged memory-based H2 baseline; a beam ID or known seat must not be substituted for a person's identity. No output winner, enrolled-name accuracy, full DER, exact live-caption latency, production motion policy or CM5 qualification is established here. Do not start S5 or S6 automatically from this update.
