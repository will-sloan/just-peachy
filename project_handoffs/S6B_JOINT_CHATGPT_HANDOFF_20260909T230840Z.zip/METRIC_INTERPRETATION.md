# How to read the S6B evidence

The unit of comparison is a named profile, a physical output recipe and a fixed synthetic scene. Reusing the same audio, speaker source, RIR or telemetry does not create an independent trial. The challenge panel is a deliberate augmentation of the S6A panel using existing source metadata; the full bank is reused engineering evidence. Neither is external real-human validation.

S6B `Bxx` IDs name full prediction profiles; `Rxx` IDs name shared native neural recipes. B00 is the exact historical B0 result. B36 is the legacy anonymous tracker under the common scheduler. B01 is the new bounded voice/time parent. R0 is the original-setting neural recipe and is not itself B0. Stage prefixes matter: the S6A reference tracker called R5 is different from S6B's R5 event-cadence neural recipe. The seed-ID mapping and final effective registry preserve these distinctions.

## Populations and denominators

Each full profile/tap contains 240 scenes and 777 deliberate speech-source occurrences. The four disjoint scene populations are 156 complete-reference non-overlap scenes (4,560 words), 47 complete-reference overlap scenes (1,456 words), 26 incomplete ambient/target-only scenes (683 designated target words), and 11 strict-empty scenes. Primary word error and character error, overlap MIMO error, ambient target error and empty inserted words per minute have separate denominators. The incomplete ambient rows do not assert a transcript for unrecorded environmental speech.

Complete-reference attributed text pools 203 scenes and 6,016 words. Its permutation maps anonymous speaker streams for evaluation; it does not enroll or recognize a person's name. A lower concatenated-permutation word error rate (cpWER) can coexist with more unknown speech, inconsistent returns or conflated identities. The one-person and all-unknown controls show this failure mode. No single weighted score determines the shortlist.

All 40 complete-reference subsecond source occurrences, located in nine scenes, stay in scope. These are 40 turns, not 40 independent scenes. The complete 1–<2-second population has 34 turns in seven scenes. The challenge includes all 40 subsecond turns but only 20 of the 1–<2-second turns. Source waveforms still reach ASR even when identity evidence is rejected.

## Three attributed-text views and event history

All three cp views use the same final recognized words. `cp_first_display_label_final_words` applies the first nonempty displayed label to those final words; it is a label-stability diagnostic, not the lexical accuracy of the first partial transcript. `cp_first_final` uses the immutable label at first finalization. `cp_latest_revised` uses the actual subsequent label state after observed ASR updates and forward correction messages. A later fix never receives credit at the earlier time.

Normal partial-display changes and bounded reconciliation are different operations. Stable utterance IDs, original and replacement labels, source evidence IDs and decision times support the event audit. Historical B00 has no new S6B event history, so unavailable revision/exposure fields remain unavailable rather than zero measured harm. A final label snapshot is not a diarization error rate (DER) timeline.

Correction exposure uses source-support-based anonymous identity mapping and observed retained-row state duration. It is not word-aligned harm or the amount of audio newly spoken during a correction. Longer retained text rows can accumulate exposure during later silence. A source participant can receive another anonymous identity's attribution; distinct wrong-attribution recipients and missing/ambiguous mappings are reported. Different ASR endpoint grouping changes retained-row denominators, so raw exposure seconds alone do not rank different recipes fairly.

## Identity and short-turn support

Unknown support and mixed/conflated support use the same sole-active-source sample denominator. `false_merge_samples` is the inherited name for support conflation; it is not a count of structural tracker merges. Track creations, prototype additions, association revisions, rejection and rollback are separately observed mechanisms. The delayed graph issues forward association revisions and does not implement structural merge/split operations.

Return consistency partitions complete-reference repeated-speaker groups into consistent, inconsistent and unknown. The full bank contains 292 such groups per tap. Reducing unknown groups while increasing inconsistent groups is a tradeoff, not an unqualified success. Duration-based identity mappings retain modal ties, unknown and unmapped cases; ambiguous alternate assignments are not silently counted correct.

A short reply can have (1) an embedding whose full waveform window is contained in the source turn, (2) any known anonymous label support, and (3) a duration-mapped correct modal label. These answer different questions. Wait quantiles report observed and missing/never-successful counts. A quantile computed from successful cases alone must not conceal the cases that never acquire usable identity evidence.

Processed embedding-window seconds include overlapping work. Unique source seconds are a union; disjoint admitted observations earn independent commitment credit only when their sample support does not overlap. A one-second window may span two people or erase a short clean turn despite producing fewer vectors. The fixed ten-second Pyannote graph still runs when its host stride changes.

## Cue, condition and uncertainty limits

XVF direction is an observation, not reference truth. The delivered coarse sector matches expected complete non-overlap support only about 45% of the time. Numerically stable but wrong direction is not proof that the DSP is stale. Native folded 0–180-degree bearings are linear: the two ends are opposite, while front/rear remains ambiguous. Manual ±5 degrees describes measurement labels only; no thresholds were fitted to corrected source seats.

Room, corpus, source quality, level, pose, obstruction and noise/SNR strata preserve their source-defined memberships. Multi-corpus or multi-level scenes may appear in more than one stratum; do not sum overlapping memberships. Real-noise event-window adaptation retains known target provenance and does not infer unknown environmental words.

Paired deltas use matching scenes and denominators. Equal-room summaries are distinct from pooled word-weighted summaries. Conditional grouped bootstrap intervals and dependency deletion sensitivity describe this reused finite bank. In the challenge cp analysis, the all-paired point contains 37 scenes/953 words, but the eligible matched-block bootstrap subset contains 27 scenes/653 words; its interval belongs to its own subset point. Crossed dependency closure connects all 203 complete-reference bank scenes, preventing an independent-population interpretation.

## Performance and operating ranges

The common replay clock is modeled causal availability from source time plus observed upstream work. It removes CPU race ordering from matched tracker comparisons; it is not measured device/display latency. Native accelerated cost, replay policy cost, cold model loading and paced full-engine observations remain separate. Nested stages and concurrent lanes must not be summed into wall latency, and replay policy cost must not be added blindly to a native engine cost that already includes a policy.

Paced probes retain all repetitions and both taps. Each cell is a fresh finite session; repeated cells are not a single uninterrupted endurance test. USS, process-tree RSS upper bound and Windows private commit are separate measures. One model thread setting does not imply one total OS thread. The bound asset files occupy about 209.59 MiB, excluding the OS, libraries, buffers and logs.

S6B tests named nominal settings and a small set of declared companions. It does not establish a numerical optimum or a continuous safe parameter range. The shortlist describes observed neighboring cells and failure boundaries; untested intermediate settings remain unvalidated. CM5 ARM64 speed, total 2 GB RAM headroom, 32 GB eMMC logging and deployment compatibility require later direct tests. No desktop-to-CM5 timing multiplier is used.
