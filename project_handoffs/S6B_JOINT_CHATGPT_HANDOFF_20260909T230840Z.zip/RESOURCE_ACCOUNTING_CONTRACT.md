# Resource interpretation for the S6B comparison

The production target is CM5 ARM64 CPU, 2 GB total RAM and 32 GB eMMC, with no wireless dependency. S6B executes on the existing Windows desktop using CPU providers. It does not qualify CM5 throughput, operating-system headroom, ARM package compatibility or sustained flash/logging behavior.

## Four distinct cost scopes

1. **Native recipe engine:** `costs.native_full_engine` measures the worker's process CPU and elapsed time from `start_file` through completed native finalization, including native journals, gates, canonical tracker/scheduler, resets, research export and EOF drain. It excludes subsequent cache extraction and separates resident-bundle admission/loading. These accelerated measurements are desktop observations, not physical display latency.
2. **Whole research job:** the receipt's `full_engine_wall_sec` and `full_process_cpu_sec` include the wider worker job, including startup/admission and evidence-cache extraction. Despite the inherited field name, this is broader than the native engine scope above. It is useful for campaign ETA and orchestration cost.
3. **Policy replay:** each candidate reports its own measured `policy_wall_sec` through the same application tracker/scheduler on cached arrived evidence. The canonical native recipe already ran a policy while collecting evidence; adding full recipe cost and replay policy cost blindly would count both policies. Keep these columns separate. Actual finalist paced runs measure the selected full pipeline directly.
4. **Paced finalist engine:** fresh per-scene state with a resident selected model bundle, source paced at real time, repeated whole cases, complete tails and explicit process/backlog/write trajectories. Model loading is separate. All repetitions are retained; no best repetition is selected.

Nested model, full-dispatch, postprocess, gate, endpoint and export timings overlap. Concurrent lane elapsed times are not additive wall latency. Process CPU can exceed elapsed time when threads overlap. Original B00 cached features alone provide no new full-engine timing; the new B00 paced probe supplies that measurement.

## Evidence work and sharing

Count each neural recipe/case/tap exactly once. Tracker-only reusers do not create additional model calls or physical recordings. Actual processed embedding-window seconds include overlapping work; unique admitted source seconds are a separate union measure. A lower call count is not a resource success if short speech or identity support disappears.

Pyannote retains its fixed ten-second graph. A shorter stride increases calls even when ReDim calls fall. N05's implemented global voice-observation-age floor supplies admission opportunities while preserving purity/RMS/overlap constraints; it does not guarantee a successful embedding every floor interval or implement the seed's full per-track priority queue.

Processed XVF telemetry is shared once per physical scene. Both output recipes and many policies may use the same trace. Repeated cache replay does not multiply physical telemetry coverage or source independence.

## Memory, workers and storage

The research coordinator uses at most four resident model workers and checks at least 16 GiB available host RAM, a 40 GiB process-tree RSS research ceiling, at least 50 GiB free on C:, at least 75 GiB free on G:, and a 120 GiB new-run output cap. Read-only scoring/audit processes are separate from the neural pool and remain small relative to the measured reserves. The observed process-tree scope is reported rather than called total system consumption.

USS, RSS-sum upper bound and Windows private commit have different meanings and are reported separately. A multi-recipe worker can retain allocator memory after a model configuration changes; that research-pool footprint is not automatically the memory required by one deployed profile. Paced probes report startup/end trends and peak values. Setting each numerical model pool to one thread does not set the process's total OS thread count to one.

The eight bound asset files total **219,771,544 bytes (about 209.59 MiB)**: Giga int8 encoder, fp32 decoder, int8 joiner and tokens; int8 punctuation model and BPE; ReDimNet2-B2 fp32; Pyannote segmentation 3.0 fp32. This is only asset-file storage. Python/runtime libraries, the OS, live buffers, journals and research logs are additional and are not included in that total.

The working SSDs were checked as healthy/OK and actual free space is sampled during execution. Large regenerable native evidence goes to G:. Compact scores and reports stay in the fresh S6B namespace. No historical evidence is deleted. Research event/posterior export and raw journal growth are measured by the paced probe; a 32 GB production logging policy remains an explicit later engineering question.

There is no Ryzen-to-CM5 multiplier, GPU acceleration claim, hidden swap allowance or real-human generalization claim. Methods remain opt-in research candidates until the observed accuracy/coverage/resource limits and later device tests support a promotion.
