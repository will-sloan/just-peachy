# S6B joint H2/XVF comparison

Run `20260909T230840Z`. **S6B_COMPLETE_WITH_LIMITATIONS.** The current Word master remains `XVF_Measurement_V15.docx`; this report does not edit it.

## Question and scope

S6B compares actual component settings and incremental anonymous speaker association on the existing 240 synthetic scenes, using both physically captured XVF output recipes. It asks which combinations deserve a later parameter study, with word accuracy, attributed text, identity coverage, short replies, returns and resource work assessed together. It does not estimate performance on new people or rooms, enrolled name recognition, production readiness or CM5 timing.

The inherited measurements and canonical RIRs were reused. Only PASS/REVIEW measurements are eligible; early testing and RETAKE records remain excluded. The two user-corrected 100 m entries remain 1.00 m in the validated overlay, with raw metadata preserved. Eligible distances are 0.46–4.07 m. Manual angle signs are internally consistent within the available records, not independently physically calibrated. Folded native direction is front/rear ambiguous, and 0° and 180° are opposite ends of its coordinate. See `INHERITED_MEASUREMENT_CONTEXT.md` for counts, provenance and the limits of the acoustic evidence.

CMU Arctic, HiFiTTS and Common Voice remain the speech sources. No L2 Arctic, new corpora, audio downloads, RIR generation, physical playback, firmware operation or new recording occurred in S6B. O0 receives +3 dB exactly once; already-gained adapters are read at unity. O1 remains unity except in explicitly separate lower-gain challenge recipes. Shared telemetry is one trace per physical scene, reused across taps rather than counted as independent observations.

## What was built and exercised

There are 44 named configurations: 27 main methods, nine companions and four controls within the 40-profile core, plus four disclosed challenge-only diagnostics. The 44-scene challenge panel augments the inherited 36 scenes and includes all 40 complete-reference subsecond utterances. All eight required families and 16 planned interaction contrasts have executed. Eight conceptual neural families expand into 18 exact neural recipes; the planning families are not cache identities. The candidate registry records seed IDs, implementation changes, controls and effective settings.

The challenge completed 1,584 native outputs and 3,872 profile predictions. Full confirmation completed six exact neural recipes across 240 scenes and both taps: 2,880 native outputs supporting 29 profiles and 13,920 predictions. This is not 13,920 independent neural runs. Across overlapping campaign indexes, there are 3,936 unique epoch 2 native jobs and 15,240 unique predictions: 13,920 full-bank predictions plus 1,320 additional challenge-only predictions. The final full inference invocation reused 920 completed outputs and ran 1,960 new ones. Its wall time was 3,748.532 seconds; combined causal replay took 325.274 seconds. Neither figure is per-profile real-time latency.

Closed-worker accounting found 3,936 physical attempts for those 3,936 logical jobs, no repeated logical attempts or recorded failed neural attempts, and 117 observed cumulative resident-bundle loads across 20 worker identities. Four successful first-pilot jobs lacked fresh coordinator status rows after a persistence fault; their durable worker receipts and later reuse rows are reconciled explicitly. Index references are deduplicated rather than counted as cache-hit executions. Seven initial neural smoke sessions, one prospective B34 repair session, 112 model-free pilot materializations and the later paced study remain separate scopes.

The methods include simple direction rules, reliability and angular innovation, folded-bearing uncertainty, dual voice/location memory, dormant re-entry, multiprototype voice state, quarantine, a bounded Bayesian hypothesis filter, HSMM continuity, bounded global assignment, delayed association revisions, evidence escrow, sensor conflict quarantine, and endpoint advice. Neural comparisons vary supported segmentation postpolicy/stride, contiguous embedding duration and cadence, RMS support, fixed gain, and supported Sherpa decoder/dispatch settings. No model weights or frontend contracts changed. Pyannote still consumes its fixed ten-second graph input, and ReDim produces the inspected 192-dimensional vectors.

Several labels require restraint. Bayesian/HSMM scores use specified heuristics, not calibrated probabilities. The delayed graph implements forward association corrections; it does not perform structural track merges/splits. Rollback and sensor recovery are tested paths whose final bank activation can be zero. Endpoint advice generated proposals, accepted advice and rate limiting on the challenge, but the circuit-open path did not activate there. An activation count establishes execution, not an accuracy benefit. `METHOD_FAMILY_COVERAGE.csv` and compact mechanism summaries distinguish these cases.

The global-assignment alternative is a bounded beam over sequential evidence groups, allowing appropriate reuse of an anonymous person across groups; it is not an offline oracle or a rule forcing one different person per observation. Short-plus-long evidence required a disclosed prospective repair from an unreachable 0.5 s clean gate to 0.45 s; its first zero-vector smoke remains preserved. B20's hop was corrected to 0.25 s before any authoritative epoch 2 campaign inference so the duration contrast would not silently change hop. The frequent/sparse/event cadence screen measures actual work, but does not establish exact equal CPU budgets. No continuous parameter neighborhood was calibrated in B.

The real application gains opt-in profile and runtime hooks. The common incremental tracker and scheduler used in replay are the same implementation imported by native runtime. Default GUI profiles were not promoted. Historical B00 remains a frozen implementation, while B36 is the original tracker under the new common scheduler. Source-level guards and legacy tests support preserved legacy algorithm branches; added instrumentation does not prove blanket GUI timing or concurrency parity. Explicit asset paths are required when running copied application snapshots. `RUN_PROFILE_README.md` supplies tested profile validation, PowerShell/CMD commands, inputs, outputs and safe rollback.

The eight required mathematical families are distinct from the eight numbered extension proposals N01–N08. Four numbered extensions are implemented: N01 sensor-credit quarantine, N03 evidence escrow, N04 bounded endpoint advice and N07 the two-budget reconciliation ledger. N05 is a narrower adaptation based on global age since admitted voice observation and event cadence; per-track unique-deficit ranking and service quotas are not implemented. N07 skips exhausted/over-age reconciliation and keeps the latest label, rather than forcing Unknown as the seed proposed. N02 cue-driven trailing-context refresh, N06 a clipping-transition prototype freeze and N08 an independent clean shadow gallery are explicitly not implemented. Fixed-stride posterior experiments, gain/RMS controls and initial-state cue-off parity do not substitute for those three extensions. Their omission is not evidence of dominance or duplication. The N01–N08 status table records these limits alongside actual activity.

Six exact recipes were admitted for full confirmation. Every listed embedding duration is a supported contiguous waveform window, not a feature mask; segmentation stride, host dispatch and endpoint durations describe different operations. Host dispatch is not Sherpa's internal encoder chunk.

| Recipe / profiles | Segmentation stride and postpolicy | Embedding window / cadence | Sherpa / RMS |
|---|---|---|---|
| R0 / B00–B15 and specified tracker controls, B30–B33, B36–B38 | 0.75 s; hard-argmax fraction | 0.5 s / fixed 0.25 s hop | Greedy, 100 ms dispatch; dispatch-block RMS |
| R1 / B16, B17 | 0.5 s; posterior hysteresis | 1 s / fixed 0.5 s hop | Greedy, 50 ms; endpoints 1.6/0.8/20 s; dispatch-block RMS |
| R5 / B24 | 0.5 s; hard-argmax fraction | Early 0.5 s then 1 s; event cadence 0.25/1 s, voice opportunity floor 0.75 s | Original greedy/100 ms/endpoints; dispatch-block RMS |
| R5_CUES / B25 | Same R5 graph/postpolicy | Event cadence with cues plus adaptive tracking; this is a joint bundle | Original greedy/100 ms/endpoints; dispatch-block RMS |
| R7 / B28 | Original 0.75 s hard policy | Original 0.5 s / 0.25 s | Modified beam search with two paths, 50 ms; original endpoints/RMS |
| R0_FULL_RMS / B35 | Original | Original | Original, except full-window RMS gate |

Original endpoint settings are 2.4/1.2/20 s. B00 is read from historical outputs rather than instantiated as a V2 profile. B17 is the tuned component recipe with tracking cues; B16 is its cue-off companion. In particular, R5 is not posterior segmentation or the tuned R1 ASR recipe, and B25 versus B24 cannot isolate tracking cues from cue-dependent cadence. The registry is authoritative for every field and the complete set of R0 policy IDs.

## Fairness, causality and attribution

The main ranking uses deterministic causal replay of genuine neural outputs. Each observation carries audio support and measured upstream computation; decisions receive it only after declared availability. Equal-time ordering, expiry and budgets are common to matched policies. This removes a native worker race from tracker comparisons while retaining model context and buffering. Its time axis is modeled availability, not measured desktop or CM5 latency. Native paced probes provide separate scheduling/resource evidence.

Changed actual audio, embedding windows, segmentation or stateful ASR settings trigger the corresponding real inference. Tracker-only policies replay compatible cached observations through the actual incremental module, with policy computation recorded. Exact audio/config/model/provider/context/state and code identities govern reuse. Per-scene state resets; resident workers reuse loaded model sets. Cache references, durable inference jobs, validation materializations and paced outputs are counted separately in `CACHE_AND_INFERENCE_COUNTS.json`.

First-display label, first-final label and latest forward-corrected label remain separate. First-display cpWER uses final recognized words with the first readable label: it is not word accuracy of the first partial. Later corrections receive their real decision times and never repair the earlier metric retrospectively. Labels are anonymous associations, not enrolled people. No snapshot metric is called DER. `SCHEDULER_AND_REVISION_CONTRACT.md` defines the two lanes, priority, deadlines, label expiry, revision horizon, storage bounds and failure behavior.

Actual-entry-point tests cover changed future, renamed truth, forbidden truth schema, cue-disabled parents, telemetry faults, cache invalidation, short text retention and complete EOF delivery. The final immutable pilot validation and its index-lineage resolver preserve earlier failed persistence attempts without regenerating successful inference. Execution faults involved JSON persistence/read observations and a corrected analysis event selector, not score-driven retries. The later null-padded live-status observation has retained byte evidence but an unproven underlying cause. See `EXECUTION_FAULT_LEDGER.md`, its V2/V3/V4 paced supplements, and the compact independent validation summary.

## Populations and interpretation

Each tap has 156 complete non-overlap scenes with 4,560 reference words; 47 complete overlap scenes with 1,456 words; 26 incomplete ambient-target scenes with 683 known words; and 11 strict-empty controls totaling 491.6498125 seconds. Complete-scene cpWER covers 203 scenes and 6,016 words. All 777 intended source occurrences remain in identity analysis, including all 40 subsecond complete-reference turns in nine scenes and 34 one-to-under-two-second turns in seven scenes. Return analysis has 292 complete repeated-speaker groups per tap.

Unknown and mixed support use the same sole-speech denominator. A known anonymous label is not automatically correct identity. Contained clean embedding evidence, any known label and duration-mapped label correctness are distinct short-turn outcomes. Source-duration mappings can be unavailable, tied or unmapped; these conditions are retained. Wrong-association exposure is modeled retained-row utterance-seconds and must be read with observed exposure and unknown/unmapped time. It is not word-aligned harm or wall time. Structural track mutations are distinguished from support conflation and forward transcript corrections.

The one-person and all-unknown controls expose metric degeneracy: both can have the same cpWER while one merges every identity and the other abstains everywhere. A return becoming inconsistent instead of unknown is not an unqualified improvement. There is no single weighted score or forced winner.

All full-bank uncertainty is conditional on this reused synthetic bank. The 203 complete scenes enter 163 declared blocks in five rooms; the crossed source/RIR closure connects all 203 scenes, so no independent population generalization follows. Equal-room, source/corpus, quality, level, pose, noise and deletion summaries retain their actual denominators. Strata overlap. The challenge was designed after S6A and is not unseen validation. Challenge-only intervals cannot be attached to a different full-bank point estimate.

## Results and selection

Final combined core scoring is complete for 13,920/13,920 outputs, with zero unscored failures. All 45,066 intended turn outputs (777 × 58 profile/tap pairs) and 2,320 subsecond outputs (40 × 58) are retained. The R0 controls establish an important distinction: all 11,040 historical/R0-policy outputs preserve normalized words and lexical error counts. All 480 B36 lexical outputs match historical B00. Across 15,649 actual embedding vectors, spans, flags and legacy anonymous labels match; only ten of 480 arrays are bit-exact and maximum absolute numeric difference is 1.7136335372924805e-6. This is semantic/numerical parity, not byte parity.

B00 versus B36 attribution differences consequently cannot be described as an improvement in their clustering sequence. They reflect historical versus common-scheduler labeling/display conventions. New methods must be assessed against the matched common controls as well as historical context.

### Full confirmation and controls

Primary word errors are 656/4,560 on O0 and 705/4,560 on O1 for every R0 tracking policy: 14.386% and 15.461%. Tracking changes cannot receive credit for lexical improvements they did not produce. R1's B16/B17 pair has identical normalized words for all 480 matched outputs, with 657/4,560 O0 and 705/4,560 O1. The unchanged O1 pooled count does not mean unchanged word strings: S45_06_01 worsens by one error on both taps, S45_06_10 worsens by one on O0, and S45_12_17 improves by one on both taps. The experiment does not isolate a causal explanation among all R1 component changes from these three examples.

| Profile | First-final cp errors O0 / O1 | Latest cp errors O0 / O1 | First-display cp errors O0 / O1 |
|---|---:|---:|---:|
| B00 historical | 3,533 / 3,714 | 3,533 / 3,714 | 3,926 / 4,060 |
| B36 common-scheduler original | 3,662 / 3,773 | 3,668 / 3,741 | 3,691 / 3,780 |
| B10 dual memory with cues | 3,607 / 4,064 | 3,638 / 4,018 | 4,125 / 4,208 |
| B16 tuned voice-only | 3,627 / 3,734 | 3,644 / 3,778 | 3,821 / 3,865 |
| B17 tuned with tracking cues | 3,631 / 3,710 | 3,643 / 3,746 | 3,830 / 3,865 |
| B24 event cadence, voice-only | 3,592 / 3,812 | 3,552 / 3,848 | 3,886 / 3,919 |
| B25 event cadence and adaptive cues | 3,641 / 3,785 | 3,563 / 3,791 | 3,899 / 3,937 |
| B28 beam/dispatch voice-only | 3,737 / 4,008 | 3,739 / 3,979 | 4,083 / 4,081 |

Every cell in this table uses all 203 complete scenes and 6,016 reference words per tap. Lower is better within that metric; the three attribution times are not interchangeable. B10 improves first-final O0 relative to B36 by 55 errors but worsens O1 by 291; first-display errors worsen by 434/428. Its latest cpWER is identical per complete scene/tap to cue-off B09, even though some decisions/events differ. The cue contribution is therefore small and timing-specific, not a general dual-memory victory.

B36 retains 107/95/90 consistent/inconsistent/unknown O0 return groups and 88/108/96 on O1. B10 gives 2/96/194 and 2/87/203. Its mixed support is lower, but unknown support grows from about 21.5% to 29.6/31.4%, and its retained-row unknown/unmapped exposure is substantially larger. B16/B17 reduce the dual-memory abstention burden but do not recover B36's consistent returns. B17 has 44/108/140 on O0 and 51/112/129 on O1. All these return triples total 292; fewer unknowns accompanied by more inconsistent groups are not an unconditional benefit.

B36's all 40 subsecond turns have known support for 36/38 and a mapped correct modal label for 14/14 on O0/O1. B17 gives 31/35 known and 13/17 correct, with zero wholly contained admitted embeddings on both taps. A one-second evidence window cannot fit inside these short turns. This is a material coverage/latency constraint even when pooled attributed-text errors look favorable.

The 34 one-to-under-two-second turns in seven scenes also show a coverage tradeoff. B36 has contained evidence in all 34 turns on each tap and correct modal labels for 24/19. B17 has contained evidence in 26/27 and correct modal labels for 17/16; B25 has contained evidence in 23/22 and correct modal labels for 13/16. All three supply some known support to all 34 turns on both taps. Complete label presence therefore conceals differences in evidence and correctness even beyond the subsecond group.

Missing counts are retained alongside observed-case wait quantiles. For B17's 40 subsecond turns, contained-evidence wait is unavailable for all 40 on each tap. Its median time to any known support is nevertheless 0.04 s among 31/35 observed turns, with 9/5 never observed. This describes label support on the modeled source timeline, which may use neighboring evidence; it is not a fresh-voice recognition latency. At least some duration-mapped correct support occurs in 15/18 turns, leaving 25/22 without it; that criterion is different from the correct modal-label counts above. For B36, contained-evidence median wait is about 0.638/0.639 s among 31/33 observed turns, with 9/7 missing. Successful-case quantiles alone cannot establish short-reply safety.

The degenerate B37/B38 controls produce identical cp error counts, 4,312/4,360, while their behaviors are opposites. One-person B37 has 0% unknown, about 30.93% mixed support and all 292 returns classified consistent; all-unknown B38 has 100% unknown, 0% mixed and all 292 unresolved. These are diagnostic controls, not shortlist candidates. They demonstrate why cpWER and return consistency must be read with identity coverage and conflation.

### Event cadence, decoder and RMS tradeoffs

B24/B25 preserve original lexical error totals in all four scene populations. B25 versus B24 changes both cue-dependent cadence and adaptive tracking: first-final cp changes by +49/−27 errors and latest by +11/−57 on O0/O1. Relative to tuned B17, B25 is worse at first finalization on both taps (+10/+75), better in latest O0 (−80), and worse in latest O1 (+45). Its first-display counts are also worse by 69/72. This is a timing- and tap-dependent pipeline interaction rather than evidence that cues generally improve identity.

The event path restores some short contained evidence:8/9 of 40 turns on O0/O1, compared with 0/0 for B17 and 31/33 for B36. B25 has 35/36 known short turns and 13/14 mapped correct. Its return groups are 41/154/97 O0 and 39/160/93 O1, versus B17's 44/108/140 and 51/112/129. Much of the reduction in unresolved returns comes with increased inconsistency. These harms must accompany the improved latest O0 cpWER. B24 has a slightly better latest O0 point than B25 and remains its required voice-only companion.

The supported non-greedy B28 branch improves primary word errors from 656/705 to 635/700 out of 4,560 per tap. The lexical gain is real on this bank and is not a cue effect: B28's tracker is cue-disabled. Overlap errors change from 486/502 to 492/491 out of 1,456, while known ambient-target errors change from 202/205 to 200/209 out of 683. O1 strict-empty insertions rise from 2 to 19 over 491.6498125 seconds (0.2441 to 2.3187 words/min); O0 remains 1. Lower primary WER therefore cannot justify a general decoder promotion. Modified beam search and 50 ms host dispatch change together, so this is not an isolated decoder-only estimate.

Full-window RMS B35 does not sustain its favorable challenge O1 attribution point. Relative to its dispatch-RMS voice parent B01, full-bank first-final cp errors worsen by 235/12 and latest by 240/46 on O0/O1, with more unknown support and more admitted embedding calls. Primary words remain unchanged. The measured RMS support policy should remain an explicit rejected nominal comparison, not a silently adopted fix to the original gate.

### Forward corrections and retained transcript exposure

The actual forward-event history supports the following diagnostic exposure totals. Each value is modeled retained-row utterance-seconds accumulated while an identifiable transcript row remains visible, not wall seconds, speech duration or word-aligned harm. Unknown/unmapped exposure belongs beside known-wrong exposure. The last column counts changed-label transitions after first finalization; it does not count structural track merges or imply every correction helps.

| Profile / tap | Identifiable rows / exposure unavailable | Known-wrong row-seconds | Unknown/unmapped row-seconds | Total identifiable row-seconds | Post-final label changes |
|---|---:|---:|---:|---:|---:|
| B36 O0 | 480 / 175 | 208.0 | 10,511.4 | 15,966.7 | 6 |
| B36 O1 | 487 / 179 | 253.6 | 10,937.9 | 16,121.3 | 7 |
| B10 O0 | 480 / 175 | 156.0 | 14,169.0 | 15,966.7 | 9 |
| B10 O1 | 487 / 179 | 155.4 | 15,119.2 | 16,121.3 | 8 |
| B17 O0 | 527 / 166 | 214.6 | 11,855.0 | 17,627.7 | 31 |
| B17 O1 | 536 / 174 | 154.7 | 11,802.3 | 17,946.1 | 32 |
| B25 O0 | 480 / 175 | 256.7 | 12,487.2 | 15,967.2 | 35 |
| B25 O1 | 487 / 179 | 145.1 | 12,512.3 | 16,122.0 | 29 |

B10's lower known-wrong exposure accompanies much greater unresolved exposure than B36 under matching row populations. B17 and B25 have different ASR-finalization row populations, so their raw seconds cannot be ranked as if the denominators were fixed. Exposure-unavailable rows remain explicit; they are not zero-error rows. These endpoint-derived rows are also not the 777 intended source utterances. Historical B00 lacks the same forward-event history and is unavailable for this exposure comparison, rather than having proven zero harm. The full revision summary retains never-correct counts, transition categories and affected-recipient diagnostics.

### Source and condition sensitivity

The component changes do not help every source group. On all complete scenes, the three corpus groups contain 61 CMU Arctic scenes/1,682 words, 70 Common Voice scenes/2,112 words and 72 HiFiTTS scenes/2,222 words. The following latest-cp changes use those exact same groups for both sides; negative means fewer errors, with O0/O1 shown together.

| Complete-source group | B17 minus B36 | B25 minus B36 | B25 minus matched B24 |
|---|---:|---:|---:|
| CMU Arctic, 1,682 words | −148 / −126 | −54 / +77 | +29 / +4 |
| Common Voice, 2,112 words | +45 / +45 | −31 / −8 | +13 / −23 |
| HiFiTTS, 2,222 words | +78 / +86 | −20 / −19 | −31 / −38 |

B17's small pooled change relative to B36 combines substantial CMU improvements with Common Voice/HiFiTTS regressions. Its much smaller matched cue effect versus B16 occurs entirely in Common Voice: latest −1/−32 errors, with zero change in the other two corpus groups. This is an observed concentration, not a causal claim that a corpus or source quality creates the effect. The B25/B24 bundle also reverses direction by source and tap.

B28's primary word gain is similarly concentrated. CMU/Common Voice/HiFiTTS primary groups contain 48/56/52 scenes and 1,319/1,736/1,505 words. O0 changes are −1/−19/−1 errors; O1 changes are −1/−6/+2. Fourteen of the 21 fewer O0 errors occur in the 16 music-background primary scenes (517 words), versus seven in 140 scenes without added real noise (4,043 words). These corpus and noise groups overlap one another. The primary pose split is 146 flat scenes/4,271 words and 10 upright scenes/289 words, so the smaller upright effect (−1 on each tap) has a narrow denominator. Source quality, level, room, obstruction and SNR results remain in the selected strata table; memberships across dimensions are not independent trials.

### Conditional uncertainty and explanatory cases

Full cp uncertainty completed 365 contrasts using 2,000 matched-block resamples. For the matched cue comparisons below, every point and eligible bootstrap subset contains 203 complete scenes/6,016 words, in 163 blocks across five rooms. These intervals describe the reused bank and its declared grouping; crossed dependencies preclude independent-population inference.

| Right minus left | Tap / view | Pooled change (percentage points) | Conditional 95% percentile interval |
|---|---|---:|---:|
| B17 − B16 | O0 first-final | +0.0665 | [0.0000, +0.1706] |
| B17 − B16 | O0 latest | −0.0166 | [−0.0529, 0.0000] |
| B17 − B16 | O1 first-final | −0.3989 | [−1.0525, 0.0000] |
| B17 − B16 | O1 latest | −0.5319 | [−1.2286, 0.0000] |
| B25 − B24 | O0 latest | +0.1828 | [−1.7399, +2.1345] |
| B25 − B24 | O1 latest | −0.9475 | [−3.3869, +1.3126] |

The B17 intervals reach zero; the B25 latest intervals span zero. A favorable point is not a general cue claim or an equivalence finding. Equal-room latest changes are −0.0288/−0.5076 pp for B17−B16 and +0.4678/−0.9092 for B25−B24, distinct from the pooled figures. Full dependency deletion ranges and whole-block eligibility remain available through the bound uncertainty tables. The challenge uses a different eligible subset and must not inherit these full-bank denominators.

The 12 diagnostic scenes are selected after outcomes to explain wins and losses; they are not a new evaluation population. S45_03_20 shows why timing views matter: B17 versus B16 on O0 has 29 versus 27 first-final cp errors over 28 words, then 26 versus 27 latest errors. O1 latest is 21 versus 31. Across all 203 complete scenes, this matched pair has no latest-cp losing scene (O0 one win/202 ties; O1 three wins/200 ties), while earlier-view losses still exist. The independent case review binds the per-scene evidence behind that statement rather than inferring it from a pooled delta.

S45_02_15 shows B25/B24's opposite tap behavior: latest +21 errors on O0 and −21 on O1. S45_01_13 and S45_03_05 retain losses against B36 rather than only favorable examples. Mandatory S45_03_01 remains a short-reply/identity challenge. S45_12_18/O1 exposes an additional full-bank B28 empty failure with four inserted words versus none; S45_12_20/O1 gives nine versus one. `DIAGNOSTIC_SCENE_RESULTS.csv` and `independent_review/FINAL_CASE_REVIEW_V1.json` retain all three label views, companion profiles and exact denominators.

## Resource and deployment boundary

The heavy comparison uses up to four CPU research workers, inner numerical pools set to one, fresh case state, and reusable resident models. Actual OS thread counts are measured and are not one. Model asset size, USS, RSS-sum upper bound and private commit are separate quantities. Engine work includes the measured native engine interval; concurrent stage sums are not wall time, and replay policy costs must not be added twice. Startup, EOF drain, export and cache overhead remain visible in the ledger.

All heavy scoring and native paced workers have closed. The paced study completed 64 logical cells in 67 physical native attempts: 64 successes and three preserved observer status-read interruptions. Four fixed 44.6954375 s whole files cover single voice, short reply, overlap and paused return, with B00/B36/B10/B17 on both taps and two balanced repetitions. The 2,860.508 completed source-seconds are repeated test exposure, not additional independent scenes. Each cell starts fresh process/state and retains one model bundle within that cell. This is not an uninterrupted endurance test. The immutable pre-paced 3,936-job accounting remains a separate scope.

### Native paced resource observations

Each row below summarizes 16 successful cells: four cases × two taps × two repetitions. Memory columns are ranges of per-cell sampled peaks in MiB. CPU is the sampled native worker-tree cumulative CPU lower bound in seconds, not wall time. Writes are measured per-cell process write bytes converted to MiB, not total physical SSD traffic.

| Profile | Peak USS MiB | Peak RSS-sum MiB | Peak private commit MiB | OS thread peak | Sampled tree CPU seconds | Process writes MiB |
|---|---:|---:|---:|---:|---:|---:|
| B00 | 385.23–387.68 | 443.56–446.01 | 419.50–420.71 | 33 | 27.95–29.89 | 1.63–1.64 |
| B36 | 386.41–394.88 | 444.36–453.85 | 452.75–461.23 | 28 | 10.17–10.91 | 4.35–4.52 |
| B10 | 386.98–396.02 | 444.92–454.01 | 453.07–460.84 | 28 | 10.08–11.02 | 4.38–4.57 |
| B17 | 399.79–402.50 | 457.73–460.45 | 468.82–470.80 | 28 | 11.44–12.22 | 5.56–5.77 |

USS is private resident memory. RSS sums can count shared pages more than once; private commit measures virtual commitment rather than resident RAM. PSS is unavailable. Coordinator RSS is separately recorded and is not silently added to the native tree. The 5,720 stored resource samples include two flagged partial process trees; complete-flag-only measurements are separately retained. The frozen sampler can also fall back to the root process after descendant-enumeration failure without clearing its completeness flag, so exhaustive descendant coverage is not independently proven. These facts limit the precision of a device-memory inference.

B00 retains historical model-thread/runtime defaults, while the named profiles use their declared thread controls and added instrumentation. Its larger sampled CPU cost cannot be credited to a tracker improvement by comparing B00 with B36. The paired B36/B10/B17 observations are useful desktop resource screens; four observer versions, three interruption gaps and unrelated host activity still prevent treating all host conditions as identical. B25/B28 were not paced.

Native worker wall intervals span 47.727–48.154 s for the 44.6954375 s source, including startup and completion. The sum of separately recorded bundle-admission and engine-launch phases spans 1.783–1.922 s. B00 constructs a trivial bundle wrapper and loads inside engine launch; the new profiles load the resident bundle before engine launch. Comparing either phase alone would falsely imply a cold-load advantage. These measurements exclude coordinator admission/preflight, interpreter/import overhead outside the worker timer, and any claim of operating-system cold boot or complete model warmup. The final continuation's wrapper spans about 2,157 s, while its 29 new worker intervals sum to about 1,390 s, leaving about 767 s of unclassified outside-worker orchestration. This includes the continuation's broader checks and gaps; admission alone was not timed. It is not an additional engine-latency sample.

Research output volume also differs. Per-cell retained application artifacts span about 1.41–1.42 MiB for B00, 4.02–4.17 for B36, 4.04–4.21 for B10 and 5.23–5.43 for B17. B17's measured process writes are about 130–135 kB per source-second. This includes research journals and instrumentation; it is not a promised production eMMC write rate or a bounded long-term retention policy. First/last memory samples can straddle model teardown, so a negative end-to-end memory delta does not prove freedom from leaks.

### Native variability, delivery and observation coverage

All 64 successful cells have exact full PCM/journal checks and complete ASR-cursor delivery. Each source contains 715,127 mono samples at 16 kHz. B00 lacks the V2 internal dispatch trace; its delivery proof uses the exact journal, cursor, tail and durable completion checks. The speaker analyzed frontier reaches 44.5 s, with a declared 0.1954375 s short remainder. Full source delivery therefore does not mean that remainder can form a new speaker embedding.

All 32 repetition pairs have identical final words, final labels and PCM journals. The 24 embedding-comparable new-profile pairs have matching spans and numerical differences within 1e-6; B00 is unavailable for this internal-vector comparison. Only 29/32 complete native display sequences match. In B00 S45_03_01/O0, one partial label changes between Speaker_1 and Speaker_3. B17 S45_04_05/O1 and S45_06_07/O0 differ in partial/revision ordering or labels, with unchanged final states. Every repetition remains in the evidence. Final parity does not erase the observed first/partial-display variability.

Native emission offsets are measured against the current run's source-start UTC and source cursor. Across recorded events, partial offsets span −0.06555 to +0.57772 s, final offsets −0.03654 to +0.47883 s, and revision offsets +0.03425 to +0.55781 s. The file route can append a 100 ms block before its pacing sleep, putting the cursor temporarily ahead of elapsed source time; this explains possible negative offsets without negative speech latency. These offsets are unsuitable as phoneme-to-token latency, evidence-recognition delay or GUI latency. They are also separate from the main modeled scheduler clock; no native score replaces the deterministic method comparison.

The stored observation grid contains 5,720 samples: 192 null LIVE observations, 192 valid model-loading objects without telemetry, and 5,336 valid cursor/telemetry observations. The final optional observer separately made 2,495 admitted LIVE reads, with zero malformed-to-missing events. Its prospective recovery branch passed fixtures but did not activate in the successful continuation. Earlier pathwise malformed-read counters are unavailable rather than zero. All three prior interruptions and their partial trajectories remain preserved.

Observed ASR-backlog peaks are about 0.10 s; speaker-backlog peaks span 0.25–0.30 s for B00/B36/B10 and 0.50 s for B17. These are sampled source-cursor differences, not proven continuous-time queue maxima. There are 128 inter-sample gaps above 0.75 s, with the largest about 1.0381 s. Missing observations are never interpolated or assigned zero backlog. Exact per-job/tap denominators, actual event timing, read counters and partial-attempt resource records are retained in the paced CSVs and closure JSON.

The final scoped audit independently passed 940 checks, including all 64 completion/trajectory bindings, 174 artifacts from the final 29 new cells, all 32 actual repetition comparisons and 138 closed owned PID/creation identities. Earlier successful cells retain their admission bindings; duplicate copied receipts are not extra inference. No Ryzen-to-CM5 multiplier, ARM64 timing claim, 2 GB total-device fit, sustained leak/thermal qualification or GUI latency claim follows from these finite Windows probes.

### Storage at closure

At 04:43 UTC on September 10, C: had 86,606,749,696 free bytes (about 80.66 GiB) and G: had 407,393,882,112 (about 379.42 GiB), above the declared 50/75 GiB reserves. The explicit volume-to-disk mapping identified C: as WD_BLACK SN850X 2000GB and G: as KINGSTON SNVS2000G, both NVMe SSDs reported Healthy/OK. The G: mapping uses the recorded CIM logical-disk/partition/disk chain because the direct Get-Partition route was unavailable. Health status does not establish the cause of the earlier null-padded monitoring reads. Exact device, capacity and process observations are in the storage receipt. A sequential metadata count at 04:52 UTC measured 42,224,814,921 bytes (about 39.32 GiB) across the admitted G: payload, C: report and C: staging roots, below the 120 GiB output cap, with no stat errors. This is a pre-package metadata checkpoint rather than an atomic filesystem snapshot. The same check freshly confirmed all 138 owned process identities closed.

## What follows

S6C is a separate decision. It should challenge the observed failures and tune a small number of matched parameters, preserve both taps and all short replies, and add external real-human validation before deployment conclusions. A nominal companion comparison or isolated failure boundary is not a validated parameter plateau. Split ASR/embedding taps, new acoustic scenarios, target-device measurements and GUI production work remain explicitly unperformed. `NEXT_STAGE_INPUTS.md` states the exact bounded questions without starting that work.
