# Run an opt-in S6B profile on the existing desktop

Purpose: run the implemented H2 pipeline on an existing prepared file, using a named S6B profile. This is a file-processing command and does not play sound or access the XVF. The GUI default is not promoted. Use the final shortlist for interpretation; a runnable profile is not automatically a recommended production setting.

## Inputs and outputs

The example uses the already-prepared mono 16 kHz `S45_01_06/O0.wav`, which already includes its historical +3 dB gain. Every named main profile consumes this adapter at unity. Do not apply gain again, use the raw multichannel capture in its place, or add the RIR's 50 ms origin again. O1 adapters already use their historical unity recipe. Lower-gain B26/B27 are separate challenge recipes and must use their separately bound gain adapters, not this example.

The profile JSONs live in this report's `profiles` directory. `B36` is the original anonymous tracker under the common causal scheduler; exact historical B00 remains a separate immutable baseline. Replacing B36 with another confirmed v2 profile changes the opt-in method, not the GUI default. Do not substitute `B00`: its JSON is a historical-control marker rather than a loadable v2 profile. The accompanying telemetry is the sanitized trace for the same scene. A cue-disabled profile ignores cue authority; a cue-enabled profile requires its matching delivered observations.

Models remain in their existing repository locations and are hash-checked by the application. The explicit interpreter avoids a new environment or package installation. The example gives this run its own data root, which keeps its enrollment roster empty and outputs separate from campaign evidence.

Outputs appear below `EDGE_SPEECH_DATA_ROOT\edge_speech_sessions`: raw input PCM journal, append-only events, first-final transcript, latest revised transcript, Markdown transcript and session summary. First-display and forward revision history remain in events. These are research exports; the production GUI does not rewrite history. Journals and detailed event logs can grow substantially during long runs.

## PowerShell

Open a new PowerShell terminal and paste these commands. The `file` command is paced at source speed unless `--accelerated` is explicitly added.

```powershell
$sim = 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
$report = Join-Path $sim 'reports\S6B\20260909T230840Z'
$py = 'C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe'
$profile = 'B36'
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:PYTHONPATH = 'C:\Users\amiri\Documents\GitHub\just-peachy\Software Validation from Datasets\Evaluation Tool\app'
$env:EDGE_SPEECH_ASSET_ROOT = ''
$env:EDGE_SPEECH_DATA_ROOT = Join-Path $sim ('staging\s6b\manual_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
$env:OMP_NUM_THREADS = '1'
$env:OPENBLAS_NUM_THREADS = '1'
$env:MKL_NUM_THREADS = '1'
$env:NUMEXPR_NUM_THREADS = '1'
& $py -m edge_speech_pipeline research-profile (Join-Path $report "profiles\$profile.json")
& $py -m edge_speech_pipeline file 'G:\Just_Peachy_S6B\20260909T230840Z\inputs\S45_01_06\O0.wav' --research-profile (Join-Path $report "profiles\$profile.json") --research-telemetry (Join-Path $sim 'reports\S6A\20260909T202250Z\cues\delivered\S45_01_06.jsonl')
```

The first command validates and prints the effective profile without model inference. Its B36 invocation was tested successfully during S6B. The actual native runtime and paced evidence have their separate receipts; this README does not imply a second execution of this illustrative command.

## Anaconda Prompt or Command Prompt

No `conda activate` is needed because the verified interpreter is named explicitly. Use a new terminal. Change `S6B_PROFILE` to a confirmed profile ID when needed.

```bat
set "SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
set "S6B_REPORT=%SIM%\reports\S6B\20260909T230840Z"
set "S6B_PY=C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe"
set "S6B_PROFILE=B36"
set "PYTHONDONTWRITEBYTECODE=1"
set "PYTHONPATH=C:\Users\amiri\Documents\GitHub\just-peachy\Software Validation from Datasets\Evaluation Tool\app"
set "EDGE_SPEECH_ASSET_ROOT="
set "EDGE_SPEECH_DATA_ROOT=%SIM%\staging\s6b\manual_cmd_%RANDOM%_%RANDOM%"
set "OMP_NUM_THREADS=1"
set "OPENBLAS_NUM_THREADS=1"
set "MKL_NUM_THREADS=1"
set "NUMEXPR_NUM_THREADS=1"
"%S6B_PY%" -m edge_speech_pipeline research-profile "%S6B_REPORT%\profiles\%S6B_PROFILE%.json"
"%S6B_PY%" -m edge_speech_pipeline file "G:\Just_Peachy_S6B\20260909T230840Z\inputs\S45_01_06\O0.wav" --research-profile "%S6B_REPORT%\profiles\%S6B_PROFILE%.json" --research-telemetry "%SIM%\reports\S6A\20260909T202250Z\cues\delivered\S45_01_06.jsonl"
```

For a different prepared scene, change both the WAV and same-scene telemetry path. For O1 of the same scene, change only the WAV suffix to `O1.wav`; both taps share one physical telemetry trace. For new audio, prepare the input and causal telemetry deliberately under a later authorized task instead of borrowing reference metadata from a different scene. Do not enroll named people from synthetic evaluation identities.

## Exact campaign replay and safe rollback

The frozen epoch lives at `simulation\staging\s6b\20260909T230840Z\epoch2`. Main native campaign execution must use the separately bound `atomic_io_v1\s6b_launch.py` adapter. Exact campaign reproduction and byte-guard commands are in `README_S6B_EXECUTION.md`, `README_S6B_REPLAY.md`, `README_S6B_PREDICTION_GUARD.md` and `README_S6B_PACED.md` under `simulation\scripts`; the handoff includes these command references. A model-free replay reuses actual evidence and is different from a new physical latency measurement.

For ordinary current-app behavior, omit `--research-profile` and `--research-telemetry` in a fresh session. To investigate the exact prior source, use an isolated copy of the accepted S6A V2 snapshot, or the separate immutable B0 snapshot, and bind the original absolute assets explicitly. Frozen copies have different directory depth, so their inferred default asset paths are not a safe substitute for explicit bindings. The rollback procedure in `independent_review/CODE_CHANGES_FROM_S6A_V2.md` preserves both snapshots and existing outputs. No reset, deletion, automatic commit or GUI promotion is required.
