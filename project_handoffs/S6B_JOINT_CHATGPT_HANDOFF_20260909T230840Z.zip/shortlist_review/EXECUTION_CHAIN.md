# Final analysis command chain

This records the executed model-free chain for the completed 29-profile index. It reuses exact scores through verified transfers, then rebuilds the aggregate tables and uncertainty. It does not run neural models, replay predictions, tune profiles or change the source analyses.

The commands below name this run's completed immutable outputs. Do not rerun them to overwrite a completed analysis. For a new scoring dependency or a deliberate new analysis, choose new target/receipt/output subdirectories consistently and keep the completed source results unchanged. Run both transfers before starting the target core scorer; the transfer helper rejects an already-started target.

Inputs: completed FULL_PREDICTION_INDEX.json, completed R0/R1 source score receipts, the unchanged support/scene bank and frozen metric code in the existing analysis environment. Outputs: two separate transfer receipts; full_analysis_v1; full_revision_v1; full_cp_uncertainty_v1; full_component_screen_v1.

## PowerShell

```powershell
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6b_score_transfer.py' --source-analysis-subdir r0_full_analysis_v1 --target-index FULL_PREDICTION_INDEX.json --target-analysis-subdir full_analysis_v1 --receipt-subdir score_transfer_r0_v1
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6b_score_transfer.py' --source-analysis-subdir r1_full_analysis_v1 --target-index FULL_PREDICTION_INDEX.json --target-analysis-subdir full_analysis_v1 --receipt-subdir score_transfer_r1_v1
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6b_analysis.py' --index FULL_PREDICTION_INDEX.json --output-subdir full_analysis_v1 --require-complete
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6b_revision_analysis.py' --index FULL_PREDICTION_INDEX.json --analysis-subdir full_analysis_v1 --output-subdir full_revision_v1 --require-complete
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6b_cp_uncertainty.py' --index FULL_PREDICTION_INDEX.json --analysis-subdir full_analysis_v1 --output-subdir full_cp_uncertainty_v1 --replicates 2000 --require-complete
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6b_component_screen.py' --analysis-subdir full_analysis_v1 --revision-subdir full_revision_v1 --cp-subdir full_cp_uncertainty_v1 --output-subdir full_component_screen_v1
```

## Anaconda Prompt or Command Prompt

The existing pinned environment is called directly; there is no package installation or environment activation requirement.

```bat
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6b_score_transfer.py" --source-analysis-subdir r0_full_analysis_v1 --target-index FULL_PREDICTION_INDEX.json --target-analysis-subdir full_analysis_v1 --receipt-subdir score_transfer_r0_v1
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6b_score_transfer.py" --source-analysis-subdir r1_full_analysis_v1 --target-index FULL_PREDICTION_INDEX.json --target-analysis-subdir full_analysis_v1 --receipt-subdir score_transfer_r1_v1
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6b_analysis.py" --index FULL_PREDICTION_INDEX.json --output-subdir full_analysis_v1 --require-complete
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6b_revision_analysis.py" --index FULL_PREDICTION_INDEX.json --analysis-subdir full_analysis_v1 --output-subdir full_revision_v1 --require-complete
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6b_cp_uncertainty.py" --index FULL_PREDICTION_INDEX.json --analysis-subdir full_analysis_v1 --output-subdir full_cp_uncertainty_v1 --replicates 2000 --require-complete
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6b_component_screen.py" --analysis-subdir full_analysis_v1 --revision-subdir full_revision_v1 --cp-subdir full_cp_uncertainty_v1 --output-subdir full_component_screen_v1
```

## Closure

The R0 transfer copied 11,040 exact score files and the R1 transfer copied 960; neither overwrote a conflicting target. The final core verified those 12,000 identities and completed all 13,920 outputs with zero unscored. Revision analysis also completed all 13,920. The cp supplement completed 365 conditional paired contrasts with 2,000 resamples, and the final factual screen contains 58 profile/tap rows. All owned transfer/scoring/uncertainty processes exited successfully before shortlist report writing and the paced-resource step.

The maintained per-script READMEs in simulation/scripts contain each tool's detailed input schema, source-binding checks, metric semantics and isolated validation limits. This document records the combined invocation order; it does not replace them.

