# Final full-bank shortlist review (V2)

This V2 corrects the B28 endpoint-setting description and the contained-evidence table header. V1 remains preserved; all metric values, selections and execution results are unchanged.

The final analysis covers all 29 retained profiles on 240 scenes and both taps: 13,920 outputs, zero failures. The earlier challenge covered 44 explicitly enumerated profiles, including four limited diagnostics. This report proposes five research directions; it does not declare five winners or five unrelated clustering algorithms.

Use B00, B36, B10 and B17 for the bounded paced comparison. B00 remains the historical control; the five-direction shortlist is B36, B10, B17, B25 and B28. B17 is the selected second joint comparator after full-bank scoring. B25 and B28 remain conditional research alternatives. Paced resource findings are a separate later evidence layer, absent from this decision.

## Why these directions remain distinct

B36 supplies a simple voice fallback. B10 changes identity-state architecture through dual memory and dormant re-entry. B17 changes the component operating recipe toward fixed longer evidence. B25 introduces real early short/long admission and adaptive cadence; it shares adaptive tracking with B17 but asks a different evidence-acquisition and compute question. B28 changes the ASR search and host-dispatch recipe while preserving the original endpoint rules, and exposes an empty-control failure. Therefore B17/B25 count as distinct pipeline directions, not as independent tracker families. B28 is an ASR research branch, not a joint-tracker win.

| Profile | Role | Required companion or boundary |
|---|---|---|
| B36 | Simple voice fallback | B00 historical control |
| B10 | Structural joint failure/resource comparator | B09 cues disabled |
| B17 | Conditional joint component comparator | B16 cues disabled |
| B25 | Conditional cadence research alternative | B24 voice-driven cadence |
| B28 | ASR/empty-control failure boundary | B22 limited challenge endpoint companion |

## Attribution, coverage and returns

Each cp entry is an error count out of 6,016 complete-reference words over 203 scenes per tap (156 primary scenes and 47 complete overlap scenes). Values are O0 / O1. The first-display view assigns the first displayed label to final words; it is not partial-word recognition accuracy. Unknown and mixed percentages share the sole-active sample denominator. Return groups are consistent / inconsistent / unknown, out of 292 on each tap.

| Profile | First-final cp | Latest cp | First-display-label(final words) cp | Unknown % | Mixed % | Returns O0 ; O1 |
|---|---:|---:|---:|---:|---:|---|
| B00 | 3533 / 3714 | 3533 / 3714 | 3926 / 4060 | 18.73 / 18.80 | 1.61 / 1.60 | 111/108/73 ; 96/118/78 |
| B36 | 3662 / 3773 | 3668 / 3741 | 3691 / 3780 | 21.48 / 21.49 | 1.49 / 1.54 | 107/95/90 ; 88/108/96 |
| B10 | 3607 / 4064 | 3638 / 4018 | 4125 / 4208 | 29.59 / 31.41 | 0.69 / 0.64 | 2/96/194 ; 2/87/203 |
| B16 | 3627 / 3734 | 3644 / 3778 | 3821 / 3865 | 27.78 / 26.81 | 1.75 / 1.57 | 44/108/140 ; 50/110/132 |
| B17 | 3631 / 3710 | 3643 / 3746 | 3830 / 3865 | 27.58 / 26.63 | 1.75 / 1.55 | 44/108/140 ; 51/112/129 |
| B24 | 3592 / 3812 | 3552 / 3848 | 3886 / 3919 | 25.54 / 25.21 | 1.23 / 1.40 | 45/147/100 ; 39/155/98 |
| B25 | 3641 / 3785 | 3563 / 3791 | 3899 / 3937 | 25.32 / 24.66 | 1.25 / 1.35 | 41/154/97 ; 39/160/93 |
| B28 | 3737 / 4008 | 3739 / 3979 | 4083 / 4081 | 28.13 / 30.08 | 1.01 / 1.11 | 12/76/204 ; 5/72/215 |

B17 versus B25 is a tradeoff. B17 has 10 fewer first-final cp errors on O0 and 75 fewer on O1. B25 has 80 fewer latest errors on O0 but 45 more on O1. B17 has 108/112 inconsistent returns versus B25 154/160. B25 has lower unknown and mixed support, but that does not offset the earlier-label and return harms for this paced selection. B17 itself is conditional: versus B36 it has lower first-final cp errors (31/63 fewer) but higher unknown support, lower return consistency, and latest O1 is five errors worse.

B10 remains a structural counterexample. Compared with B36 it has 55 fewer first-final errors on O0 but 291 more on O1; latest changes are -30/+277. First-display-label(final words) errors worsen by 434/428. Its return consistency is only 2/292 on either tap, versus B36 107/292 and 88/292. Its lower mixed support coexists with higher Unknown. The matched B09 comparison shows only 16 fewer O0 first-final errors and no O1 change; latest cp errors are identical on every complete scene/tap. General cue benefit is not established.

## Every subsecond instance remains visible

There are 40 complete-reference subsecond source instances per tap, preserved for every profile. Contained evidence, any known support and correct duration-mapped modal identity are distinct tests. The full score grid retains 45,066 intended source-turn outputs (777 x 58 profile/tap cells), including 2,320 subsecond outputs (40 x 58).

| Profile | Turns with ≥1 contained embedding /40 | Any known support /40 | Correct modal identity /40 | Incorrect modal identity /40 | Unknown or unmapped /40 |
|---|---:|---:|---:|---:|---:|
| B36 | 31 / 33 | 36 / 38 | 14 / 14 | 3 / 3 | 23 / 23 |
| B10 | 31 / 33 | 36 / 38 | 13 / 11 | 1 / 1 | 26 / 28 |
| B17 | 0 / 0 | 31 / 35 | 13 / 17 | 0 / 0 | 27 / 23 |
| B24 | 8 / 9 | 35 / 36 | 12 / 14 | 1 / 0 | 27 / 26 |
| B25 | 8 / 9 | 35 / 36 | 13 / 14 | 1 / 0 | 26 / 26 |
| B28 | 31 / 33 | 36 / 38 | 13 / 13 | 1 / 1 | 26 / 26 |

B25 improves contained and any-known short support over B17, but its mapped-correct count is unchanged on O0 and three lower on O1. B17 has no wholly contained subsecond embedding; its labels may come from neighboring or partly spanning evidence, so the 13/17 correct modal counts do not validate short-only speaker evidence. Neither recipe is a universal short-reply solution.

## Revision exposure and compute do not reverse the selection

The exposure ledger uses offline duration-based identity mapping and source-identifiable transcript spans. Multiple retained rows may coexist, so the unit is modeled row-seconds, not wall-time or word-aligned GUI harm. Different endpoint recipes have different row populations. Raw totals across B17/B25 therefore are descriptive, not a controlled per-utterance causal contrast.

| Profile | Identifiable rows O0/O1 | Known-wrong row-seconds O0/O1 | Unknown/unmapped row-seconds O0/O1 | Observed row-seconds O0/O1 | Strictly post-final changed-label transitions |
|---|---:|---:|---:|---:|---:|
| B36 | 480 / 487 | 208.004 / 253.562 | 10511.386 / 10937.878 | 15966.744 / 16121.288 | 6 / 7 |
| B10 | 480 / 487 | 155.986 / 155.424 | 14168.971 / 15119.216 | 15966.744 / 16121.288 | 9 / 8 |
| B17 | 527 / 536 | 214.585 / 154.704 | 11855.037 / 11802.340 | 17627.696 / 17946.076 | 31 / 32 |
| B25 | 480 / 487 | 256.667 / 145.082 | 12487.236 / 12512.328 | 15967.169 / 16121.966 | 35 / 29 |

All ongoing display updates, bounded reconciliation events and strictly post-final changed labels have separate ledgers. A correction does not erase an earlier error. Unknown, mixed or ambiguous source mappings do not become identifiable recipient claims. B17 has 31/32 strictly post-final changed labels; B25 has 35/29. B25 has lower raw O1 known-wrong exposure but worse O0, and its row populations differ; the exposure findings do not create an overall advantage.

Measured upstream native process CPU totals give B17 1.226/1.222 times R0 and B25 1.178/1.176 times R0. B25 is modestly lower than B17, but both exceed R0 despite roughly halving embedding call counts. Native accelerated elapsed sums are nearly equal between B17 and B25 (about 1,435/1,446 seconds versus 1,437/1,448), over 10,893.905 source-audio seconds per tap. These are actual batch observations under their execution conditions; no desktop-to-CM5 conversion or isolated causal CPU saving is claimed. Reused recipe costs are counted once upstream and must not be added across every tracker reuser. Inclusive CPU/elapsed and nested phase timers are not additive.

The full mechanism audit observes 8,303 R5 embeddings and 8,479 R5_CUES embeddings: net +176. Its 316 cue-only earlier-cadence admission opportunities are a different local counter, not 316 net new inference calls. B17 rejects nine updates across three outputs under its cap; B25 rejects 22 across seven. B10 rejects 1,670 across 163 outputs. B36 retains cap 256 and maximum gallery 27, whereas the new methods use cap 16. No cap was tuned after outcomes.

## The ASR branch is conditional because empty controls regress

B28 primary word errors fall from B00 656/705 to 635/700 out of 4,560 words on each tap: 21/5 fewer errors. Complete-overlap MIMO errors become 492/491 versus 486/502 out of 1,456. Designated ambient-target errors become 200/209 versus 202/205 out of 683 target words; incomplete-reference ambient scenes remain separate from complete cp scoring.

The strict-empty population has 11 scenes and 491.6498125 seconds per tap. B28 O1 insertions increase from two to 19 (about 0.244 to 2.319 inserted words/minute). The affected O1 cases are S45_12_09 (0 to 1), S45_12_16 (1 to 5), S45_12_18 (0 to 4), and S45_12_20 (1 to 9). The O0 empty count stays one. B28 is retained to study this ASR failure boundary alongside its word-recognition gain; it is not recommended for unrestricted use. Against original B01, B28 changes greedy search to modified beam search (two active paths) and host dispatch from 100 to 50 ms. Endpoint rules stay exactly 2.4/1.2/20 seconds and blank penalty stays zero. The screen-only B22 companion instead uses 1.6/0.8/20 endpoint rules, so B28-versus-B22 changes both endpoint settings and search; it does not isolate decoder behavior or supply a matched all-bank comparison.

## Uncertainty, selection and limitations

Full cp paired uncertainty uses 2,000 within-room matched-block resamples, retaining all 203 complete scenes and 6,016 words in 163 blocks across five rooms. Source-dependency closures collectively connect all 203 scenes. The confidence intervals, equal-room views and source/room deletions are conditional diagnostics, not independent-population generalization or equivalence. B25-versus-B24 intervals cross zero on both taps/views. B17-versus-B16 O1 first/latest interval upper endpoints reach zero; the small O0 effects also reach zero. Do not turn these bounded descriptive effects into a general cue advantage.

This is an outcome-based shortlist from the complete retained bank, not a held-out validation set. The challenge-first recipe admission and prospective all-R0 confirmation remain documented. No opaque combined rank, post-outcome profile tuning, unmeasured continuous parameter range, target CM5 qualification, production promotion or training conclusion is asserted. A later stage must separately test the short-reply and return tradeoffs, gallery capacity/evidence maturity, ASR false alarms and actual paced deployment costs.

The older R0 structural review remains preserved; this combined review supersedes its pending-component selection. The current Word master remains the single planning/results guide.
