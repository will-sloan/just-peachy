# Additional S6B paced execution faults

This supplement preserves `EXECUTION_FAULT_LEDGER.md` unchanged (SHA256 `a8e383023eec7ffe67d028b92f12bd225f82cd0e8e6b0a1a9a70922b15978b02`). The earlier ledger and immutable validation summary remain authoritative for pilot persistence, gain-audit pointer and endpoint-extractor faults. This file records the later paced interruption and its recovery; it does not alter neural/model results.

## First paced coordinator: denied status read

The `paced_finalists_epoch2_v1` plan contains 64 whole-file cells for B00/B36/B10/B17, four cases, both taps and two repetitions. Its first B00 and B36 O0 cells completed with exact PCM journals, complete ASR cursors, no drops and owned-process closure. The third cell, `B10_S45_01_06_O0_R1`, was interrupted after about 20 seconds when the coordinator's direct `LIVE.json` read raised Windows `PermissionError`.

The coordinator exited with failure and stopped its owned worker/helper. The failed partial B10 session is preserved alongside its launch, logs, samples and `FAILURE.json`. It is not a completed output and is not an accuracy rejection. `paced/PACED_V1_INTERRUPTION_SOURCE_INDEX.json` inventories the 41 unchanged source files and exact process/creation identities. No unrelated process was affected.

## Narrow coordinator-only recovery

The new `s6b_paced_read_retry_v1.py` imports the original driver only after verifying its fixed SHA. It wraps the coordinator's JSON `read` function: only `PermissionError` is retried, with at most 20 attempts and a 1-second between-read deadline. Backoff durations and actual retries are logged. A new read cannot begin after an overslept deadline. An OS read itself cannot be preempted, so this is a bounded retry policy rather than an OS-I/O timeout guarantee. Missing/invalid JSON and semantic errors propagate.

The wrapper's native children still execute the original frozen `s6b_paced.py` directly. Application, models, profiles, source audio, scheduler and worker code are unchanged. The wrapper cannot select worker mode through a duplicate/abbreviated mode override. Ten focused model-free fixtures verify actual-read behavior, deadline/error handling, unchanged source and the original child entry point. Independent review caught and corrected the deadline and mode-guard edges before any recovered native launch.

A fresh `paced_finalists_epoch2_v2` namespace preserves the original v 1 tree at its original paths. All 64 job objects and keys match. Only the two completed receipts and their sampled trajectories are copied byte-for-byte, with original worker artifact paths and hashes retained. The interrupted B10 attempt is not copied as success. The remaining 62 cells include one fresh attempt at the interrupted B10 job because its execution was cut short by a status-reader fault. See `paced/PACED_READ_RETRY_RESUME_V1.json`, its independent review and the final paced report for exact completion.

## Interpretation and remaining closure

The two reused cells use the original coordinator; later cells use its read-retry wrapper. The interruption gap and this difference remain disclosed. Retry waits can delay observer sampling; no missing samples are interpolated and no best repetition is selected. The source-paced worker and model paths remain fixed. The failed partial attempt contributes to physical-attempt/resource accounting, separately from the final 64 completed cells if all succeed.

The original driver refreshes a convenience `PREPARATION.json` when run calls prepare again. `PREPARATION_LINEAGE_V1.json` resolves the earlier preparation binding to an exact immutable initial copy. This changes convenience metadata, not job/model identities. Final gates must use the immutable copy/lineage rather than pretending the mutable convenience file has its earlier bytes.

Final recovered status, actual retries and total attempted/completed cells will be recorded in the paced summary and completion manifest after the run closes. The pre-paced `CACHE_AND_INFERENCE_COUNTS.json` remains an unchanged checkpoint scoped to epoch 2 native/replay work; it is not rewritten to absorb paced sessions.
