# Closed S6B native/cache/replay accounting

The closed epoch2 audit verifies **3,936 unique completed native recipe/scene/tap
jobs and 3,936 recorded physical attempts**, with no repeated logical attempt,
missing attempt pair, or recorded failed neural attempt. All20 recorded model
worker identities and all6 coordinator identities are closed; no visible Python
process is running the replay entry point. This does not mark later scoring,
paced qualification or the overall stage complete.

| Quantity | Verified count |
|---|---:|
| Exact neural recipes / conceptual families | 18 / 8 |
| Challenge native jobs:18 recipes x44 scenes x2 taps | 1,584 |
| All-bank extension:6 recipes x196 additional scenes x2 taps | 2,352 |
| Unique epoch2 native jobs | 3,936 |
| Final six-recipe all-bank scope, already included above | 2,880 |
| Reused / new at that final native admission | 920 / 1,960 |
| Observed cumulative resident bundle loads / worker identities | 117 / 20 |
| Recorded fresh / reused coordinator row references | 3,932 / 1,159 |
| Unique primary materialized prediction outputs | 15,240 |
| Final full scope:29 profiles x240 scenes x2 taps | 13,920 |
| Extra15 challenge-only profiles x44 scenes x2 taps | 1,320 |
| Historical B00 outputs / actual-neural-feature-derived outputs | 480 / 14,760 |
| Primary index row references / duplicate cross-index references | 32,296 / 17,056 |
| Separate model-free pilot validation materializations | 112 |

Four worker completions were durably saved before the first coordinator lost
its fresh status rows. Their exact IDs remain in the JSON. They account for the
difference between3,932 fresh coordinator rows and3,936 actual complete jobs;
they were later reused, not inferred again. The two documented coordinator
status-I/O faults preserved completed audio. Their history remains in
`EXECUTION_FAULT_LEDGER.md`. No accuracy-driven rerun is inferred from cache rows.

Successful jobs processed177,925.242seconds of repeated source audio. The sum of
inclusive session wall times is23,232.190seconds; process CPU sums to39,443.484
seconds. These are sums across concurrent sessions, not total campaign elapsed
or paced latency. Resident admission/check time314.894seconds is already nested
inside the session total. There were297,240 observed segmentation records and
98,696 actual embedding records. The2,250,632 ASR dispatch records and equally
many full-dispatch-cost records describe the same dispatches. There is one
observed real-tail and one final-drain record for each of3,936 complete jobs;
these counters are API events, not hidden Sherpa network-forward counts.

Bundle loads use each PID+creation-time maximum cumulative counter, then sum
those maxima. They do not sum every scene's counter or estimate active memory.
Prediction deduplication uses profile/scene/tap plus exact output binding.
Repeated index references are not measured replay cache-hit executions; replay
does not log every execution-versus-reuse separately. Source reuse also prevents
these counts from implying independent new recordings or independent people.

The separate component smoke contains seven native sessions, plus one explicitly
repaired B34 session. Both receipts and the failed eligibility configuration are
preserved; these eight sessions are outside epoch2 totals. The prospective
both-tap64-cell paced study has not started at this checkpoint and contributes
zero observed paced summaries. Its IDs and quiet measurement period remain
pending. Synthetic logic checks and model-free cached replays are not neural
sessions.

## Inputs, outputs and reproduction

`CACHE_AND_INFERENCE_COUNTS.json` is the compact projection of the immutable
`inference_accounting/audit_20260910T020945908231Z/INFERENCE_ACCOUNTING.json` and
its exact bound native/prediction indexes, admission, code, fault and smoke
receipts. It verifies the full13920-cell index grid, parent-supplied final index
hashes and process closure. The larger timestamped audit binds every inspected
compact native receipt. Neither derivative substitutes for the original heavy
payload integrity guards. The JSON includes all source paths/hashes and precise
missingness/limitations; this Markdown is the readable view.

The source audit completed in one invocation on2026-09-10 after native and
combined replay closure. Reproduce into a new timestamped audit with the existing
maintained accountant. Then create a newly reviewed compact derivative/version
from that audit; do not overwrite this closed checkpoint or rerun inference.

PowerShell:

```powershell
$sim = 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe' "$sim\scripts\s6b_inference_accounting.py" --report "$sim\reports\S6B\20260909T230840Z" --epoch epoch2
```

Anaconda Prompt / Command Prompt:

```bat
set "SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe" "%SIM%\scripts\s6b_inference_accounting.py" --report "%SIM%\reports\S6B\20260909T230840Z" --epoch epoch2
```

These commands read metadata and write a new timestamped accounting report and
LATEST pointer. They load no models, change no predictions and require no new
environment. See `README_S6B_INFERENCE_ACCOUNTING.md` for all accounting rules.
