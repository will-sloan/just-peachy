# Measurement and source context retained for S6B

The current planning/results guide is `C:\Users\amiri\Downloads\XVF_Measurement_V15.docx`, SHA256 `107a4a33cbe435e4ca409d29d9e76d5da5d15db24b97b5fe918d3e1d282f2f30`. It was read as context and remains unchanged. This stage returns a separate WORKBOOK_UPDATE for reviewed insertion.

S6B reuses the accepted S0–S6A lineage. It does not repeat the historical measurement audit or regenerate impulse responses. The finite admission receipt binds the S6A handoff, current bank, original application and exact pre-S6B V2 source snapshot. Completed S6A V2 evidence supersedes earlier partial numerical receipts while preserving them.

## Acoustic eligibility

The canonical library contains 121 RIRs; 120 are eligible and 39 are used by the fixed scene bank. The 81 other eligible RIRs remain unused in this bank. Beginning/testing takes and recordings labelled RETAKE are excluded; only accepted PASS or REVIEW measurements enter the canonical eligible lineage. R13 with a clock problem remains excluded.

Accepted distances span 0.46–4.07 m, with none above 5 m. The two “Opening Behind Listener” +20° R05 records at Arise 5th floor low table (flat and upright) originally said 100 m. The user explicitly confirmed 1.00 m (100 cm); the correction is a documented metadata overlay, with raw source files preserved. Manual angle signs were checked for internal consistency. That does not independently calibrate the delivered XVF processed direction. Manual ±5° is label uncertainty; no correction is fitted to model errors.

The bound RIR library manifest SHA256 is `468b2b306f994937a7d02db611080d38c7a4bcc7dc89ce7dc73d93762380f546`. The scene manifest SHA256 is `69131a703ffc631b461bbf3c46c12de50ecdae2afd77d357d61c72ebf306fd18`. Exact local paths and predecessor bindings are in ADMISSION_RECEIPT and INPUT_INDEX.

## Fixed synthetic bank and captures

All 240 scenes and both physical XVF output recipes remain in scope. There are 777 deliberate utterance occurrences across 156 complete non-overlap scenes, 47 complete-overlap scenes, 26 incomplete ambient-reference scenes and 11 empty controls. Common Voice, CMU ARCTIC and HiFiTTS are the admitted corpora; L2 ARCTIC is excluded. Unknown environmental speech is not transcribed or inferred from hypotheses. The historical 180/60 labels are descriptive, not a closed unseen reserve.

The 44-scene S6B challenge augments the accepted 36-scene panel with the existing scenes needed to cover all 40 complete-reference subsecond utterances and the missing folded-bearing ambiguity tag. It is a post-S6A diagnostic selection, not independent validation. Distinct short utterances sharing a scene are not counted as independent scenes.

Historical O0 uses +3 dB exactly once; O1 uses unity. Main S6B adapter WAVs have sample bytes identical to the already-gained historical PCM16 journals and are consumed at unity. The separately declared lower-gain branch uses raw O0 at unity and raw O1 at −3 dB, both 3 dB below their historical recipe, once. No hindsight per-utterance normalization or O1 gain boost is used. The accepted historical O1 rail count is 2,027 versus zero O0; this is retained context rather than a new raw-capture audit.

Shared telemetry is counted once per physical scene even though multiple policies and taps reuse it. Processed bearing is a folded linear 0–180° observation with front/rear ambiguity. S6A observed frequent availability but only about 45% coarse-sector agreement on complete non-overlap support; stable wrong values are not proof of DSP staleness. The predictor may use observable disagreement, age and validity, never the reference angle or true seat.

No acoustic playback, device control, firmware update, new corpus download, source rendering or RIR regeneration occurs in S6B. Existing PC speakers, headphones and other microphones require no changes for this file-based stage.

Synthetic selection remains exploratory engineering. Reused speakers, words, clips, rooms, RIRs and noise form crossed dependencies. Paired grouped uncertainty and deletion sensitivity condition on this bank and do not establish independent real-human population generalization.
