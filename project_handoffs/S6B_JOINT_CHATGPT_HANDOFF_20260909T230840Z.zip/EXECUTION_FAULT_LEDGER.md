# S6B execution faults

## Epoch2 pilot invocation1: transient Windows status-file replacement

The first coordinator (PID38416, workers39624/31972/39488/12256) stopped with `PermissionError: [WinError5] Access is denied` when worker39624 atomically replaced its small READY status JSON. The exception occurred after its complete attempt, evidence and run receipt had been saved. ProcessPool joined the owned workers. A subsequent process check found none of these five processes running.

Inspection found23 attempted outputs, all23 COMPLETE with final run receipts, and no incomplete/failed audio run. Recovery is an exact same-command resume using the immutable epoch2 code and inputs. The actual cache validator verifies source and artifact hashes before reusing all completed work. No code or model setting changed; no result is repeated for accuracy. The original invocation rows/resources/cleanup and the completed native evidence remain preserved. This is an execution-status I/O failure, not a model or audio-completion failure.

## Epoch1: never executed

Epoch1 was frozen before final independent design review returned the B18/B20 duration/cadence confound. B20 and B20_C1 were prospectively corrected to0.25s embedding hop, keeping cadence equal across duration cells. No epoch1 neural jobs were attempted. Epoch2 is the authoritative campaign.

## Epoch2 pilot invocation2: final status replacement

All64 native outputs completed, and `PILOT_NEURAL_INDEX.json` and the invocation completion receipt were saved. A second PermissionError occurred while replacing the final shared HEARTBEAT. The original heartbeat thread was still active until the finally block, which also exposed a possible same-PID temporary-filename collision. Native model work did not fail. The worker pool joined before the exception.

The separately frozen and hashed atomic_io_v1 launch adapter fixes unique writer temp paths and bounded Windows sharing-denial retry. Its four focused writer fixtures include actual injected PermissionErrors and160 concurrent replacements. It leaves all original frozen prediction dependencies unchanged, preserves the failed invocation, and reuses the exact64 outputs through normal byte-hash validation. The overlay is recorded separately from inference identity because it changes only JSON persistence, not inference or decisions.

## Pilot index lineage repair

An all-cache closure invocation replaced the convenience `PILOT_NEURAL_INDEX.json` after an earlier validation had bound its first-completion bytes. Both indexes describe the same 64 native receipt bindings, but their invocation metadata differ. The original index bytes were recovered from the immutable invocation completion receipt, and both versions were preserved under `validation`. `PILOT_INDEX_LINEAGE.json` records their identities. A new model-free `ACTUAL_PILOT_VALIDATION_FINAL.json` binds `PILOT_NEURAL_INDEX_ALL_CACHE_IMMUTABLE.json`; the separate `PILOT_NEURAL_INDEX_FIRST_NATIVE_IMMUTABLE.json` resolves the earlier validation receipt. All 64 native receipt paths and hashes are identical across the two index versions, and final validation passes with zero neural reruns. The earlier validation and convenience index are retained as historical evidence.

## Gain-journal audit convenience pointer

The independent gain audit completed all 176 challenge journals for R6 and R6_FULL_RMS with zero payload mismatches or missing jobs. A Windows sharing denial occurred only while updating its small `LATEST` pointer after the immutable timestamped audit had already been saved. The pointer was repaired from the saved bytes after verifying the audit hash. Neither audit nor inference was repeated. The authoritative result is `independent_review/gain_pcm_audits/AUDIT_20260910T003902490258Z.json`.

## Endpoint audit event selector

The first full challenge mechanism audit passed all 3,872 tracker rows but failed accepted-endpoint-advice counter parity in 22 native R0_ENDPOINT jobs. The extractor searched for `research_asr_dispatch_cost`; the frozen application actually emits `research_asr_full_dispatch_cost`. Existing raw events contained the accepted advice and matching resets. The original failed audit and extractor source were preserved, the selector was corrected, and a targeted actual-schema fixture was added. This is a model-free reporting correction; frozen application, inputs and native predictions were unchanged. The separate final audit and its coverage receipt carry the corrected outcome and supersession link.
