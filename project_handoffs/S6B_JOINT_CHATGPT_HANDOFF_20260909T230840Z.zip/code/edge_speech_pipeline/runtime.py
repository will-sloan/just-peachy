"""Independent-lane runtime: capture, ASR, and speaker work never share a queue."""

from __future__ import annotations

from datetime import datetime, timezone
from collections import deque
import json
import os
from pathlib import Path
import queue
import threading
import time
import uuid

import numpy as np

from .audio import AudioJournal, MicrophoneSource, WavSource
from .config import PipelineConfig
from .contracts import PipelineEvent, SpeakerDecision, SpatialEvidence
from .enrollment import (
    EnrollmentRecorder,
    enroll_wavs,
    enrollment_recording_path,
    record_microphone_wav,
)
from .models import SherpaStream, SpeakerModels
from .speakers import ProfileStore, SpeakerTracker
from .text_format import format_partial_display


class PipelineEngine:
    """One session at a time, backed by persistent model objects."""

    def __init__(self, config: PipelineConfig | None = None, *, research_profile=None, spatial_provider=None, model_bundle=None) -> None:
        self.config = research_profile.apply(config) if research_profile is not None else config or PipelineConfig()
        self._research_profile = research_profile
        self._research_v2 = getattr(research_profile, "schema_version", None) == "edge-research-profile.v2"
        self._model_bundle = model_bundle
        self._bundle_acquired = False
        self._scheduler = None
        self._research_utterance_start_sec = 0.0
        self._research_asr_event_serial = 0
        self._spatial_provider = spatial_provider
        if research_profile is not None and research_profile.xvf.mode != "none" and spatial_provider is None:
            raise ValueError("a cue-enabled profile requires an explicit causal spatial provider")
        self._research_speaker_history = deque(maxlen=4096)
        self._research_segmentation_history = deque(maxlen=4096)
        self._research_asr_available_sec = 0.0
        self.events: queue.SimpleQueue[PipelineEvent] = queue.SimpleQueue()
        self._event_lock = threading.Lock()
        self._speaker_lock = threading.Lock()
        self._models_lock = threading.Lock()
        self._speaker_models: SpeakerModels | None = None
        self._enrollment_recorder: EnrollmentRecorder | None = None
        self._enrollment_name: str | None = None
        self._last_enrollment_status: dict[str, object] = {
            "active": False,
            "duration_sec": 0.0,
        }
        self._source: MicrophoneSource | WavSource | None = None
        self._journal: AudioJournal | None = None
        self._event_handle = None
        self._transcript_handle = None
        self._readable_transcript_handle = None
        self._session_dir: Path | None = None
        self._threads: list[threading.Thread] = []
        self._finalization_thread: threading.Thread | None = None
        self._finalization_error: Exception | None = None
        self._stop_event = threading.Event()
        self._current_speaker: SpeakerDecision | None = None
        self._overlap_active = False
        self._state = "IDLE"
        self._started_monotonic = 0.0
        self._telemetry: dict[str, object] = {
            "audio_frames_dropped": 0,
            "portaudio_input_overflows": 0,
            "raw_capture_reserve_failures": 0,
            "asr_cursor_sec": 0.0,
            "speaker_cursor_sec": 0.0,
            "speaker_analyzed_through_sec": 0.0,
            "speaker_unanalyzed_short_tail_sec": 0.0,
            "asr_lag_sec": 0.0,
            "speaker_lag_sec": 0.0,
            "punctuation_utterances": 0,
            "punctuation_total_ms": 0.0,
            "punctuation_max_ms": 0.0,
            "punctuation_fallbacks": 0,
            "punctuation_terminal_fallbacks": 0,
            "punctuation_inference_failures": 0,
        }

    @property
    def state(self) -> str:
        return self._state

    @property
    def session_dir(self) -> Path | None:
        return self._session_dir

    def _ensure_speaker_models(self) -> SpeakerModels:
        with self._models_lock:
            if self._speaker_models is None:
                self._speaker_models = SpeakerModels(self.config)
            return self._speaker_models

    def enroll_files(self, display_name: str, wav_paths: list[Path]) -> dict[str, object]:
        """Backend-owned enrollment entry point used identically by GUI and CLI."""

        return enroll_wavs(
            display_name,
            wav_paths,
            models=self._ensure_speaker_models(),
            config=self.config,
        )

    def enroll_microphone(
        self,
        display_name: str,
        *,
        device: int | None,
        duration_sec: float = 6.0,
    ) -> dict[str, object]:
        output = enrollment_recording_path(self.config.profile_root, display_name)
        recorded = record_microphone_wav(
            output, device=device, duration_sec=duration_sec
        )
        return self.enroll_files(display_name, [recorded])

    def start_enrollment_recording(
        self, display_name: str, *, device: int | None
    ) -> dict[str, object]:
        """Start an unlimited disk-backed enrollment recording."""

        name = display_name.strip()
        if not name:
            raise ValueError("display name is required")
        if self._state not in {"IDLE", "COMPLETED", "FAILED"}:
            raise RuntimeError("stop the transcript session before enrollment")
        if self._enrollment_recorder is not None:
            raise RuntimeError("an enrollment recording is already active")
        recorder = EnrollmentRecorder(
            enrollment_recording_path(self.config.profile_root, name),
            device=device,
            preferred_rate=self.config.sample_rate,
            block_ms=self.config.capture_block_ms,
            reserve_sec=self.config.raw_capture_reserve_sec,
        )
        self._enrollment_recorder = recorder
        self._enrollment_name = name
        try:
            status = recorder.start()
        except Exception:
            self._enrollment_recorder = None
            self._enrollment_name = None
            raise
        self._last_enrollment_status = dict(status)
        return status

    def stop_enrollment_recording(self) -> dict[str, object]:
        """Stop capture, quality-check all audio, and build the local profile."""

        recorder = self._enrollment_recorder
        name = self._enrollment_name
        if recorder is None or name is None:
            raise RuntimeError("no enrollment recording is active")
        try:
            path = recorder.stop()
            self._last_enrollment_status = dict(recorder.status())
        finally:
            self._enrollment_recorder = None
            self._enrollment_name = None
        return self.enroll_files(name, [path])

    def cancel_enrollment_recording(self) -> None:
        recorder = self._enrollment_recorder
        if recorder is not None:
            recorder.cancel()
            self._last_enrollment_status = dict(recorder.status())
        self._enrollment_recorder = None
        self._enrollment_name = None

    def enrollment_recording_status(self) -> dict[str, object]:
        if self._enrollment_recorder is not None:
            self._last_enrollment_status = dict(
                self._enrollment_recorder.status()
            )
        return dict(self._last_enrollment_status)

    def start_live(self, device: int | None = None) -> Path:
        self._begin_session("microphone")
        assert self._journal is not None
        source = MicrophoneSource(
            self._journal,
            device=device,
            target_rate=self.config.sample_rate,
            block_ms=self.config.capture_block_ms,
            reserve_sec=self.config.raw_capture_reserve_sec,
            status_callback=self._source_status,
        )
        return self._launch(source)

    def start_file(
        self, path: Path, *, realtime: bool = True, accelerated_factor: float = 4.0
    ) -> Path:
        self._begin_session("wav")
        assert self._journal is not None
        source = WavSource(
            self._journal,
            path,
            target_rate=self.config.sample_rate,
            realtime=realtime,
            accelerated_factor=accelerated_factor,
            status_callback=self._source_status,
        )
        return self._launch(source)

    def _begin_session(self, mode: str) -> None:
        if self._enrollment_recorder is not None:
            raise RuntimeError(
                "stop or cancel enrollment recording before starting transcription"
            )
        if self._state not in {"IDLE", "COMPLETED", "FAILED"}:
            raise RuntimeError(f"a session is already {self._state.lower()}")
        if self._finalization_thread is not None and self._finalization_thread.is_alive():
            raise RuntimeError("the previous session is still finalizing its artifacts")
        self._finalization_thread = None
        self._finalization_error = None
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        self._session_dir = self.config.session_root / f"edge_{mode}_{stamp}_{uuid.uuid4().hex[:8]}"
        self._session_dir.mkdir(parents=True, exist_ok=False)
        self._journal = AudioJournal(self._session_dir / "audio_spool.pcm16", self.config.sample_rate)
        self._event_handle = (self._session_dir / "events.jsonl").open("a", encoding="utf-8", buffering=1)
        self._transcript_handle = (self._session_dir / "labelled_transcript.jsonl").open("a", encoding="utf-8", buffering=1)
        self._readable_transcript_handle = (self._session_dir / "transcript.md").open("a", encoding="utf-8", buffering=1)
        self._readable_transcript_handle.write("# Session transcript\n\n")
        self._stop_event.clear()
        self._current_speaker = None
        self._overlap_active = False
        self._research_speaker_history.clear()
        self._research_segmentation_history.clear()
        self._research_asr_available_sec = 0.0
        self._research_utterance_start_sec = 0.0
        self._research_asr_event_serial = 0
        if self._research_v2:
            from .research_scheduler import CausalScheduler
            from .research_tracking_v2 import S6BTracker
            self._scheduler = CausalScheduler(S6BTracker(self._research_profile.tracker),
                spatial_provider=self._spatial_provider,
                cues_enabled=self._research_profile.xvf.mode in {"tracking_only", "both"},
                revision_horizon_sec=self._research_profile.scheduler.revision_horizon_sec,
                evidence_expiry_sec=self._research_profile.scheduler.evidence_expiry_sec,
                max_pending_events=self._research_profile.scheduler.max_pending_events,
                max_events=self._research_profile.scheduler.max_events,
                max_utterances=self._research_profile.scheduler.max_utterances,
                max_revisions_per_utterance=self._research_profile.scheduler.max_revisions_per_utterance,
                emit=self._scheduled_event)
        self._state = "LOADING"
        self._started_monotonic = time.perf_counter()
        self._telemetry.update({"audio_frames_dropped": 0, "portaudio_input_overflows": 0, "raw_capture_reserve_failures": 0, "asr_cursor_sec": 0.0, "speaker_cursor_sec": 0.0, "speaker_analyzed_through_sec": 0.0, "speaker_unanalyzed_short_tail_sec": 0.0, "asr_lag_sec": 0.0, "speaker_lag_sec": 0.0, "punctuation_utterances": 0, "punctuation_total_ms": 0.0, "punctuation_max_ms": 0.0, "punctuation_fallbacks": 0, "punctuation_terminal_fallbacks": 0, "punctuation_inference_failures": 0})
        self._emit("session_created", 0.0, {"mode": mode, "session_dir": str(self._session_dir), "xvf_result_effects_enabled": self._research_profile is not None and self._research_profile.xvf.mode != "none"})
        if self._research_profile is not None:
            effective = self._research_profile.effective(self.config)
            effective["telemetry_sha256"] = getattr(self._spatial_provider, "sha256", None)
            self._emit("research_effective_config", 0.0, effective)

    def _launch(self, source: MicrophoneSource | WavSource) -> Path:
        assert self._session_dir is not None
        try:
            model_load_started = time.perf_counter()
            if self._model_bundle is None:
                models = self._ensure_speaker_models()
                asr = SherpaStream(self.config)
            else:
                models, asr = self._model_bundle.acquire(self.config)
                self._bundle_acquired = True
            if self._research_profile is not None:
                self._emit("research_models_ready", 0.0, {"model_load_elapsed_sec": time.perf_counter() - model_load_started, "session_elapsed_sec": time.perf_counter() - self._started_monotonic, "capture_not_started": True, "modeled_availability_origin": "source start after model loading; warm-resident serial lanes, loading excluded and separately measured"})
                if self._model_bundle is not None:
                    self._emit("research_resident_bundle", 0.0, {"bundle_admission_elapsed_sec": getattr(self._model_bundle, "admission_elapsed_sec", None),
                        "session_index": getattr(self._model_bundle, "sessions_created", None), "fresh_asr_stream": True,
                        "fresh_tracker_scheduler_endpoint_state": True, "weights_reused": True,
                        "admitted_files_must_remain_immutable": True})
            self._source = source
            self._threads = [
                threading.Thread(target=self._asr_loop, args=(asr,), name="edge-asr", daemon=True),
                threading.Thread(target=self._speaker_loop, args=(models,), name="edge-speaker", daemon=True),
            ]
            # Publish startup before any worker can report a terminal failure.
            self._state = "RUNNING"
            self._emit("session_started", 0.0, {"state": self._state})
            for thread in self._threads:
                thread.start()
            source.start()
            watcher = threading.Thread(target=self._watch_session, name="edge-session-watcher", daemon=True)
            self._finalization_thread = watcher
            self._threads.append(watcher)
            watcher.start()
            return self._session_dir
        except Exception as exc:
            self._fail(f"session launch failed: {exc}")
            cleanup = threading.Thread(
                target=self._watch_session,
                name="edge-failed-launch-cleanup",
                daemon=True,
            )
            self._finalization_thread = cleanup
            self._threads.append(cleanup)
            cleanup.start()
            raise

    def pause(self) -> None:
        if self._source is None or self._state != "RUNNING":
            return
        self._source.pause()
        self._state = "PAUSED"
        self._emit("session_paused", self._source_time(), {"intentional_audio_exclusion": True})

    def resume(self) -> None:
        if self._source is None or self._state != "PAUSED":
            return
        self._source.resume()
        self._state = "RUNNING"
        self._emit("session_resumed", self._source_time(), {})

    def stop(self) -> None:
        if self._state in {"IDLE", "COMPLETED", "FAILED"}:
            return
        self._state = "STOPPING"
        self._stop_event.set()
        if self._source is not None:
            self._source.stop()

    def _asr_loop(self, asr: SherpaStream) -> None:
        assert self._journal is not None
        cursor = 0
        read_size = round(self.config.sample_rate * self.config.journal_read_ms / 1000)
        last_partial = ""
        pending = np.empty(0, dtype=np.float32)
        last_display_sec = float("-inf")
        utterance_start_sec = 0.0
        advisor = None
        if self._research_v2 and self._research_profile.xvf.mode in {"endpoint_only", "both"}:
            from .research_profiles import EndpointAdvisorV2
            advisor = EndpointAdvisorV2(self._research_profile)
        elif self._research_profile is not None and "advisory" in self._research_profile.xvf.mode:
            from .research_profiles import EndpointAdvisor
            advisor = EndpointAdvisor(self._research_profile)
        try:
            while True:
                audio = self._journal.read(cursor, read_size)
                if audio.size:
                    cursor += int(audio.size)
                    pending = np.concatenate((pending, audio))
                    while pending.size >= read_size:
                        block, pending = pending[:read_size], pending[read_size:]
                        source_sec = (cursor - pending.size) / self.config.sample_rate
                        if self.config.input_gain != 1.0:
                            block = block * np.float32(self.config.input_gain)
                        decode_started = time.perf_counter()
                        text, endpoint = asr.accept(block)
                        if self._research_profile is not None:
                            self._research_asr_available_sec = max(self._research_asr_available_sec, source_sec) + asr.decode_ms / 1000.0
                        native_endpoint = endpoint
                        advisory_endpoint = False
                        advisor_sec = 0.0
                        if advisor is not None:
                            advisor_started = time.perf_counter()
                            observation = self._spatial_provider.evidence(source_sec - block.size / self.config.sample_rate, source_sec)
                            advisory_endpoint = advisor.observe(observation, source_sec, float(np.sqrt(np.mean(np.square(block), dtype=np.float64))), block.size / self.config.sample_rate, utterance_start_sec)
                            endpoint = endpoint or advisory_endpoint
                            advisor_sec = time.perf_counter() - advisor_started
                            if self._research_v2:
                                self._research_asr_available_sec += advisor_sec
                        if self._research_profile is not None:
                            self._emit("research_asr_dispatch", source_sec, {"source_start_sec": source_sec - block.size / self.config.sample_rate, "source_end_sec": source_sec, "receptive_start_sec": utterance_start_sec, "available_source_cursor_sec": source_sec, "modeled_available_at_sec": self._research_asr_available_sec, "availability_method": "serial lane max(previous available, input end) + measured compute; modeled, not calibrated live latency", "compute_ms": asr.decode_ms, "compute_started_elapsed_sec": decode_started - self._started_monotonic, "compute_finished_elapsed_sec": time.perf_counter() - self._started_monotonic, "native_endpoint": native_endpoint, "advisory_endpoint": advisory_endpoint, "reset_requested": endpoint})
                        self._telemetry["asr_cursor_sec"] = source_sec
                        self._telemetry["asr_lag_sec"] = max(0.0, self._journal.duration_sec - source_sec)
                        if text and text != last_partial and source_sec - last_display_sec >= self.config.partial_display_min_interval_sec:
                            self._transcript_event(text, source_sec, final=False, utterance=asr.utterance_index, decode_ms=asr.decode_ms)
                            last_partial = text
                            last_display_sec = source_sec
                        if endpoint:
                            reset_started = time.perf_counter()
                            final = asr.reset_endpoint()
                            if self._research_v2:
                                reset_sec = time.perf_counter() - reset_started
                                self._research_asr_available_sec += reset_sec
                                self._emit("research_asr_reset", source_sec, {"compute_ms": reset_sec * 1000, "available_at_sec": self._research_asr_available_sec, "native_endpoint": native_endpoint, "advisory_endpoint": advisory_endpoint, "advisor": getattr(advisor, "last_status", None)})
                            if final:
                                punctuation = asr.punctuate(final)
                                self._record_punctuation(punctuation)
                                self._transcript_event(final, source_sec, final=True, utterance=asr.utterance_index - 1, decode_ms=asr.decode_ms, punctuation=punctuation)
                            last_partial = ""
                            utterance_start_sec = source_sec
                            self._research_utterance_start_sec = source_sec
                        if self._research_v2:
                            self._scheduler_advance("asr", source_sec, self._research_asr_available_sec)
                            self._emit("research_asr_full_dispatch_cost", source_sec, {"source_start_sec": source_sec - block.size / self.config.sample_rate,
                                "source_end_sec": source_sec, "decode_compute_ms": asr.decode_ms,
                                "advisor_compute_ms": advisor_sec * 1000.0, "advisor": getattr(advisor, "last_status", None),
                                "full_dispatch_elapsed_ms": (time.perf_counter() - decode_started) * 1000.0,
                                "modeled_available_at_sec": self._research_asr_available_sec,
                                "policy_export_in_full_elapsed_not_shared_clock": True})
                elif self._journal.finished and cursor >= self._journal.committed_samples:
                    break
            if pending.size:
                if self.config.input_gain != 1.0:
                    pending = pending * np.float32(self.config.input_gain)
                asr.accept(pending)
                if self._research_profile is not None:
                    source_sec = cursor / self.config.sample_rate
                    self._research_asr_available_sec = max(self._research_asr_available_sec, source_sec) + asr.decode_ms / 1000.0
                    self._emit("research_asr_tail_dispatch", source_sec, {"source_start_sec": source_sec - pending.size / self.config.sample_rate, "source_end_sec": source_sec, "samples": int(pending.size), "compute_ms": asr.decode_ms, "modeled_available_at_sec": self._research_asr_available_sec, "compute_finished_elapsed_sec": time.perf_counter() - self._started_monotonic})
            self._telemetry["asr_cursor_sec"] = cursor / self.config.sample_rate
            self._telemetry["asr_lag_sec"] = 0.0
            drain_started = time.perf_counter()
            final = asr.finish()
            drain_ms = (time.perf_counter() - drain_started) * 1000.0
            if self._research_profile is not None:
                self._research_asr_available_sec = max(self._research_asr_available_sec, cursor / self.config.sample_rate) + drain_ms / 1000.0
                self._emit("research_asr_drain", cursor / self.config.sample_rate, {"source_end_sec": cursor / self.config.sample_rate, "synthetic_right_padding_sec": 0.66, "padding_is_observed_audio": False, "compute_ms": drain_ms, "modeled_available_at_sec": self._research_asr_available_sec, "compute_finished_elapsed_sec": time.perf_counter() - self._started_monotonic})
            if final:
                punctuation = asr.punctuate(final)
                self._record_punctuation(punctuation)
                self._transcript_event(final, cursor / self.config.sample_rate, final=True, utterance=asr.utterance_index, decode_ms=drain_ms if self._research_profile is not None else asr.decode_ms, punctuation=punctuation)
        except Exception as exc:
            self._fail(f"ASR lane failed: {exc}")
        finally:
            if self._research_v2 and self._scheduler is not None:
                self._scheduler_advance("asr", float("inf"), self._research_asr_available_sec)

    def _speaker_loop(self, models: SpeakerModels) -> None:
        if self._research_v2:
            return self._speaker_loop_v2(models)
        assert self._journal is not None
        cursor = 0
        read_size = round(self.config.sample_rate * self.config.embedding_hop_sec)
        segmentation_hop = round(self.config.sample_rate * self.config.segmentation_hop_sec)
        segmentation_window = round(self.config.sample_rate * self.config.segmentation_window_sec)
        embedding_window = round(self.config.sample_rate * self.config.embedding_window_sec)
        rolling = np.empty(0, dtype=np.float32)
        pending = np.empty(0, dtype=np.float32)
        since_segment = 0
        speech = False
        overlap = False
        speaker_available_sec = 0.0
        tracker = SpeakerTracker(
            self.config,
            ProfileStore(
                self.config.profile_root,
                expected_backend_sha256=self.config.asset("redimnet2_b2_fp32").sha256,
            ),
        )
        research_tracker = None
        if self._research_profile is not None and self._research_profile.tracker.mode != "baseline":
            from dataclasses import asdict
            from .research_tracking import ResearchTracker, TrackingConfig
            values = asdict(self._research_profile.tracker)
            values = {key: value for key, value in values.items() if not key.startswith("identity_")}
            research_tracker = ResearchTracker(TrackingConfig(**values))
        try:
            while True:
                audio = self._journal.read(cursor, read_size)
                if audio.size:
                    cursor += int(audio.size)
                    pending = np.concatenate((pending, audio))
                    while pending.size >= read_size:
                        block, pending = pending[:read_size], pending[read_size:]
                        source_sec = (cursor - pending.size) / self.config.sample_rate
                        if self.config.input_gain != 1.0:
                            block = block * np.float32(self.config.input_gain)
                        rolling = np.concatenate((rolling, block))[-segmentation_window:]
                        since_segment += int(block.size)
                        if since_segment >= segmentation_hop:
                            since_segment %= segmentation_hop
                            padded = np.pad(rolling, (segmentation_window - rolling.size, 0))
                            views = models.segment(padded)
                            speaker_available_sec = max(speaker_available_sec, source_sec) + models.last_segment_ms / 1000.0
                            from .research_profiles import segmentation_gate, spatial_is_fresh
                            assist = 0.0
                            if self._research_profile is not None and "soft_energy" in self._research_profile.xvf.mode:
                                observation = self._spatial_provider.evidence(max(0.0, source_sec - self.config.segmentation_hop_sec), source_sec)
                                if spatial_is_fresh(observation, speaker_available_sec, self._research_profile) and observation.energy is not None and np.isfinite(observation.energy) and observation.energy > 0:
                                    assist = self._research_profile.xvf.speech_assist_delta
                            gate = segmentation_gate(views, self.config, speech, speech_assist_delta=assist)
                            speech, overlap = gate["speech"], gate["overlap"]
                            speech_fraction, overlap_fraction = gate["speech_fraction"], gate["overlap_fraction"]
                            with self._speaker_lock:
                                self._overlap_active = overlap
                                if self._research_profile is not None:
                                    self._research_segmentation_history.append((source_sec, overlap, speaker_available_sec))
                            self._emit("segmentation", source_sec, {"speech": speech, "overlap": overlap, "speech_fraction": speech_fraction, "overlap_fraction": overlap_fraction, "compute_ms": models.last_segment_ms})
                            if self._research_profile is not None:
                                self._emit("research_segmentation", source_sec, {**gate, "source_start_sec": max(0.0, source_sec - self.config.segmentation_hop_sec), "source_end_sec": source_sec, "receptive_start_sec": max(0.0, source_sec - 10.0), "receptive_end_sec": source_sec, "left_padding_sec": max(0.0, 10.0 - source_sec), "available_source_cursor_sec": source_sec, "modeled_available_at_sec": speaker_available_sec, "compute_ms": models.last_segment_ms, "compute_finished_elapsed_sec": time.perf_counter() - self._started_monotonic, "frame_step_sec": 0.016875, "frame_duration_sec": 0.0619375, "local_speakers_are_per_invocation": True})
                        rms = float(np.sqrt(np.mean(np.square(block), dtype=np.float64)))
                        if speech and not overlap and rolling.size >= embedding_window and rms >= self.config.minimum_rms:
                            vector = models.embed(rolling[-embedding_window:])
                            speaker_available_sec = max(speaker_available_sec, source_sec) + models.last_embed_ms / 1000.0
                            research_decision = None
                            if research_tracker is not None:
                                from .research_tracking import decision_to_speaker
                                observation = self._spatial_provider.evidence(max(0.0, source_sec - self.config.embedding_window_sec), source_sec) if self._spatial_provider is not None and self._research_profile.xvf.mode != "none" else None
                                research_decision = research_tracker.update(vector, max(0.0, source_sec - self.config.embedding_window_sec), source_sec, speaker_available_sec, spatial=observation, speech=speech, overlap=overlap)
                                decision = decision_to_speaker(research_decision)
                            else:
                                decision = tracker.update(vector, source_sec)
                            with self._speaker_lock:
                                self._current_speaker = decision
                                if self._research_profile is not None:
                                    self._research_speaker_history.append((source_sec, decision, overlap, speaker_available_sec))
                            self._emit("speaker_decision", source_sec, {**decision.to_jsonable(), "embedding_compute_ms": models.last_embed_ms, "spatial_evidence": SpatialEvidence(max(0.0, source_sec - self.config.embedding_window_sec), source_sec).to_jsonable()})
                            if self._research_profile is not None:
                                self._emit("research_embedding", source_sec, {"source_start_sec": max(0.0, source_sec - self.config.embedding_window_sec), "source_end_sec": source_sec, "receptive_start_sec": max(0.0, source_sec - self.config.embedding_window_sec), "receptive_end_sec": source_sec, "available_source_cursor_sec": source_sec, "modeled_available_at_sec": speaker_available_sec, "availability_method": "serial speaker lane with segmentation and embedding compute charged", "compute_finished_elapsed_sec": time.perf_counter() - self._started_monotonic, "compute_ms": models.last_embed_ms, "block_rms": rms, "normalized_embedding": vector.tolist(), "decision": research_decision or decision.to_jsonable()})
                        self._telemetry["speaker_cursor_sec"] = source_sec
                        self._telemetry["speaker_analyzed_through_sec"] = source_sec
                        self._telemetry["speaker_lag_sec"] = max(0.0, self._journal.duration_sec - source_sec)
                elif self._journal.finished and cursor >= self._journal.committed_samples:
                    break
            self._telemetry["speaker_cursor_sec"] = cursor / self.config.sample_rate
            self._telemetry["speaker_unanalyzed_short_tail_sec"] = pending.size / self.config.sample_rate
            self._telemetry["speaker_lag_sec"] = 0.0
        except Exception as exc:
            self._fail(f"speaker lane failed: {exc}")

    def _speaker_loop_v2(self, models):
        from .research_profiles import segmentation_gate
        from .research_scheduler import EmbeddingAdmission
        assert self._journal is not None and self._scheduler is not None
        cursor = 0
        size = round(self.config.sample_rate * self.config.embedding_hop_sec)
        seg_hop = round(self.config.sample_rate * self.config.segmentation_hop_sec)
        rolling = np.empty(0, dtype=np.float32)
        pending = np.empty(0, dtype=np.float32)
        since_segment = 0
        speech = overlap = False
        ready = 0.0
        seg_serial = embed_serial = 0
        admission = EmbeddingAdmission(self._research_profile)
        try:
            while True:
                audio = self._journal.read(cursor, size)
                if audio.size:
                    cursor += int(audio.size)
                    pending = np.concatenate((pending, audio))
                    while pending.size >= size:
                        block_started = time.perf_counter()
                        block, pending = pending[:size], pending[size:]
                        end = (cursor - pending.size) / self.config.sample_rate
                        if self.config.input_gain != 1.0:
                            block = block * np.float32(self.config.input_gain)
                        rolling = np.concatenate((rolling, block))[-160000:]
                        since_segment += int(block.size)
                        segment_ms = 0.0
                        if since_segment >= seg_hop:
                            since_segment %= seg_hop
                            segment_call_started = time.perf_counter()
                            views = models.segment(np.pad(rolling, (160000 - rolling.size, 0)), include_posteriors=True)
                            segment_ms = models.last_segment_ms
                            segment_api_sec = time.perf_counter() - segment_call_started
                            post_started = time.perf_counter()
                            gate = segmentation_gate(views, self.config, speech)
                            speech, overlap = gate["speech"], gate["overlap"]
                            admission.segmentation(views, end)
                            post_sec = time.perf_counter() - post_started
                            ready = max(ready, end) + segment_api_sec + post_sec
                            seg_serial += 1
                            payload = {**gate, "source_start_sec": max(0.0, end - self.config.segmentation_hop_sec),
                                "source_end_sec": end, "receptive_start_sec": max(0.0, end - 10.0), "receptive_end_sec": end,
                                "left_padding_sec": max(0.0, 10.0 - end), "modeled_available_at_sec": ready,
                                "compute_ms": segment_ms, "postprocess_compute_ms": post_sec * 1000.0,
                                "model_api_elapsed_ms": segment_api_sec * 1000.0,
                                "compute_finished_elapsed_sec": time.perf_counter() - self._started_monotonic,
                                "frame_step_sec": .016875, "frame_duration_sec": .0619375,
                                "speech_frames": np.asarray(views["speech"]).tolist(), "overlap_frames": np.asarray(views["overlap"]).tolist(),
                                "speech_probability_frames": np.asarray(views["speech_probability"]).tolist(),
                                "overlap_probability_frames": np.asarray(views["overlap_probability"]).tolist()}
                            self._emit("research_segmentation", end, payload)
                            self._emit("segmentation", end, {**gate, "compute_ms": segment_ms})
                            self._scheduler.push({"kind": "segmentation", "event_id": f"seg:{seg_serial:08d}",
                                "source_start_sec": payload["source_start_sec"], "source_end_sec": end,
                                "available_at_sec": ready, "speech": speech, "overlap": overlap}, lane="speaker")
                        gate_started = time.perf_counter()
                        observation = self._spatial_provider.evidence(max(0.0, end - self.config.embedding_window_sec), end) if self._research_profile.embedding.cadence_cues_enabled else None
                        embedding_size, diagnostic = admission.candidate(rolling, block, end, speech, overlap, observation)
                        gate_sec = time.perf_counter() - gate_started
                        ready = max(ready, end) + gate_sec
                        self._emit("research_embedding_admission", end, {**diagnostic, "compute_ms": gate_sec * 1000.0, "modeled_available_at_sec": ready})
                        embed_ms = 0.0
                        if embedding_size is not None:
                            embed_call_started = time.perf_counter()
                            vector = models.embed(rolling[-embedding_size:])
                            embed_ms = models.last_embed_ms
                            embed_api_sec = time.perf_counter() - embed_call_started
                            ready += embed_api_sec
                            admission.admitted(vector, end)
                            embed_serial += 1
                            start = end - embedding_size / self.config.sample_rate
                            self._emit("research_embedding", end, {"source_start_sec": start, "source_end_sec": end,
                                "receptive_start_sec": start, "receptive_end_sec": end,
                                "available_source_cursor_sec": end, "modeled_available_at_sec": ready,
                                "availability_method": "serial neural+postprocess+gate lane; scheduler policy cost separate",
                                "compute_finished_elapsed_sec": time.perf_counter() - self._started_monotonic,
                                "compute_ms": embed_ms, "normalized_embedding": vector.tolist(), "admission": diagnostic,
                                "model_api_elapsed_ms": embed_api_sec * 1000.0,
                                "speech": speech, "overlap": overlap, "evidence_event_id": f"embedding:{embed_serial:08d}"})
                            self._scheduler.push({"kind": "embedding", "event_id": f"embedding:{embed_serial:08d}",
                                "vector": vector.tolist(), "source_start_sec": start, "source_end_sec": end,
                                "available_at_sec": ready, "speech": speech, "overlap": overlap}, lane="speaker")
                        before_scheduler = time.perf_counter()
                        self._scheduler_advance("speaker", end, ready)
                        self._emit("research_speaker_dispatch_cost", end, {"source_start_sec": end - size / self.config.sample_rate,
                            "source_end_sec": end, "segment_compute_ms": segment_ms, "embedding_compute_ms": embed_ms,
                            "gate_compute_ms": gate_sec * 1000.0,
                            "scheduler_dispatch_ms": (time.perf_counter() - before_scheduler) * 1000.0,
                            "full_dispatch_elapsed_ms": (time.perf_counter() - block_started) * 1000.0,
                            "modeled_available_at_sec": ready})
                        self._telemetry.update(speaker_cursor_sec=end, speaker_analyzed_through_sec=end,
                            speaker_lag_sec=max(0.0, self._journal.duration_sec - end))
                elif self._journal.finished and cursor >= self._journal.committed_samples:
                    break
            self._telemetry.update(speaker_cursor_sec=cursor / self.config.sample_rate,
                speaker_unanalyzed_short_tail_sec=pending.size / self.config.sample_rate, speaker_lag_sec=0.0)
        except Exception as exc:
            self._fail(f"S6B speaker lane failed: {exc}")
        finally:
            self._scheduler_advance("speaker", float("inf"), ready)

    def _scheduler_advance(self, lane, lower_bound, modeled_lane_ready):
        closed = lower_bound == float("inf")
        self._emit("research_scheduler_watermark", self._source_time() if closed else lower_bound,
            {"lane": lane, "lower_bound_sec": None if closed else lower_bound, "lane_closed": closed,
             "modeled_lane_ready_sec": modeled_lane_ready,
             "compute_finished_elapsed_sec": time.perf_counter() - self._started_monotonic})
        return self._scheduler.advance({lane: lower_bound})

    def _scheduled_event(self, record):
        kind = record["event_type"]
        source_sec = record["source_end_sec"]
        payload = {**record, "modeled_available_at_sec": record["available_at_sec"],
                   "compute_finished_elapsed_sec": time.perf_counter() - self._started_monotonic}
        if kind == "speaker_decision":
            payload.update(record["decision"])
        self._emit(kind, source_sec, payload)
        if kind == "transcript_final":
            with self._event_lock:
                if self._transcript_handle is not None:
                    self._transcript_handle.write(json.dumps({"schema_version": "edge-labelled-transcript.v2", **payload}, ensure_ascii=False) + "\n")
                if self._readable_transcript_handle is not None:
                    self._readable_transcript_handle.write(f'**{payload["first_final_label"]}:** {payload["display_text"]}\n\n')

    def _write_revised_transcript(self):
        if self._session_dir is None or self._scheduler is None:
            return
        snapshot = self._scheduler.snapshot()
        path = self._session_dir / "latest_labelled_transcript.jsonl"
        with path.open("x", encoding="utf-8") as handle:
            for row in snapshot["utterances"]:
                if row["is_final"]:
                    handle.write(json.dumps({"schema_version": "edge-latest-labelled-transcript.v2", **row}, ensure_ascii=False) + "\n")
            handle.flush()
            os.fsync(handle.fileno())

    def _record_punctuation(self, result: dict[str, object]) -> None:
        compute_ms = float(result.get("compute_ms", 0.0))
        if self._research_profile is not None:
            self._research_asr_available_sec += compute_ms / 1000.0
        self._telemetry["punctuation_utterances"] = int(
            self._telemetry["punctuation_utterances"]
        ) + 1
        self._telemetry["punctuation_total_ms"] = float(
            self._telemetry["punctuation_total_ms"]
        ) + compute_ms
        self._telemetry["punctuation_max_ms"] = max(
            float(self._telemetry["punctuation_max_ms"]), compute_ms
        )
        terminal_fallback = result.get("terminal_fallback") is not None
        inference_failure = result.get("status") == "fallback"
        if terminal_fallback or inference_failure:
            self._telemetry["punctuation_fallbacks"] = int(
                self._telemetry["punctuation_fallbacks"]
            ) + 1
        if terminal_fallback:
            self._telemetry["punctuation_terminal_fallbacks"] = int(
                self._telemetry["punctuation_terminal_fallbacks"]
            ) + 1
        if inference_failure:
            self._telemetry["punctuation_inference_failures"] = int(
                self._telemetry["punctuation_inference_failures"]
            ) + 1

    def _transcript_event(self, text: str, source_sec: float, *, final: bool, utterance: int, decode_ms: float, punctuation: dict[str, object] | None = None) -> None:
        if self._research_v2:
            self._research_asr_event_serial += 1
            observation = {"kind": "asr", "event_id": f"asr:{self._research_asr_event_serial:08d}",
                "utterance_id": f"utterance:{utterance:06d}", "source_start_sec": self._research_utterance_start_sec,
                "source_end_sec": source_sec, "available_at_sec": self._research_asr_available_sec,
                "text": text, "final": final, "display_text": str(punctuation["text"]) if final and punctuation else format_partial_display(text),
                "punctuation": punctuation, "asr_decode_ms": decode_ms}
            self._emit("research_asr_observation", source_sec, observation)
            self._scheduler.push(observation, lane="asr")
            return
        with self._speaker_lock:
            decision = self._current_speaker
            overlap_active = self._overlap_active
            if self._research_profile is not None and self._research_profile.tracker.mode != "baseline":
                eligible = [item for item in self._research_speaker_history if item[0] <= source_sec and item[3] <= self._research_asr_available_sec]
                decision = eligible[-1][1] if eligible else None
                eligible_segmentation = [item for item in self._research_segmentation_history if item[0] <= source_sec and item[2] <= self._research_asr_available_sec]
                overlap_active = eligible_segmentation[-1][1] if eligible_segmentation else False
        base_label = decision.display_label if decision is not None else "Speaker_?"
        label = (
            f"{base_label} + overlapping speaker"
            if overlap_active
            else base_label
        )
        payload = {
            "text": text,
            "display_text": (
                str(punctuation["text"])
                if final and punctuation is not None
                else format_partial_display(text)
            ),
            "punctuation": punctuation,
            "is_final": final,
            "utterance_index": utterance,
            "speaker": label,
            "speaker_state": (
                "overlap_uncertain"
                if overlap_active
                else decision.state if decision else "pending"
            ),
            "overlap_detected": overlap_active,
            "asr_decode_ms": decode_ms,
        }
        if self._research_profile is not None:
            payload["modeled_available_at_sec"] = self._research_asr_available_sec
            payload["compute_finished_elapsed_sec"] = time.perf_counter() - self._started_monotonic
            payload["label_revision_of"] = None
            payload["first_display_is_preserved"] = True
        self._emit("transcript_final" if final else "transcript_partial", source_sec, payload)
        if final:
            row = {"schema_version": "edge-labelled-transcript.v1", "source_end_sec": source_sec, **payload}
            with self._event_lock:
                if self._transcript_handle is not None:
                    self._transcript_handle.write(json.dumps(row, ensure_ascii=False) + "\n")
                if self._readable_transcript_handle is not None:
                    self._readable_transcript_handle.write(
                        f'**{label}:** {payload["display_text"]}\n\n'
                    )

    def _source_status(self, kind: str, payload: dict[str, object]) -> None:
        if kind == "fatal":
            self._fail(str(payload.get("reason", "audio source failed")), payload)
        else:
            self._emit(kind, self._source_time(), payload)

    def _watch_session(self) -> None:
        # Source completion closes the journal; model lanes then drain their own cursors.
        try:
            while self._journal is not None and not self._journal.finished and self._state not in {"FAILED"}:
                time.sleep(0.1)
            if self._state == "FAILED" and self._source is not None:
                self._source.stop()
            for thread in list(self._threads):
                if thread is threading.current_thread() or thread.name == "edge-session-watcher":
                    continue
                thread.join(timeout=30.0)
                if thread.is_alive():
                    raise TimeoutError(f"session lane {thread.name} did not finish within 30 seconds")
            if self._research_v2 and self._scheduler is not None:
                self._scheduler.finish()
                self._telemetry["scheduler"] = self._scheduler.snapshot()
                self._write_revised_transcript()
            if isinstance(self._source, MicrophoneSource):
                self._telemetry["portaudio_input_overflows"] = self._source.input_overflow_events
                self._telemetry["raw_capture_reserve_failures"] = self._source.raw_reserve_failures
                self._telemetry["intentional_pause_samples"] = self._source.intentional_pause_samples
            if self._state != "FAILED":
                self._state = "COMPLETED"
                self._emit("session_completed", self._source_time(), {"telemetry": self.telemetry()})
            self._write_summary()
        except Exception as exc:
            self._finalization_error = exc
            try:
                self._fail(f"session finalization failed: {exc}")
            except Exception:
                # A failed event writer must still prevent successful CLI exit.
                self._state = "FAILED"
        finally:
            if self._bundle_acquired:
                self._model_bundle.release()
                self._bundle_acquired = False
            for attribute in ("_event_handle", "_transcript_handle", "_readable_transcript_handle"):
                handle = getattr(self, attribute)
                try:
                    if handle is not None:
                        handle.close()
                except Exception as exc:
                    if self._finalization_error is None:
                        self._finalization_error = exc
                    self._state = "FAILED"
                finally:
                    setattr(self, attribute, None)

    def wait_for_completion(self, timeout: float = 65.0) -> None:
        """Join the artifact writer before a caller reports successful exit."""
        writer = self._finalization_thread
        if writer is not None:
            if writer is threading.current_thread():
                raise RuntimeError("the session writer cannot join itself")
            writer.join(timeout=timeout)
            if writer.is_alive():
                raise TimeoutError(f"session finalization did not finish within {timeout:g} seconds")
        if self._finalization_error is not None:
            raise RuntimeError(f"session finalization failed: {self._finalization_error}") from self._finalization_error

    def _fail(self, reason: str, detail: dict[str, object] | None = None) -> None:
        if self._state == "FAILED":
            return
        self._state = "FAILED"
        self._stop_event.set()
        if self._source is not None:
            self._source.stop_event.set()
        if self._journal is not None:
            self._journal.finish(reason)
        self._emit("failure", self._source_time(), {"reason": reason, **(detail or {})})

    def _emit(self, event_type: str, source_sec: float, payload: dict[str, object]) -> None:
        event = PipelineEvent(event_type, source_sec, payload)
        self.events.put(event)
        with self._event_lock:
            if self._event_handle is not None:
                self._event_handle.write(json.dumps(event.to_jsonable(), ensure_ascii=False) + "\n")

    def _source_time(self) -> float:
        return self._journal.duration_sec if self._journal is not None else 0.0

    def telemetry(self) -> dict[str, object]:
        data = dict(self._telemetry)
        data.update({"state": self._state, "source_duration_sec": self._source_time(), "elapsed_wall_sec": max(0.0, time.perf_counter() - self._started_monotonic) if self._started_monotonic else 0.0, "session_dir": str(self._session_dir) if self._session_dir else None})
        return data

    def _write_summary(self) -> None:
        if self._session_dir is None:
            return
        summary = {
            "schema_version": "edge-speech-session.v1",
            "state": self._state,
            "telemetry": self.telemetry(),
            "assets": [{"component_id": asset.component_id, "sha256": asset.sha256} for asset in self.config.assets],
            "scientific_policy": {"identity_score_threshold": self.config.identity_score_threshold, "identity_margin_threshold": self.config.identity_margin_threshold, "identity_minimum_evidence_sec": self.config.identity_minimum_evidence_sec, "clustering_threshold": self.config.clustering_threshold},
            "xvf": {"contract_available": True, "result_effects_enabled": False},
        }
        if self._research_profile is not None:
            summary["research"] = self._research_profile.effective(self.config)
            summary["research"]["telemetry_sha256"] = getattr(self._spatial_provider, "sha256", None)
            summary["xvf"]["result_effects_enabled"] = self._research_profile.xvf.mode != "none"
        destination = self._session_dir / "session_summary.json"
        temporary = destination.with_name(f".{destination.name}.{uuid.uuid4().hex}.tmp")
        with temporary.open("x", encoding="utf-8") as handle:
            handle.write(json.dumps(summary, indent=2))
            handle.flush()
            os.fsync(handle.fileno())
        for attempt in range(4):
            try:
                os.replace(temporary, destination)
                break
            except OSError as exc:
                if getattr(exc, "winerror", None) not in {5, 32, 33} or attempt == 3:
                    raise
                # Bounded Windows sharing/access retry; never delete the destination.
                time.sleep(0.01 * (2 ** attempt))
