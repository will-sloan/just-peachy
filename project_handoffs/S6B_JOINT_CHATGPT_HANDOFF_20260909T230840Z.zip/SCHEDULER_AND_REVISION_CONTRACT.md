# Executed S6B scheduler and revision contract

S6B uses the same opt-in application `CausalScheduler` and `S6BTracker` for actual native runs and deterministic evidence replay. Epoch2 preserves exact code, effective profiles, original model weights/frontends, numerical runtime, input bytes and gain history. Historical B00 remains the immutable original result; B36 is the original tracker under the new common scheduler and is a distinct control.

## Evidence and ordering

Every input has a stable ID, explicit source span and causal availability. Neural observations are emitted by actual fixed-shape Pyannote, supported contiguous ReDim waveform windows and fresh stateful Sherpa streams. Unknown/reference fields are rejected. The predictor never receives reference words, source identities, true person count or source-seat corrections. Processed XVF telemetry uses only sanitized observation fields and arrived timestamps.

Both native lanes seal lower-bound watermarks. Events strictly below both bounds release in availability order, followed by segmentation/embedding/ASR priority and stable event ID. Replay consumes original raw `research_asr_observation` inputs, not text already labelled by an earlier policy. All matched tracker-only candidates share those exact upstream evidence records and availability times. Tracker computation is measured separately; an asymmetric cost shift is not inserted into their common logical clock.

Source-clock plus observed warm compute is a modeled availability convention. Native lane batching may release an event later: release-watermark metadata and actual session elapsed remain separate. Exact semantic parity therefore compares input IDs, source/declared availability, decisions and transcript state; it does not require native release bounds to equal replay's immediate sealed bound. Neither convention alone is a measured CM5 latency.

## Evidence maturity and attribution

The standard S6B trackers expose observation count, unique admitted speech, disjoint observations, commitment state, revision eligibility and update events. Overlapping windows do not earn repeated independent evidence credit. The default new trackers require 1.0 s admitted unique speech and two disjoint observations for commitment. B18/B20 and their C1 companions explicitly cross 0.5/1.0 s windows with one/two disjoint commitments while holding 0.25 s cadence fixed. The first source observations can remain provisional while words are still emitted.

At attribution, speaker and overlap support expire when modeled ASR availability minus evidence source end exceeds 0.75 s. A final-only event can preserve the same utterance's last still-supported label through silence; a later partial can explicitly become Unknown, and finalization cannot restore a label that partial discarded. Unknown identity never discards its ASR words. This conservative expiry can harm late-partial/final attribution and is retained as an observed limitation.

B37 assigns one person; B38 assigns Unknown independently of embedding supply. Their degenerate behavior exposes misleading cpWER gains from conflation/abstention. B36 has a 256-track bound, matching all 15,649 accepted historical vector decisions across 480 outputs; a 16-track bound failed once historical cases exceeded that capacity and was corrected before campaign inference.

## Display and forward correction

Stable utterance IDs preserve immutable first-readable-display and first-final label/time. Later evidence may issue a timestamped forward correction, with the prior/replacement label, evidence lineage and revision scope. The latest state follows subsequent ASR observations and explicit corrections; even a same-label partial can update its text or time. A rollback to Unknown clears identity metadata as well as the displayed label. Ordinary partial-display label changes and bounded retrospective reconciliation are separate operations.

The default retrospective horizon is 2 s with at most four reconciliations per utterance. Once that reconciliation budget is exhausted, the current latest label is retained; the N07 seed's proposed forced-Unknown fallback is not implemented. Default storage budgets are 20,000 pending events, 1,000,000 input IDs, 4,096 utterances and bounded observation histories. Exceeding a storage limit raises an explicit failure. These bounds describe finite research sessions, not proof of indefinite deployment memory safety.

The reported first-display-label cpWER applies each utterance's first readable label to its final recognized words. First-final and latest-revised cpWER use the same final word sequence with their respective labels. This isolates attribution; it is not lexical accuracy of the first partial, time-aligned DER, or retrospective credit for a repaired initial error. The separate event analysis reports corrections/exposure and missing or unidentifiable participant mappings.

## Cues, endpoints and neural recomputation

Tracking-only, endpoint-only, both and no-cue routes are explicit profiles. Cues-disabled configurations match their same-code voice parent. During a cue-enabled run, missing or stale packets do not erase previously cue-conditioned state; each method applies its recorded age, reliability and memory rules. B02 is an explicit exception to voice fallback: the angle-dominant diagnostic abstains when no qualified cue is available, and is not a general-purpose fallback. Folded0–180 bearings are linear;0 and180 are opposite ends. Front/rear uncertainty is retained. Stable numerical direction does not establish physical correctness, and correlated beam outputs are not treated as independent people.

Protected endpoint advice is silence-confirmed, rate-limited and circuit-broken; actual endpoint/decoder changes execute fresh Sherpa state. Cadence cues and evidence debt influence actual embedding admission only when explicitly enabled. Changed waveform, segmentation, windows, RMS support, endpoint or decoding produce distinct true neural recipes. Only prediction-only tracker changes reuse compatible features.

## Validation and persistence

The 64-output pilot validated 1,323 exact tracker decisions, 2,605 semantic transcript events and 144 final utterance states in each label view against native outputs. Neural-cache tests reject changed source/config/context/provider/state and missing or byte-changed neural artifacts. Replay records also bind their profile/evidence identity; completed prediction indexes bind individual output bytes for scoring/admission checks. These are distinct boundaries. Prefix/different-future and no-truth fixtures exercise actual entry points. See `validation/ACTUAL_PILOT_VALIDATION_FINAL.json`, `validation/PILOT_INDEX_LINEAGE.json` and the compact component/tracker receipts for scope and denominators. The final pilot receipt binds an immutable index; the earlier convenience-index binding is preserved and resolved by the lineage record.

The atomic_io_v1 overlay repairs only Windows JSON status persistence, with unique writer temporary files and bounded sharing-denial retries. It does not modify frozen application code, model calls, input/gain, event ordering or cached prediction identity. Original failed coordinator receipts and all completed native evidence are preserved. No completed audio run was repeated for accuracy.

Default GUI behavior is unchanged. Opt-in runtime/CLI integration exists; production GUI history rewriting, real-human validation and CM5 qualification remain future stages.
