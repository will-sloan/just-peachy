# Final paced timing and resource interpretation

The reviewed closure remains unchanged. These notes bind its actual ranges and the implementation that defines each clock and interval.

| Profile | Worker elapsed s | Model/container + engine start s | Sampled tree CPU s | Peak USS MiB | OS threads |
|---|---:|---:|---:|---:|---:|
| B00 | 47.727â€“48.009 | 1.783â€“1.903 | 27.953â€“29.891 | 385.227â€“387.676 | 33.000â€“33.000 |
| B36 | 47.793â€“48.037 | 1.794â€“1.879 | 10.172â€“10.906 | 386.406â€“394.879 | 28.000â€“28.000 |
| B10 | 47.808â€“48.040 | 1.801â€“1.883 | 10.078â€“11.016 | 386.977â€“396.020 | 28.000â€“28.000 |
| B17 | 47.833â€“48.154 | 1.808â€“1.922 | 11.438â€“12.219 | 399.785â€“402.496 | 28.000â€“28.000 |

The clean final continuation contains 29 fresh workers. Its wrapper UTC envelope is 2156.839 s; summed worker internal elapsed is 1389.694 s. The difference, 767.144 s, is unclassified orchestration time outside those worker intervals. Admission/preflight alone was not separately timed.

For B00, startup_bundle_sec times only PipelineEngine construction (27â€“34 microseconds here); actual model creation occurs in engine.start_file/_launch and is included in startup_engine_launch_sec (1.78â€“1.90 s). Named profiles instantiate ResidentModelBundle, whose constructor loads SpeakerModels and SherpaStream, so their startup_bundle_sec includes weights/model admission (1.78â€“1.91 s); the later engine launch is a fresh stream/worker launch (8â€“11 ms). Compare combined intervals cautiously. These are fresh processes with an existing OS cache, not cold-disk tests; imports and other orchestration are outside these component intervals.

Dependency hashing, resource/directory scans, child-interpreter startup, between-cell waiting, coordinator observation and final export are not separately timed as admission/preflight components. The clean final coordinator UTC envelope minus summed reported worker intervals is an unclassified orchestration residual, not an isolated preflight or model cost. It is not added to neural CPU or translated to CM5 RTF.

The unchanged WavSource emits source_started, then appends each 100 ms source block before sleeping for that block duration. The journal/source cursor can therefore lead wall elapsed time by nearly one block. Negative B00 emission-minus-current-source-cursor offsets are compatible with this block-pacing convention, not negative speech latency or future access. Values include dispatch/release effects, use UTC timestamps, and are neither token/phoneme latency nor GUI display latency. Modeled scheduler readiness remains separate.

Every cell has full 44.6954375 s PCM, ASR cursor and consumed speaker cursor. The speaker analyzed-through frontier is 44.5 s, leaving 0.1954375 s reported as an unanalyzed short speaker tail. Thus full audio delivery/ASR completion does not mean every tail sample received a final speaker window. B00 lacks candidate internal dispatch instrumentation; its journal/cursor/durable validation remains its delivery evidence.

The B00 default path and named profiles differ in model-thread settings, process instrumentation and runtime path. Observed B00 versus B36 CPU/thread differences cannot be attributed to the tracker alone. Configured model threads and total OS thread counts are distinct.

Resource ranges are successful-cell observations of fresh processes. USS is private resident, RSS sums can duplicate shared pages, private commit is virtual commitment, and PSS is unavailable on this host. The coordinator RSS is separate. Sampled tree CPU is a lower bound; two sample trees are flagged partial, and frozen sampler fallback limits exhaustive descendant guarantees. Backlog values are observed-sample maxima, not continuous-time maxima.

Four observer versions, three interruptions and unrelated host activity affect comparability. All final words and labels match across 32 repetition pairs; three discrete intermediate display sequences differ. All 24 candidate embedding pairs match spans/vectors within 1e-6; B00 has no embedding-vector trace for this comparison. No accuracy-selected repeat or CM5 qualification is claimed.
