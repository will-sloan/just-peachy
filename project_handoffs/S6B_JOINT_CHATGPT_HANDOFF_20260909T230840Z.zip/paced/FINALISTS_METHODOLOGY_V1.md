# Prospective paced finalist protocol

The approved profiles are B00, B36, B10 and B17. B00 is the exact historical
baseline; B36 is its original-setting tracker through the common scheduler.
B10 and B17 are structurally distinct research comparisons. B10's known
attribution harms remain part of the comparison; its inclusion is not a claim
of cue benefit. B25 and B28 are outside this paced measurement.

Preparation completed on 2026-09-10 without starting a model. The immutable
manifest is `G:\Just_Peachy_S6B\20260909T230840Z\paced_finalists_epoch2_v1\MANIFEST.json`,
with manifest key
`229b93d2b187560f475db75c874d86875d11c97774c22cdf847bd5f62bf0675e`.
The driver, epoch2 application, profiles, inputs and model weights are unchanged.

The fixed whole cases are S45_01_06 (single speaker), S45_03_01 (short replies),
S45_04_05 (overlap), and S45_06_07 (return after a pause). Both O0 and O1 run
twice for each method: 64 cells and 47.6751333 minutes of source audio. No trim,
concatenation, new gain or new scene is introduced. Repetition two reverses
method order. Every cell has a fresh process and scene state, and candidate
cells use one resident model bundle for the whole scene. These are repeated
44.6954375-second trajectories, not a continuous multi-minute session.

Execution is held until the root coordinator confirms that native/replay,
heavy scoring/uncertainty, table export and figure generation have closed.
Only light inspection/documentation may overlap. Unrelated user processes are
left untouched. Start exactly one paced coordinator; it starts one owned model
worker at a time, records PID creation identities, uses bounded timeouts and
emits regular heartbeats. No repetition is discarded or repeated for accuracy.

## Inputs and outputs

Inputs are the manifest's bound prepared audio, sanitized telemetry, exact
historical B00 source and frozen epoch2 dependencies. Outputs remain beneath
`G:\Just_Peachy_S6B\20260909T230840Z\paced_finalists_epoch2_v1`: native sessions,
process/queue/write trajectories, display events, launches and complete
receipts. Final `SUMMARY.json` is also copied beneath this report's `paced`
directory. Model startup, private resident USS, RSS upper bounds, private commit,
OS threads, queue backlog and log growth remain distinct. Modeled evidence
availability is not measured GUI display time or CM5 performance.

The existing `README_S6B_PACED.md` documents the frozen driver, numeric-pool
settings, complete tail checks, output guards, clock definitions and stop/resume
rules. Its prior preparation examples remain historical. This is a new exact
selection protocol, not an edit to the earlier bound README or the pre-paced
`CACHE_AND_INFERENCE_COUNTS` snapshot.

## PowerShell

The `prepare` command below has completed. The otherwise identical `run`
command may execute only after the quiet interval is confirmed.

```powershell
$sim = 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
$pacedPython = 'C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe'
$pacedReport = "$sim\reports\S6B\20260909T230840Z"
$pacedOutput = 'G:\Just_Peachy_S6B\20260909T230840Z\paced_finalists_epoch2_v1'
& $pacedPython "$sim\scripts\s6b_paced.py" --mode prepare --epoch epoch2 --profiles 'B00,B36,B10,B17' --repetitions 2 --streams 'O0,O1' --report $pacedReport --output $pacedOutput
& $pacedPython "$sim\scripts\s6b_paced.py" --mode run --epoch epoch2 --profiles 'B00,B36,B10,B17' --repetitions 2 --streams 'O0,O1' --report $pacedReport --output $pacedOutput
```

## Anaconda Prompt / Command Prompt

Use the exact EDGE interpreter; no environment activation or installation is
needed. Comma-separated profile and stream lists are single arguments.

```bat
set "SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
set "PACED_PY=C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe"
set "PACED_REPORT=%SIM%\reports\S6B\20260909T230840Z"
set "PACED_OUTPUT=G:\Just_Peachy_S6B\20260909T230840Z\paced_finalists_epoch2_v1"
"%PACED_PY%" "%SIM%\scripts\s6b_paced.py" --mode prepare --epoch epoch2 --profiles B00,B36,B10,B17 --repetitions 2 --streams O0,O1 --report "%PACED_REPORT%" --output "%PACED_OUTPUT%"
"%PACED_PY%" "%SIM%\scripts\s6b_paced.py" --mode run --epoch epoch2 --profiles B00,B36,B10,B17 --repetitions 2 --streams O0,O1 --report "%PACED_REPORT%" --output "%PACED_OUTPUT%"
```

Exact complete cells are reusable only through the driver's binding checks.
Failed or incomplete cells are preserved for diagnosis. The final completion
manifest must bind both the pre-paced accounting checkpoint and the independent
paced summary; the earlier checkpoint's NOT_STARTED status is never rewritten.
