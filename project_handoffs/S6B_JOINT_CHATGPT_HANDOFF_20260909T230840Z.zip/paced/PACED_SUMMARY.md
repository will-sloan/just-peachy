# S6B paced closure

64 logical cells completed in 67 physical native attempts: 64 complete, three preserved interruptions.
The source plan covers four fixed whole scenes, both O0/O1 taps and two balanced repetitions for B00/B36/B10/B17.

| Namespace | Fresh complete | Interrupted | Copied references |
|---|---:|---:|---:|
| paced_finalists_epoch2_v1 | 2 | 1 | 0 |
| paced_finalists_epoch2_v2 | 22 | 1 | 2 |
| paced_finalists_epoch2_v3 | 11 | 1 | 24 |
| paced_finalists_epoch2_v4 | 29 | 0 | 35 |

All final PCM/journal and ASR cursor checks passed; all owned process identities are closed.

Repetition pairs: 32. Exact final words 32; exact final labels 32; exact full display sequence 29; exact journals 32.

| Profile/tap | USS peak MiB range | RSS peak MiB range | Private commit MiB range | OS thread peak range |
|---|---:|---:|---:|---:|
| B00/O0 | 385.56–387.57 | 443.89–445.89 | 419.66–420.71 | 33.00–33.00 |
| B00/O1 | 385.23–387.68 | 443.56–446.01 | 419.50–420.52 | 33.00–33.00 |
| B10/O0 | 387.52–389.59 | 445.46–447.54 | 453.07–454.38 | 28.00–28.00 |
| B10/O1 | 386.98–396.02 | 444.92–454.01 | 453.35–460.84 | 28.00–28.00 |
| B17/O0 | 399.79–401.98 | 457.73–459.93 | 469.48–470.37 | 28.00–28.00 |
| B17/O1 | 399.99–402.50 | 457.94–460.45 | 468.82–470.80 | 28.00–28.00 |
| B36/O0 | 386.85–394.88 | 444.81–453.85 | 452.75–461.23 | 28.00–28.00 |
| B36/O1 | 386.41–389.50 | 444.36–447.45 | 452.94–454.43 | 28.00–28.00 |

## Observed and missing telemetry

| Profile/tap | Stored samples | LIVE observed/null | Observed LIVE without telemetry | ASR backlog observed/missing |
|---|---:|---:|---:|---:|
| B00/O0 | 715 | 691/24 | 24 | 667/48 |
| B00/O1 | 714 | 690/24 | 24 | 666/48 |
| B10/O0 | 716 | 692/24 | 24 | 668/48 |
| B10/O1 | 715 | 691/24 | 24 | 667/48 |
| B17/O0 | 715 | 691/24 | 24 | 667/48 |
| B17/O1 | 715 | 691/24 | 24 | 667/48 |
| B36/O0 | 716 | 692/24 | 24 | 668/48 |
| B36/O1 | 714 | 690/24 | 24 | 666/48 |

Final optional observer: 0 explicit malformed JSON reads represented as missing, out of 2495 admitted LIVE read calls. These are not counts of null startup rows or native failures.

JSON and PACED_OBSERVATION_COVERAGE.csv retain exact per-cell denominators and phases. Observed backlog peaks are sampled values, never proven continuous-time maxima. No interpolation. Complete native process-tree observations and coordinator RSS are separate. Interrupted partial trajectories do not enter successful-cell ranges.

- Four observer versions, three interruption gaps and varying unrelated host activity; resource conditions are not identical.
- Each cell is a fresh process with one resident bundle for its scene; no continuous multi-scene leak claim.
- USS is private resident; RSS sums duplicate shared pages; private commit is virtual commitment; PSS null means unavailable.
- Configured model threads do not equal total OS thread count. No CM5 throughput, 2 GB fit or thermal qualification.
- B00 has no internal per-dispatch trace. Exact full PCM, journal/cursor and durable completion checks are its delivery evidence.
- Modeled scheduler availability, native event emission and GUI/phonetic latency remain distinct.
- All repetitions retained; changed words, labels or vectors are observations, never accuracy retry criteria.
- Observer double reads and retries may delay sampling; gaps are measured without interpolation.
- Null LIVE, observed LIVE without telemetry, and explicit malformed JSON read events are separate denominators.
- Observed backlog peaks are retained; missing telemetry has no imputed value and whole-time maxima remain unavailable.
- Tree metrics use sampler-complete flags. Root-only fallback after OS descendant enumeration failure is not flagged by the frozen sampler, so exhaustive descendant coverage is not independently proven.
- Separate coordinator RSS and interrupted partial trajectories are explicit.
