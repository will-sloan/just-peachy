# Full confirmed-bank mechanism audit

PASS: 13,920 actual predictions, 29 profiles, 240 scenes, both taps; 2880 unique native jobs.

All exact scene/profile/tap cells and original audit counters match. This report is model-free and uses no reference identity or geometry. It reports activation, not measured benefit.

| Profile | Decisions | Unknown observations | Capacity rejects / affected outputs | Positive cue observations | Nonzero location-score observations | Forward tracker revisions |
|---|---:|---:|---:|---:|---:|---:|
| B00 | Uninstrumented | Unavailable | Unavailable | Unavailable | Unavailable | Unavailable |
| B01 | 15649 | 1666 | 912 / 127 | 0 | 0 | 0 |
| B02 | 15649 | 9675 | 0 / 0 | 5974 | 4460 | 0 |
| B03 | 15649 | 1648 | 913 / 128 | 5974 | 2139 | 0 |
| B04 | 15649 | 1608 | 912 / 127 | 5974 | 4747 | 0 |
| B05 | 15649 | 1640 | 912 / 127 | 5974 | 4747 | 0 |
| B06 | 15649 | 1577 | 912 / 127 | 5974 | 4744 | 0 |
| B07 | 15649 | 1655 | 912 / 127 | 5974 | 560 | 0 |
| B08 | 15649 | 1615 | 912 / 127 | 5974 | 4746 | 0 |
| B09 | 15649 | 2085 | 1670 / 163 | 0 | 0 | 0 |
| B10 | 15649 | 2076 | 1670 / 163 | 5974 | 4744 | 0 |
| B11 | 15649 | 1645 | 894 / 127 | 0 | 0 | 0 |
| B12 | 15649 | 1666 | 912 / 127 | 0 | 0 | 0 |
| B13 | 15649 | 2289 | 914 / 127 | 0 | 0 | 0 |
| B14 | 15649 | 2173 | 914 / 127 | 5974 | 4730 | 0 |
| B15 | 15649 | 1666 | 912 / 127 | 0 | 0 | 6 |
| B16 | 8535 | 317 | 9 / 3 | 0 | 0 | 0 |
| B17 | 8535 | 299 | 9 / 3 | 3367 | 2480 | 0 |
| B24 | 8303 | 309 | 15 / 4 | 0 | 0 | 0 |
| B25 | 8479 | 304 | 22 / 7 | 3284 | 2346 | 0 |
| B28 | 15649 | 1666 | 912 / 127 | 0 | 0 | 0 |
| B30 | 15649 | 1767 | 915 / 127 | 0 | 0 | 0 |
| B31 | 15649 | 5689 | 920 / 127 | 0 | 0 | 0 |
| B32 | 15649 | 1647 | 912 / 127 | 5590 | 4464 | 0 |
| B33 | 15649 | 1686 | 943 / 128 | 5974 | 4743 | 0 |
| B35 | 17041 | 2105 | 1255 / 172 | 0 | 0 | 0 |
| B36 | 15649 | 0 | 0 / 0 | 0 | 0 | 0 |
| B37 | 15649 | 0 | 0 / 0 | 0 | 0 | 0 |
| B38 | 15649 | 15649 | 0 / 0 | 0 | 0 | 0 |

The JSON preserves separate O0/O1 counters, cue rejection reasons, individual mechanism operations and transcript revision scopes. A zero count means no observed activation in this population. It does not mean an absent implementation or demonstrated ineffectiveness.

Structural track merge and split are absent; graph recomputation and forward association revision are distinct operations. This full-bank index covers six admitted neural recipes: R0, R0_FULL_RMS, R1, R5, R5_CUES, R7. N05 event/debt activity is included; N04 protected-endpoint profiles remain challenge-only, so their evidence belongs to the separate full challenge audit.

Source audit SHA-256: `636158e254291842effabf60e4558ff4b8150dd58bbaa489c5719ceda5f433fb`. Compact JSON SHA-256: `59c2269039b7545d83fc84138e21a46a76b57c5d70f979e3e95b1347d64aa89e`.

Reproduction commands and exact population arguments are in `simulation/scripts/README_S6B_MECHANISM_SUMMARY.md`.

The unchanged compact exporter was invoked with `--expect-profiles 29 --expect-scenes 240 --expect-native-jobs 2880`. Its R0-specific Markdown heading and scope sentence were generalized for this new six-recipe report; no JSON counter was changed. The separate `FULL_NATIVE_MECHANISM_BY_RECIPE.json` supplies per-recipe/per-tap admission and endpoint totals, bound to the same full audit.
