# S6B figure captions

## 01_words_and_attribution

All plotted profiles have240 scenes on each tap. Left: pooled primary S+D+I /4,560. Right: first-final cpWER /6,016 complete-reference words, including overlap scenes. Lower cpWER alone does not establish better identity: inspect coverage/mixing and the separately tabulated first-display/latest views. B00 retains historical attribution timing; B36 is the common-scheduler original tracker.

## 02_unknown_and_mixing

Unknown and mixed/conflated support use the same complete-reference sole-speech denominator; the two displayed fractions can be added. Mixed support is an offline anonymous-association diagnostic, not enrolled recognition or word-aligned DER. A coverage gain with more mixing is a tradeoff, not an unqualified improvement.

## 03_all_short_replies

All40 complete-reference subsecond source occurrences are retained. A wholly contained admitted waveform, any non-Unknown label support, and a duration-mapped correct modal label are different outcomes. Unknown, unmapped and tied assignments stay in the denominator; the dotted line is40, not40 independent scenes. Tables retain missing/never-successful latency counts.

## 04_return_consistency

Return-group consistency is evaluated separately from pooled cpWER. Consistent anonymous reuse, inconsistent labels and unresolved/Unknown groups are shown together; each profile uses the same complete-reference grouping. Lower Unknown with more inconsistent returns remains an observed harm. Silent-relocation and source/room strata are retained in the tables.
