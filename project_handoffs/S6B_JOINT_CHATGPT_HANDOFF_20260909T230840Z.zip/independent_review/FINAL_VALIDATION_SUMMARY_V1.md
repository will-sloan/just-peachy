# Independent validation summary

**PASS for the declared validation scopes.** This summarizes accepted receipts and rechecks their byte bindings. It does not rerun historical tests or infer that the later combined-bank results, deployment or final packaging are complete.

| Evidence | Accepted scope | Important limit |
|---|---|---|
| Native/replay parity |64 actual pilot outputs across eight neural recipes;1,323 decisions,2,605 transcript events and144 final utterances agree semantically.|Physical compute/release timing is excluded; this is not all final profiles. |
| Causality/truth boundary |64 decision-prefix,64 transcript-prefix and64 metadata-renaming checks pass.59 same-code/schema checks use32 actual cached vectors.|Finite scoped proofs, not exhaustive future-input noninterference. |
| Cache/provenance |28 native-cache fault cases plus3 prediction-guard and4 atomic-writer fixtures pass.|Only temporary copies were corrupted; filesystem immunity is not claimed. |
| Cue behavior |24 disabled-spatial-parent checks,7 structural-parent checks,19 mode-prefix and8 future-cue checks pass; focused age/reorder/dropout/conflict fixtures also pass.|A currently missing cue can retain past cue influence; it is not a disabled-from-start run. |
| Legacy/source |24 tracker,17 component and13 legacy checks;30 source/receipt checks. Full R0 has exact spans and0 legacy-label differences across480 outputs/15,649 vectors.|10/480 vector arrays are bit-exact; max absolute difference1.7136335372924805e-6. B00/B36 scheduling differs. |
| Coverage/activation |3,872 challenge predictions cover44 profiles,8 families and16 interactions;11,040 full R0 predictions cover23 profiles and240 scenes.|27 reviewed mechanisms are not27 independent causal interventions or demonstrated benefits. |
| Export guards |12 focused certified-byte, key/grid and failed-row checks pass.|Final table export and final case selection remain separate. |

Primary receipts: [final pilot](<C:/Users/amiri/Documents/GitHub/just-peachy/XVF 3800 Testing/XVF Integration Real World RIRs/simulation/reports/S6B/20260909T230840Z/validation/ACTUAL_PILOT_VALIDATION_FINAL.json>), [source comparison](<C:/Users/amiri/Documents/GitHub/just-peachy/XVF 3800 Testing/XVF Integration Real World RIRs/simulation/reports/S6B/20260909T230840Z/independent_review/CODE_CHANGES_FROM_S6A_V2.json>), [coverage](<C:/Users/amiri/Documents/GitHub/just-peachy/XVF 3800 Testing/XVF Integration Real World RIRs/simulation/reports/S6B/20260909T230840Z/coverage/challenge_final_v1/COVERAGE_RECEIPT.json>), [full R0 mechanism summary](<C:/Users/amiri/Documents/GitHub/just-peachy/XVF 3800 Testing/XVF Integration Real World RIRs/simulation/reports/S6B/20260909T230840Z/mechanisms/R0_FULL_MECHANISM_SUMMARY.json>). The JSON companion contains all28 exact source bindings and detailed scopes.

Native semantic comparison excludes raw `compute_finished_elapsed_sec`, `modeled_available_at_sec`, `release_watermark_lower_bound_sec` and `release_after_all_lanes_closed` event fields. Canonical source spans and declared availability are retained. All2,605 raw release diagnostics differ between native batched lane sealing and immediate model-free replay; this does not establish equivalent wall-clock latency.

Material limitations:

- Several16-track policies reach capacity in127/480 full R0 outputs; B36 has an explicit256 bound and observed max27. Treat capacity failure as a method constraint, not evidence of another real speaker.
- N01 recovery, prototype rollback and the challenge endpoint breaker did not activate on the observed bank. N03 escrow released once. Fixture success proves exercised code paths, not empirical benefit.
- Structural track merge/split is absent. Tracker revisions and transcript revisions are distinct. N07 age/edit exhaustion retains the latest label. N05 uses global observation-time debt; per-track debt queues are absent. N02/N06/N08 are not implemented.
- Reused synthetic scenes are exploratory. Conditional timing/short-reply metrics, pooled counts and overlapping strata retain their explicit denominators. No CM5, blanket GUI, holdout-generalization or production readiness claim follows.

Fault resolution:

- [Pilot index lineage](<C:/Users/amiri/Documents/GitHub/just-peachy/XVF 3800 Testing/XVF Integration Real World RIRs/simulation/reports/S6B/20260909T230840Z/validation/PILOT_INDEX_LINEAGE.json>) resolves both immutable index versions. **FINAL binds the all-cache copy**; the earlier validation resolves the first-native copy. All64 native receipt hashes agree.
- [Corrected fault ledger](<C:/Users/amiri/Documents/GitHub/just-peachy/XVF 3800 Testing/XVF Integration Real World RIRs/simulation/reports/S6B/20260909T230840Z/EXECUTION_FAULT_LEDGER.md>) explains Windows status-only I/O failures and the never-executed epoch1 correction. [Preserved prior ledger](<C:/Users/amiri/Documents/GitHub/just-peachy/XVF 3800 Testing/XVF Integration Real World RIRs/simulation/reports/S6B/20260909T230840Z/independent_review/EXECUTION_FAULT_LEDGER_BEFORE_PILOT_WORDING_FIX.md>) retains the exact bytes before the one-sentence pilot wording correction.
- [Endpoint extractor correction](<C:/Users/amiri/Documents/GitHub/just-peachy/XVF 3800 Testing/XVF Integration Real World RIRs/simulation/reports/S6B/20260909T230840Z/mechanisms/ENDPOINT_EXTRACTOR_CORRECTION.json>) preserves the failed report/source and shows unchanged native predictions after the reporting fix.
- [Original cap16 failure](<C:/Users/amiri/Documents/GitHub/just-peachy/XVF 3800 Testing/XVF Integration Real World RIRs/simulation/reports/S6B/20260909T230840Z/tracking/ORIGINAL_COMMON_CAP16_FAILURE.json>), [prospective short/long repair](<C:/Users/amiri/Documents/GitHub/just-peachy/XVF 3800 Testing/XVF Integration Real World RIRs/simulation/reports/S6B/20260909T230840Z/COMPONENT_NEURAL_REPAIR_B34.json>), and [immutable gain audit](<C:/Users/amiri/Documents/GitHub/just-peachy/XVF 3800 Testing/XVF Integration Real World RIRs/simulation/reports/S6B/20260909T230840Z/independent_review/gain_pcm_audits/AUDIT_20260910T003902490258Z.json>) retain the remaining scoped failure/resolution evidence.

No APP, prediction, code or README dependency was changed by this summary. The separate combined-bank mechanism audit, final diagnostic-case review and final admitted runtime/packaging receipts are still required outside this document.
