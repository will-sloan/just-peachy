# Source changes from preserved S6A V2

Read-only review passes: {'UNCHANGED': 14, 'ADDED': 4, 'CHANGED': 4}. This compares the exact pre-S6B snapshot to frozen epoch2, not git HEAD or original B0.

| Module | Change | Behavior |
|---|---|---|
| checks_research_tracking_v2.py | ADDED | New24 focused tracker checks and optional historical-vector parity. Test code is not a candidate mechanism. |
| cli.py | CHANGED | Adds a model-free research-profile validation/printing subcommand. Existing GUI/live/default dispatch and file research opt-in remain. |
| models.py | CHANGED | Adds optional resident Sherpa constructor and ResidentModelBundle: matching configuration, one lease, fresh stream per acquire. Normal inference/reset/drain/punctuation and SpeakerModels remain unchanged. |
| research_profiles.py | CHANGED | Exact v2 schema dispatch plus validated evidence/RMS/purity/cadence, explicit cue routes, endpoint interval/burst breaker and scheduler settings. Original v1 classes/functions retained. |
| research_s6b_checks.py | ADDED | New17 component/runtime fixtures with model substitutes. Not broad neural or GUI validation. |
| research_scheduler.py | ADDED | New strict arrived schemas, watermark ordering, evidence expiry, first/latest utterance states, age/edit budgets and admission/cadence. N05 uses global observation age, not per-track deficit priority. |
| research_tracking_v2.py | ADDED | New actual bounded tracker families/controls, independent evidence, N01 quarantine, N03 escrow, reversible prototype and delayed association lineage. Structural track merge/split absent. |
| runtime.py | CHANGED | Explicit v2 tracker/scheduler, separate speaker admission loop, raw ASR observations, forward transcript revisions/latest export. Independently optional model_bundle. Shared legacy paths remain, with added bookkeeping/timing calls. |

All old hashes match the original admission snapshot; all new hashes match the epoch manifest. The JSON contains every module path, before/after hash and line delta. README/non-code changes are outside these counts.

## Opt-in boundaries

**No profile, no bundle:** Unchanged defaults, original tracker, old speaker/transcript body. No V2 scheduler/admission/latest export. New bookkeeping and perf_counter reads can affect timing; no exhaustive GUI/concurrency parity claim.

**Explicit v1 profile:** Original schema/policies/adviser remain; V2 flag false and legacy bodies execute. 13 focused checks match all final hashes, not every v1 neural output or GUI workflow.

**Explicit edge-research-profile.v2:** New scheduler/tracker/admission/advice paths and forward latest exports. Runtime/CLI opt-in; production GUI history rewriting absent.

**Explicit optional model_bundle:** Independent opt-in even without a research profile: exact config signature, single lease, fresh stream. None preserves old loading path. Admitted files must stay immutable; only session/gallery paths excluded from signature. V2 does not automatically create a bundle.

**EOF and tail:** Shared ASR tail AST unchanged: accepts remaining source PCM, then existing synthetic0.66s drain/punctuation. V2 speaker reports unanalysed short tail and seals its lane. Synthetic padding is not observed audio; unanalysed speaker tail is not counted as ReDim evidence.

There are 30 passing static/receipt checks. The original speaker/transcript bodies after their V2 guard, shared ASR EOF body, SpeakerModels, normal Sherpa bodies and retained v1 parser/provider/adviser/gate have exact AST equality. The existing13 focused checks bind every final epoch2 code hash. None of this proves identical timing, every neural transcript or complete GUI regression coverage.

## Reversible rollback route

1. Finish/stop the owned active session at a safe checkpoint; retain all current S6B source and evidence.
2. Select the preserved snapshot in a fresh process, or copy the whole package to a new isolated folder; never mix old/new modules or replace a running process source.
3. Supply unchanged explicit AssetSpec paths/hashes from the epoch manifest plus fresh session/gallery paths. Snapshot-relative default asset discovery points into staging and must not be assumed correct.
4. Omit model_bundle and v2 profiles, which the old API does not support; use no profile or a preserved v1 profile.
5. Verify module __file__ and hashes, then existing model-free checks before any separately authorized neural replay. No rollback was performed.

Pre-S6B snapshot contains completed S6A V2 integration. Original B0 is the separate S6A baseline_app and historical evidence.

## Read-only verification commands

The following confirms package selection and repeats existing model-free checks. Do not add --models. These examples were not rerun for this report; the existing13-check receipt was verified and reused. Use a new result filename if repeating.

PowerShell:

```powershell
$env:PYTHONDONTWRITEBYTECODE = '1'
Set-Location -LiteralPath 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s6b\20260909T230840Z\epoch2\app'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe' -c "import edge_speech_pipeline; print(edge_speech_pipeline.__file__)"
& 'C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe' -m edge_speech_pipeline.research_profile_checks --output 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6B\20260909T230840Z\independent_review\OPTIONAL_REPEAT_LEGACY_CHECKS.json'
```

Anaconda Prompt / Command Prompt:

```bat
set PYTHONDONTWRITEBYTECODE=1
cd /d "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s6b\20260909T230840Z\epoch2\app"
"C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe" -c "import edge_speech_pipeline; print(edge_speech_pipeline.__file__)"
"C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe" -m edge_speech_pipeline.research_profile_checks --output "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6B\20260909T230840Z\independent_review\OPTIONAL_REPEAT_LEGACY_CHECKS.json"
```

For preserved S6A V2, use its package-parent working directory. Any later actual run requires explicitly verified assets and fresh output/gallery roots because asset discovery is package-path relative. No deletion, reset or in-place overwrite is required.

JSON SHA256: `712a559176c496f54d98a3b237c80870334b7840ed8ba4eb39e9ac74949abf09`.
