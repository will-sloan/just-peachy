# Independent final case and family review

All13,920 requested outputs were scored, with zero unscored. Each profile/tap preserves203 complete-reference scenes,6,016 cp words,777 deliberate source turns across all populations and40 complete-reference subsecond turns. All table bytes were checked against completed upstream receipts.

**B17 is the preferred fourth paced cell alongside B00/B36/B10.** B25 remains a conditional event/short-evidence direction; B28 remains an ASR direction with an explicit strict-empty failure. None dominates every outcome.

| Comparison | O0 latest cp error change | O1 latest cp error change | Scope |
|---|---:|---:|---|
| B10 minus B36 |-30 |+277 |Structural profile; Unknown and return consistency worsen. |
| B17 minus B16 |-1 |-32 |Matched R1 observations; no latest-cp losing scene. |
| B17 minus B36 |-25 |+5 |Different pipeline profiles. |
| B25 minus B24 |+11 |-57 |Cue cadence and tracking change together. |
| B25 minus B36 |-105 |+50 |Different pipeline profiles. |
| B25 minus B17 |-80 |+45 |First-final errors instead worsen+10/+75. |

Each cell above uses6,016 reference words. Negative means fewer errors. First-final, latest and first-display-label/final-word views are kept separate; the JSON includes all three views and per-scene win/loss/tie counts.

Coverage and harm remain visible. B10 has only2 consistent returns per292 opportunities on either tap, versusB36 107/88; its lower mixed-label fraction accompanies higher Unknown. B17 has0 subsecond turns with at least one wholly contained embedding, B25 has8/9 andB36 31/33, yet mapped modal correctness differs:13/17,13/14 and14/14 of40. These measures are not interchangeable.

Exposure uses different observed populations: B17 has527/536 identifiable rows and17,627.696/17,946.076 modeled row-seconds; B25 has480/487 and15,967.169/16,121.966. The JSON preserves missing row counts and both exposure fractions. Row-seconds can overlap across retained transcript rows and are not elapsed time or word-aligned harm.

B28 O1 emits19 words across11 strict-empty scenes (491.6498125 seconds), versus2 forB00/B36. Besides requiredS45_12_20 (9vs1), S45_12_18 emits“um um um and” (4vs0), S45_12_16 gives5vs1 andS45_12_09 gives1vs0.

The following12 cases are selected after outcomes for explanation, not independent validation. Retain companions B16/B24 and preferablyB09 in the export.

| Case | Why retain it |
|---|---|
| S45_01_03 | B10 O0 latest-label win versus B36; B25 O0 loses versus its B24 parent. |
| S45_01_13 | B10 and B17 O1 latest-label losses versus B36. |
| S45_02_01 | B10 O1 and B25 O0 latest-label wins versus B36. |
| S45_02_08 | B10 O0 and B25 both-tap losses versus B36; B25 O1 also loses versus B24. |
| S45_02_15 | B25/B24 reverses direction by tap: latest +21 errors O0, -21 O1. |
| S45_03_01 | Mandatory short-reply/identity evidence case; retain all profiles and both taps. |
| S45_03_05 | B17 O0 loses versus B36; B25 O1 loses versus B24. |
| S45_03_11 | B17 O0 strong latest-label win versus B36. |
| S45_03_20 | B17/B16 first-final harm later reverses: O0 +2 first-final errors then -1 latest; O1 latest improves10. |
| S45_07_16 | B17 O1 wins versus B36; B25 O1 wins versus both B24 and B36. |
| S45_12_18 | Additional full-bank empty-control failure: B28 O1 emits4 words versus blank B00/B36. |
| S45_12_20 | Mandatory strict-empty boundary: B28 O1 emits9 words versus1 for B00/B36. |

Do not manufacture a B17/B16 latest-label loss: there is none in the203 complete scenes on either tap. S45_03_20/O0 instead makes the timing tradeoff concrete: first-final29vs27 errors over28 words, then latest26vs27. O1 latest is21vs31. The JSON gives exact view-specific counts for all targeted examples.

The source-bound JSON also includes all nonzero strict-empty cases, per-profile unknown/mixed/return/short/exposure denominators and complete-scene contrasts. Its SHA-256 is`eb91b4bd22e02100852f3b7f498f22c25dd56ce787b95c4b573b345f538bed22`. Conditional uncertainty must be read from the separate bound whole-block supplement; no statistical significance or real-world generalization is claimed here.
