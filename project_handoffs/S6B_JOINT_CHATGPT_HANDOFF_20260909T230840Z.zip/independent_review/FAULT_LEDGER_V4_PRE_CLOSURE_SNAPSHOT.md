# Retained malformed live status and optional-observer recovery

This supplement follows the three earlier execution-fault ledgers. It preserves the third paced interruption and the evidence that motivates a change limited to optional monitoring data. Final completion and physical-attempt counts remain the responsibility of the final paced closure receipt.

## Third interruption and exact bytes

The `paced_finalists_epoch2_v3` run reached 35 completed logical cells. During `B00_S45_01_06_O0_R2`, two identical snapshots of `LIVE.json` raised `JSONDecodeError: Extra data` at character 1,244. The reviewed stable-reader policy failed as specified and stopped its owned worker. Worker PID 23040, helper PID 4012 and coordinator PID 13576 closed; the source inventory records all 73 relevant PID/creation identities as closed.

The observer retained `000073.bin` and `000074.bin`. Each is 8,192 bytes, with SHA256 `5be190a75f12875439698d7573e0c39ef1b088cbae219021b93b51c3a39c949d`. The original JSON text occupies 1,242 bytes, followed by CRLF, then 6,948 NUL bytes. The first snapshot's file metadata changes from 1,244 to 8,192 bytes; the second snapshot is stable at 8,192. The later closed live-status file is valid and 1,261 bytes long.

This proves that null-padded monitoring data was observed. It does not prove the underlying filesystem or publication cause. The writer already uses a unique temporary file, flush/fsync and replacement. Parsing the valid prefix is useful only for this forensic description; it is prohibited as a way to recover measurements or feed the application.

`paced/PACED_V3_INTERRUPTION_SOURCE_INDEX.json` preserves 214 files totaling 57,084,303 bytes. The failed partial native attempt remains separate from the 35 valid completions and is not an accuracy rejection.

## Why optional telemetry can be missing

Independent review of the original coordinator confirmed that it already supports `live=None`. Process-tree memory/CPU sampling, resource-reserve checks, process timeout, the strict final `WORKER_RESULT` read, complete PCM/cursor validation and artifact binding do not depend on accepting this optional live-status JSON.

`paced/PACED_OPTIONAL_LIVE_POLICY_REVIEW_V1.json` records the prospective boundary judgment. A separately versioned wrapper may convert only a manifest-listed `LIVE.json` parsing failure into an explicit missing live observation, after successful retention of its exact failed bytes. It must not parse a prefix, reuse an earlier status, interpolate observations, conceal missingness or relax final-result validation. Path/binding, size, deadline, retention-cap and authoritative-data failures remain fatal. Valid JSON receives no semantic coercion.

The implemented wrapper is `s6b_paced_optional_live_v3.py`, SHA256 `9c5d65dbf21dc2feeaec0352943aa7fe506d5c36cd22e310380feb1511c52beb`. Its 11 focused fixtures passed. It pins the previously reviewed 18-check stable reader and the original native driver. Retention or event-writing failures cannot become a missing sample. The inherited reader's failed-call counter includes retained parse failures represented as missing telemetry; it must not be confused with failed native executions.

`paced/PACED_OPTIONAL_LIVE_INDEPENDENT_REVIEW_V3.json` passed 567 admission checks. It verified 576 preserved files, 64 unchanged ordered jobs, 35 logical completions, 70 exact copies, 210 original native artifact bindings and 79 closed PID/creation identities. The completed cells originate from the first three namespaces in counts 2/22/11. All three interrupted attempts remain separate. The fresh `paced_finalists_epoch2_v4` manifest has SHA256 `2cbb4e5cfa57991b0411ef41290a5f91aabacf8f7f0fe25dc5b8ca1e45988cb1` and leaves 29 native cells to run.

The renewed native run was authorized after independent admission. No remaining cell is claimed complete here. Final closure will distinguish null live samples, valid live objects without telemetry during loading, valid backlog observations and explicit malformed-read events. It will also distinguish the 64 planned logical cells from all physical attempts across four observer versions and three interruption gaps. Missing observations are never interpolated or treated as zero backlog.
