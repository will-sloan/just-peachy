# Executed family coverage

The selected audit contains 3,872 actual comparison outputs. All eight required families have reviewed executable implementations. The map identifies 27 distinct research mechanisms, excluding two control rows; it does not count profile aliases or fixture parsing as experimental results.

METHOD_FAMILY_COVERAGE.csv records executable entry points, fixture scope, actual activity, pending profile populations and limits. MATCHED_INTERACTION_TABLE.csv contains exact effective-field differences, including prepared input gain, and exposes bundled interventions. N01_N08_IMPLEMENTATION_STATUS.csv distinguishes four complete ideas (N01/N03/N04/N07), the narrower N05 adaptation and three absent proposals.

The selected population and any pending component recipes are explicit in each CSV row. Zero rollback/recovery is retained when it did not occur; code checks do not turn that into successful empirical recovery. Native job counts are deduplicated within each mechanism row, but rows overlap and must not be summed as distinct neural runs. Historical B00 internals are not instrumented.

B24/B25 bundles cue-driven cadence with cue-driven association. B22/B28 bundles endpoint restoration with decoder search. Sparse/frequent/event comparisons report actual work and are not automatically equal-budget. The 0.5/1s duration x1/2-disjoint-count diagnostic holds0.25s cadence and1s unique evidence fixed. Segmentation policy/stride/purity is a fractional design with explicit matched edges.

No benefit is inferred here. Read score, short-turn, wrong-merge/Unknown, return, latency and resource outcomes together. Full-bank shortlist and real-human/CM5 qualification are separate evidence boundaries. Rebuild under a new output namespace when the full prediction audit is available; exact commands are in README_S6B_FAMILY_COVERAGE.md.

The separate newly executed R0 proof covers480 outputs and15,649 vectors: all source spans and legacy anonymous labels match;10/480 vector arrays are bit-exact, with maximum absolute difference1.7136335372924805e-6. This is distinct from the64-output semantic pilot and fixed-input legacy tracker tests. B00/B36 transcript attribution can still differ through scheduler and expiry rules.
