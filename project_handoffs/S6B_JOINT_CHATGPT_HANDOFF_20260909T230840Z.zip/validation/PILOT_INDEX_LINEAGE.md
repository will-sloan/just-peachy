# Pilot index and validation lineage

The final authoritative validation is ACTUAL_PILOT_VALIDATION_FINAL.json. It passes all64 actual pilot outputs against PILOT_NEURAL_INDEX_ALL_CACHE_IMMUTABLE.json. The bounded repeat executed no neural inference or hardware and completed in23.79seconds.

The earlier ACTUAL_PILOT_VALIDATION.json is preserved byte-for-byte. It originally bound the convenient epoch2/PILOT_NEURAL_INDEX.json path at SHA a7d9e659cabe78ecb250cac58897dcbd84a79b2398c5696f7f01258281e282c8. A later all-cache coordinator closure replaced that convenience index with different invocation/status/timing metadata. Both immutable invocation completion files survive.

PILOT_NEURAL_INDEX_FIRST_NATIVE_IMMUTABLE.json recovers the exact old bytes from epoch2/invocations/20260909T235343_2936/completion.json. The newer PILOT_NEURAL_INDEX_ALL_CACHE_IMMUTABLE.json is an exact copy of epoch2/invocations/20260909T235732_14180/completion.json at SHA1ceec42d9c4c1b061aa6a515f2148983703f9c573a81f8a7db5205ba2cffdfe1. No historical receipt was relabelled or overwritten.

All64 case/recipe/tap keys and native receipt paths/hashes are identical between the index versions. The original and final validation native/parity/causality rows are identical. The current pilot admission binds the newer all-cache index; this final validation binds its immutable copy. PILOT_INDEX_LINEAGE.json records the explicit resolution of the old stale path and hashes both versions. A generic recursive checker should use this documented resolver for the historical validation rather than pretend its original path still contains the old index.

The final receipt retains28 temporary-copy cache rejection fixtures, same-code cue-off/strict-schema tests, and semantic transcript/timing scope. Release-watermark metadata remains excluded from semantic native/replay equality because batched native release and sealed replay release differ. No measured live or GUI latency claim follows from this validation.

For a new repeat, use the --neural-index immutable-copy path and a new --output-name as shown in README_S6B_VALIDATION.md. Preserve these completed receipts and immutable copies.
