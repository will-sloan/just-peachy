# Five conditional S6B research directions

The final choice is **B36, B10, B17, B25 and B28**, all confirmed on 240 scenes and both taps (480 outputs per profile). These are five pipeline research directions, not five winners or five unrelated tracker algorithms. This Pareto-style shortlist keeps different observable tradeoffs; it is not a proof of formal dominance over every metric or untested parameter value. No weighted composite score or production default was selected.

B36 is the simple voice fallback. B10 changes identity-state architecture. B17 changes the fixed component/evidence operating recipe. B25 changes early evidence and event cadence while sharing adaptive tracking with B17. B28 changes supported ASR search and host dispatch. The paced set is historical B00 plus B36/B10/B17. B25/B28 have full-bank accuracy and accelerated-work evidence but are not paced in this bounded run. All 64 paced cells are complete; exact results and observation limits are in the paced summary and closure receipt.

All cp counts below use 203 complete scenes and 6,016 reference words per tap. Primary words use 156 scenes/4,560 words, empty controls 11 scenes/491.6498125 seconds, short evidence 40 turns in nine scenes and returns 292 repeated-speaker groups. Values separated by a slash are O0/O1. No profile enrolls a person's name. Prepared O0 already has its +3 dB gain; all named main adapters are consumed at unity and O1 remains unity.

| Direction | Actual recipe and required control | Full first-final / latest cp errors O0; O1 | Main unresolved condition |
|---|---|---|---|
| B36 simple voice fallback | Original R0; compare historical B00 and new voice parent B01 separately | 3662→3668; 3773→3741 | Substantial identity errors remain; timing differs from historical B00 |
| B10 dual memory with cues | R0 with dual voice/location memory; matched cue-off B09 | 3607→3638; 4064→4018 | Very weak returns and much more Unknown, especially O1 |
| B17 tuned fixed evidence with cues | R1 posterior/stride/1 s evidence/50 ms ASR recipe; matched B16 | 3631→3643; 3710→3746 | No contained subsecond evidence; more Unknown and worse returns than B36 |
| B25 early/event evidence with cues | R5_CUES hard policy, early 0.5→1 s windows, event cadence; matched B24 | 3641→3563; 3785→3791 | Later O0 gain coexists with earlier/O1/return harms |
| B28 beam/dispatch ASR branch | R7 modified beam search 2,50 ms; voice tracker B01 parent | 3737→3739; 4008→3979 | Primary WER improves, but O1 empty insertions rise 2→19 |

## B36: simple voice-only fallback

Use as the reference implementation for straightforward anonymous voice association on the existing prepared mono 16 kHz file route. It does not need spatial cues. Its R0 recipe uses original hard segmentation at 0.75 s stride,0.5 s embeddings at 0.25 s hop, dispatch-block RMS, greedy ASR at 100 ms and original 2.4/1.2/20 s endpoint rules. It preserves the legacy label sequence and normalized words, while the common scheduler changes transcript attribution timing. B00 must therefore remain a separate historical control.

B36 gives 107/95/90 and 88/108/96 consistent/inconsistent/unknown return groups. Among 40 subsecond turns,31/33 have at least one wholly contained admitted embedding,36/38 have known support and 14/14 have a mapped correct modal label. These are comparatively useful fallback properties, not proof of correct diarization. Unknown support still occupies about 21.5% of complete sole speech and mixed support about 1.49/1.54%.

The tested point keeps the legacy-compatible cap 256 and observed maximum 27 tracks. Changing the cap or original association thresholds would create a new candidate. No continuous safe neighborhood is established. Its shared native R0 evidence is the cost reference; paced B36 must be read beside B00 because code/runtime timing differs. Later questions concern bounded retirement/capacity and attribution timing without sacrificing immediate text or short coverage.

## B10: dual-memory structural comparator

This direction uses a slow voice prototype, faster location state and dormant re-entry under the original R0 neural recipe. Delivered causal direction remains uncertain folded evidence. B09 is required to distinguish architecture from cue effects; cue-disabled mode uses its same-code parent, while disabling cues after prior cue-conditioned state is not a promise of fresh-state bit parity.

Its lower mixed support (about 0.69/0.64%) and lower known-wrong retained-row exposure are useful counterpoints, but Unknown rises to 29.59/31.41%. Compared with B36, first-final cp changes by−55/+291 errors, latest by−30/+277 and first-display by+434/+428. Only 2/292 returns are consistent on either tap. The matched B09/B10 latest cp results are identical for every complete scene/tap; cues change O0 first-final by only−16 errors and do not establish a general gain. Do not describe B10 as the recommended everyday tracker.

At the tested cap 16,1,670 updates were rejected across 163 outputs; there were 83 dormant reactivations across 41. These are observed state events, not independent lost utterances. Its 0.04 slow-voice and 0.65 location learning rates,5 s dormancy and 0.55 re-entry cosine are nominal settings, not calibrated constants. The completed paced run measures the actual implementation. S6C should first test capacity/retirement and maturity against the same cue-off parent, then challenge silent relocation and stable conflicting cues while retaining all failures.

## B17: tuned fixed evidence with adaptive cues

R1 uses posterior hysteresis with 0.5 s segmentation stride,1 s embeddings every 0.5 s, dispatch RMS, greedy 50 ms host reads and 1.6/0.8/20 s endpoint rules. Adaptive tracking uses the same original model weights. B16 is its matched cue-off companion; B05/B01 provide the original-component cue-on/off interaction controls. Do not attribute the entire R1 component bundle to direction.

B17 is chosen for the second joint paced slot because its first-final outcomes on both taps and return inconsistency are preferable to B25's corresponding points. Versus B36, first-final cp improves by 31/63 errors but latest O1 worsens by 5. First-display worsens by 139/85. Unknown support is 27.58/26.63%, and return groups are 44/108/140 and 51/112/129. Compared with B16, latest cp improves by 1/32 errors; there is no complete scene with a latest-cp loss, but first-final losses exist. Conditional uncertainty does not establish a broad cue advantage.

All 40 subsecond turns remain: zero have a wholly contained admitted embedding,31/35 have known support and 13/17 have a mapped correct modal label. The latter can use neighboring or spanning evidence and does not validate short-only voice evidence. The recipe is unsuitable as a universal short-reply solution at this nominal point.

Measured batch process CPU is about 1.226/1.222 times R0, despite fewer embedding calls. This is observed upstream work under the batch conditions, not a portable speed estimate or an additive per-tracker charge. Paced measurements provide the separate full-engine desktop resource layer. There is no demonstrated continuous plateau around the 1 s window or commitment gate. Later work should test an early clean short path and maturity/capacity separately from postpolicy, stride and ASR settings.

## B25: early short/long event-cadence alternative

R5_CUES uses hard segmentation at 0.5 s stride, an initial 0.5 s embedding then 1 s evidence, nominal 0.25 s hop,0.25/1 s event cadence and a 0.75 s voice observation opportunity floor. ASR remains original greedy 100 ms with 2.4/1.2/20 s endpoint rules. It is not R1 posterior segmentation or tuned R1 ASR. B24 supplies the voice-driven cadence parent; both cue-dependent cadence and adaptive tracking change in the B25 comparison.

B25 restores contained evidence in 8/9 of 40 subsecond turns, with 35/36 known and 13/14 correct mapped modal labels. Its latest O0 point improves over B17 by 80 errors, but first-final is worse by 10/75 and latest O1 by 45. Returns become 41/154/97 and 39/160/93, compared with B17's 44/108/140 and 51/112/129. More inconsistent returns accompany fewer unresolved groups. B24 is slightly better than B25 at latest O0 and remains necessary in later trials.

Native batch CPU is about 1.178/1.176 times R0, modestly below B17 but still above the original recipe. The full R5_CUES recipe produced 8,479 embeddings versus 8,303 for R5:176 net additional calls. Its 316 cue-only earlier-admission opportunities are a different counter and are not 316 net extra embeddings. Neither fewer vectors nor a nominal cadence budget proves less total work. B25 is unpaced here; its resource conclusions are limited to the measured accelerated evidence.

Frequent/sparse companions are challenge-only nominal comparisons, not an exact equal-CPU or continuous parameter sweep. S6C should match observed work, retain the voice opportunity floor, and test whether short evidence and revisable maturity can improve first labels and returns without increasing contamination. Different endpoint-derived transcript row populations also prevent ranking B17/B25 by raw correction-exposure seconds alone.

## B28: ASR gain with a false-speech boundary

R7 retains original hard segmentation, short embeddings, RMS and the cue-disabled voice tracker. It changes greedy search to supported modified beam search with two active paths and 100 to 50 ms host dispatch. Endpoint settings remain 2.4/1.2/20 s, exactly as B01; these configured rules do not change. Host reads are not the model's encoder chunk. Challenge B22 has other endpoint settings and does not isolate B28 on the full bank.

Primary errors improve from 656/705 to 635/700 out of 4,560. Overlap changes from 486/502 to 492/491 out of 1,456, and known ambient-target errors from 202/205 to 200/209 out of 683. O1 empty insertions rise from 2 to 19 over 491.6498125 seconds, including S45_12_09,_16,_18 and_20; O0 remains 1. This direction merits a targeted ASR failure study, not unrestricted use or a cue-fusion claim. Its anonymous return/unknown behavior remains close to the bounded voice parent rather than the B36 fallback.

B28 is not paced in this bounded study. Actual batch costs remain in the summary with their own scope. Only nominal two-path/50 ms settings were tested at full scale; there is no validated safe search/dispatch neighborhood. Later work should separate search from dispatch, retain all 11 empty controls and the short/overlap failures, and investigate false speech before any default decision.

## Completed paced resource screen

All four paced profiles completed 16 cells each across the four cases, both taps and two repetitions. Sampled peak USS ranges are B00 385.23–387.68 MiB, B36 386.41–394.88 MiB, B10 386.98–396.02 MiB and B17 399.79–402.50 MiB. Native worker wall intervals are about 47.73–48.15 s for each 44.6954375 s source, including startup and completion. B00 retains its historical model-thread defaults and peaks at 33 OS threads; the named profiles peak at 28. Their CPU difference is not an isolated tracker improvement.

Final words and final labels match in all 32 repetition pairs, while three full display sequences differ. All frame/journal and ASR-cursor checks pass. Three interrupted attempts, four observer versions, sampled telemetry gaps and the sampler's descendant-coverage limitation remain disclosed. These finite Windows results do not certify sustained operation or CM5 fit. B25/B28 remain unpaced; do not assign them another profile's measurements.

## Rules for the next comparison

Use all 240 scenes and both taps for retained general-purpose claims; the 12 explanatory cases in the diagnostic export are outcome-selected illustrations. Retain first-display, first-final and latest labels, same-denominator unknown/mixed support, all 40 short turns and 292 return groups. The full conditional cp supplement includes 2,000 resamples and 365 contrasts, with crossed dependencies preventing independent population generalization. No CM5 qualification, GUI promotion, enrollment, training or S6C run follows automatically from this shortlist. Exact commands and model/input paths are in `RUN_PROFILE_README.md` and `LOCAL_ARTIFACT_INDEX.json`.
