# Compact table scope

Complete cp totals use 203 complete scenes and 6,016 words per tap; primary words use 156 scenes and 4,560 words. Ambient targets, overlap MIMO and strict-empty controls remain separate.

Native recipe costs repeat across profile reusers for comparison and must not be summed across those rows. Nested phases overlap; measured engine CPU, accelerated wall, replay cost and paced latency have different scopes.

Short-turn wait quantiles include observed and missing counts. Contained waveform, known label support and duration-mapped correctness are different measures. Retained-row exposure is not word-aligned harm and needs its own observed-state denominator.

First-display cp applies first labels to final words; it is not first-partial word accuracy. Strata may overlap. Conditional uncertainty belongs to its explicit eligible subset. Diagnostic scenes were selected after outcomes for explanation, not independent validation.

Selected profile IDs: B00, B01, B05, B09, B10, B16, B17, B24, B25, B28, B36, B37, B38.

Diagnostic case IDs: S45_01_03, S45_01_13, S45_02_01, S45_02_08, S45_02_15, S45_03_01, S45_03_05, S45_03_11, S45_03_20, S45_07_16, S45_12_18, S45_12_20.
