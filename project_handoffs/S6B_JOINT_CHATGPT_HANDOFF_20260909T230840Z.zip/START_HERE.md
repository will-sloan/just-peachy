# Just-Peachy S6B handoff

**Status: S6B_COMPLETE_WITH_LIMITATIONS.** The broad comparison, full-bank analyses and bounded paced study are complete. Run: `20260909T230840Z`. Current Word guide: `XVF_Measurement_V15.docx`, preserved unchanged.

## What this stage establishes

S6B implemented real opt-in H2 component/tracker/scheduler paths and executed a broad comparison using the existing physical XVF outputs and synthetic scene bank. Forty core configurations plus four explicit diagnostics ran on both taps of a 44-scene challenge. Twenty-nine retained profiles then received complete 240-scene/both-tap confirmation:13,920 scored outputs with zero unscored failures. All 777 source occurrences and all 40 complete-reference subsecond turns remain in scope for every profile/tap.

The actual unique campaign work is 3,936 epoch 2 native jobs and 15,240 prediction files. The final six-recipe full scope contains 2,880 native outputs; shared recipes and overlapping indexes must not be added as independent inference. `CACHE_AND_INFERENCE_COUNTS.json` separates durable jobs, observed resident model loads, reused baseline outputs, index references, smoke sessions and the pre-paced checkpoint. The final completion manifest binds the separate paced evidence.

The central finding is a set of tradeoffs, not a global winner. B36 is the simple voice fallback under the common scheduler. B17 is the selected tuned joint comparator for paced testing, but its long evidence window leaves zero subsecond turns with a wholly contained admitted embedding. B10 is a useful structural counterexample with lower mixing but severe unknown/return harms. B25 is an early/event-evidence direction with later O0 gains and worse earlier/O1/return behavior. B28 improves primary words while producing substantially more O1 false speech on empty controls.

## Results that should survive every later prompt

- Original-recipe primary errors are 656/4,560 O0 (14.386%) and 705/4,560 O1 (15.461%). All R0 tracking variants preserve words. Historical B00 and B36 have identical legacy clustering decisions, but their transcript labeling/display timing differs. B00 is not a loadable V2 profile and B01 is not the original tracker.
- Full cpWER uses 203 complete scenes/6,016 words per tap. First-display-label/final-word, first-final and latest corrected views are separate. A later correction cannot repair the earlier metric. These anonymous-label scores do not establish enrolled person recognition or DER.
- B17 versus B36 improves first-final cp by 31/63 errors but has more Unknown, weaker returns and latest O1 five errors worse. All 40 subsecond turns are retained: B17 has 0/0 with contained evidence,31/35 with any known support and 13/17 with correct mapped modal identity. Label presence is not proof of adequate short-only evidence.
- B10 has only 2/292 consistent complete return groups on each tap, versus B36's 107/88. Its lower mixed support coexists with much more Unknown. Its matched cue-off B09 has identical latest cp on every complete scene/tap, so a general directional-cue gain is not demonstrated.
- B25 versus B17 worsens first-final on both taps (+10/+75 errors), improves latest O0 (−80) and worsens latest O1 (+45). Its inconsistent returns increase to 154/160 versus 108/112. Its lower native CPU is relative to B17; it still exceeds R0.
- B28 reduces primary errors to 635/700, but O1 empty insertions rise from 2 to 19 across 11 scenes/491.6498125 seconds. Search and 50 ms host dispatch change together; configured endpoint rules remain original. The empty, overlap and ambient failures remain in the decision.
- One-person and all-unknown controls have identical cp error counts despite opposite identity behavior. Read coverage, mixing, short replies, returns and exposure denominators alongside attributed-text scores. There is no composite winner score.

## Read the archive in this order

1. `S6B_JOINT_REPORT.md` for executed scope, component settings, matched results, failures, measured cost and limitations.
2. `PARETO_SHORTLIST.md` for the five conditional directions, operating assumptions, nominal settings and precise later questions.
3. `PER_PROFILE_SUMMARY.csv`, full paired/population/short tables, conditional cp uncertainty and the selected strata/case tables for denominators and evidence. The 12 illustrative cases were chosen after outcomes; they are not a new validation set.
4. `CANDIDATE_REGISTRY.json`, `EFFECTIVE_PROFILE_DIFFS.csv`, `METHOD_FAMILY_COVERAGE.csv` and the N01–N08 status table. The eight mathematical families are not the eight numbered extension ideas: N02/N06/N08 remain unimplemented, N05 is narrower, and N07 retains the latest label when its revision budget is exhausted.
5. `SCHEDULER_AND_REVISION_CONTRACT.md`, `METRIC_INTERPRETATION.md`, compact independent reviews and execution-fault records. These define causality, immutable first labels, cache identity and proof limits.
6. `WORKBOOK_UPDATE.md` for a reviewed light-yellow addition to the same master, and `NEXT_STAGE_INPUTS.md` for later prompt preparation. S6C has not started.

Four scientific figures have been visually checked. They show primary words/first-final attribution, same-denominator unknown/mixed support, all 40 short turns and return categories. The archive omits audio, full vectors, model weights, full event logs, duplicate prior packs and the Word master. `LOCAL_ARTIFACT_INDEX.json` supplies exact local evidence/code/input paths and hashes, with larger indexes available through their bound locations.

## Runtime, use and limits

The paced study completed all 64 cells: B00/B36/B10/B17 × four whole cases × both taps × two repetitions. This required 67 physical native attempts, including three preserved observer status-read interruptions. All successful PCM/journal and ASR-cursor checks passed, and all owned processes closed. All 32 repetition pairs have identical final words, final labels and journals; three differ in their full native display-event sequence. Peak sampled native USS spans 385.23–402.50 MiB across profiles; this excludes a claim of total device fit. The final continuation observed zero malformed-to-missing reads in 2,495 LIVE reads. Startup nulls and model-loading observations remain separate missing-telemetry categories. See the paced summary, coverage table and closure receipt for exact costs, denominators and observer limitations.

The common replay clock models causal evidence availability; native paced emission/resource measurements are separate. Finite fresh-process cells are not an uninterrupted endurance test. Desktop USS/RSS/private commit and CPU do not qualify CM5 ARM64 with 2 GB total RAM or 32 GB eMMC. No speed multiplier or production guarantee is claimed.

`RUN_PROFILE_README.md` contains exact PowerShell and Anaconda/CMD commands for prepared local files, using the existing interpreter, model paths and a new isolated data root. Select B36 for the simple opt-in fallback; use other profiles only with their documented research assumptions. Prepared O0 already includes +3 dB and must be read at unity; O1 remains unity. No new physical playback is required for these file commands.

Measurements remain restricted to validated PASS/REVIEW records, with testing/RETAKE excluded. The two raw 100 m entries retain the user's 1.00 m correction in the overlay; eligible distances are 0.46–4.07 m. Manual angle signs have internal checks, not independent physical calibration. The corpora remain CMU Arctic, HiFiTTS and Common Voice, with no L2 Arctic. No RIR generation, capture, firmware change, model training, S6C campaign or GUI default promotion was performed in S6B.
