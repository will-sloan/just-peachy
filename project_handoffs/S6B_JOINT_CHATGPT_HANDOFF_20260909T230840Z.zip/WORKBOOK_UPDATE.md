# Reviewed insertion material for XVF Measurement Revision 15

**S6B_COMPLETE_WITH_LIMITATIONS.** The full-bank comparison and all 64 bounded paced checks are complete; the final handoff includes their independent reviews. The Word master itself remains unchanged. Suggested placement: append to the S6 results section, with new material highlighted light yellow for review.

## S6B: broad joint pipeline comparison

S6B expanded the comparison from tracker metadata alone to actual supported component settings and incremental anonymous speaker association. It reused the existing measured room impulse responses, physical XVF outputs, speech sources and sanitized directional traces. No new RIR, recording, playback, model training, model weights or dataset download was needed. Both O0 and O1 remain in scope. O0's historical +3 dB is applied only once, and prepared inputs are read at unity.

The study contains 40 core profiles—27 main methods, nine companions and four controls—plus four disclosed challenge-only diagnostics. Every one of the 44 configurations ran on a 44-scene diagnostic challenge panel containing all 40 complete-reference subsecond turns. Eighteen exact neural recipes cover eight conceptual families. Six retained neural recipes were then completed on all 240 scenes and both taps, supporting 29 fully confirmed profiles and 13,920 profile outputs. Overlapping execution indexes represent 3,936 unique native jobs and 15,240 unique prediction files, not 15,240 independent neural runs or recordings.

There are 777 intended source occurrences. Each tap has 156 complete non-overlap scenes with 4,560 reference words, 47 complete overlap scenes with 1,456 words, 26 incomplete ambient-target scenes with 683 known words, and 11 strict-empty controls totaling 491.6498 seconds. Complete-scene attributed-text scoring uses 203 scenes and 6,016 words per tap. All 40 subsecond turns in nine scenes and 34 one-to-under-two-second turns in seven scenes remain in the analysis. Missing environmental words are never invented as truth.

The comparison separates first-display label, first-final label and the latest forward-corrected label. Corrections do not erase an earlier error. First-display cpWER uses the final recognized words with their first readable label; it does not measure the accuracy of the first partial words. These are anonymous association metrics, not enrolled person recognition or word-aligned DER.

## Confirmed controls and cautionary results

All original-recipe tracking variants preserve lexical errors: 656/4,560 O0 (14.386%) and 705/4,560 O1 (15.461%). The original tracker under the common scheduler, B36, also preserves the historical track-label sequence across 15,649 actual embeddings. Attribution scores still differ from historical B00 because transcript labeling occurs under different timing conventions. That difference cannot be credited to better clustering.

| Full-bank comparator | First-final cp errors O0 / O1 | Latest cp errors O0 / O1 |
|---|---:|---:|
| B00 historical original | 3,533 / 3,714 | 3,533 / 3,714 |
| B36 original tracker, common scheduler | 3,662 / 3,773 | 3,668 / 3,741 |
| B10 dual voice/location memory with cues | 3,607 / 4,064 | 3,638 / 4,018 |
| B17 tuned components with tracking cues | 3,631 / 3,710 | 3,643 / 3,746 |
| B25 early/event cadence with tracking cues | 3,641 / 3,785 | 3,563 / 3,791 |
| B28 beam/dispatch ASR, voice-only | 3,737 / 4,008 | 3,739 / 3,979 |

Each table cell uses 6,016 complete-reference words. None is an independent validation estimate. B10 reduces mixed support but substantially increases unknown support and harms returns: only 2/292 complete return groups are consistent on each tap, versus 107/292 and 88/292 for B36. Its latest score matches cue-off B09 per complete scene, so the apparent benefit of the dual-memory family cannot be generalized into a benefit from directional cues.

B17 has zero wholly contained admitted embeddings for the 40 subsecond turns. It still supplies some known labels, which demonstrates that contained evidence, label presence and correct mapped identity are separate quantities. New methods also hit the 16-track cap; the historical behavior uses up to 27 tracks in this bank. Capacity and evidence maturity therefore need matched testing before interpreting extra unknown labels as an inherent limitation of a mathematical family.

The one-person and all-unknown controls have the same cp error counts, 4,312/4,360, despite opposite behavior. One merges all people; the other abstains everywhere. A lower attributed-text score or fewer unknown returns is insufficient unless mixed support, inconsistent returns, short coverage and timing are shown alongside it.

## Final selection, resources and next decision

The conditional shortlist is B36 (simple voice fallback), B10 (dual voice/location memory), B17 (tuned fixed evidence with cues), B25 (early/event evidence with cues) and B28 (ASR search/dispatch). These are five pipeline research directions, not five winners or five unrelated clustering algorithms. All five have complete 240-scene/both-tap confirmation. Historical B00 plus B36/B10/B17 are the bounded paced set; B25/B28 have accelerated-work evidence only.

B25 restores some contained short evidence—8/9 of 40 turns have at least one wholly contained admitted embedding, versus 0/0 for B17—but its first-final cp errors are worse than B17 on both taps. Its latest O0 point improves while latest O1 and return inconsistency worsen. This is a useful later research question, not a general improvement.

B28 improves primary word errors to 635/700 out of 4,560 on O0/O1, versus 656/705 for the original recipe. However, O1 strict-empty insertions increase from 2 to 19, or 0.244 to 2.319 words/minute. Those extra outputs occur in S45_12_09,_16,_18 and_20. The configured endpoint rules remain original; supported beam search and 50 ms host dispatch change together. Better primary WER does not justify unrestricted use.

The paced study completed 64 logical cells in 67 physical attempts, with three preserved Windows observer status-read interruptions. All complete PCM/journal and ASR-cursor checks passed; all owned processes closed. Final words and final labels matched in all 32 repetition pairs, while three full native display sequences differed. Sampled peak USS ranged from 385.23–387.68 MiB for historical B00, 386.41–394.88 MiB for B36, 386.98–396.02 MiB for B10 and 399.79–402.50 MiB for B17. B00 peaked at 33 OS threads and the named profiles at 28. Different thread defaults prevent interpreting B00/B36 CPU differences as a tracker-only gain. There is no automatic GUI promotion or global winner.

The deterministic scheduler uses causal modeled availability of genuine neural observations. It is separate from measured desktop latency. The paced study uses repeated whole-file cells with fresh process/state and resident weights within each cell; it does not certify indefinite live operation. Desktop CPU/RAM results cannot establish CM5 ARM64 timing or fit within 2 GB total system RAM. No desktop-to-CM5 multiplier is used.

S6C should test matched track capacity/retirement, early short evidence and later identity maturity, cue-off/on controls, event-cadence work and false speech on empty controls. Keep short-turn S45_03_01 and the challenged O1 beam empty-control case S45_12_20. Later external real-human and target-device tests remain necessary for deployment conclusions. S6C, new capture, split-tap routing, training and production GUI work have not started.

## Figure captions for reviewed insertion

The final handoff contains four scientific figures with source hashes: primary words and first-final attribution; unknown/mixed support on the same denominator; all 40 short replies with contained/known/correct outcomes separated; and consistent/inconsistent/unknown returns. Use the final `FIGURE_CAPTIONS.md` verbatim with the final images. Do not use the baseline preview figures or imply independent source samples from multiple turns in one scene.
