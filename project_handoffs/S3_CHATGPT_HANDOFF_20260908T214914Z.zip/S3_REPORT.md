# S3 physical XVF proof — READY_WITH_LIMITATIONS

The bounded proof is complete. Eight physical captures recovered **12,503,040 compared microphone samples with zero mismatches**, and both explicit mono outputs completed unchanged H2 with zero dropped audio frames. This establishes a working selected-RIR-to-physical-XVF-to-H2 path. Output headroom, direction transitions and host timing remain limited; this is not permission to launch a full simulation or training campaign.

## Findings and evidence

| Capability | Result | Population and consequence |
|---|---|---|
| Offline pack/check software | PASS | 17/17 checks, including sign, channel, delay, missing/duplicate-group and framing failures |
| Physical PCM24 transport | PASS | 8 captures; 0/12,503,040 compared MIC0–3 payload samples differ; all active payload retained |
| Category 3 unity/zero replay | PASS | Mic/ref gains 1, SYS_DELAY 0 read back and exact input loopback demonstrated |
| Simultaneous O0/O1 routing | PASS | Four diagnostic mics plus ASR-auto and postprocessed-auto captured together; ASR enabled, fixed gain 1 |
| Processed-output headroom | LIMITED | O0: 0 rails; O1: 329 rail samples across 3,021,889 samples in seven speech captures |
| Single-seat direction plausibility | LIMITED | Native medians front 90.00°, left 148.39°, right 23.26° support the side convention, not calibrated angle accuracy |
| Conversation direction transitions | LIMITED | Auto direction often retained a near-front/old beam during B-right; first right-sector receipt was not a sustained handoff |
| Persistent angle/energy reads | LIMITED | 12,616 replies per field, zero failed reads; generally 16 ms cadence but maximum gap 731.49 ms |
| Same-configuration retry pair | PASS for readback; LIMITED for behavior | Matching 50-value-setting dictionaries; adaptive trajectories still varied |
| Unchanged H2 file interoperability | PASS | 2/2 mono invocations, three final transcripts each, zero dropped frames, no exceptions |
| Restoration | PASS | Both owners restored their recorded initial settings and USB16/16, disabled packed input and released all handles/lease |

`metrics.json` defines the metrics and links their sources. `per_case_metrics.csv` contains every original and retry capture. The local raw evidence remains indexed in `LOCAL_ARTIFACT_INDEX.json`.

## Inputs, execution and the one retry

The user confirmed that nothing was connected to the XVF audio output. Other PC speakers, headphones and microphones remained connected. Every capture/playback stream explicitly used the unique named XVF Windows WDM-KS pair; no default, Realtek, HDMI or Bluetooth route was opened. USB width changed from observed 16/16 to 24/24 using the documented control, with fresh endpoint discovery after resets. No drivers or firmware were replaced.

Only three canonical, S2-eligible Library Conference Room / Square Table End / flat-clear RIRs were consumed: R01 front (0°, 1.70 m), R12 left (+75°, 0.74 m), and R04 right (−80°, 0.90 m). Their exact hashes and the canonical manifest binding are retained. No measurement selection or RIR extraction was repeated. The deferred low-table R13 and excluded tests/RETAKE/Loeb Caf data were absent. S3 does not replay-qualify the other library entries.

The dry drive was original LibriSpeech dev-clean PCM multiplied by 0.25 (−12.0412 dB), followed by four-channel convolution. No second −6 dB factor, division by acquisition gain 10, independent normalization or microphone alignment was applied. The common additional headroom scalar was 1.0. RIR pre-onset of about 50 ms remains, without a guessed distance/c delay. Each width was quantized directly from the numerical vector once; only PCM24 was physically tested, with 23 payload bits and a 2.38419e−7 FS grid step.

The three utterances (1272-128104-0000, 1272-128104-0003, 1462-170138-0006) and speaker identities LibriSpeech:1272 / LibriSpeech:1462 are development fixtures. Exact audio/transcripts and the local CC BY 4.0 license were checked. They must not enter a later untouched evaluation split. Source boundaries are exact scheduling labels, not phonetic or word timestamps.

The original core comprised an 8 s tagged case, three 13 s single-seat cases, and two 38 s A-left/B-right/A-left conversations. All six passed transport. Review found different current AGC readings in the original conversation snapshots: 61.38675 versus 58.89388. Setup had also left physical microphone mode active during several seconds of post-reset configuration. Thus the original pair was insufficiently controlled for a strong same-state comparison.

The single diagnosed retry repeated only the conversation pair. Packed input was selected immediately after firmware-ready readback and retained throughout setup; current AGC gain was initialized to the existing maximum 125, without changing AGC tuning. The retry settings matched. Pre-audio energy was zero in both; observed initial beam values differed by about 0.38°, so identical hidden state is not claimed. The reset-to-first-control interval remains finite. Both original runs remain reported, and the retry does not prove that initialization caused every earlier difference. No third attempt or parameter sweep occurred.

Total physical playback was **199 s** (123 + 76), below the 15-minute boundary. Hardware-owner wall time including configuration/restoration totaled **372.86 s**. H2 subprocesses took 26.37 s combined. The external package receipt records total run elapsed time, which includes the earlier wait for speaker confirmation.

## Audio, timing and direction interpretation

Packed input slots were `[zero far-end, zero ignored, MIC0, MIC1, MIC2, MIC3]`. Output mux arguments were `3 0 / 3 2 / 7 3 / 3 1 / 3 3 / 6 3`, ordered L_PK0, L_PK1, L_PK2, R_PK0, R_PK1, R_PK2. The unpacked order was MIC0–3, O0, O1. This follows the supplied XMOS implementation and was checked against the known four-channel vector.

All eight streams had 14,619 leading zero native frames before valid packed framing, separately excluded. There were no interior marker errors, callback error flags, missing/duplicated active payload samples or per-mic level changes. Comparison used one common integer offset per capture. Its native-stream value was 473.625 ms in seven captures and 324.625 ms in retry conversation 1. These are captured-buffer/sample-index offsets, **not XVF algorithm latency**. Startup and trailing padding were never repaired into the evidence.

Figure 1 compares levels and approximate processing delays. O1's 329 speech rail samples are 0.0109% of its seven speech-capture samples; they are a headroom limit, even though the fraction is small. The nonspeech tagged test separately produced 4,366 O1 rail samples. O0 did not rail. Silence/support RMS, peaks, counts and adjacent steps are in metrics; input continuity does not independently certify every processed waveform discontinuity.

Absolute waveform correlation against recaptured MIC0 estimated O0 lags of 54.50–54.8125 ms and O1 lags of 54.4375–54.75 ms over 15 utterance windows. Grid resolution is 0.0625 ms; near-peak spans reached two samples. Signed coefficients were negative (approximately −0.82 to −0.69); files were never polarity-flipped. Filtering/beam steering changes the waveform, so these are descriptive relative-delay estimates, not calibrated full-stack latency or a precise uncertainty interval.

Four timelines remain distinct: source-file scheduling with RIR onset convention, recaptured input sample indices, processed audio, and telemetry host request/receipt. WDM-KS ADC/DAC timestamps started at zero while currentTime used QPC; they did not establish a calibrated common epoch. Audio callback blocks reached 150 ms, with a startup callback gap about 305 ms. Figures 2–3 use actual host availability without any fitted telemetry shift. Absolute device/telemetry offset remains unresolved.

The qualified queued logger streamed full AEC angle and energy arrays with request/response bounds. Median gaps were near 16 ms and per-case 95th percentiles were at most 16.65 ms, but the front case had a 731.49 ms maximum gap and retry conversation 1 a 537.51 ms gap. Successful pending-command retries were not counted as failed measurements. Of 12,608 adjacent comparisons per field, 6,953 angle arrays and 8,275 energy arrays were unchanged. Read rate is not DSP freshness. The available selected-azimuth command was included as one preflight probe; its continuous trajectory was not logged by the existing two-field queued adapter.

Native linear-array direction remains 0–180°, distinct from signed lab angles. The single-seat results support left/right sign plausibility but do not satisfy an invented ±5° accuracy threshold. Front/rear cannot be distinguished. In the retry pair, B-right's all-support native-auto medians were 89.23° and 89.62°, even though the single-seat right median was 23.26°. First energized right-sector receipts occurred 0.808 s and 6.967 s after the callback writing B's source boundary. This definition includes queueing and unknown phonetic onset and permits brief transitions; it is **not sustained handoff latency**. Figure 3 preserves this instability rather than hiding it behind similar medians.

Retry O0 and O1 support-RMS differences were +0.121 dB and +0.469 dB. Their first-B-sector receipt differed by 6.160 s despite matching configuration. Two repeats provide no population confidence interval. Direction must remain a fallible, possibly stale observation for later research, not a speaker identity rule.

## H2 and next gate

H2 consumed mono O0 and O1 from **original conversation repeat 1**, after that owner closed/restored and before the retry. Both completed, each producing three raw final hypotheses with no audio drops or exceptions. Raw hypotheses, event counts, sessions and eight validated asset identities are retained. The source matched S0; profiles were separate empty roots, and no generic six-channel averaging occurred. H2 was not rerun to select a favorable result, and no model, threshold, GUI or private enrollment data changed.

Proceed only to a small controlled level/transition diagnostic bank after ChatGPT review. Resolve output headroom policy, stale/gapped telemetry handling and the usable timing contract before a broad scene campaign or fusion claims. Keep both outputs until matched evaluation supports a choice. There is **no output accuracy winner, enrollment/naming validation, moving-person validation or CM5 qualification** from S3. The canonical library and Revision 6 Word workbook were not rewritten; `REPORT_SECTION.md` is the proposed reviewed insertion.
