# Next bounded decision — controlled levels and transitions

S3 is complete with limitations. ChatGPT should review this packet, insert the accepted `REPORT_SECTION.md` material in the Revision 6 workbook's S3 block with light-yellow marking, then write a narrowly bounded next prompt. No next phase was started here.

Use the existing root:
`C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs`

Exact accepted inputs:

- `simulation\rir_library\v1\RIR_MANIFEST.json` — SHA-256 `468b2b306f994937a7d02db611080d38c7a4bcc7dc89ce7dc73d93762380f546`.
- Front `wav\JPXVF_P1_R06_T01_D01_S01_F00_NAT_CU_R01_rir.wav` — `7e8f1c161df4a409eda7a2883fe81446b5ebda2ae56db591b0f8bd4369b099de`.
- Left `wav\JPXVF_P1_R06_T01_D01_S01_F00_NAT_CU_R12_rir.wav` — `389ac71e8ae7ffbd60b28fb6ee04bd4340e204e25e6697c0844857898b05f0f0`.
- Right `wav\JPXVF_P1_R06_T01_D01_S01_F00_NAT_CU_R04_rir.wav` — `48405b9a856a634872942561c8fc4d9bd0f9fe649e5cf110f1401d7854f38f72`.
- Master `C:\Users\amiri\Downloads\Just_Peachy_Master_Workbook_Progress_Through_S2_V6.docx` — `df9bc6e8159f2980d9d8a7924999fb3229a8e78e8019fc54b698c3ad31b5ea17`. S3 did not rewrite it.
- `simulation\reports\S3\20260908T214914Z\inputs_manifest.json` — exact vectors, post-drive policy, utterance/transcript/license bindings; its SHA is in `run_manifest.json`.
- `simulation\reports\S3\20260908T214914Z\hardware_retry1\T3_ABA_repeat1\configuration.json` and repeat 2 — matching exposed test settings; their hashes and original/retry code snapshots are in the manifest/local index.
- `simulation\reports\S3\20260908T214914Z\h2_smoke.json` — paired **original** conversation-1 mono smoke. Its eight model IDs/hashes and source/config bindings remain the H2 baseline. This smoke is not from the retry pair.

The source utterances and speaker keys LibriSpeech:1272 and LibriSpeech:1462 are development-only. Keep them out of future untouched evaluation splits. The three exact sources, transcripts, copyright attribution and transformations are in the manifest; do not substitute a corpus re-download or silently rename identities.

The next prompt should settle these decisions before broad scene generation:

1. Choose a bounded output-level policy that prevents O1 clipping while preserving four-channel/cross-scene scale. Keep O0 and O1 paired; do not call the louder stream better or choose a winner from this smoke.
2. Define how stale/held angles and energy, long host-read gaps and transition instability are represented. The auto angle must not become a hard speaker ID or seat lock. Compare raw and selected/smoothed direction only through a verified single-owner logger with honest timing.
3. Establish a usable timing contract. Retain the 50 ms RIR onset convention, exact per-capture input offsets, host availability intervals and unresolved device timestamp offset. Do not insert a fitted telemetry shift or call 324.625/473.625 ms a device algorithm delay.
4. Freeze initialization explicitly: early packed-input selection, full static configuration, stated initial current AGC gain, pre-audio beam/energy observations, reset only between independent scenes. Identical hidden state is not guaranteed.

A small level/transition diagnostic bank is the recommended next scope. No training, H2 changes, full factorial scene bank, whole-library replay claim, naming evaluation or CM5 qualification is authorized by this handoff. The S3 retry budget is exhausted and all hardware is closed/restored.

To reproduce only metrics/plots, use the exact commands in the local `simulation\scripts\README_S3.md` or `LOCAL_ARTIFACT_INDEX.json`. Numerical analysis is safe offline. Do not rerun physical capture folders or resume a device using old endpoint indexes.
