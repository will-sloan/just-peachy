# S3 — READY_WITH_LIMITATIONS

The selected-RIR → physical XVF → unchanged H2 path works. All **8 physical captures** recovered their four microphone inputs exactly: **0 mismatches in 12,503,040 compared samples**. Both paired mono H2 runs completed with **zero dropped frames** and three final transcripts each.

Important limits: O1 had **329 rail samples in seven speech captures**; auto direction was unstable during B-right; logging had isolated gaps up to **731 ms**; absolute device/audio/telemetry alignment is unresolved. This is not an output winner or a full-campaign approval.

The six original cases and one initialization retry of the conversation pair used **199 seconds of playback**. Both owners restored their recorded initial configuration, including USB16/16 and packed input off, then closed all handles and released the hardware lease. Other PC audio devices remained connected and were not selected by the runner.

Read in order:

1. `S3_REPORT.md` — observations, interpretation and limits.
2. `metrics.json`, `per_case_metrics.csv` and Figures 1–3 — every original/retry attempt is represented.
3. `REPORT_SECTION.md` — proposed Revision 6 S3 results insertion, for ChatGPT review and light-yellow marking.
4. `NEXT_PHASE_INPUTS.md` — exact resume sources and the next bounded decision.

The initial comparison exposed uncontrolled current-gain readings. The single retry used early packed-input isolation and a consistent initial current gain; all original evidence remains. Similar repeat medians do not conceal the differing direction trajectories.

Recommended next gate: a small level/transition diagnostic bank that settles output headroom and stale-telemetry policy before wider scene generation. Do not train, change H2, regenerate RIRs or start a full campaign. No accuracy winner, enrollment/naming, moving-person or CM5 qualification is claimed.

Full local evidence: `C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S3\20260908T214914Z`. Raw audio, full transaction logs, models and private profiles are not in this ZIP. See `LOCAL_ARTIFACT_INDEX.json` and the external package receipt for hashes, sizes and timing.
