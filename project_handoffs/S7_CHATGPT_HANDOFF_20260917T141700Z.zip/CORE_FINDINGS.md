Final component analysis. Consult START_HERE.md and ACCEPTANCE_AND_MODE_STATUS.json for the complete stage disposition.

# S7 core results


## Population and timing

All960 original core conditions completed:240scenes ×2output taps ×2fixed C065/C088 paths.954were new serial native executions;6were exact compatible S7 reuse selected before the bank. Every original result retains its full-source PCM, source-clock, model/profile/gallery and completion binding. Prior supervisor interruptions and the archived incomplete attempt remain separate. One specifically reviewed earlier parent exit code is unavailable; it was not fabricated as zero.

The original bank contains955timing passes and5timing failures. The all-bank timing gate did not pass. All960 original results remain primary in the lexical/identity analysis; a955-cell/475-pair qualified subset is explicitly secondary and selected by observed timing. Earlier common clock/caption gates remain separately bound; these later failures cannot be retroactively erased by them.

| Original condition | Observed failure |
|---|---|
| C065 / S45_06_06 / O1 | One ASR journal append took15.53s, followed by155catch-up blocks; steady p95lateness10.83s |
| C088 / S45_09_05 / O1 | One admission overrun, about120ms total commit lateness |
| C065 / S45_10_19 / O1 | One admission overrun at1.8source seconds, about108ms commit lateness |
| C065 / S45_12_08 / O1 | One admission overrun, about101ms commit lateness |
| C088 / S45_12_20 / O0 | One admission overrun, about130ms commit lateness |

No source samples were dropped or trimmed, and no early/future release was observed in these five failures. The long interval is localized to the ASR append boundary; the trace does not establish whether storage, OS scheduling or a lock caused it. The four short overruns likewise do not identify a particular external process. Each failed condition received exactly one unchanged diagnostic repeat; all five repeats passed. That indicates intermittent recurrence in this small diagnostic set, not a repaired cause or permission to substitute favorable results.

## Reference-scored comparison

The following final-presentation metrics use the existing conditioned reference population:153numeric scenes per condition,4,623reference words per tap. The other87scenes per condition remain explicitly unavailable for attributed rate or zero-denominator where the original lexical metric defines that case. This is not an all240-scene complete-transcript accuracy claim and not a new untouched holdout.

| Path / tap | Serialized word errors | Serialized rate | Anonymous attributed errors | Attributed rate |
|---|---:|---:|---:|---:|
| C065 / O0 |892 /4,623|19.2948%|3,037 /4,623|65.6933%|
| C088 / O0 |892 /4,623|19.2948%|3,037 /4,623|65.6933%|
| C065 / O1 |939 /4,623|20.3115%|2,911 /4,623|62.9678%|
| C088 / O1 |939 /4,623|20.3115%|2,892 /4,623|62.5568%|

Across480scene/tap pairs,306have numeric attributed-reference scores. C088 has19fewer attributed errors over9,246reference words, a0.2055percentage-point reduction:2pairs improved,0worsened and304tied.174pairs lack the required numeric attributed denominator. Serialized error totals are unchanged in all306numeric pairs. Equal error totals alone do not prove identical raw transcripts; full text/span preservation is checked separately in native and mode evidence.

These findings support a cautious interpretation: adding optional names did not improve lexical accuracy on this scored subset, and attributed accuracy improved only modestly. They do not establish reliable known-person identification, outsider rejection, useful strict filtering or directional identity association. Visible Unknown/wrong-name exposure, timing and filtering are separate analyses; absence of a wrong-name event is not success if naming coverage is absent.

## Resource scope

Exact observed mean process CPU per completed cell was approximately15.59–15.69s across the four conditions, including initialization, processing and audits. Reused cells without an exact retained CPU observation remain unavailable. Maximum sampled RSS across these groups was approximately496–519MB(decimal). Samples are not proof of continuous peak memory, system-wide consumption, energy or CM5 suitability. The actual M0/other-mode compute comparisons come from the separate GUI/native panel.

## Binding and interpretation sources

- `application/core_bank_v1/CORE_CLOSURE_REVIEW.json`: original960closure, three owner epochs and five timing failures.
- `application/core_timing_review_v1/ROOT_REVIEW.json`: exact failure traces, component intervals and explicit adverse-evidence admission.
- `application/core_timing_review_v1/DIAGNOSTIC_REVIEW.json`: five distinct diagnostic repeats; original bank not replaced.
- `application/core_text_scoring_v1/full_v2_01/INDEX.json`: all960 original reference scores and per-cell timing eligibility.
- `application/core_summary_v1/full_v2_01/SUMMARY.json`, `CELLS.json`, `PAIRS.json`: condition/family/reference-qualified summaries, exact paired numerators and resource observations.
- `application/core_recovery_v1` and `application/core_disk_recovery_v1`: preserved supervisor failures, specific exit-code exception and archived incomplete retry history.
