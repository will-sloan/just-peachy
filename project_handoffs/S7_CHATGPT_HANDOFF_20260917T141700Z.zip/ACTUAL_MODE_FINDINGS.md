Final component analysis. Consult START_HERE.md and ACCEPTANCE_AND_MODE_STATUS.json for the complete stage disposition.

# Actual modes, fault exercises and public application checks

This analysis covers the completed 119 actual integrated GUI runs: seventeen matched sets, each with seven modes, comprising twelve scene families, C105 and four repeated cases. It is distinct from the 960 core runs and the separate 3,360 offline views. All 119 per-cell results and 102 paired contrasts are complete. The aggregate reports zero raw final text differences and zero raw final source-span differences across the actual paired mode comparisons. This was measured; identical neural output was not assumed.

Source pacing passed in 118/119 actual GUI runs. The original M1/C105 run had a 111.679 ms admission overrun at source0.8s; it remains failed rather than being replaced by a retry. Seven runs had empty native ASR/caption inventories; no text-rendering or caption-latency success is asserted for those. Full source PCM and actual mode/action mechanics are separately reviewed.

## Caption preservation and filtering

All seven modes produced 443 final raw words across the seventeen runs. The full visible M0/M1/M2/M3/M5 outputs each had 79 serialized edits over453 reference words (17.44%). This is the actual panel population, not the core bank's conditioned4,623-word population. Anonymous attributed scoring was available for fifteen of seventeen cells: M0 had340/453 errors (75.06%); M1/M2/M3/M5 had276/453 (60.93%). The other two cells remain explicitly unavailable. M0's single neutral-label presentation trades away diarization semantics; anonymous cpWER is not an intrinsic word-quality comparison.

Strict T1 and T2 each retained38/113 recognized, reference-qualified target words while strict mode was active (33.63%). The other75 target words were visible only during the scripted full-view/M2 rescue periods. Reporting ever-visible113/113 alone would therefore conceal strict-filter omission. No qualified non-target word was visible during strict periods (0/224), but seven unqualified recognized words were visible; that population cannot establish correct or incorrect person association. Each strict mode's final full-reference serialized score was420/453 edits; this includes intentional non-target omission and is not target-only recall. The strict-filter result remains inadequate for a general selected-person caption recommendation. T1/T2 equality is a measured result on this panel, not proof that their policies are equivalent generally.

M3 selected emphasis and M5 columns preserved all443 raw words, including113 qualified target,224 qualified non-target and106 unqualified words. They do not perform acoustic separation. Zero latest wrong-known fraction on this small GUI panel does not override adverse naming outcomes in the continuous/core cohorts.

Each mode had57 reference opportunities:39 observed first-text,15 right-censored and3 incomplete-reference opportunities for the unfiltered modes. M2 had15 observed correct-visible-name opportunities,12 right-censored,24 withheld/unselected,3 intended-but-unavailable and3 incomplete-reference opportunities. Only6 were confirmed-correct and4 stable-correct under the defined policy. Strict modes observed first visible text in33 opportunities, with21 right-censored and3 incomplete. Latency summaries condition on observed events; censored opportunities are never silently discarded or reported as fast successes.

## Actual desktop process cost

| Mode | Actual runs with CPU evidence | Mean whole-process CPU seconds | Maximum sampled RSS bytes |
|---|---:|---:|---:|
| M0 caption only |17|10.3199|391,634,944|
| M1 anonymous conversation |17|17.3447|513,527,808|
| M2 original-A15 naming |17|17.4798|511,713,280|
| M4 T1 strict |17|17.3153|511,283,200|

These are separately executed desktop workloads, including startup/drain. They are not elapsed source time, model-only CPU, simultaneous memory, CM5 capacity or watts. No resource-observation-gap cells were reported for these groups. The full summary contains all modes and strata.

## Bounded fault outcomes

All four exercises passed their declared functional source/closure predicates. F1 combined journal, reader, identity and UI delays; F2 exercised missing direction metadata; F3 manually changed idle/display states and deliberately paused the source; F4 cancelled at12s with an exact source prefix and closed workers. F3 is not faithful uninterrupted source pacing and is not labelled as such. F4 was never scored as a complete scene.

The three full-source fault cases retained the same final raw text and spans as their separately executed M2 control, and unchanged lexical/anonymous scoring numerators. Only one of six reference opportunities had observed first text in each full-source contrast; five remained right-censored. The single both-observed first-visible-text differences were+226.3ms (F1),-48.7ms (F2) and-24.1ms (F3). These are single observations, not population quantiles or isolated causal effects. Whole-process CPU differences were+1.3125,+0.96875,+0.90625seconds respectively. No automatic wake, first-phonetic-word preservation, lower model duty cycle, false-trigger rate or energy benefit has been qualified.

## Ordinary launcher, relocation and boundaries

All eight actual public CLI runs completed and independently passed source, timing and owned-closure review: four supported modes times file/actual GUI, on full C105 O0. A separate journal review verified eight distinct native process identities and session IDs, strictly increasing publication sequences, zero foreign-session events and no missing-session-ID events. This supports separate-process session isolation, not active-session gallery mutation or crash-resume recovery.

The two additional relocated public CLI runs completed and both passed timing review: copied C105 O0/file and O1/actual GUI, open_with_names, using the copied52-source-file/eight-asset/original-A15 capsule and its explicit windows_01 path derivative. Original vector/metadata bytes and thresholds were preserved. The installed desktop Python environment was reused; Linux/ARM64 and CM5 remain untested.

The first portable queue never launched because its repeated small-source checks incorrectly included the187.8MB model encoder. The new queue excludes only the eight model assets from repeated supervisor checks; the unchanged child verifies every asset before/after execution, and independent review verifies them again. Old failed preparation files remain intact. No completed audio experiment was repeated to repair this orchestration error.

Eight actual application-boundary checks passed: the real Tk GUI rejects gallery-file enrollment, profile removal, microphone enrollment and live-source start; no model/source starts during these checks; a fresh caption-only constructor has no prior gallery/session; original gallery metadata/vectors are unchanged; the exact production logging-handler constructor rotates diagnostics into at most five files of1MiB each while preserving the scientific-journal fixture. These are deliberately bounded desktop checks, not unsupported features presented as implemented.

The current listening review verified exact scene/pass coverage and current size/header/gain conventions for2,688 files:480 prepared O0/O1,480 accepted raw O0/O1 and1,728 mono streams from240 MAIN plus48 SCAN passes. MAIN and SCAN have different exact six-stream sets. Existing accepted payload/gain receipts were reused; there was no new waveform generation, playback or scientific readmission.

## Authorities

- application/mode_batch_analysis_v1/aggregate_01/{SUMMARY,CELLS,PAIRS}.json
- application/fault_outcomes_v1/run_01/{SUMMARY,CONTRASTS}.json
- application/native_fault_v1/review_01/REVIEW.json
- application/prototype_smoke_v1/STAGE_REVIEW.json
- application/portable_smoke_v2/STAGE_REVIEW.json
- application/native_session_review_v1/run_01/REVIEW.json
- application/application_boundaries_v1/run_01/CHECKS.json
- application/listening_verify_v1/run_01/REVIEW.json
