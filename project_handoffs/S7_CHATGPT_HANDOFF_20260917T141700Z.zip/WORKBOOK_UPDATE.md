# Proposed S7 insertion into V21 at human review

Leave the existing Word master unchanged until this text is reviewed. Suggested insertion: a new S7 results subsection, highlighted light yellow per the planning workflow.

S7 completed the bounded desktop pacing, caption/identity delivery and mode study:960 original core conditions/480 paired comparisons;119 actual GUI runs/102 comparisons; four30.7-minute continuous sessions;12 C-only calibration conditions; four fault exercises; eight public launcher and two relocated Windows runs;3360 offline presentation views/2880 contrasts. No new physical replay, RIR regeneration, training, neural-weight/default/H2 change or S8/S9 execution occurred.

Absolute source pacing and caption delivery repairs improved the measured time base and exact C105 sentinel. The broad bank retained955 core timing passes/5 failures and118 GUI timing passes/1 failure, including an unexplained15.53s ASR-journal append stall. Five unchanged diagnostic repeats passed but did not establish its cause. A positive bounded study completion is not an all-bank timing certification.

Lexical accuracy on the conditioned population was19.29% serialized error for O0 and20.31% for O1, unchanged by optional A15 naming. Naming reduced anonymous attributed errors by19/9246 words across306 numeric pairs;174 pairs were unavailable. Actual strict target retention was33.63%; full-bank offline strict-only retention was34.25% for T1 and32.25% for T2 on their different target populations. Full-view rescues are reported separately. Continuous identity/track accuracy remained adverse despite full caption/source preservation.

Both MAIN and SCAN calibration proposals remain disabled because no valid negative C sources met the unchanged fitting prerequisites. Clock repair did not supply missing contrasts. M6 missing-metadata abstention was tested; direction/person efficacy and scanner selection remain unavailable. Manual dim/listening/active states were exercised, but automatic wake/work reduction and energy benefit are not implemented/qualified.

Retain a caption-first opt-in desktop prototype, optional provisional names/emphasis, full transcript recovery and explicit Unknown. Do not promote strict filtering, spatial/scanner or automatic-wake capability. Windows relocation/source/asset/session/closure and diagnostic rotation checks passed; CM5 2GB/32GB ARM64 qualification remains future work. The compact S7 ZIP and external SHA256/CRC receipt are the authoritative reviewed handoff; detailed local bindings remain available.

Suggested figures if added later: (1) original timing pass/fail counts with outlier retained; (2) lexical versus attributed errors with explicit denominators; (3) strict-only versus rescued target coverage; (4) optional-mode capability matrix. No figure is required to understand the supplied tables, and no new perceptual/device result should be inferred.
