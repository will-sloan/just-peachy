Final component analysis. Consult START_HERE.md and ACCEPTANCE_AND_MODE_STATUS.json for the complete stage disposition.

# S7 calibration and conditional scanner disposition

Status: the complete twelve-condition C-only native collection and feature analysis are complete. Both separate physical profiles, P_MAIN6 and P_SCAN6, have `CALIBRATION_SUPPORT_INSUFFICIENT_SELECTORS_DISABLED`. No threshold, selector, duplicate resolution or default was enabled. This is a feasibility result, not successful spatial or scanner efficacy.

The native C collection independently passed full three-stream PCM, timing and process-closure checks for all twelve conditions. The collection used the existing thirty C clips, original A15 and recorded paths, with the repaired absolute source clock. E/C/Q roles and existing partition/support bindings remain attached to every feature document. No Q outcome entered threshold fitting. All twelve saved feature documents were reproduced from their bound native inputs before the completed proposals were written.

## Exact support at the five frozen fitting gates

Counts below are fitting-input rows after the existing eligibility and metric selection rules. These are not independent people or unique events; do not sum them into a new population. Every gate requires at least two distinct valid positive and negative C source IDs and retained positive support beyond negative/ambiguous bounds. No valid negative source is present at any gate.

| Gate | MAIN positive / negative / ambiguous rows | MAIN positive source IDs | SCAN positive / negative / ambiguous rows | SCAN positive source IDs |
|---|---:|---:|---:|---:|
| Selected score | 14 / 0 / 2 | 2 | 8 / 0 / 2 | 1 |
| Selected margin | 14 / 0 / 2 | 2 | 8 / 0 / 2 | 1 |
| Beam margin | 0 / 0 / 3 | 0 | 0 / 0 / 2 | 0 |
| Automatic correlation | 79 / 0 / 522 | 9 | 78 / 0 / 520 | 10 |
| Automatic margin | 0 / 0 / 292 | 0 | 0 / 0 / 290 | 0 |

The two MAIN selected-score sources are CMU_awb_arctic_b0177 and CMU_bdl_arctic_b0294; SCAN supports only the former. Ambiguous identity, overlap, same-bearing support, unmatched speech and incomplete ambience remain ambiguous rather than being relabelled as negative truth. Improving the clock cannot supply missing contrasts. The absence of positive beam-margin and automatic-margin support is an additional limitation.

The required missing evidence is defensibly labelled target-absent/out-of-gallery C material on compatible captured paths, with at least two distinct negative sources per gate, adequate positive competition/margin support and exact-selector joint negative challenges. No new physical acquisition is authorized by S7. MAIN and SCAN are separate adaptive physical passes; they were not joined as simultaneous waveforms.

## Numerical validation recovery

Native cosine-like waveform correlation produced thirteen values of 1.0000000000000002, exactly one float64 representable step above 1. Original strict input validation rejected these. A separately bound adapter accepts only that one-step endpoint allowance for automatic correlation; it rejects a two-step excursion, nonfinite values and booleans. Raw values are not clamped, rounded, deleted or rewritten. Threshold arithmetic, support labels, freshness gates and selector logic remain unchanged. The original failed outputs and frozen helper are preserved. Checks cover both probe extraction and fitting-input validation.

Windows CRLF expansion also made a feature file exceed its LF-based serialized-byte estimate. A new writer explicitly uses LF, preserving exact size enforcement and JSON content. Twelve complete existing feature documents are retained in C_analysis_v4/run_01; the separate finished_01 completion contains two proposals and an index and references those documents rather than duplicating them.

## Conditional modes

Spatial/person association and scanner selection remain disabled for recommended operation because their calibration prerequisites are absent. C freshness success is not proof that a beam identifies a person. M6 missing-metadata abstention is exercised separately by the fault panel; its completed result is joined in ACTUAL_MODE_FINDINGS.md. No zero-eligible result is called zero-error efficacy. No new secondary-ASR merge policy is enabled or Q-tuned. The existing same-pass 48-scene SCAN opportunity remains motivation for future authorized work, not runtime policy evidence for 240 scenes.

## Local authorities

- application/C_native_v3/ALL12_REVIEW.json: independently accepted twelve native conditions.
- G:/Just_Peachy_S7/20260917T141700Z/C_analysis_v4/finished_01/INDEX.json: completed extraction and separate profile proposals.
- P_MAIN6_PROPOSAL.json and P_SCAN6_PROPOSAL.json beside that index: exact support counts, source IDs and five disabled gates.
- application/C_admission_recovery_v1/CORRELATION_FAILURE_CENSUS.json: original thirteen endpoint values.
- application/C_roundoff_review_v1/README_FINISH.md: recovery scope, checks, reproduction commands and unchanged-science limits.
