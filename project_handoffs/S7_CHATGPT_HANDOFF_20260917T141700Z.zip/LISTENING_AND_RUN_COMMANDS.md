Final component analysis. Consult START_HERE.md and ACCEPTANCE_AND_MODE_STATUS.json for the complete stage disposition.

# Existing audio and the opt-in S7 desktop launcher

These commands use the implemented public App.py interface that completed eight ordinary file/GUI smokes. No scientific manifest is required by the public application. Use a fresh output directory for each run. The examples use an already processed, full-duration mono C105 O0 file; its historical+3dB preparation is already present, so the application reads it at unity. No XVF connection or speaker playback is needed for this saved-file processing.

The conservative starting mode is caption_only. It preserves words with a neutral label and avoids optional speaker analysis. open_conversation adds anonymous tracking; open_with_names uses the original fifteen-person A15 gallery; selected_emphasis preserves the full transcript while highlighting a selection. Their functionality was exercised, but identity accuracy and occasional source-admission stalls remain limitations. Strict filtering, spatial association and scanner selection are not offered as qualified ordinary modes. No existing default is promoted.

## PowerShell

```powershell
$Py='C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe'
$R7='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S7\20260917T141700Z'
$App="$R7\application\prototype_v1\App.py"
$Config="$R7\application\prototype_v1\CONFIG.json"
$Wav='G:\Just_Peachy_S6B\20260909T230840Z\inputs\S45_08_07\O0.wav'
$Out='G:\Just_Peachy_S7\20260917T141700Z\user_gui_'+(Get-Date -Format 'yyyyMMdd_HHmmss')
& $Py -B $App gui --config $Config --mode caption_only --wav $Wav --output $Out --language en
```

For file-only processing, substitute `file` for `gui` and use a fresh output path. To inspect the existing gallery, run:

```powershell
& $Py -B $App profiles --config $Config
```

Use a returned profile ID with the public `--selected` option when choosing selected_emphasis. Do not insert evaluator actor IDs, reference transcripts or true angles into runtime inputs. An explicit caption-only fallback can be requested with `--allow-caption-fallback`; its reason is recorded. The application otherwise rejects invalid prerequisites rather than silently changing mode.

## Anaconda Prompt / Windows CMD

The executable already identifies the existing environment; activation and installation are unnecessary. Change USER_GUI_01 to an unused folder on subsequent runs.

```bat
set "PY=C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe"
set "R7=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S7\20260917T141700Z"
set "WAV=G:\Just_Peachy_S6B\20260909T230840Z\inputs\S45_08_07\O0.wav"
set "OUT=G:\Just_Peachy_S7\20260917T141700Z\USER_GUI_01"
"%PY%" -B "%R7%\application\prototype_v1\App.py" gui --config "%R7%\application\prototype_v1\CONFIG.json" --mode caption_only --wav "%WAV%" --output "%OUT%" --language en
```

Input must meet the implemented saved-file contract: mono16kHz PCM16 English, at most one hour. The config explicitly binds source, profiles, eight model assets and gallery. Outputs include application RESULT.json, consumer/resource logs and a unique session directory containing original PCM journals, clocks and transcript histories. Application diagnostics rotate at1MiB with four backups. Scientific audio/event journals remain immutable and do not rotate; the caller must budget storage.

Live input, recording enrollment, gallery mutation and device enumeration are disabled in this prototype. Changing workload mode requires a fresh process. The successful boundary tests do not qualify active-session gallery replacement or automatic wake. Close the GUI normally to stop. To roll back the opt-in candidate, close its process and return to the existing pre-S7 application/launcher; no default, model asset, H2 engine or pre-S7 source was replaced, so no file restoration or dependency downgrade is required.

## Listening to pre-existing scenarios

Open this existing page to browse the240 scene descriptions, cast/turns and reference words:

`C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\listening\S45_all240_v1\index.html`

Prepared mono files are:

`G:\Just_Peachy_S6B\20260909T230840Z\inputs\<S45_scene_id>\O0.wav`

`G:\Just_Peachy_S6B\20260909T230840Z\inputs\<S45_scene_id>\O1.wav`

O0 includes the historical+3dB adapter once; O1 is unity. Do not apply that gain again. Read/play both prepared signals at unity. Their full saved durations preserve scene timing, silence and later activity; this is not a requirement imposed by a44-second impulse response. S7 did not trim silence to improve speed or latency.

The existing same-pass beam library is:

`C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\listening\S45_all240_v1\S6D_same_pass_v1\index.html`

Its AUDIO_REFERENCES.json gives the exact accepted paths for240 MAIN and48 SCAN physical passes. MAIN contains auto_asr_raw, auto_pp_raw, focus0_asr_raw, focus1_asr_raw, focus0_pp_raw and focus1_pp_raw WAVs. SCAN contains the same first four plus scan_asr_raw and scan_pp_raw. These are mono unity-saved processed signals; the packed four-channel carrier is not a listening output. MAIN and SCAN cannot be compared as simultaneous streams from one pass. A beam is not a person.

The S7 read-only review checked2,688 current audio references, sizes, frames, mono16kHz headers, exact scene/pass coverage and saved gain conventions. It reused accepted waveform-hash and exact-gain receipts; it did not recreate audio, run perceptual playback or grant renewed scientific timing/person association. Incomplete environmental-speech references remain labelled in the original index.

## Verified relocated Windows capsule

`G:\Just_Peachy_S7\20260917T141700Z\Desktop_Capsule_v1`

The copied App.py with `configurations\windows_01\CONFIG.json` completed full C105 O0/file and O1/GUI open_with_names tests. The capsule contains52 source files, eight existing assets, original A15 metadata/vectors and two workload files, not the research corpus. Relocate.py creates a new explicit configuration/gallery-path derivative if the capsule moves; original template bytes and thresholds remain unchanged. Use the capsule's README and the local portability_v1/README for exact relocation commands. Reusing desktop Python does not establish Linux/ARM64 compatibility, CM5 2GB memory suitability,32GB eMMC deployment, live audio or power performance; those remain S9 work.
