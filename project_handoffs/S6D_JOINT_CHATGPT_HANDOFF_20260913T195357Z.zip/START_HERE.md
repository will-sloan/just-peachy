# S6D expanded capture and integrated application study

Read S6D_REPORT.md first, then BEAM_INTEGRATION_RESULTS.md and DISPLAY_AND_DIRECTION_MODES.md. This package records a bounded research stage with mixed and negative outcomes. It does not certify a finished product, reliable speaker extraction, calibrated direction, or CM5 performance. Consult external DELIVERY_CLOSURE.json for the final archive verification and execution state; these documents alone are not a delivery receipt.

The physical bank and declared native populations have completed. MAIN has all240 scenes with six same-pass processed outputs; SCAN has48 scenes with its separate six-output pass. Four continuous native conditions, two30-minute host sessions, full960 native cells, selected-speaker GUI coverage, device enrollment and saved-output scientific comparisons have been evaluated. Counts overlap where prior compatible outputs were credited; never add every table as independent trials.

Main decisions:

- Keep the existing default. C065 anonymous and C088/A15 naming are opt-in desktop research conditions with exact bindings, not newly promoted configurations.
- Retain ±5° acquisition uncertainty. Hypothetical ±2°/0° only alter interval-based evaluation. Reject all eight narrower operational-width replacements.
- Preserve the full transcript. Selected-person display withholds substantial target speech; it is a conservative presentation filter, not acoustic isolation.
- Do not enable calibrated beam/person association or advertise useful voice-gated arrows. C12 supplies neither timely eligible association evidence nor unambiguous negative calibration support. Zero arrows/known names is unavailable efficacy, not perfect accuracy.
- Focused streams sometimes recover omitted words but usually lose more; scanner has panel-limited lexical opportunities. No runtime selector or replacement device gallery was selected from Q.
- Text delivery and bounded source/event handling are implemented, but naming latency goals and speaker continuity remain unmet. Preserve the C105 native attribution regression.
- CM5 manifests/workload are preparation only. No ARM64, total2GB, eMMC or field qualification was executed.

All audio remains local. Open `simulation/listening/S45_all240_v1/index.html` beneath the simulation root in LOCAL_ARTIFACT_INDEX.json. Its S6D_same_pass_v1 subfolder adds1,728 links to actual new raw mono outputs. Original240 O0/O1 model-input pairs remain under `G:/Just_Peachy_S6B/20260909T230840Z/inputs`; O0 already has the historical +3dB once. The listening indices include scenario/voice/overlap descriptions and source text where available. Do not treat incomplete ambient text as complete truth.

The supplied XVF_Measurement_V20.docx remains unchanged. WORKBOOK_UPDATE.md is an insertion draft with light-yellow guidance. Earlier pending snapshots and failed epochs remain local history; current measured tables and the delivery closure take precedence for completion status.

For a later ChatGPT/Codex planning step: identify the desired next research question explicitly, preserve these negative controls, and use exact sources in PROFILE_EPOCH_GALLERY_MANIFEST.json. Do not automatically resume captures, replace galleries, tune on Q, regenerate RIRs, or launch S7–S9. The broader S7 UX work is not completed by these prototypes.
