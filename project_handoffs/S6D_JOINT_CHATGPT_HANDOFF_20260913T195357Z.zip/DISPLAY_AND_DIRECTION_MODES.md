# Display and direction capability

| Mode | Actual implementation/testing | Scientific disposition |
|---|---|---|
| T0 full conversation |Native full-bank and paced application, actual Tk and long host|Retain full journal; words are not speaker-identity proof|
| T1 selected person |Application CLI/config/GUI; all-bank compatible policy replay; actual selected-present/absent GUI|Optional research display, substantial target omissions; no acoustic separation|
| T2 selected set/all enrolled |Same hooks; fixed selections, actual gallery queries and native shared-engine GUI views|Optional research display; known/unknown rejection remains; not a gallery-threshold shortcut|
| V0 recent direction |Implemented/replay/GUI source fixtures; historical telemetry diagnostic|Not proof that the visible angle belongs to the named voice|
| V1 speech-gated direction |Implemented/replay/fixture-tested; native policy hook exists|Qualified source/beam association unavailable; no useful arrow coverage demonstrated|
| V2 selected-person direction |Implemented/replay/fixture-tested|Requires current voice AND independently associated spatial support; same unavailable efficacy|
| V3 at most2 distinct supported people |Implemented/replay/fixture-tested, expiry/duplication fixtures|No physical demonstration of2correct distinct person/beam arrows|

No mode has CM5/physical display-scanout qualification. Actual Tk callback evidence means real widget mutations after publication; it does not measure photons or add independent neural trials for the three views.

Selectors are fixed before prediction. The unfiltered event/text journal remains available, including speech hidden by T1/T2. Pending or unknown identity does not become the selected person simply because one gallery member is requested. Historical names/locations cannot authorize current-speech arrows during music, silence, stale observations or a new session. Folded0..180° ambiguity remains explicit.

The repaired full-bank A15 replay covers480scene/tap outputs. It is separate from the original A15/B15 historical replay. Actual selected42 comprises38new GUI runs and4original credits, all target-absent. A disclosed posthoc coverage repair adds16actual GUI runs(8source-present scenes ×2taps) for the original fixed selected person. This is not an independent holdout. Underlying models/source/gallery/settings remain bound.

Target-present T1 shows38/85conservatively matched target words onO0 and46/85onO1; respective T0 values65and64. Five/nine and four/nine supported target turns never become visible. The small T2set has the same result in this subset. In the full-bank all-enrolled T2 population(117source-present scenes/tap), target matches fall from1,485→589(O0) and1,471→535(O1) over2,500reference words;190/280 and188/280 target turns never appear. Speech/source support is estimated, not word-aligned ground truth. Mixed/ambient/incomplete words remain unclassified and receive no false-name success credit.

Keep the actual event-level timing and cold/first/stable/warm-return denominators in the bound per-case scores. A row never shown has no favorable visibility latency. GUI_VISIBILITY_ROWS.json preserves116view-comparison rows with all never-visible denominators separately from callback timing. Callback summaries in RESOURCE_GROUPS.json explicitly distinguish per-cell percentiles from pooled event percentiles.

The historical V0 replay displays3,348.7direction-seconds per240-case tap, including about1,471seconds outside complete referenced speech and another174.627seconds on incomplete-reference cases. V1–V3 yield no supported association. False-arrow error/coverage cannot be called a useful frontier by declaring the empty output perfect. No embedding contains azimuth; beam indices and automatic-selected processed angles do not identify the correct voice on their own.

C105 source-only boundary tests cover timing perturbations, ties, out-of-order/expired evidence and adjacent voices without permitting unlimited stale revision. Native repaired C105 still contains an attribution regression. ARRIVAL_BOUNDARY_AND_NATIVE_LIMITS.md preserves both facts; no general identity-fix claim is justified.
