# Matched clean versus device-domain enrollment

All360 native device templates were created and independently read back:30people ×2measured positions ×6processed streams, with56originalPASS and304REVIEW_LOW_CONSISTENCY flags. The190unique E utterances remain disjoint from C/Q. Two renderings or beams of one utterance are correlated acoustic variants, not additional unique enrollment duration. Clean per-clip and device whole-capture window contexts differ; this comparison cannot isolate a device-only cause.

Twenty-six fixed gallery conditions (clean A15/B15 plus24 device conditions) were calibrated on disjoint source-clean C using the unchanged rules. There were no actual stranger C queries; the original unknown_rejected field denotes abstained known C queries. No Q thresholds or gallery winner were fitted. Current physical C12 beam-selector calibration is a separate unavailable capability.

The completed576-cell cached panel provides scene-compatibility diagnostics across all available streams. Its scene-present nominations are not active-talker identity. A new, stricter temporal comparison uses2616actual saved auto-ASR embeddings from96query recordings:48MAIN and48SCAN. All26galleries see the identical query vectors and roster-matched denominators. The six enrollment taps and two seats remain separate conditions. Focused/PP query timing is not silently borrowed from automatic ASR.

For temporal scoring, the full receptive window must fit within one source speaker's declared clip/convolution support, with no other source identity overlapping, at five fixed perturbations around the descriptive auto lag. This is conditional source support, not certified physical timing or a guarantee that the window contains only clean speech. Incomplete, mixed, partial and missing-lag cases remain explicit.

| MAIN auto-ASR query / clean gallery | Correct known / eligible known windows | False name / eligible outside-gallery windows | Known source turns with supported correct nomination |
|---|---:|---:|---:|
| A15 mature |12/12|3/177|5/24|
| A15 short |12/41|1/272|6/24|
| B15 mature |60/62|0/127|22/44|
| B15 short |39/114|0/199|22/44|

The12/12 A15 mature result spans only four contributing scenes and five supported source turns. Nineteen of24known source turns have no eligible mature window. B15 mature has22/44known turns without eligible support. Those denominators prevent a misleading claim of near-perfect end-to-end recall. An unsupported turn is not automatically a model miss, but it also cannot receive success credit.

Source-turn coverage is authoritative in conditional_coverage_completion_v1/TURN_COVERAGE4992.json. It materializes every26gallery ×96query ×2evidence-kind row, including156missing-kind rows where no short or mature event existed. All earlier populated rows match exactly; event scores/predictions and bootstrap rates did not change.

Device enrollment has mixed effects. Across24device conditions on MAIN mature queries, the change in correct-known window coverage spans -8.33 to+3.23percentage points; outside-gallery false-name rate change spans -0.565 to+2.260points. For example, B15/R04 automatic-ASR enrollment changes60/62 to62/62with0/127outside-gallery false names, while some focused/PP conditions lose correct matches. A15/R04 automatic-ASR remains12/12but changes3/177false names to4/177. These are descriptive matched conditions, not a chosen winning gallery.

All paired comparisons and fixed-seed2000scene bootstrap intervals are in ENROLLMENT_DOMAIN_COMPARISON.csv. Windows within scenes are not treated as independent. Repeated people/utterances across scenes remain a limitation; intervals are exploratory and unadjusted for the many displayed conditions. Cached cosine nominations are not native tracker/GUI predictions under a replacement gallery. No consistent deployable enrollment improvement is established and no template/default is replaced.

H13 independently reconstructs all360original native centroids from exact saved window embeddings. A descriptive counterfactual removes windows below RMS0.002:35of56originalPASS remainPASS,149of304originalREVIEW becomePASS, and21originalPASS losePASS. This changes totalPASS56->184, but quiet speech can be removed and consistency changes mechanically. No new template is written and recognition benefit is not inferred from this statistic.

Authoritative local inputs/results: device_enrollment/native_templates_readback_v1, cached_C_calibration_v1, conditional_heldout_analysis_v1 and conditional_coverage_completion_v1; application/cached_panel_analysis_v1 and additional_hypotheses_v1/H13_ENROLLMENT_WINDOW_CONTEXT.json. Each executable stage has exact reproduction instructions in its README. Full vector and nomination tables remain local.
