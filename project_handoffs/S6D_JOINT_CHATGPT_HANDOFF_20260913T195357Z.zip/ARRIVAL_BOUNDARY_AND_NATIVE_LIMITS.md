# Arrival boundary and native confirmation

The original C105/S45_08_07/O0 problem involved identical saved vectors/choices with roughly1.14ms arrival-order changes and1→21cp edits over41reference words. S6D adds bounded event ownership/source spans, immediate text delivery, stable row revision, freshness/expiry and order-boundary handling. The exact source epoch and model-free tests are bound in the artifact index.

Ten saved-event C105 boundary rows in the v3 replay cover variants around the original ordering while preserving raw words. Independent GUI/direction tests also address prior session-clock and stale/session rollover defects. These are source/replay checks, not a replacement for native measured attribution.

Native comparison preserves all adverse results:176declared paired comparisons are raw-word/final-span equivalent under their comparison gate. C105's repaired O0 second repeat still changes1→21cp edits/41words; its4cell grouped cpWER rises26.829→39.024%. Keep C105 diagnostic-only and do not call the native ordering/attribution problem generally fixed.

The42core C065 pairs have median consumer delta−0.289s but p95+2.591s; C088 pairs median−0.220s,p95+3.268s. Extra naming versus anonymous in repaired core is median−0.001s,p95+2.316s. On the two30-minute host conditions it is median+1.261s,p95+1.585s,p99+1.622s across105comparable first rows. Thus the provisional+0.10smedian/+0.25sp95 naming goal is not consistently achieved. Do not advertise a general latency win from median-only repair results.

Fullbank conditioned attributed scores, selected-view omissions, long-session fragmentation and raw-word equivalence have different populations. The original native176 analysis is retained in NATIVE176_ANALYSIS.md, with its historical future-queue wording clearly superseded by the final960assembly. Source revision guards are useful engineering, but text correctness, named identity, GUI callback delay and physical scanout are separate claims.
