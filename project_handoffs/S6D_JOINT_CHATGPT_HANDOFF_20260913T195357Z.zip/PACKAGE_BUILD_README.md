# S6D compact handoff builder and verifier

Purpose: assemble the final analysis-first package from accepted local results, preserve adverse/unsupported outcomes, pin local artifact/source/workbook bindings, and verify archive members/checksums. No audio processing, models, hardware, source deletion or Word modification. BUILD_RECEIPT is package validation pending root final review; external DELIVERY_CLOSURE records final delivery afterward.

Inputs: authored Markdown in this directory; the explicit AUTH/COPIES maps in Build.py; original/new listening indices; exact profile/model/source manifest; completed host/resource/selected/enrollment/beam/angle evidence. Outputs: fresh package/ folder, BUILD_RECEIPT.json, and simulation/handoffs/S6D_JOINT_CHATGPT_HANDOFF_20260913T195357Z.zip. Copies compact metadata and summaries; raw audio/models/vectors/full logs remain local. Target10MiB, hard20MiB, maximum80members. All direct listed source files are rehashed, but nested bulk payloads rely on prior accepted binding receipts.

Run once from the original local namespace. Verification can be repeated read-only. This builder locates the original report root relative to its saved source; a copied archive is not a self-contained simulation environment.

PowerShell:

```powershell
$d = 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6D\20260913T195357Z\handoff_final_v2'
& 'C:\Users\amiri\anaconda3\python.exe' -B "$d\Build.py" build
& 'C:\Users\amiri\anaconda3\python.exe' -B "$d\Build.py" verify
```

Anaconda Prompt / CMD:

```bat
cd /d "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6D\20260913T195357Z\handoff_final_v2"
"C:\Users\amiri\anaconda3\python.exe" -B Build.py build
"C:\Users\amiri\anaconda3\python.exe" -B Build.py verify
```

The original allocation guard and campaign C50/G75 floors/cutoff apply to build. Existing package/ZIP causes refusal. Before repairing an interrupted build, preserve its source/failure/partial output, then use a new explicitly versioned namespace and unused destination. Do not overwrite final evidence or delete a previous package to rerun. No new tests mirror the copy implementation; verification checks actual ZIP CRC, complete member population, all SHA256 hashes, JSON parsing, safe names and required deliverables.
