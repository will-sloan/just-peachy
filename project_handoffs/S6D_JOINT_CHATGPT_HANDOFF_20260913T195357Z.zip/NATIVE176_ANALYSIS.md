# Historical native176 analysis

This is the original measured analysis. References below to future892/native execution are historical: final960is now complete with68reviewed credits. Adverse C105/latency results remain valid.

# Native176 closed results and retention proposal

All176 scientific IDs are scored:168core and8C105 diagnostic, comprising171 original closed jobs and5 exact fresh recoveries. The old176 checkpoint remains REPORT_BLOCKED; the stopped old C105 result is uncredited. Exact scorer retry exited0. This report is descriptive and creates no retention, cache, or future execution approval.

All176 predeclared pair comparisons preserve entire raw text, exact final raw rows and supplied final source spans. All388 first-row comparison opportunities are comparable. Reference-conditioned text correctness has a narrower population than this text-equivalence check.

| Condition | Jobs | Serialized errors/reference words | Pooled per-job anonymous cpWER | Correct / eligible enrolled | Stable / eligible enrolled |
|---|---:|---:|---:|---:|---:|
| C065_original | 42 | 160/800 | 57.500% | 0/0 | 0/0 |
| C065_delivery_repair | 42 | 160/800 | 54.750% | 0/0 | 0/0 |
| C088_original | 42 | 160/800 | 56.625% | 10/34 | 5/34 |
| C088_delivery_repair | 42 | 160/800 | 56.375% | 10/34 | 5/34 |
| C105_original | 4 | 4/164 | 26.829% | 0/0 | 0/0 |
| C105_delivery_repair | 4 | 4/164 | 39.024% | 0/0 | 0/0 |

Each42-job core group has136 reference occurrences:106 eligible text occurrences and30 excluded due incomplete speech reference. Correct naming for C088 has34 enrolled eligible occurrences:10 observed,24 right-censored; the other102 are30 incomplete,50 withheld/unselected and22 intended-but-unavailable. Confirmed/stable naming is5/34, with29 right-censored. C065 has no gallery, and C105 targets are withheld/unselected; their0/0 naming entries are unavailable controls, not success rates.

The four incomplete speech cases are S45_01_16, S45_03_19, S45_06_19, S45_10_10. No full-session WER is claimed there.24 zero-reference noise/silence jobs emitted zero final raw words; they remain separate from reference-word WER. Repeats remain observations, not independent cases. Among the fixed C088 preferredr1 rows, correct-name statuses are {"INCOMPLETE_REFERENCE": 30, "OBSERVED": 10, "WITHHELD_OR_UNSELECTED": 42, "RIGHT_CENSORED": 12, "INTENDED_BUT_UNAVAILABLE": 18}.

Short-reply S45_03_03 is adverse: all C088 original/repaired O0/O1 repeats have no correct name in the48 combined enrolled opportunities. Raw serialized text is correct for its10 words per job, but anonymous cpWER is100% and only one first-text opportunity is attributable among six reference turns per job. Merged utterance spans are not split into invented word timestamps.

| Comparison (right minus left) | Pairs | First rows | Median consumer delta(s) | p95 delta(s) | Right earlier / later |
|---|---:|---:|---:|---:|---:|
| C065_original_to_repair | 42 | 91 | -0.289 | +2.591 | 55/36 |
| C088_original_to_repair | 42 | 91 | -0.220 | +3.268 | 53/38 |
| C088_additional_naming_original | 42 | 91 | +0.132 | +1.664 | 40/51 |
| C088_additional_naming_delivery_repair | 42 | 91 | -0.001 | +2.316 | 46/45 |
| C105_diagnostic_original_to_repair | 4 | 12 | -0.833 | +0.974 | 8/4 |
| C105_diagnostic_additional_naming_repair | 4 | 12 | -2.591 | +0.147 | 11/1 |

These paired observations show mixed timing, not universal improvement. C065 repair has36 later rows (maximum+4.040s); C088 has38 (maximum+4.238s). Two biggest examples and every per-pair delta are in DESCRIPTIVE_COMPARISONS.json/PAIR176.json. First-text reference-level censored cases remain separate; per core group71/106 are observed and35 are right-censored. Timing is actual headless publication/consumer timing, not Tk rendering or physical scanout; host/load/time drift is not causally isolated.

C088 final qualified correct-name rows increase8→10 while opportunity-level ever-correct stays10/34 and stable stays5/34. No wrong-known-name exposure was scored in qualified visible intervals. Unqualified/hidden intervals are retained, so this is not proof of zero wrong names everywhere. Row-seconds overlap and must not be read as wall-clock percentages.

C105 remains diagnostic only. Its four repair comparisons preserve raw words; first-text median delta is−0.833s with four later rows. The repaired O0 second repeat changes anonymous cpWER from1/41 to21/41 despite unchanged text, so the pooled diagnostic cpWER worsens26.829%→39.024%. All12 naming opportunities per condition are withheld/unselected. This does not demonstrate general name recovery or actual GUI ordering repair.

Recommend retaining C065 as the anonymous research control and C088 as a limited named research candidate for the required full240 confirmation, conditional on root review. This is a recommendation to continue evaluation, not default promotion, latency dominance or study completion. Preserve C105 as an adverse sentinel; do not extend it to the general matrix.

The68 fixed preferred repairedr1 metadata joins pass against the accepted full-source composite proof. Accepted credits remain zero until root reviews retention and exact future source/profile/gallery/PCM/context/pacing compatibility. Four repeated cases retain both repeats; none may be replaced by a more favorable repeat. If all68 are accepted,892 new serial jobs plus68 credits cover960 cells. Any rejected credit requires an explicit revised plan.

Future892 remains gated by root authority, one total native efficacy NNworker, threadpools1, controlled allocation, separate C12/Tk/HOST closure, current process/resource checks, C50/G75GiB floors, exact80GiB exception, and original deadline/45min closeout reserve. No current resource census, process query, model/scorer call or approval was performed by this report.

Exact input bindings and all adverse/never-correct cases are retained in the adjacent JSON files and original scored outputs. Metrics are unchanged4260 through composite31408; current accepted specaf0951 uses the reviewed identical-byte dependency relocation.
