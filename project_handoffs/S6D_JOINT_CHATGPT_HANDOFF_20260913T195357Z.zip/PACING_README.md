# Estimated support pacing audit

240 scenes total 10,967 source seconds. Summed whole-probe duration is 2,830.589250s; the estimated speaking-support union is 1,851.659s, with 63.342s of distinct-voice overlap. The supported duty fraction is 16.8839%. These are broad 20 ms energy-support estimates reused from bound source activity; no precise silence percentage is claimed.

Whole probe length includes source-internal silence and overlap between utterances. Per-scene unions avoid double counting; overlap requires different speaker keys. Read all limitations in PACING_AUDIT.json. Scene padding to first/last whole probe, source-internal support gaps, inter-actor handoffs, levels, corpus partitions, room/family coverage and reuse are separate tables. Long lead/tail durations and limited simultaneous voice support constrain dialogue realism. No fresh models, human judgments or stress derivatives were produced.

Inputs and reproduction: see simulation/scripts/s6d_listening_README.md; run the build with a new output/report location. Output CSVs preserve every case and source instance, including limited/incomplete references.
