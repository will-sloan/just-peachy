# Beam integration results and dispositions

This consolidates the bounded hypothesis study. The external delivery closure records final package verification. Read S6D_REPORT.md and the bound result files. No default was promoted and no new model/hardware call was needed for the added diagnostics.

| Hypothesis | Actual evidence | Disposition and limit |
|---|---|---|
| BXR1 auto-selector omissions | Same-pass fixed48panel, full-text624 scores,31complete nonempty scenes/965words; actor-exclusive lexical comparison63actor-scene rows/881tokens | Focused streams sometimes retain reference tokens absent from auto, but also lose tokens. No causal selection or clean-source separation inferred. |
| BXR2 mono ASR plus beam identity | Core96 and four continuous native runs, full-source/readback; matched controls | Automatic ASR text retained. With unavailable C association, beam branch yields no known names and poor anonymous attribution; no integration benefit established. |
| BXR3 embedding-led beam choice | Physical C12, two proposals, native unavailable-mode behavior, fixed query diagnostics | Disabled. All5882candidate observations fail original0.75s source-age rule; minimum first-availability source age1.78985s. Independently, no unambiguous negative calibration examples exist. Not merely a failed score threshold; no Q fitting or relaxation. |
| BXR4 duplicate control |336same-frame waveform pair comparisons plus actual saved embedding contexts and source-count strata | High cross-focus similarity is common and does not imply distinct sources. No calibrated same-person merge enabled; similar/overlapping voices and absent negative calibration remain unresolved. |
| BXR5 dual ASR/PP views | Same-pass text/rail findings;240fixed paired conditions,5397unique exact frame/clean/evidence contexts | Views can change words, admission and embeddings. Not independent votes or a universal PP winner; unmatched contexts and90PP rail streams retained. |
| BXR6 scanner as change sensor |48SCAN cases with same-pass controls, whole-word and actor-exclusive scanner comparisons | Scanner shows lexical recovery opportunities. No validated causal change-trigger policy or identity cue is claimed; noise/music and association/calibration limits remain. |
| BXR7 stable person/beam association | Native dual focus states, strict expiry/NO_MATCH behavior, core96 and continuous4 | Identity continuity is not demonstrated. Correct spatial/person association cannot be established from beam number or scene presence; ambiguous/front-rear cases remain unknown. |
| BXR8 dynamic extra computation | One shared model stack, serial focus identity processing, bounded queues and measured fixed-mode costs | Dynamic second ASR / waveform switching was not implemented or validated. Fixed-mode diagnostics are not a cost/accuracy frontier. No safe causal ambiguity-trigger calibration supports promotion; no truth-triggered work. |
| BXR9 device enrollment |360native templates,26Cfits,576scene diagnostics and96conditional timed query cells ×26galleries | Mixed coverage/false-name changes; original quality flags and all source-turn denominators retained. No replacement gallery selected from Q or promoted. |
| BXR10 AGC-aware reliability | Raw unity waveform/rail analysis, paired text/voice differences, recorded telemetry observer findings |90PP rail streams versus0ASRrails; sparse optional gain telemetry cannot identify an inverse gain or isolate AGC causality. No loudness-based identity or quiet-speech suppression. |
| BXR11 continuous-state recovery |Two uninterrupted900s physical conversations, four full native runs; all57source occurrences per conversation, pauses and queues scored | Caption text resumes after all4physicalpause episodes in both modes; voice continuity remains poor. No matched cold-reset causal attribution. |
| BXR12 user-assisted fixed beams |Verified captured automatic/focused/scan routes; original geometry/native-angle transform remains unverified | No fixed-table hardware contrast was executed. Cannot claim verified wrong-setup/relocation robustness or steer to evaluation truth. Retain as unqualified research capability, not a usable tested profile. |

Additional nonredundant exploratory hypotheses were executed: H13window-context effects on E-template consistency; H14shared lexical errors despite unanimous ASR; H15cross-pass ranking/contrast instability. H14finds3of6unanimous MAIN complete cases and5of7SCAN cases still contain reference errors. H15finds automatic text changes in15/31eligible cases and best-stream winner-set changes in19/31. MAIN/SCAN are different physical passes and mixed inference resource contexts, not eight simultaneous outputs or an isolated scanner effect.

## New lexical findings

The population is 63 actor-scene rows over 31 complete nonempty scenes, with 881 actor-exclusive reference token occurrences. Shared token types between source actors are excluded, and repeated counts are bounded by source multiplicity. This measures lexical presence, not acoustic identity.

| Pass / fixed candidate vs same-pass auto | Extra reference tokens present | Reference tokens lost |
|---|---:|---:|
| MAIN focus0 ASR |10|50|
| MAIN focus1 ASR |14|24|
| SCAN focus0 ASR |13|22|
| SCAN focus1 ASR |11|33|
| SCAN scanner ASR |15|6|

These rows do not form a stitched transcript. Full-recording reference-informed ASR minima save11errors on MAIN and23onSCAN over965words; those are oracle diagnostic opportunities, not deployable improvements.

Focus0/focus1 whole-frame Pearson correlation exceeds0.9in28/48MAIN and32/48SCAN pairs, with no exact identical WAV pairs. Correlation alone cannot decide whether one person, two similar voices, shared noise, silence or beam gating caused the similarity. Full336rows preserve source-count/completeness strata and zero-energy handling.

The ASR/PP comparisons preserve exactly matched source/receptive/clean intervals and evidence kind:1089autoMAIN,1022focus0MAIN,1096focus1MAIN,1073autoSCAN and1117scannerSCAN vector pairs. There is one zero-match scene in every48-case contrast; unpaired segmentation/admission differences are not erased.


BXR8/BXR12 are explicitly deferred unsupported branches, not measured failures. PER_BEAM_CAPABILITY_REPORT.md explains the missing causal trigger/transition evidence and hardware geometry/wrong-setup contrast. Native/GUI/resource and workbook consolidation are included in this handoff. No calibrated beam method or replacement device gallery is promoted.
