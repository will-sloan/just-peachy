# Operating and reproducing this evidence

Two actual opt-in desktop research conditions are preserved: C065 anonymous (no gallery) and C088 naming with original15-person A15. They share the repaired research delivery/source epoch and historical O0 adapter already gained+3dB once. Their exact profiles, settings, gallery, model assets and source files are in PROFILE_EPOCH_GALLERY_MANIFEST.json; configs/contains the small O0 examples. Historical default and B36 epoch remain unchanged. Do not construct a hybrid from table minima, rename A15 to the14-person matched-duration cohort, or promote C105.

T0 is the useful full-journal research control. T1/T2 are optional presentation prototypes with omissions, not acoustic separation. V1–V3 and beam selectors have unavailable calibrated efficacy. Additional decoder/waveform switching and fixed steering are not provided. No claim that the captured beam index is a stable person or verified lab bearing is made.

Original completed output directories are immutable. Do not invoke old job manifests directly and overwrite their outputs. Native reproduction needs a fresh namespace, matching source/models/context, original full-input/completion guards and a newly bounded admission. Actual GUI helper v4 disables wrapping of diagnostic JSON to avoid layout stalls; this does not discard journal records. Use its maintained README and the actual runner v10 admission documents in the artifact index. A copied frozen application path alone is not a reliable standalone launch: asset roots must be set correctly by the admitted helper.

For model-free final analyses, open these maintained READMEs at the report root:

- application/host_correctness_final_v1/README.md — two closed30-minute sessions; original metrics; bounded process-local cpWER population adapter.
- application/runtime_synthesis_v2/README.md — accepted resource/queue/timing census, no model calls.
- continuous/scientific_analysis_v2/README.md — four continuous full-reference scores and conditional recovery.
- device_enrollment/conditional_heldout_analysis_v1/README.md — C-only galleries and held-out conditional query comparison.
- device_enrollment/conditional_coverage_completion_v1/README.md — complete no-event source-turn denominators.
- application/beam_remaining_diagnostics_v1/README.md — lexical opportunities/waveform/context comparisons.

Each supplies PowerShell and Anaconda/CMD commands, inputs, outputs, bounds and no-overwrite rules. Completed namespaces are not rerunnable in place; use a documented new version if a source change requires recomputation. No missing package installation, download or full new inference is implied by this handoff.

Read-only inspection in PowerShell:

```powershell
Get-Content -Raw -LiteralPath 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6D\20260913T195357Z/handoff_final_v2/package/PROFILE_EPOCH_GALLERY_MANIFEST.json'
Get-Content -Raw -LiteralPath 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6D\20260913T195357Z/application/runtime_synthesis_v2/RESULT.json'
```

Anaconda Prompt / CMD:

```bat
type "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6D\20260913T195357Z\handoff_final_v2\package\PROFILE_EPOCH_GALLERY_MANIFEST.json"
```

CM5_PREPARATION_README.md and CM5_MANIFEST.json describe a future pinned ARM64Python3.12 deployment/workload with3whole44.695s O0 scenes and2profiles(6serialjobs,268.17scheduled seconds). Current desktop native Python is3.11; metadata supervisor is3.12. ARM64 wheel availability,2GB total-memory fit,32GB eMMC rotation/endurance, thermal/latency and live I/O remain untested. Retention figures are proposals, not enforced device measurements. Research corpora/unbounded PCM journals must not be copied blindly to eMMC.
