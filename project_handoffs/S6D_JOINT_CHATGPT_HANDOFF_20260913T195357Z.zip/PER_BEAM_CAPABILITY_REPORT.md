# Per-beam capability and unsupported branches

MAIN provides auto ASR/PP, focus0 ASR/PP and focus1 ASR/PP within each six-stream pass for240scenes. SCAN provides auto ASR/PP, focus0ASR, focus1ASR and scanner ASR/PP for48scenes in separate physical passes. VERIFIED_STREAM_MAP.json preserves actual ordered stream/category/source fields from accepted case metadata. Categories are device output routes, not independent speakers. Do not infer physical beam direction from a column number.

Exact tagged four-MIC recovery is verified in each own QA pass. Processed-only scenes do not contain a simultaneous exact four-MIC echo. Framing, hashes, stream/recipe/mux readback and original capture acceptance remain bound per case. Conditional source-extent/correlation analysis on the48×2panel is not a claim of sub-word alignment for every beam or all240scenes. Weak or constant signals have unavailable lag, not zero lag.

| Capability | Implemented | Measured scope | Available for efficacy |
|---|---|---|---|
| Fixed single-stream ASR/identity |Yes|Fixed48 stream panel,528diagnostics plus48matched auto controls|Text diagnostic within eligible reference subset|
| Mono auto ASR + two focus identity states |Yes, one shared representation backend, serial focus processing|Core96 and continuous4 full-source native runs|No calibrated voice/beam identity benefit established|
| Selected-person beam association |Hook and explicit unavailable branch|C12 prerequisites and native refusal/NO_MATCH behavior|No; unavailable calibration is not an abstention success rate|
| Same-person duplicate merging |Guarded/disabled without calibration|Waveform336pairs and saved embedding context comparisons|No calibrated merge rule; correlation is not person identity|
| ASR/PP dual view |Fixed diagnostics|240paired conditions,5,397unique matched saved embedding contexts|Descriptive; views are correlated, admission differs|
| Scanner trigger |Recorded stream/diagnostics|48SCAN cases, same-pass auto control|No validated causal change trigger|
| Dynamic second ASR / waveform switching |No|Fixed-mode costs/oracle opportunities only|Deferred; no causal trigger, bounded transitions/dedup/pre-roll validation|
| Fixed-table hardware steering |No executed contrast|Route controls only|Deferred; signed-lab/native transform and wrong-setup/relocation behavior unverified|

Deferral is based on evidence scope, not repeated threshold search. For dynamic work the available oracle lexical gain requires Q reference truth, while ambiguous/timely association and negative calibration examples are absent. Fixed-mode runtime is not an adaptive compute/accuracy curve. Implementing a truth-triggered selector would invalidate the experiment. For fixed-table steering, captured auto/focus categories do not verify intended physical steering or its sign; a new controlled hardware contrast would be needed. Neither branch is described as a tested failure.

The original contract allows bounded unsupported/deferred branches with evidence. No generally useful beam behavior was retained; all240 native confirmation is complete for retained C065/C088 application conditions, while the beam extension remains48-panel/continuous research. No extra full240 multi-ASR grid or invented scanner audio was generated.

Clipping/rail findings remain visible:90PP streams in the96pass-case analysis, zero ASR rails. Raw gain stays unity; there is no new universal normalization. Fast telemetry is15.84–16.76Hz against20requested/below18flag threshold. Optional gain/slow-field drops prevent inverse-gain or AGC-causal interpretation. TELEMETRY_OBSERVER_EFFECT.json includes the four-repeat order and cross-pass confounding.

The broader source separation, AEC, port/enclosure geometry and new human-room calibration questions remain outside this bounded stage. No clean target/interferer references support source-separated SIR/SI-SDR claims inside the nonlinear adaptive mixtures.
