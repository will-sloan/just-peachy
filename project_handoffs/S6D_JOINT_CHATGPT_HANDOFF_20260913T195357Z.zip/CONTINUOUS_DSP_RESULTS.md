# Continuous DSP and native pipeline results

Four accepted native runs cover two uninterrupted physical 900-second synthetic microphone conversations, each tested with the same automatic ASR control and mono-ASR plus focused-beam identity branch. Each saved recording contains 903.7454375 seconds including its capture guard/tail. All frames were consumed, with zero reported audio-frame drops and complete event/journal/policy/punctuation drainage. These are synthetic corpus voices and static measured room paths, not real dinner or walking recordings.

The full-source references contain 57 intended utterance occurrences per conversation. Main-table has 23 distinct identities and495 reference words; library has26 identities and509 words. Each includes18 complete-reference speech blocks and two45-second exact digital-silence blocks. The earlier description of two incomplete blocks was incorrect and is superseded by byte-bound source/gap verification.

| Conversation / mode | Full-session serialized word errors | Anonymous cpWER errors | Actual final transcript rows |
|---|---:|---:|---:|
| Main table / automatic control | 138/495 (27.88%) | 471/495 (95.15%) |44|
| Main table / beam identity | 138/495 (27.88%) | 765/495 (154.55%) |44|
| Library / automatic control |97/509 (19.06%) |463/509 (90.96%) |50|
| Library / beam identity |97/509 (19.06%) |884/509 (173.67%) |50|

All intended words and actual final raw words enter these full-session scores; no source/capture clock alignment is used for full-session text. Serialized word error remains sensitive to reference ordering during overlap. cpWER is a retrospective permutation of final anonymous labels and can exceed100% because wrong speaker allocation creates insertion/deletion errors. The beam branch retains identical ASR words but puts every final row under Unknown; this is an adverse attribution result, not successful beam integration. Controls use22 and26 anonymous labels; the presence of a label does not prove person continuity.

The installed MeetEval0.4.3 cpWER implementation rejects inputs with more than20speaker identities as a likely-data-error guard. The verified23/26-person populations are intentional. A separate frozen v2 analysis compiles that same function with only the guard changed20->32 in the analysis process; assignment and edit-distance code are unchanged and no installed file is edited. Tests reproduce the old rejection, retain small-case counts/assignment, score a23-person perfect match, count an omitted23rd person as a deletion, and still reject33people. Failed v1 is preserved.

All four unique physical pause/return episodes produced caption text in both native modes: eight run/episode observations, not eight independent physical trials. The pause interiors contain zero final words under the predeclared timing-sensitivity checks. Post-pause block serialized errors at the descriptive central alignment are6.67%/32.26% for the two main-table returns and9.09%/14.29% for library; the modes are equal. Any returned text is not proof of correct first words or correct identity.

The nominal auto-ASR alignment uses the actual one-second packed pre-roll plus the independently recorded descriptive common-lag estimate (0.2228125s main,0.2259375s library). Repeating the return test at -1,-0.25,0,+0.25,+1s perturbations retains the presence of text on every episode. These offsets are sensitivity tests, not confidence bounds, exact phonetic timing, per-beam delay or hardware latency. Nominal estimated-activity-onset to available-text values range approximately0.32–3.15s and must not be advertised as certified latency.

Final-name assessment uses only source intervals supporting one identical identity across all five offsets. For the main control,20/44 rows meet that criterion:1 correct final known name,4 abstained known rows and15 outside-gallery rows withheld. Library control has18/50:3 correct,5 abstained known and10 outside-gallery withheld. The other24/32 rows remain ambiguous, including some emitted names; they cannot establish zero false-name risk. Beam identity has no known names and therefore no demonstrated name recovery. These are retrospective conditional labels, not causal live identity accuracy.

Actual runs take about1019–1023s per903.745s input. Event-consumer p95 queue age is about11ms andp99 about35–37ms; the retained maximum is1.87–2.32s, including startup. Maximum observed event queue depth is16–17 of8192. All final depths are zero; journal/policy/punctuation accepted counts equal completed counts with no worker error. Do not drop startup maxima or equate queue age with end-to-end speech latency. Desktop timing is not CM5 qualification.

This distinguishes successful frame/queue processing and caption resumption from poor identity continuity. No matched cold-reset acoustic control was run here, so these outcomes do not isolate a DSP, AGC, beam-reacquisition or voice-memory cause. Focus clocks remain independently unverified and C-dependent person/beam association stays disabled.

Authoritative local results: continuous/scientific_analysis_v2/RESULT.json, SCORES4.json and PROVENANCE.json. Scope correction: application/additional_hypotheses_resume_v2. Reproduction commands and tests are in the corresponding README files. This report contributes to S6D closure; it does not itself declare the entire phase finished.
