# S6D report: completed evidence and decisions

## Outcome

S6D collected the expanded same-pass hardware bank, executed the declared native comparisons and application prototypes, and analyzed the saved evidence. It did not establish a generally better beam integration, reliable selected-speaker extraction, useful calibrated direction overlay, or CM5 readiness. Negative outcomes remain in the tables; no default, model family, weight, firmware, gallery or RIR was promoted or replaced.

The decisive distinction is between successful execution/transport and useful scientific performance. Full-source audits, process ownership and queue drainage passed for accepted jobs. Speech recognition, voice naming, latency and direction have separate limitations. Old failed/partial jobs remain immutable and earn no completion credit.

## Populations and provenance

| Component | Completed scientific/execution population | Scope |
|---|---:|---|
| Original listening bank |240 scenes,480 O0/O1 inputs|Accepted historical derivatives; original gain recipe|
| Angle study |5/2/0 label overlays;5,760 operational rows|Fixed predictions for label overlays;8 narrower variants plus controls|
| Expanded MAIN |240/240 scenes|Six simultaneous outputs within each MAIN pass|
| Expanded SCAN |48/48 scenes|Separate six-output pass; no all240 scanner claim|
| Association calibration |12 captures,2 proposals,0 enabled|Original freshness/negative-support requirements unmet|
| Enrollment captures/templates |60 captures,360 templates|30 people ×2positions ×6streams;190 unique E utterances|
| Repeat controls |4|Expanded/standard/standard/expanded; not sufficient causal equivalence|
| Continuous physical conversations |2×900seconds|No scene reset within either physical conversation|
| Native full bank |960 cells|C065/C088 ×240 ×O0/O1;892 new plus68 credited|
| Original/repaired native contrasts |176 cells|168 core and8 C105; overlap68 with full-bank credits|
| Beam core / diagnostic panel |96 core;528 diagnostics +48 controls|624 unique native jobs;576 stream-panel cells reuse48 core controls|
| Whole-recording beam text |624 scored dispositions|13 conditions ×48;31 complete nonempty,1 empty,16 incomplete scenes per condition|
| Gallery comparison |26 C fits;576 scene diagnostics;96 conditional timed query cells ×26|C-only calibration, fixed E rosters, Q evaluation only|
| Continuous native |4/4|Auto/beam-ID on each physical900s capture|
| GUI |8 initial +38 added +16 target-present =62 unique|Selected42 includes4 original credits;58 selected conditions;3 views share one engine|
| Long host |2×1,827.426625seconds|Anonymous/naming; historical captured scenes concatenated in host, not continuous physical XVF state|

CAPTURE_COVERAGE.csv and LOCAL_ARTIFACT_INDEX.json distinguish exact namespaces. Runtime synthesis deduplicates1,760 accepted native result files across its declared populations; this is not the entire historic experiment inventory, independent trials, or all enrollment calls. Physical ledger has534 charged attempts:527PASS and7historicalFAIL, with24,522.5545seconds charged. QA/recovery/control attempts are not additional unique scenes. User-authorized ceilings were extended to550 attempts/25,000seconds; original lower pack ceilings are history.

Existing acquisition exclusions, RIRv1, the low-table R13 clock restriction, Upper Loeb inclusion and both corrected1.00m distances remain unchanged. Source roles remain E/C/Q; no retakes/test acquisitions were reintroduced by this stage. Common Voice, original CMU ARCTIC and HiFiTTS remain distinct; no L2 ARCTIC was added.

## Angles

Manual ±5° is acquisition uncertainty, not sensor standard deviation. On identical predictions,5→2→0 changes interval-distance means40.4421°→43.3670°→45.3410°. Nominal stable-but-wrong remains179/768 selected-direction turns across124cases. Words, embeddings and label-independent outputs remain invariant. Narrower labels cannot explain away the large nominal errors.

The separate C079/C120 operational2/5/10/20° study can change attribution. None of8variants improves latest attributed error over its own25° parent on either tap. C0792° adds71 errors onO0 and C1202° adds83; conditional bootstrap limits and adverse individual scenes are preserved. No narrower variant was retained, so no new width-specific native grid was warranted. See ANGLE_ASSUMPTION_FINDINGS.md.

## Native text, attribution and delivery

The full-bank960 table uses original conditioned source-support scoring, not unrestricted all-speaker WER for incomplete ambient scenes. Each240-cell group has161 complete-reference cells;153 have nonempty reference words. C065/C088 O0 serialized word error is19.29% over4,623reference words; O1 is20.31%. Anonymous cpWER is61.80% onO0,62.47% C065/O1 and62.75% C088/O1. Read NATIVE960_ALL_GROUPS.json for exact numerators, denominators, first/correct/stable-name censoring and exposure. Compatible retained cells retain their actual older timing rather than pretending to be newly measured.

All176 original/repaired matched comparisons preserve raw words/final spans for admitted timing comparisons. Core C065 attributed cpWER changes57.50→54.75%; C08856.625→56.375%, with lexical errors160/800 unchanged in each condition. C088 has10/34 ever-correct and5/34 stable-correct enrolled occurrences in both original/repaired groups. Short-reply S45_03_03 remains0correct names across48combined enrolled opportunities although its raw10words/job are recognized.

Median first-text delivery improved on the42 C065 repair pairs by0.289s and42 C088 pairs by0.220s; tails worsened on some pairs. Repaired naming versus anonymous median extra delay is about−0.001s but p95+2.316s. This fails the provisional+0.25s p95 goal. A median alone is insufficient.

The C105 boundary fixtures cover ordering/ties/expiry/adjacent speakers and preserve words. They do not establish robust native attribution repair: repaired C105 O0 second repeat changes1→21cp edits/41words. Across its4-cell group cpWER26.83→39.02%. Keep C105 diagnostic-only. Replay stability must not erase a native regression.

Both long host sessions consume the full1,827.426625seconds, with zero dropped audio frames and drained consumers. Of38reference pieces,32 qualify for conditioned scoring. Both produce182/984 word errors(18.50%) and1,180/984anonymous cp errors(119.92%). Ninety-two final rows enter the conditioned metric;13rows/78words remain explicitly outside it, and all105raw rows are preserved. Fifty-two actual anonymous labels indicate fragmentation; cpWER above100% is possible. These are not unrestricted full-session metrics. Of44reference-supported enrolled opportunities, C088 reaches any correct name on33(11never-correct), confirmed-correct on13(31never-confirmed), and stable-correct on8(36never-stable);78of122occurrences are unavailable for enrolled-name scoring. Any early match is not sustained identity continuity.

The host naming condition preserves all raw text but adds1.261s median,1.585s p95 and1.622s p99 consumer delay across105compatible first rows. These measured desktop event delays fail the stated goals. They are not phonetic or GUI latency and do not isolate one bottleneck.

## Selected display and direction

T0/T1/T2 exist in application research configuration/CLI/GUI, retain an unfiltered journal, and use selection fixed before predictions. The initial42 selected GUI conditions were target-absent; these establish withholding/wiring, not target recall. A separately disclosed coverage repair added16native conditions on8source-present scenes for the same selected person, both taps.

On those16conditions, T1 retains conservative target-word matches38/85(O0) and46/85(O1), versus65/85 and64/85 in T0. Five/nine and four/nine source-supported target turns are never visible. The selected small-set T2 has the same values on this population. Zero unambiguous non-target words is conditional and does not erase incomplete/mixed-content exposure. Posthoc coverage repair is not an independent held-out trial.

Across the full repaired A15 bank, all-enrolled T2 matches589/2,500target words onO0 versus1,485T0; O1 matches535 versus1,471. There are190/280 and188/280 never-visible target turns. This is a major coverage cost, not separation success.

V0–V3 hooks separate identity, speech, association and freshness; fixtures exercise expiry, stale/session errors, duplicate limits and true widget mutations. V1–V3 lack qualified person-to-bearing association and do not demonstrate useful target-direction coverage. Zero supported arrows is not zero-error success. Historical V0 exposure outside complete speech is diagnostic; stored processed angles cannot be attached to a name without an independently established same-source relation. See DISPLAY_AND_DIRECTION_MODES.md.

## New beam and enrollment findings

Same-pass six-stream routing and QA are verified, but stream identity does not mean speaker identity. On the fixed48panel,94/96pass-cases have conditional source-extent evidence;2zero-source controls have no meaningful lag. Ninety PP streams have rail samples; ASR rail counts are zero. MAIN/SCAN auto differs in19/48pairs below0.9correlation, including4with>3dB level difference. These are separate physical passes with adaptive state, not eight simultaneously captured streams.

Thirty-one complete nonempty panel scenes supply965reference words per condition. MAIN automatic ASR has142errors(14.72%); focus0ASR187(19.38%), focus1ASR157(16.27%). SCAN automatic has153(15.85%); scanner ASR142(14.72%). PP is not uniformly better. Reference-informed per-scene ASR minima recover11MAIN or23SCAN errors; that oracle is not a deployable selector.

Actor-exclusive lexical support provides63actor-scene rows/881tokens. MAIN focus0 gains10 auto-missing tokens but loses50; focus1 gains14/loses24. SCAN scanner gains15/loses6. This is presence of source-exclusive lexical types with bounded multiplicity, not source-separated acoustic leakage, active-talker timing or a stitched transcript. Whole-frame focus correlation>0.9 occurs28/48MAIN and32/48SCAN; it cannot distinguish one person, shared noise or similar voices.

C12 supplies5,882candidate observations, all failing the original0.75s source-age rule; minimum first-availability age is1.78985s. It also lacks unambiguous negative association examples. Neither loosening a threshold nor using Q truth is a valid remedy. Native mono-ASR/beam-ID hooks were exercised in unavailable-calibration mode; zero names/arrows must not count as efficacy. No general beam method was retained; therefore no additional240-scene beam finalist rerun was justified. Scanner findings remain48-panel limited.

Enrollment preserves56PASS/304REVIEW_LOW_CONSISTENCY templates. Twenty-six clean/device galleries are fitted on C only. Conditional held-out timed comparison reuses2,616actual auto-query embeddings across96cells and fixed26galleries, requiring full source-window support and single identity across five offset sensitivities. MAIN mature device-vs-clean correct-known rates change−8.33 to+3.23percentage points; false-known stranger rates change−0.565 to+2.260points across24device conditions. Gains are not consistent. Source-turn coverage includes zero-event cases through the corrected4,992-row table. No new gallery is selected on Q. See ENROLLMENT_DOMAIN_FINDINGS.md and the192paired comparisons.

Three additional hypotheses were tested: E-window context changes consistency flags without proven recognition benefit; unanimous3-stream ASR can still be wrong(3/6MAIN and5/7SCAN unanimous scenes); automatic text differs across15/31cross-pass scenes and best-stream winner sets across19/31. Their limits argue against indiscriminate voting or assumed pass equivalence.

## Uninterrupted physical conversations

Both900-second physical inputs contain18complete-reference speech blocks and two45-second digital-silence gaps. Earlier documentation calling those gaps incomplete references was corrected. Each conversation retains57Qsource occurrences. Four native runs consume all903.7454375saved seconds including guards/tail, with zero dropped frames and drained queues.

Auto and beam-ID raw final text is identical. MAIN serialized WER27.88%, library19.06%; anonymous cpWER worsens from95.15→154.55%MAIN and90.96→173.67%library in beam-ID mode. This is a negative identity outcome, not a text improvement. Caption text resumes after all4physical pause episodes in both modes(8native observations, not8independent physical trials); there are no final words in guarded pause interiors. Correct names, speaker continuity and exact acoustic recovery remain conditional. No matched cold-reset experiment isolates DSP/AGC/voice-memory causality. See CONTINUOUS_DSP_RESULTS.md.

## Costs, execution and limits

The resource census covers1,760distinct accepted native outputs with actual resource files. Long host wall/input ratios are1.0211/1.0216, with process-tree sampled peak RSS about496/498MiB. Four physical-continuous native runs have ratios1.1275–1.1318 and peak tree RSS up to485MiB. These include load/drain/observer overhead and paced input; they do not prove unrestricted faster-than-real-time capacity.

Most long-session resource sampling gaps stay below0.67s, but a full-bank C088/O0 record has a14.37s gap; sampled maxima may miss peaks. Process-tree RSS can double-count shared pages. Tree USS/PSS, whole-system headroom, active inference duty/calls-per-true-speech-minute, CM5 thermals/live I/O/UI/camera and eMMC endurance are unmeasured. No inference from one desktop process to total2GB qualification is valid.

Actual selected-present GUI callback maxima are0.193–0.217s across views. The42target-absent population has36nonempty callback records per view;6no-text cells retain empty timing, not invented zeros. UI callback timing is not physical screen paint or scanout. Three views share one native engine. Diagnostic four-worker epochs stay separate from serial paced comparisons.

Local supervisors used fixed ownership, heartbeat/progress/artifact checks, bounded actions, disk floors, fresh allocation, STOP/closure and user-authorized deadline extensions. Original failures include Windows launcher/telemetry/GUI-layout issues and resumed diagnostic/scoring schema failures; they remain local. Metadata analysis repairs reran no completed model inference. Final delivery lists actual closed owners; no overnight compute is still owed by these completed queues.

## Deferred capability dispositions and next action

BXR8 dynamic extra ASR/waveform switching remains unimplemented. Fixed-stream comparisons do not supply a causal, calibrated ambiguity trigger or validated transition/dedup/pre-roll policy; Q-informed oracle gains cannot authorize it. BXR12 fixed-table steering remains untested: verified output categories do not establish a signed-lab→native hardware steering transform, wrong-setup robustness or relocation behavior. These are explicit evidence-based unsupported branches under the contract's bounded-defer rule, not measured failures or covert omissions. All12 hypotheses and3additional hypotheses have dispositions in BEAM_INTEGRATION_RESULTS.md.

Use C065 anonymous and C088/A15 naming only as the exact opt-in desktop research conditions. T1/T2 remain optional prototypes with coverage warnings; V1–V3 and calibrated beam selection remain unavailable for efficacy. Preserve historical default and exact gallery identities. CM5_PREPARATION_README.md and its manifest define a future small pinned workload; no target execution occurred.

The next stage requires a separately chosen objective. Priority questions are voice continuity/false naming, naming-delay tails and robust association calibration with actual negative/timely evidence. This package does not authorize new recordings, threshold search, model changes or automatic S7–S9 work.
