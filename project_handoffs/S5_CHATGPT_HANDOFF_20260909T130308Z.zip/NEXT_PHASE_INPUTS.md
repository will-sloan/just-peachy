# Exact inputs for later S6 planning

Primary: O0. Fallback: O1.
Decision: C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S5\20260909T130308Z\OUTPUT_DECISION.json

With O0 fixed as the input recipe, can a separately evaluated direction-assisted anonymous-speaker layer improve ordinary returning-speaker consistency and final attributed-text quality over unchanged H2 without reducing short-turn evidence coverage or worsening noise-associated behavior?

Use the unchanged H2 baseline in execution_contract.json and the existing accepted paired captures.
O0 host scalar 1.4125375446227544 once; O1 unity. Device ASR gain was1 during capture.
Apply that scalar only to the original PCM24 output. The indexed FLOAT adapters and native
PCM16 journals already contain it; their downstream input gain must be unity.
Recipes: C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S5\20260909T130308Z\OUTPUT_RECIPES_V1.json
SHA256: 1b40c6cf2bcef17346ec9af02792a6aa9c6c9205590746de0317066974dfbcbd
Complete360-job mapping: C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S5\20260909T130308Z\JOB_MANIFEST.json
SHA256: af925d3793fbd90a784d38eefc55433672bc36136bd72c1a1402f99f49232087
Scene manifest: C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scene_bank\s45_v2_20260909T031300Z\SCENE_MANIFEST.json
SHA256: 69131a703ffc631b461bbf3c46c12de50ecdae2afd77d357d61c72ebf306fd18
Current RIR manifest: C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\rir_library\v1\RIR_MANIFEST.json
SHA256:468b2b306f994937a7d02db611080d38c7a4bcc7dc89ce7dc73d93762380f546
Old accepted hardware/native payloads: G:\Just_Peachy_S4_5\20260909T031300Z
New canonical adapters/journals: G:\Just_Peachy_S5\20260909T130308Z\h2
All exact per-file paths/hashes: LOCAL_ARTIFACT_INDEX.json and native completion receipts.

Resolved: complete development paired comparison; old 48 reuse; validated MIMO/cpWER; source-derived
noise windows; explicit short-turn/evidence/continuity definitions; default and fallback.
Limited: untranscribed ambient speech, source/room/dependency gaps, partial timing coverage,
anonymous-label fragmentation, no reconciled lineage/names/full DER, no live or CM5 qualification.

Retained source gaps are recorded in INPUT_COVERAGE_REVIEW.json under prior_source_limits, with the
upstream evidence bound there. In particular, only 5 of 34 development IDs have dedicated noise-free isolated
development scenes; 34 optional reference inputs were prepared but deliberately not captured. The other
source/partner/role/short-clip gaps are not repaired by the larger output panel. CMU bare clip basenames are
speaker-qualified names, not reliable global prompt IDs; use the retained normalized lexical groups.

Keep60 reserves closed: 30 new-source, 20 Upper Loeb acoustic and 10 joint cases. No reserve predictions,
direction scores or task performance may choose or tune the output/fusion. Metadata inventory is separate.
Do not regenerate RIRs, scenes or captures, refill corpora, change scientific H2 policies, train,
create split ASR/embedding paths or automatically start S6 from this handoff.
