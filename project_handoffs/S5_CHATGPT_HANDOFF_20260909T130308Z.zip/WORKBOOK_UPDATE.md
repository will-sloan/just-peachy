# Proposed light-yellow insertion into V10

Review this narrative for insertion into the existing S5 results section of XVF_Measurement_V10.docx.
Do not replace or independently rebuild the master. These are actual S5 results; S6 remains future planning.

**COMPLETE_WITH_LIMITATIONS — primary O0, fallback O1.**

Choose O0 at the frozen +3 dB host gain once. It makes 36 fewer primary word errors (525/3509 versus 561/3509), 14 fewer overlap MIMO errors, and 90 fewer final-attributed text errors, with better primary returning-label consistency and no raw or native PCM16 rails. The primary word direction favors O0 in all four rooms, all three corpus strata, and every room/speaker-component deletion sensitivity. Its 1.03-point advantage is modest: the conditional interval is +0.28 to +1.87 points and does not establish a minimum 1.0-point benefit. Prioritize this combined word/headroom/continuity pattern while retaining O1 for its low-source-level and overlap-return advantages. This is a development audio default, not certification of usable diarization.

Coverage: 180 development scenes, 360/360 native outputs,
48 reused and 312 new;
0 terminal failures; zero reserve task evaluations.
O0 uses +3 dB host gain once (1.4125375446227544); O1 uses unity.

Primary WER: O0 14.96% (525/3509; 348S/123D/54I); O1 15.99% (561/3509; 361S/148D/52I).
Paired O1−O0 difference 1.03 points; conditional block interval [+0.28, +1.87] percentage points.
This is development evidence with crossed source/RIR dependencies, not a population confidence claim.

Biggest tradeoff: O0 improves primary WER by 1.03 points and primary repeated-person consistency from 45/132 to 53/132, but O1 makes five fewer word errors in the five -6 dB source-level scenes (41/157 versus 46/157) and has more consistent overlap return groups (13/36 versus 8/36). Neither proxy establishes reliable speaker identity.

Read S5_REPORT.md for the completed function/condition pros-and-cons table, then OUTPUT_DECISION.json.
Use SUMMARY_METRICS.json, PAIRED_METRICS.json, condition/short-turn/return/noise/timing tables and
the four figures for verification. Full audio/logs/vectors remain local through LOCAL_ARTIFACT_INDEX.json.
WORKBOOK_UPDATE.md is an insertion proposal for the existing V10 master, which was not rewritten.

Noise windows now cover 39 development cases; 32 have defensible output-local timing, and all 39 have shared
direction analysis counted once. Incomplete ambient references, exact word timing, reconciled identity,
enrolled names, live latency, untested paths and CM5 operation remain limited or unavailable.

Next S6 question: With O0 fixed as the input recipe, can a separately evaluated direction-assisted anonymous-speaker layer improve ordinary returning-speaker consistency and final attributed-text quality over unchanged H2 without reducing short-turn evidence coverage or worsening noise-associated behavior?
Keep all 60 reserve task scores closed until later locked evaluation. S5 execution is complete; stop here.


## Small results table

| Metric / population | Paired scenes | O0 | O1 | O1 minus O0 |
| --- | --- | --- | --- | --- |
| Ordinary WER, full-reference nonoverlap | 117 | 14.96% (525/3509; 348S/123D/54I) | 15.99% (561/3509; 361S/148D/52I) | 1.03 pp |
| MIMO WER, complete-reference overlap | 36 | 32.59% (363/1114; 89S/262D/12I) | 33.84% (377/1114; 99S/266D/12I) | 1.26 pp |
| cpWER, all complete-reference speech | 153 | 58.75% (2716/4623; 511S/1262D/943I) | 60.70% (2806/4623; 520S/1318D/968I) | 1.95 pp |
| cpWER, nonoverlap only | 117 | 57.71% (2025/3509; 318S/888D/819I) | 59.85% (2100/3509; 310S/943D/847I) | 2.14 pp |
| cpWER, overlap only | 36 | 62.03% (691/1114; 193S/374D/124I) | 63.38% (706/1114; 210S/375D/121I) | 1.35 pp |

## Evidence and remaining limits

| Measured quantity | O0 | O1 |
| --- | --- | --- |
| Native embedding decisions | 5610 | 6041 |
| Eligible reconstructed hops | 5610 | 6041 |
| Eligible hops without native decision | 0 | 0 |
| Native decisions despite reconstructed ineligibility | 0 | 0 |
| Unique evidence audio, seconds | 1592.75 | 1676.25 |
| Total overlapping-window audio processed, seconds | 2805.00 | 3020.50 |
| Embedding calls / decoded minute | 40.99 | 44.14 |
| Raw PCM24 rail samples / total | 0/131394860 | 747/131394860 |
| Raw rail-affected outputs | 0 | 67 |
| Longest raw rail run, samples | 0 | 7 |
| Fresh canonical child wall, seconds | 2343.31 | 2340.62 |
| Reused historical child wall, seconds | 406.23 | 383.49 |

The 0.5 s oracle representation diagnostic used 222 paired windows/34 development IDs and 444 calls,
with 104 genuine and 104 balanced impostor comparisons. Mean separation was0.11837 O0 and 0.11787 O1,
with broad overlap; this did not establish online identity accuracy or a winner.

Retain the source/room/short-duration gaps, conditional uncertainty and unsupported naming/DER/live/CM5 claims.
Figure captions and plotted data are supplied in the figures directory; use its four final figures only.
The 60 reserve scenes were not scored. V10's source, measurement geometry and prior S0–S4.5 history remain unchanged.
