# S5 handoff: start here

**COMPLETE_WITH_LIMITATIONS — primary O0, fallback O1.**

Choose O0 at the frozen +3 dB host gain once. It makes 36 fewer primary word errors (525/3509 versus 561/3509), 14 fewer overlap MIMO errors, and 90 fewer final-attributed text errors, with better primary returning-label consistency and no raw or native PCM16 rails. The primary word direction favors O0 in all four rooms, all three corpus strata, and every room/speaker-component deletion sensitivity. Its 1.03-point advantage is modest: the conditional interval is +0.28 to +1.87 points and does not establish a minimum 1.0-point benefit. Prioritize this combined word/headroom/continuity pattern while retaining O1 for its low-source-level and overlap-return advantages. This is a development audio default, not certification of usable diarization.

Coverage: 180 development scenes, 360/360 native outputs,
48 reused and 312 new;
0 terminal failures; zero reserve task evaluations.
O0 uses +3 dB host gain once (1.4125375446227544); O1 uses unity.

Primary WER: O0 14.96% (525/3509; 348S/123D/54I); O1 15.99% (561/3509; 361S/148D/52I).
Paired O1−O0 difference 1.03 points; conditional block interval [+0.28, +1.87] percentage points.
This is development evidence with crossed source/RIR dependencies, not a population confidence claim.

Biggest tradeoff: O0 improves primary WER by 1.03 points and primary repeated-person consistency from 45/132 to 53/132, but O1 makes five fewer word errors in the five -6 dB source-level scenes (41/157 versus 46/157) and has more consistent overlap return groups (13/36 versus 8/36). Neither proxy establishes reliable speaker identity.

Read S5_REPORT.md for the completed function/condition pros-and-cons table, then OUTPUT_DECISION.json.
Use SUMMARY_METRICS.json, PAIRED_METRICS.json, condition/short-turn/return/noise/timing tables and
the four figures for verification. Full audio/logs/vectors remain local through LOCAL_ARTIFACT_INDEX.json.
WORKBOOK_UPDATE.md is an insertion proposal for the existing V10 master, which was not rewritten.

Noise windows now cover 39 development cases; 32 have defensible output-local timing, and all 39 have shared
direction analysis counted once. Incomplete ambient references, exact word timing, reconciled identity,
enrolled names, live latency, untested paths and CM5 operation remain limited or unavailable.

Next S6 question: With O0 fixed as the input recipe, can a separately evaluated direction-assisted anonymous-speaker layer improve ordinary returning-speaker consistency and final attributed-text quality over unchanged H2 without reducing short-turn evidence coverage or worsening noise-associated behavior?
Keep all 60 reserve task scores closed until later locked evaluation. S5 execution is complete; stop here.
