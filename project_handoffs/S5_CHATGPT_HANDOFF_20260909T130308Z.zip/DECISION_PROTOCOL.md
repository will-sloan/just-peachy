# S5 decision protocol, frozen before new full-panel comparisons

The 24 S4.5 development scenes were already inspected. This is a complete
development comparison, not blind preregistration or a pristine test set.

Primary word evidence is pooled ordinary WER across117 complete-reference,
nonoverlap scenes. Report exact paired counts, the2000-replicate conditional
matched-block interval, room/source/dependency sensitivity, and practical
references of1.0 absolute WER point plus0.5/2.0 sensitivity. These are new
planning conventions, not validated product requirements. A non-significant
difference is not equivalence.

Reliability and usable words have first priority for an audio benchmark default.
Evaluate overlap words, actual final-snapshot cpWER, short-turn segmentation,
embedding evidence/anonymous continuity, ambient/strict-control behavior,
rails/headroom and workload alongside them. Use no opaque combined score.
If meaningful word benefit opposes material continuity/noise/reliability cost,
declare and quantify the tradeoff and choose one provisional default explicitly.
If no clear practical word advantage is supported and neither has a decisive
functional drawback, prefer O0 as an engineering default for preserved raw
headroom and fewer processing stages; do not call it a proven winner.

Each choice retains the other output as fallback. Neither choice certifies
diarization, naming, arrows, live latency, CM5 deployment, new voices or rooms.
No reserve result may break a tie. No split ASR/embedding input or automatic
mode switch is implemented. Stop after the S5 handoff.
