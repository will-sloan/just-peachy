# S5 complete development output comparison

**COMPLETE_WITH_LIMITATIONS. Primary for S6: O0; retain O1 as fallback.**
Choose O0 at the frozen +3 dB host gain once. It makes 36 fewer primary word errors (525/3509 versus 561/3509), 14 fewer overlap MIMO errors, and 90 fewer final-attributed text errors, with better primary returning-label consistency and no raw or native PCM16 rails. The primary word direction favors O0 in all four rooms, all three corpus strata, and every room/speaker-component deletion sensitivity. Its 1.03-point advantage is modest: the conditional interval is +0.28 to +1.87 points and does not establish a minimum 1.0-point benefit. Prioritize this combined word/headroom/continuity pattern while retaining O1 for its low-source-level and overlap-return advantages. This is a development audio default, not certification of usable diarization.

The final panel contains 360/360 native completed output jobs on 180 development scenes:
48 compatible historical outputs and 312 new canonical outputs.
There were 0 terminal failures, 0 quarantines and 0 retried jobs.
All 60 reserve task evaluations remain closed. This is a development operating choice with evidence strength
**Moderate descriptive support for O0 on this complete development bank; limited certainty that the advantage exceeds 1.0 WER point or generalizes beyond the observed dependencies.**, not a claim of broad product readiness.

## Decision and costs

| Function / condition | O0 | O1 | Decision implication |
| --- | --- | --- | --- |
| Primary words: 117 scenes | 14.96% WER; 525/3509 errors; CER 8.76% | 15.99% WER; 561/3509 errors; CER 9.85% | O0: 36 fewer word errors; 33 scene wins versus 22, 62 ties. Neither has an empty primary hypothesis. |
| Rooms, sources and uncertainty | Lower pooled WER in all 4 rooms and CMU/CV/HiFi strata | Room deltas favor O0 by 0.50 to 2.57 points; corpus deltas 0.64/1.63/0.60 | Conditional O1-minus-O0 interval[+0.28,+1.87] points; all leave-room/component signs positive, but magnitude/dependence limit generalization. Leave-one-room-out differences are +0.69 to +1.30 points; leave-speaker-component-out,+0.48 to +1.24. |
| Practical planning references | Point advantage 1.03 points; equal-room 1.16 | Conditional interval not entirely beyond 0.5 or 1.0 points | Within the 2.0-point band conditionally; not a population-equivalence claim. Minimum 1.0-point benefit is unproven. |
| Relative source level: 5 matched scenes per extreme | -6 dB: 46/157 errors; +6 dB: 39/157 | -6 dB: 41/157 errors; +6 dB: 59/157 | O1 helps low-level speech by 5 errors; O0 helps high-level speech by 20. Small cells; no automatic switching. |
| Pose, obstruction and HiFi quality | Upright 33/204; obstructed 19/203; HiFi mixed 35/520 | Upright 34/204; obstructed 19/203; HiFi mixed 35/520 | Only 7 upright and 7 obstructed scenes. The pooled obstructed and 17 mixed-quality cells tie; individual scenes differ. No clean-only primary cell. |
| Overlap words: 36 scenes | MIMO 32.59%; 363/1114 errors | MIMO 33.84%; 377/1114 errors | O0: 14 fewer errors. Both omit substantial overlapping speech; this is one-stream utterance-serialization scoring. |
| Competing-talker SIR | -6/0/+6 dB: 37/139, 52/161, 79/143 MIMO errors | -6/0/+6 dB: 37/139, 55/161, 77/143 | Tie at -6; O0 three fewer errors at 0; O1 two fewer at +6. Respect 5/6/5 small-scene denominators. |
| Attributed final text: 153 scenes | cpWER 58.75%; 2716/4623 errors | cpWER 60.70%; 2806/4623 errors | O0 lower by 1.95 points, but both have large anonymous-label/attribution error; no usable diarization/name certification. |
| Ordinary anonymous continuity | 132 repeated-person groups: 53 consistent/42 inconsistent/37 unknown; 1090 switches | 45 consistent/40 inconsistent/47 unknown; 1276 switches | O0: 8 more consistent groups and 186 fewer switches. Unknown groups stay in the denominator. |
| Returns after another speaker, primary | 47 consistent/36 inconsistent/34 unknown of 117 groups | 41 consistent/35 inconsistent/41 unknown of 117 | O0 offers modestly stronger ordinary-return evidence; no truth-driven label reconciliation. |
| Overlap and silent-relocation returns | Overlap 8/10/18 C/I/U of 36; relocation 7/4/4 of 15 | Overlap 13/9/14; relocation 7/3/5 | O1 helps overlap-return proxy; both have 7 consistent relocation groups. This competing evidence is retained. |
| Short source clips, source-attributable turns | <1 s: 34/34 positive flags, 8 no contained embedding; 1-<2 s: 26/26, 0 missing | <1 s: 34/34 positive flags, 7 no contained embedding; 1-<2 s: 26/26, 0 missing | Segmentation flags tie; O1 covers one more subsecond turn with an embedding. These are not recognition or boundary-accuracy rates. |
| Estimated active duration, separately | <1 s: 56/56 positive, 9 no contained embedding; 1-<2 s: 93/93 | <1 s: 56/56 positive, 8 no contained embedding; 1-<2 s: 93/93 | Preserve active-versus-whole duration and absent Common Voice whole-clip sub-two-second support. |
| Embedding evidence and work | 5610 calls; 1592.75 s union; 2805 s processed windows; 40.99 calls/min | 6041 calls; 1676.25 s union; 3020.5 s processed windows; 44.14 calls/min | O1 adds 7.68% calls and 5.24% union evidence, with no eligible-hop/decision mismatch; extra work is not extra identity accuracy. |
| Oracle representation diagnostic | Mean genuine-impostor separation 0.11837 | 0.11787 | 222 paired windows/34 IDs,104 genuine and 104 impostor pairs: broadly overlapping distributions, no practical winner. |
| Strict silence/music controls | 0 words in 8 controls/357.56 s; 0 affected | 0 words in 8 controls/357.56 s; 0 affected | Observed tie; WER undefined; source vocals=N is not new frame-level listening certification. |
| Incomplete ambient references: 19 scenes | Target-only 154/492 errors(31.30%); speech flags 21.77% of decoded support | 155/492(31.50%); speech flags 21.42% | Only one target-only error separates recipes; untranscribed speech prevents all-speaker accuracy or proven false-word claims. |
| Mapped real-noise windows: 32 of 39 | Speech-active flag support 94.16%; noise without estimated speech 20.87% | Speech-active91.92%; noise without estimated speech 21.09% | O0 has more speech-supported indication; tiny noise-only difference is not a false-speech or SNR claim. Shared 39 direction traces counted once. |
| Primary noise SNR: 0/10/20 dB | 104/243, 11/87, 7/99 word errors | 109/243, 12/87, 7/99 | O0 five/one fewer errors and a tie across 7/3/3 scenes; 0 dB speech remains difficult for both. |
| Levels and retained headroom | No raw/PCM16 rails; native peak 0.6435 FS(-3.83 dBFS) | 747 raw rail samples in 67 scenes; longest 7; 1524 PCM16 rails in 93 | O0 preserves headroom. Residual O1 rails remain LIMITED and are not repaired or quarantined retrospectively. |
| Measured offline cost and reliability | 156 fresh jobs: 2343.31 s; 180/180 complete overall | 156 fresh jobs: 2340.62 s; 180/180 complete overall | Same median child wall 14.7265 s; paired O1-minus-O0 median +0.015 s. No meaningful speed winner; all 360 succeeded without retry. |

Change the choice only under the following evidence condition: Reconsider only under a later separately authorized, predeclared development requirement showing that the low-source-level or overlap-return advantage of O1 consistently outweighs its word, headroom and ordinary-continuity costs under unchanged recipes. Freeze any choice before the protected reserve is used for later locked evaluation; never inspect reserve results to resolve uncertainty in this S5 comparison or tune the choice.
No split ASR/embedding input, automatic mode switching, cue fusion, tuning, training or deployment was implemented.

## Scope, reusable evidence and exact recipes

The exclusive populations are 117 complete-reference nonoverlap speech scenes, 36 complete-reference overlap
scenes, 19 incomplete-ambient-reference scenes and 8 strict empty-reference controls. Real noise occurs in 39
development scenes and is an overlapping diagnostic population. S5 does not add the 24 old dry jobs to the 360.
The 24 prior development scenes were already inspected; this is not blind preregistration or pristine held-out testing.

| Output | Frozen device source | Host adapter | Canonical input |
| --- | --- | --- | --- |
| O0 | ASR-oriented output; device AEC_ASROUTGAIN=1 | +3 dB, scalar 1.4125375446227544 once | Recorded mono 16 kHz PCM24 -> FLOAT adapter -> unchanged native PCM16 |
| O1 | Postprocessed auto output | Unity scalar 1.0 | Same format/conversion convention; original rails retained |

Apply the recipe scalar only when constructing an adapter from original PCM24 output.
Indexed FLOAT adapters and native PCM16 journals already contain that scalar; consume them at unity.

H2 retained Sherpa streaming Zipformer English 2023-06-21, Pyannote segmentation 3.0, ReDimNet2 B2,
and the existing online punctuation assets. CPU execution uses 2 ASR threads, 2 speaker threads and 1 punctuation
thread, one fresh independent canonical process/session per output. Segmentation remains 10 s/0.75 s;
embedding remains 0.5 s/0.25 s. Existing scientific thresholds and enrollment/session-memory rules are unchanged.
Only the previously validated S4.5 runtime/CLI durability repair remains in the tracked H2 diff.
Eight assets and exact configuration/source identities are bound in execution_contract.json.

Every consumed output is joined to its accepted capture and saved hash. Reuse verifies raw bytes, one fixed gain,
assets/config/provider/code/lifecycle, native summary/events and the exact full PCM16 journal.
The final audit independently checks these joins and actual process closure; its evidence is not only a status flag.
Positive raw PCM24 rail/near-rail samples can meet the unchanged native PCM16 clamp. They are retained and counted,
not erased or reclassified as a gain repair. An overstrict preflight assertion was corrected before new inference;
the failed preflight contract and correction receipt remain local.

## Words and attributed text

| Metric / population | Paired scenes | O0 | O1 | O1 minus O0 |
| --- | --- | --- | --- | --- |
| Ordinary WER, full-reference nonoverlap | 117 | 14.96% (525/3509; 348S/123D/54I) | 15.99% (561/3509; 361S/148D/52I) | 1.03 pp |
| MIMO WER, complete-reference overlap | 36 | 32.59% (363/1114; 89S/262D/12I) | 33.84% (377/1114; 99S/266D/12I) | 1.26 pp |
| cpWER, all complete-reference speech | 153 | 58.75% (2716/4623; 511S/1262D/943I) | 60.70% (2806/4623; 520S/1318D/968I) | 1.95 pp |
| cpWER, nonoverlap only | 117 | 57.71% (2025/3509; 318S/888D/819I) | 59.85% (2100/3509; 310S/943D/847I) | 2.14 pp |
| cpWER, overlap only | 36 | 62.03% (691/1114; 193S/374D/124I) | 63.38% (706/1114; 210S/375D/121I) | 1.35 pp |

Primary CER: O0 8.76%
(1366/15600);
O1 9.85%
(1537/15600).
Empty primary hypotheses: O0 0, O1 0.
O0 has fewer word errors in 33 primary scenes; O1 in 22;
62 have equal error counts.

Normalization exactly reproduces S4.5: lowercase, delete ASCII punctuation, collapse whitespace, and remove
normalized spaces for CER; no number or contraction expansion. The 48 historical text/count dispositions reproduce
exactly: 47/480 O0 and 41/480 O1 on the 15 historical ordinary cases. Final native raw ASR text is scored,
not punctuation display text.

MeetEval 0.4.3 is installed only in an isolated analysis environment. MIMO keeps every original ordered utterance
within each reference speaker stream and uses exactly one output hypothesis stream; it permits cross-speaker
utterance serialization, not arbitrary word shuffling. Fixtures include both valid speaker orders, missing speech,
duplicates and forbidden word interleaving. This is not time-resolved overlap recall or source separation.
cpWER uses actual final speaker-labelled text streams with one global assignment per scene. Missing and extra
streams remain counted; values above 100% can be valid. It is final-snapshot attributed-text quality, not
reconciled identity accuracy, full DER/JER or enrolled-name accuracy.

## Conditions and uncertainty

| Fixed development room | Scenes | O0 WER | O1 WER | O1−O0 pp |
| --- | --- | --- | --- | --- |
| Arise 5th floor low table | 21 | 18.62% | 21.19% | 2.57 |
| Arise Floor 2 Kitchen | 32 | 16.62% | 17.64% | 1.03 |
| Arise Kitchen Main Table | 41 | 11.86% | 12.35% | 0.50 |
| Library Conference Room | 23 | 14.75% | 15.32% | 0.57 |

| Stratum | Scenes | O0 errors/words | O1 errors/words | O1−O0 pp |
| --- | --- | --- | --- | --- |
| CMU ARCTIC | 34 | 87/935 | 93/935 | 0.64 |
| Common Voice | 44 | 345/1413 | 368/1413 | 1.63 |
| HiFiTTS | 39 | 93/1161 | 100/1161 | 0.60 |
| MIXED: clean + other | 17 | 35/520 | 35/520 | 0.00 |
| other | 22 | 58/641 | 65/641 | 1.09 |
| self_reported_60plus_real_recording | 44 | 345/1413 | 368/1413 | 1.63 |
| studio_project_design | 34 | 87/935 | 93/935 | 0.64 |

Mixed HiFi quality stays mixed. The full condition table includes family, room, corpus/quality, pose, obstruction,
source level, requested noise SNR and requested speech SIR. These are fixed-scene contrasts, not causal
age/accent/gender effects. SIR uses the native requested_sir_db field; no absent SIR is assigned a number.

The paired O1-minus-O0 primary difference is 1.03 absolute WER points.
The 2,000-replicate, deterministic matched-block percentile interval is [+0.28, +1.87] percentage points. It resamples 85 explicit
matched blocks within the four observed rooms. Shared people, prompts/books, RIRs and noise parents still cross
those blocks. Collapsing all dependencies gives one 117-scene component: this conditional interval can be
optimistic and is not a room/source-population confidence claim.

Equal-room difference: 1.16 points.
UNCERTAINTY.json contains leave-one-room-out and six uneven speaker-connected-component deletion sensitivities.
Neither four rooms nor six components justify a broad population CI. Pooled rates sum counts; scene macro and
equal-room results are separate, not replacements for the pooled denominator.

| Planning reference | Point inside band | Conditional interval inside band | Interval favors O0 beyond band | Interval favors O1 beyond band |
| --- | --- | --- | --- | --- |
| 0.5 | False | False | False | False |
| 1 | False | False | False | False |
| 2 | True | True | False | False |

The 1.0-point reference and 0.5/2.0 sensitivities are new S5 planning conventions, not validated product/runtime
requirements. Nonsignificance is not equivalence. Failure sensitivity is
IDENTICAL_TO_PRIMARY_NO_FAILED_PRIMARY_JOBS; failed outputs are never silently successful zero-error observations.

## Short turns, segmentation and anonymous continuity

| Duration definition | Bin | O0 positive/observed | O1 positive/observed | No-positive O0/O1 | No contained embedding O0/O1 |
| --- | --- | --- | --- | --- | --- |
| whole_clip_bin | <1 s | 34/34 | 34/34 | 0/0 | 8/7 |
| whole_clip_bin | 1-<2 s | 26/26 | 26/26 | 0/0 | 0/0 |
| whole_clip_bin | >=2 s | 385/385 | 385/385 | 0/0 | 1/1 |
| active_duration_bin | <1 s | 56/56 | 56/56 | 0/0 | 9/8 |
| active_duration_bin | 1-<2 s | 93/93 | 93/93 | 0/0 | 0/0 |
| active_duration_bin | >=2 s | 296/296 | 296/296 | 0/0 | 0/0 |

These rows are single-scheduled-source temporal proxies. Whole-file duration differs from estimated active
speech duration. A positive exported segmentation interval intersecting source support is not word recognition;
negative observed support and genuinely unobserved gaps remain distinct. No native word intervals exist, so
event-local insertion counts and recognized-turn omission are unavailable. There is no Common Voice
whole-clip sub-two-second result; strict source/identity cohort gaps remain in the coverage tables.
The emitted segmentation flag summarizes44 tail frames (~0.7425 s) at 0.75 s hops; its boundary intervals are coarse.

| Population | Output | Supported turns | No contained evidence | Dominant ties | Multilabel turns | Within-turn switches | Repeated-person groups C/I/U |
| --- | --- | --- | --- | --- | --- | --- | --- |
| primary_nonoverlap | O0 | 409 | 9 | 41 | 308 | 1090 | 53/42/37 of 132 |
| primary_nonoverlap | O1 | 409 | 8 | 57 | 330 | 1276 | 45/40/47 of 132 |
| overlap_complete | O0 | 113 | 24 | 13 | 56 | 137 | 8/10/18 of 36 |
| overlap_complete | O1 | 113 | 26 | 11 | 53 | 145 | 13/9/14 of 36 |
| ambient_incomplete | O0 | 61 | 2 | 9 | 53 | 178 | 0/0/19 of 19 |
| ambient_incomplete | O1 | 61 | 3 | 10 | 53 | 180 | 0/0/19 of 19 |

Repeated-participant groups include isolated/adjacent repeats. RETURN_GROUPS.csv separately labels actual
returns after another speaker, silent relocation/long pauses, folded spatial contrasts, scheduled overlap and
short replies from frozen metadata. F05 is a folded spatial comparison and is not mislabeled as speech overlap.
Dominant ties and missing labels stay unknown. Unknown ambient speech cannot establish source-specific identity
or misses. Labels and contemporaneous cluster IDs are observations; no retrospective merging, inherited
post-merge lineage or reconciled transcript identity is invented.

## Noise, strict controls and retained direction

| Output | Strict controls | Inserted words | Affected controls | Decoded seconds | Words / decoded minute |
| --- | --- | --- | --- | --- | --- |
| O0 | 8 | 0 | 0 | 357.56 | 0.00 |
| O1 | 8 | 0 | 0 | 357.56 | 0.00 |

Strict-control WER is undefined. Music vocals=N is the existing source annotation, not new frame-level listening
certification. The 19 incomplete-reference cases retain their native output and diagnostics:

| Output | Incomplete-reference scenes | Native speech-flag / decoded support | Embedding decisions | Target-only diagnostic |
| --- | --- | --- | --- | --- |
| O0 | 19 | 21.77% | 567 | 31.30% (154/492; 56S/61D/37I) |
| O1 | 19 | 21.42% | 592 | 31.50% (155/492; 63S/62D/30I) |

Target-only error rates compare the whole mixed output with annotated target text, so untranscribed ambient
speech can contribute insertions. They are LIMITED diagnostics and are excluded from primary all-speaker WER.
Noise-associated flags are not proven false speech.

All 39 real-noise scenes have frozen source/crop-derived activity windows and a shared direction analysis.
Output-local timing is available for32/39 cases on each recipe. Seven music-only controls have no saved output
lag; the silence control is also unmapped, leaving172/180 mapped outputs per recipe overall. Those cases
retain whole-output words, speech flags, evidence and rails. No zero lag or favorable shift was invented.

The adapter uses the existing20 ms source RMS activity rule, the retained800-sample RIR origin exactly once,
saved capture offset and saved output lag. Quiet lies outside full scheduled convolution envelopes; uncertain
tails are separate. Source schedules, RIR origin, microphone capture, processed output and host availability
remain distinct clocks. Manual bearing uncertainty is about±5 degrees, not an XVF accuracy threshold.
NOISE_EVENT_METRICS.csv and REGION_METRICS.csv retain support/observed denominators, flags and raw/adapter levels.
SHARED_NOISE_DIRECTION.csv and SUMMARY_METRICS.shared_noise_direction contain the 39 physical traces once.
Neither output is credited with improving the same shared telemetry. No nonlinear mixture-energy contrast is
called a target-only SNR improvement.

## Evidence workload, headroom and timing

| Measured quantity | O0 | O1 |
| --- | --- | --- |
| Native embedding decisions | 5610 | 6041 |
| Eligible reconstructed hops | 5610 | 6041 |
| Eligible hops without native decision | 0 | 0 |
| Native decisions despite reconstructed ineligibility | 0 | 0 |
| Unique evidence audio, seconds | 1592.75 | 1676.25 |
| Total overlapping-window audio processed, seconds | 2805.00 | 3020.50 |
| Embedding calls / decoded minute | 40.99 | 44.14 |
| Raw PCM24 rail samples / total | 0/131394860 | 747/131394860 |
| Raw rail-affected outputs | 0 | 67 |
| Longest raw rail run, samples | 0 | 7 |
| Fresh canonical child wall, seconds | 2343.31 | 2340.62 |
| Reused historical child wall, seconds | 406.23 | 383.49 |

| Region | Output | Nonempty / mapped scenes | Support seconds | Raw RMS dBFS median [p10, p90] | Native-adapter RMS dBFS median [p10, p90] |
| --- | --- | --- | --- | --- | --- |
| Estimated speech-active support | O0 | 172/172 | 1399.22 | -39.67 [-42.90, -36.05]; n=172; zero RMS=0 | -36.67 [-39.90, -33.05]; n=172; zero RMS=0 |
| Estimated speech-active support | O1 | 172/172 | 1399.22 | -22.17 [-24.54, -18.41]; n=172; zero RMS=0 | -22.17 [-24.54, -18.41]; n=172; zero RMS=0 |
| Quiet outside all convolution envelopes | O0 | 172/172 | 5112.06 | -133.74 [-135.42, -132.74]; n=172; zero RMS=0 | unavailable [unavailable, unavailable]; n=0; zero RMS=172 |
| Quiet outside all convolution envelopes | O1 | 172/172 | 5112.06 | -133.60 [-135.29, -132.61]; n=172; zero RMS=0 | -132.03 [-135.96, -128.10]; n=2; zero RMS=170 |

RMS distributions describe nonzero per-scene energy on the stated mapped support, with zero-RMS scene
counts shown separately. They are not pooled dB averages or clean-target SNR. Missing timing is unavailable,
not a zero-level observation; raw and native-adapter support lengths are retained in REGION_METRICS.csv.

Gate reason categories overlap. Eligible-without-decision and decision-despite-ineligible counts are reported
directly; unlogged rejected embedding calls stay unavailable. Overlapping windows are not independent new
speech: their union and summed processed durations are different quantities. Raw PCM24, FLOAT adapters and
native PCM16 are distinguished; active/support/quiet energy is not whole-file speech SNR.
Raw residual rails remain LIMITED under the unchanged gross-saturation rule.

Fresh paired child-wall O1-minus-O0 median is
0.02 s over
156 fresh scene pairs.
These are offline accelerated costs, not live word/name latency or CM5 fit. Historical reuse timing is separate.
Host load included concurrent analysis. One intermediate refresh briefly used two four-thread analysis
pools (eight worker slots), exceeding the intended six-slot analysis cap; EXECUTION_NOTES.json records
this deviation. Final text/support scoring uses three workers each after canonical inference closes.
Canonical inference used one worker throughout. Timing is not an idle-host or repeated speed experiment.
TIMING_SUMMARY.csv records measured process-start, session/source-start, native completion and child-exit
boundaries; model loading and isolated summary-writing time are not guessed. Queue waits include earlier
serial work. Partial-text prefix additions, lexical rewrites and label changes are exported snapshot changes,
not edits corrected against reference truth or evidence of reconciliation.

| Audited resource / runtime | Observed value | Scope |
| --- | --- | --- |
| S5 wall time through final audit | 5552.46 s (1.54 h) | 2026-09-09T14:35:40.461500+00:00 |
| Sampled canonical model-tree peak RSS | 444.73 MiB | 2276 samples; not a continuous absolute peak |
| Minimum sampled available OS RAM | 31.27 GiB | Recorded canonical-run samples |
| Available OS RAM at audit | 32.38 GiB | Final audit snapshot |
| New S5 logical storage at audit | 1.37 GiB | Bounded new files; existing datasets excluded; later package bytes not yet included |
| Fresh native child wall sum | 4683.94 s / 312 jobs | Offline child process elapsed sums, separate from end-to-end S5 wall time |
| Historical reused child wall sum | 789.72 s / 48 jobs | Child process elapsed sums; historical work is outside S5 elapsed wall time |
| C: free space and mapped SSD | 85.76 GiB free | WD_BLACK SN850X 2000GB: Healthy / OK |
| G: free space and mapped SSD | 416.18 GiB free | KINGSTON SNVS2000G: Healthy / OK |

SSD health is the audit's mapped Windows provider observation, not a comprehensive SMART test. Resource
samples and the separate oracle-process RSS observation do not establish a simultaneous system-wide peak
or 2 GB CM5 fit. End-to-end wall time includes S5 preparation and reporting through the named audit boundary;
RUN_MANIFEST_FINAL.json extends it through package assembly start, and PACKAGE_RECEIPT.json records ZIP completion.

## Bounded representation diagnostic

All 444 embedding calls completed on 222 unique source-clip windows from 34 corpus-qualified development identities, 121 scenes and 28 RIRs. There are 104 disjoint genuine comparisons and 104 balanced different-person comparisons; all paired O0/O1 results are available. Each source interval is 0.5 s, mapped to each output using saved offsets, with identical source-relative timing. Selection was frozen before waveforms, embeddings and cosines. No reserve audio or task performance was accessed.

Mean genuine cosine was 0.21915 on O0 and 0.21262 on O1; mean impostor cosine was 0.10078 and 0.09475. Mean matched-anchor genuine-minus-impostor separation was 0.11837 and 0.11787, respectively (O1−O0 about −0.000506). The distributions overlap substantially. This is descriptive oracle-window evidence, not online identity accuracy, a practical-equivalence test, a threshold recommendation or proof of a representation winner. Source and condition strata remain available in SUMMARY_COMPACT.json and RESULTS.json.

The 222 windows contain 85 CMU ARCTIC, 79 Common Voice and 58 HiFiTTS sources (11 clean, 47 other). Only 13 source recordings are 1–<2 s; 209 are ≥2 s. No subsecond source survives the strict continuous-active and boundary margins. Whole source duration differs from the fixed 0.5 s analysis window. Conservatively excluding every other utterance's convolution envelope leaves gaps and unequal condition coverage; it is not phonetic certification.

The unchanged native ReDimNet2 CPU backend and embedding method ran with 2 speaker threads. The exact existing gain and AudioJournal PCM16 conversion were reused; O0 gain 1.4125375446227544 and O1 gain 1.0 were applied once. No ASR, Pyannote inference, H2 session, enrollment or tracking state was created. No threshold was tuned and no vector was fed back. The single process took 8.328 s internally (8.993 s observed tool wall), used 175,579,136 bytes maximum sampled RSS, exited 0 and was independently confirmed absent by PID/creation identity. CPU time was not separately sampled.

Use SUMMARY_COMPACT.json and this note in the handoff. Keep WINDOW_PLAN.json, full per-window receipt, per-comparison scores and vectors_local_only.npz in the local artifact index. Do not add another figure beyond the coordinator's four-figure limit. The frozen script and README remain unchanged after model execution; their exact bindings are in WINDOW_PLAN.json and TEST_RECEIPT.json.


## Coverage, provenance and limitations that remain

The fixed bank uses CMU ARCTIC, HiFiTTS clean/other and Common Voice26 self-reported60+.
L2-ARCTIC and DEMAND were not used. Development has 34 corpus-qualified IDs and 342 unique probe clips;
cross-corpus human uniqueness is unverified. There are 33 development RIRs across four room/table settings,
7 upright and 7 obstructed scenes. All 240 captures together use39 of 120 eligible RIRs; 81 eligible paths remain
unused, and one clock-sensitive path is ineligible for canonical/HIL selection. RIR_COVERAGE.csv includes all 121 paths.
Unused/rare paths are not called inferior or equivalent. Upper Loeb remains in protected acoustic/joint reserve.
All 121 acquisition records in this library are REVIEW; the canonical RIR validation PASS status is a separate
validation result, not an acquisition-status upgrade. Historical testing and RETAKE acquisitions are excluded
by the preserved upstream selection. The clock-sensitive flat R13 path is excluded from canonical/HIL
selection entirely, with zero scene uses. The two original 100 m metadata unit errors were user-confirmed as
100 cm = 1.00 m: low-table Opening Behind Listener, flat/upright R05, both +20 degrees with about +/-5 degrees
manual uncertainty. The corrected flat path is used in 6 development scenes; the upright path is unused.
No selected distance exceeds5 m. No measurement/RIR was regenerated in S5.

The pack prompt contained a malformed57-character RIR hash. The current manifest and two qualified prior
receipts agree on the 64-character hash 468b2b306f994937a7d02db611080d38c7a4bcc7dc89ce7dc73d93762380f546;
the original pack and library were not changed. V10 remains read-only; this handoff includes only a reviewed
insertion proposal. Prior Windows snapshot/I/O incident context is retained without claiming a proven cause
or changing services. No physical XVF playback occurred in S5.

Unsupported conclusions remain: full DER/JER, enrolled naming, precise live text/name latency, reliable
direction-to-person assignment, new voices/rooms, walking/final-enclosure behavior and 2GB CM5 operation.
The deterministic failure catalogue includes O0-helping, O1-helping, shared difficult and equal-error cases;
audio was not listened to as part of this analysis. Source rights/notice/training caveats remain bound to the
prior source manifests; this comparison is not automatic clearance for future training.

## Four figures and their exact plotted data

The following figures are bound by figures/FIGURE_RECEIPT.json to this final panel. Captions and every
plotted value are retained in figures/CAPTIONS.md and figures/plotdata.csv.

![01 words and paired scenes](figures/01_words_and_paired_scenes.png)

Development only. O0 = recorded ASR output with fixed +3 dB host gain; O1 = postprocessed auto output at unity. Primary and MIMO use different populations and are not pooled together. MIMO permits reference-utterance serialization, not separated-stream or timed-overlap recall. Scene points share people, text and measured room paths.

![02 primary condition differences](figures/02_primary_condition_differences.png)

Negative differences favor O1; positive favor O0. Points are descriptive pooled primary-WER differences, with explicit paired-scene counts. Only the overall line is a 2,000-replicate room-stratified matched-block percentile interval; remaining dependencies can make it optimistic. Grey ±1-point band is a planning reference, not equivalence. Family n=0 means no eligible primary scenes. MIXED source groups remain mixed; corpus contrasts are not causal age/accent effects.

![03 attribution returns and short turns](figures/03_attribution_returns_and_short_turns.png)

cpWER bars show percent and errors/reference words under one global final-label assignment; this is not DER or reconciled identity. Primary continuity retains consistent/inconsistent/unknown; after-other groups are a subset of all repeated participants. Short-turn flags use single-known-source temporal support, not recognized replies. Clip and estimated-active bins differ; windows are coarse and correlated. Unknown ambient and scheduled-overlap attribution are excluded from source-specific flag percentages.

![04 evidence headroom and oracle](figures/04_evidence_headroom_and_oracle.png)

All native development jobs; overlapping windows and reused people are dependent. Successful calls are observed; rejected calls are not fully logged. Union duration counts each sample once within a job. Raw PCM24 positive rail uses the retained packed-payload criterion; host attenuation cannot repair clipping. Oracle source-selected windows use unchanged embeddings, not online identity/enrollment accuracy; quantile lines are distributions, not confidence intervals or tuned thresholds.

## Reproduce and stop

Use scripts/README_S5.md and the component READMEs. JOB_MANIFEST.json binds every accepted raw output and exact
execution identity; LOCAL_ARTIFACT_INDEX.json resolves native sessions, audio, logs, plans, test receipts and
omitted large artifacts. FINAL_AUDIT.json and RESERVE_PROTECTION.json qualify closure and zero reserve task
access. The archive has member hashes and a strict20 MiB cap, with a10 MiB target.

Next authorized planning question: With O0 fixed as the input recipe, can a separately evaluated direction-assisted anonymous-speaker layer improve ordinary returning-speaker consistency and final attributed-text quality over unchanged H2 without reducing short-turn evidence coverage or worsening noise-associated behavior?
S5 stops here. No S6 implementation, new capture, reserve scoring, model training or CM5 deployment was launched.
