**01_words_and_paired_scenes.png**

Development only. O0 = recorded ASR output with fixed +3 dB host gain; O1 = postprocessed auto output at unity. Primary and MIMO use different populations and are not pooled together. MIMO permits reference-utterance serialization, not separated-stream or timed-overlap recall. Scene points share people, text and measured room paths.

**02_primary_condition_differences.png**

Negative differences favor O1; positive favor O0. Points are descriptive pooled primary-WER differences, with explicit paired-scene counts. Only the overall line is a 2,000-replicate room-stratified matched-block percentile interval; remaining dependencies can make it optimistic. Grey ±1-point band is a planning reference, not equivalence. Family n=0 means no eligible primary scenes. MIXED source groups remain mixed; corpus contrasts are not causal age/accent effects.

**03_attribution_returns_and_short_turns.png**

cpWER bars show percent and errors/reference words under one global final-label assignment; this is not DER or reconciled identity. Primary continuity retains consistent/inconsistent/unknown; after-other groups are a subset of all repeated participants. Short-turn flags use single-known-source temporal support, not recognized replies. Clip and estimated-active bins differ; windows are coarse and correlated. Unknown ambient and scheduled-overlap attribution are excluded from source-specific flag percentages.

**04_evidence_headroom_and_oracle.png**

All native development jobs; overlapping windows and reused people are dependent. Successful calls are observed; rejected calls are not fully logged. Union duration counts each sample once within a job. Raw PCM24 positive rail uses the retained packed-payload criterion; host attenuation cannot repair clipping. Oracle source-selected windows use unchanged embeddings, not online identity/enrollment accuracy; quantile lines are distributions, not confidence intervals or tuned thresholds.
