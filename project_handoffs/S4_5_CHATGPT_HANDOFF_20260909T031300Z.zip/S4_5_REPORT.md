# S4.5 analysis-first handoff

Status: **COMPLETE_WITH_SOURCE_GAPS**. S4 remains **COMPLETE_WITH_LIMITATIONS**. This run uses original CMU ARCTIC, HiFiTTS and older English Common Voice, as the user requested. L2 ARCTIC is excluded. The unchanged Revision 9 workbook is the planning/results guide; WORKBOOK_UPDATE.md is proposed insertion text.

| Observation | Actual |
|---|---:|
| planned_canonical | 240 |
| rendered | 240 |
| accepted | 240 |
| development_accepted | 180 |
| reserve_accepted | 60 |
| failed_capture_attempts | 1 |
| recorded_hardware_batch_errors | 3 |
| canonical_analyzed | 240 |
| optional_reference_accepted | 0 |
| physical_passes | 242 |
| charged_active_playback_s | 11020.0 |
| H2_model_wall_s | 882.2679999996908 |
| model_invocation_attempt_receipts | 72 |
| observed_model_child_PIDs | 72 |
| unconfirmed_model_starts | 0 |
| run_elapsed_s | 26763.138726 |
| prepared_new_source_clips | 794 |
| prepared_noise_parents | 32 |

## Observed analysis

# S4.5 completed evidence and interpretation

S4.5 completed its mandatory **240 accepted canonical captures, 48 native output diagnostics and 24 native dry-source diagnostics**. The final stage classification is **COMPLETE_WITH_SOURCE_GAPS**, with residual task limitations: direction availability is not reliable identity, anonymous-label continuity remains unstable, and source/role/short-clip coverage is incomplete. The 60 reserve scenes remain unscored for task performance. S4 remains **COMPLETE_WITH_LIMITATIONS** and its original evidence is preserved.

## Physical evidence and scope

All **240 new canonical scenes** have one accepted capture: **180 development and 60 protected reserve**, across twelve families of twenty. The active four-microphone FLOAT32 bank totals **10,967 seconds (3 h 2 m 47 s)**. All accepted captures pass framing, callback, mandatory telemetry and microphone-payload checks. Their **694,643,004 compared microphone scalar samples have zero mismatches**, with **zero marker errors**. This is a four-microphone comparison count, not a six-channel output count. All nonzero source payload is present in the 239 nonsilent cases. Pure digital silence cannot establish alignment; inactive boundary padding excluded from comparison is retained explicitly.

The physical ledger contains **242 passes: 240 accepted canonical takes, one excluded failed canonical take and one eight-second tagged diagnostic**. Charged active playback totals **11,020 seconds (3 h 3 m 40 s)**. There are **zero optional isolated-reference captures**: thirty-four disjoint source-reference renders were prepared, then skipped under the explicit analysis-time budget. They remain local for a later authorized stage, outside the canonical 240 and outside enrollment/model scoring. No RIR was regenerated and no reserve task score was inspected.

## Output level evidence

| Raw output partition | O0 rail samples / decoded samples | O1 rail samples / decoded samples | O1 cases with rails | Longest O1 rail run |
|---|---:|---:|---:|---:|
| Development, 180 captures | 0 / 131,394,860 | 747 / 131,394,860 | 67 | 7 samples |
| All accepted, 240 captures | 0 / 174,302,480 | 1,024 / 174,302,480 | 93 | 7 samples |

The longest observed O1 rail run is 0.4375 ms at 16 kHz. **No output meets the predeclared gross-saturation quarantine rule** (at least 1,600 consecutive rail samples or at least 1% rails). The O1 cases with residual rails remain LIMITED; exact input transport does not turn their clipped samples into unclipped output. Denominators include silence/padding and refer to raw decoded audio before H2 gain. O0 +3 dB is the unchanged host adapter policy; O1 remains unity. No per-scene attenuation or retuning was applied after inspecting outcomes.

## Bounded speech-recognition evidence

All **48 output jobs completed natively**, with 24 predeclared development scenes processed once per output. There are no output model failures, quarantines or reconstructed S4.5 summaries. The unchanged text rules yield **15 ordinary nonoverlap scenes per output**, five overlap-limited scenes, two scenes with incomplete ambient references, and two strict empty-reference controls. Ordinary WER therefore covers 30 of the 48 output jobs, not the full 240-scene bank.

| Source stratum | Eligible scenes per output | Reference words per output | O0 errors / words (WER) | O1 errors / words (WER) |
|---|---:|---:|---:|---:|
| Original CMU ARCTIC | 4 | 99 | 6/99 (6.06%) | 5/99 (5.05%) |
| Common Voice, selected self-reported 60+ cohort | 5 | 178 | 32/178 (17.98%) | 28/178 (15.73%) |
| HiFiTTS, scenes mixing clean and other sources | 3 | 109 | 7/109 (6.42%) | 6/109 (5.50%) |
| HiFiTTS, other-only scenes | 3 | 94 | 2/94 (2.13%) | 2/94 (2.13%) |
| **Pooled eligible set** | **15** | **480** | **47/480 (9.79%)** | **41/480 (8.54%)** |

O0's 47 errors comprise **38 substitutions, five deletions and four insertions**. O1's 41 comprise **30 substitutions, seven deletions and four insertions**. Character errors are **100/2,137 (4.68%)** and **89/2,137 (4.16%)**, respectively. Both outputs share the same eligible scene and reference denominators. These are pooled edit counts, not means of per-scene percentages, and repeated words/voices/paths remain dependent. There is no pure-clean HiFiTTS scene stratum in this particular valid-WER sentinel subset; mixed clean/other scenes cannot isolate the clean branch.

O1 has six fewer word edits in this small fixed subset, while its residual rail and identity-continuity limitations remain. This observation does not choose the final output or establish statistical superiority. Common Voice has more errors in these allocated conditions, but source quality, text, talkers, rooms and scene allocation are confounded; age or accent alone cannot explain the difference.

The two strict controls, **S45_12_01** (documented nonspeech music) and **S45_12_15** (digital silence), emitted **zero words on both outputs**: 0 insertions over **89.390875 decoded seconds per output**, comprising two 44.6954375-second H2 inputs. WER/CER is undefined for an empty reference. This is a bounded two-control observation, not a zero false-word rate established for all music or all 240 scenes. The 45-second intended/native capture duration differs from the decoded H2 duration because the capture/framing convention excludes startup frames.

## Dry-source difficulty and comparison scope

All **24/24 predeclared unique dry controls completed natively** through the same ASR path, using the frozen source gain only, with no RIR, XVF output or O0 host gain. Their 169 reference words yield **10 edits (5.92% WER): six substitutions, three deletions and one insertion**. Character errors are **17/720 (2.36%)**.

| Dry source stratum | Unique whole clips | Word errors / reference words | WER |
|---|---:|---:|---:|
| Original CMU ARCTIC | 11 | 2/51 | 3.92% |
| Selected older Common Voice | 5 | 2/27 | 7.41% |
| HiFiTTS clean | 3 | 3/54 | 5.56% |
| HiFiTTS other | 5 | 3/37 | 8.11% |

These few, nonuniformly allocated clips show that some recognition errors exist before the measured room/XVF chain. They do not quantify its causal contribution, establish a guaranteed lower bound on processed WER, or support a population ranking of source domains. The 30 control–scene links span 16 distinct sentinel scenes, each containing multiple utterances, so **zero of the 60 output contexts qualifies for the existing exact-single-clip paired comparison**. Compatible processed-minus-dry WER is correctly null. These accelerated file runs measure offline throughput, not live end-to-end word latency.

## Anonymous speaker-label evidence

| Measure | O0 | O1 |
|---|---:|---:|
| Native output jobs / embedding-gate hops | 24 / 4,492 | 24 / 4,492 |
| Successful embedding decisions | 650 | 728 |
| Reconstructed eligible hops without a decision | 0 | 0 |
| Decisions despite an ineligible gate | 0 | 0 |
| Reference-supported scheduled turns | 68 in 20 jobs | 68 in 20 jobs |
| Turns with no fully contained decision evidence | 3 | 3 |
| Turns with more than one anonymous decision label | 47 | 53 |
| Within-turn decision-label switches | 137 | 170 |
| Repeated-participant groups: consistent / inconsistent / unknown | 6 / 9 / 7 (22 total) | 10 / 7 / 5 (22 total) |
| Whole-job decision-label observations / switches | 650 / 216 | 728 / 256 |
| Final-transcript label snapshots / switches | 62 / 37 | 65 / 39 |

The 22 return groups are participant-within-job groups, not 22 independent people. Consistency requires a dominant anonymous label for every scheduled turn; missing or tied evidence remains unknown. These 68 file-support turns use fully contained single-source embedding windows, including eligible exclusive portions of overlap scenes. They are a different population and support rule from the 409 primary spatial turns and cannot be merged into a joint accuracy denominator. No identity labels or transcript truth entered H2.

Across the 24 fresh jobs per output, the sum of within-job distinct decision labels is **157 for O0 and 191 for O1**; 22 jobs per output contain multiple labels. The corresponding final-transcript sums are **55 and 57**, with 20 jobs per output containing multiple emitted labels. These sums are not numbers of distinct people. Label strings reset between jobs, and switches across a whole conversation can reflect actual speaker changes. Within-turn variation is concerning evidence of anonymous-label instability under this support rule, but it is not full DER or a verified cluster-splitting count.

Final transcript labels are snapshots of the concurrent speaker state. The baseline exports **no reconciled cluster lineage in any of the 48 jobs**, so underlying cluster fragmentation, post-merge identity continuity, enrolled-name accuracy and full diarization error remain unavailable. Successful embedding calls use overlapping windows; rejected embedding-call counts are not logged and remain null. Gate reasons such as low RMS and no speech can overlap, so their counts must not be added as a disjoint rejection total.

## Direction availability and continuity

The primary spatial subset is **409 eligible turns across 117 of the 180 development scenes**, totaling **1,158.1372653 s** of estimated, callback-mapped active support. Of 583 scheduled development turns, 113 turns from overlap-limited scenes and 61 turns with incomplete ambient references are excluded from this primary comparison. The frozen spatial rule excludes all turns in a flagged overlap scene, including later nonoverlap turns. The support sum and within-case union agree; this subset does not multiply overlapping speech into an independent denominator.

| Cue | Usable support / total support | Nominal-sector matching / total support | Sustained acquisition / eligible turns | Repeated-participant sustained acquisition |
|---|---:|---:|---:|---:|
| Selected processed | 1,076.6000 / 1,158.1373 s (92.96%) | 544.1402 / 1,158.1373 s (46.98%) | 208 / 409 | 81 / 183 |
| Selected automatic | 599.5928 / 1,158.1373 s (51.77%) | 287.2309 / 1,158.1373 s (24.80%) | 81 / 409 | 27 / 183 |
| Raw automatic | 599.5928 / 1,158.1373 s (51.77%) | 282.5796 / 1,158.1373 s (24.40%) | 81 / 409 | 27 / 183 |

These are descriptive cue-availability and coarse-sector occupancy measurements under the frozen policy, not a calibrated XVF angle-accuracy specification or conditional accuracy given an available cue. Matching uses the same full support denominator, including unavailable time. The manual loudspeaker-bearing uncertainty remains ±5 degrees; the linear array retains front/rear ambiguity, and neither truth nor a fitted transform steered the device.

For selected processed direction, first sector hits were observed on **281/409 turns**; **128** were censored. Its observed-only first-hit median was **0.1287002 s**, with **96** turns already matching at onset. Sustained acquisition occurred on **208/409**, with **201 censored**; the **1.05154285 s acquired-only median** excludes those censored turns. The sustained rule requires a full second with at least 80% occupancy. **Thirty-seven envelopes are shorter than one second**, so cannot satisfy it. Acquisition uses each turn's first-to-last support envelope, including internal gaps; coverage uses the activity-support union.

The 183 repeated-participant turns comprise **147 returns after another participant, 30 repeated isolated turns and six adjacent same-participant turns**. They are not 183 independently established identity-reacquisition trials. All primary turn orderings are chronological. Ten F09 diagnostic lists are nonchronological after the frozen background-timing alignment, but all ten are excluded overlap cases with zero primary contribution; the original diagnostics remain unchanged.

Off-delay is cue loss, encompassing wrong-sector, unavailable, stale or zero-energy states. Selected processed off-delay is observed on **393 turns**, censored on **16**, and already zero on **245**. Its zero median is therefore not proof of fast successful release. The separate 250-ms transaction, delivery-delay and receipt-age limits do not establish a 250-ms end-to-end latency bound. Internal DSP observation time is unknown.

## Direction is not a speech-presence or identity label

Seven development controls containing music annotated with **vocals=N** produced a finite selected-processed cue for **259.704997 / 315.0268075 s (82.44%)** of whole-capture support. Digital silence produced **0 / 45.0038727 s**. Thus the selected-direction cue is not specific to speech or a known person. The music's original annotation is retained; it is not a new phonetic certification. These are whole-capture controls, not event-localized false-indication estimates.

The inherited spatial scorer has **no event-specific noise windows for all 39 development scenes using real_noise**. It recognizes the older synthetic-noise event type. Missing windows mean this part of noise-event analysis is unavailable, not zero false indications. Future evaluation should address that scorer coverage gap before claiming event-specific suppression or false-trigger rates.

Development telemetry contains **134,107 transactions per field**, with **zero invalid transactions** and **zero receipt gaps above 250 ms** in the reviewed accepted set. Selected-angle fields include **93,567 invalid/nonfinite value slots**, including documented no-speech NaN; those are different from transaction failures. Equal adjacent values do not by themselves prove stale DSP frames.

## Incidents, recoveries and desktop conditions

Three hardware batches recorded errors. The first two were **pre-playback control readback timeouts**, so neither produced a failed audio take. The second also failed its automatic restoration readback. The initial supervisor closed, a bounded recovery verified the complete starting state, and the previously tested v2 supervisor resumed identical inputs under the original deadline. Original failure and checkpoint evidence was preserved.

The third error was the **first actual failed physical take**, S45_12_16, due to a finite capture timeout. It retained all expected frames and exact microphone payload with valid telemetry, but remained ineligible because the frozen capture gate failed. The recorded callbacks contain no corresponding long audio hole; the extra wall delay occurred after the last copied samples. Its restoration readback also timed out. A separate exact-state recovery restored the initial PP_AGCGAIN value, and **one identical retry passed**. This scene has exactly two physical attempts and no retry allowance left. Recovery did not play audio or change the capture recipe.

Windows events show Acronis/VSS snapshot activity overlapping the two recent stall windows, a Registry Writer freeze/thaw timeout, and an independently logged 36-second Windows database read wait. An earlier hung-I/O event precedes the snapshot-initiation log, so the precise root cause and sole attribution remain unresolved. Storage-provider health observations are separate from these I/O stalls. No backup service, unrelated process, security setting, driver or firmware was changed. Future real-time sessions should be scheduled with known background snapshot activity in mind.

## Source and design limits for later planning

Actual canonical speech uses original CMU ARCTIC, HiFiTTS and the selected older English Common Voice cohort; **L2 ARCTIC is excluded by the user's instruction**. HiFiTTS clean and other partitions remain distinct. The roster was frozen before waveform QC; a fourth targeted CV reserve contributor had no clip survive the maximum-boost rule and was not replaced after inspection. Source-domain comparisons cannot identify causal age, accent or gender effects.

The canonical bank contains credible complete short utterances, but no Common Voice sub-two-second examples and no newly held-out-speaker subsecond coverage. Only five development identities have dedicated noise-free isolated development scenes; all thirty-four have conversation exposure, but five have only one partner and fourteen never take a background-talker role. The optional isolated XVF references were not captured, so do not claim those gaps were repaired.

The fixed source/scenario allocation, matched-pair dependencies, shared text/book/artist groups, corpus rights, source-quality selection and unknown environmental speech must travel with later S5/S6 prompts. The 240 scenes are not 240 independent rooms or an enclosure/generalization qualification. DEMAND was unavailable during bounded official-source attempts; verified MUSAN was actually used. No training, enrolled naming, O0/O1 winner selection or fusion search occurred in this stage.

Thirteen bare CMU parent basenames cross declared roles/splits because an arctic_a/bNNNN filename can contain different text across voices. The source audit found zero role/split crossings for exact normalized prompt groups, HiFi book groups and PCM hashes. Later split code must use those qualified content groups and preserve the basename caveat; a bare filename is not a globally unique prompt identity.

The frozen dry plan contains 24 individual whole clips and 30 control–scene links across 16 distinct sentinel scenes (60 output contexts). Every context contains multiple utterances, so none meets the existing exact-single-clip comparison rule. Dry results describe source difficulty through the same ASR path; subtracting their WER from multi-utterance processed-scene WER would not isolate the RIR/XVF effect. The compatible paired-difference field must remain unavailable in this stage.

## What changed from S4, and what is ready next

The preserved S4 stage contains 24 canonical scenes, 26 accepted captures including repeats, and 48 output jobs. Its 18 nonoverlap scenes yielded **72/467 word errors for O0 (15.42%) and 91/467 for O1 (19.49%)**. S4.5's 15 valid nonoverlap sentinels yield **47/480 (9.79%) and 41/480 (8.54%)**. Different source/scenario allocation and dependent reference sets prevent treating that numerical change as a matched performance gain or an effect of the export repair.

The authorized H2 repair addressed atomic summary durability, writer completion/failure propagation and startup terminal-state ordering. All **72 new jobs have native completed summaries**. The independent final native review verified **37,080,544 samples** across gained input adapters and full PCM16 journals: **36,086,096 output samples plus 994,448 dry samples**, zero mismatches. Completed jobs contain one terminal completion event, no failure events and no recorded audio drops. Actual final labels and event journals agree with the bound analyses. The original 44 native and four explicitly reconstructed S4 summaries remain unchanged. No neural asset, scientific threshold, segmentation rule or naming policy was retuned.

The bank is ready to support a **separately authorized S5 planning/evaluation step**, with no mandatory S4.5 execution job pending. Before claiming event-specific noise suppression, address the real-noise event-window scoring gap under a new version. Before reliable diarization/naming claims, specify evidence for source-aligned identity continuity and reconciled cluster lineage; the current snapshots do not supply it. Retain source/role/short-clip gaps, O1 LIMITED levels, manual geometry uncertainty and protected reserve. No S5/S6 run, fusion search, training, enrollment or deployment has started.

## Retained bytes, timing and closure

The **240 active canonical four-channel renders occupy 2,807,576,960 bytes (2.61 GiB)**. The 240 accepted captures' retained native-packed, decoded-six-channel, O0 and O1 WAV representations total **7,341,798,240 bytes (6.84 GiB)**. These are multiple representations of the same captures, not extra accepted trials. The full hardware tree, including setup inputs, shared telemetry, all failures/diagnostic data and receipts, contains **9,317,112,823 bytes (8.68 GiB)** at the recorded observation. The unplayed v1 render bank remains separately preserved. BANK_SIZE_REVIEW.json binds the source manifests, component sizes and accounting scope.

Recorded model-child intervals total **882.268 s (14 min 42.268 s)**: **789.725 s** for 48 outputs and **92.543 s** for 24 dry clips. The inputs total **2,255.381 output seconds plus 62.153 dry seconds**. Child intervals include that child's startup/asset/finalization work but exclude substantial coordinator and between-job overhead; they are not the total neural-stage or live-audio wall time. The supervisor closed at **2026-09-09 10:16:56.101 UTC**, **7 h 3 min 56.101 s** after the original 03:13 start. Final report/plot review and packaging follow that closure; the final run_manifest.json records the later handoff elapsed time without resetting the eight-hour deadline.

Physical playback remained **3 h 3 min 40 s**, below 4.5 hours; 242 passes stayed below 320. Exposed XVF state was restored before H2, and supervisor/model/hardware closure is independently checked in the final audit. Software receipts mark scoped keep-awake released; the frozen code did not retain the cleanup API return value, so independent OS power-state restoration is not claimed. The final resource receipt separates current storage-provider health/free-space observations from a comprehensive SSD health diagnosis and from the unresolved earlier I/O stalls.


The final resource/restoration audit **passed at 2026-09-09T10:37:53.078764+00:00**. It rehashed all 121 RIR WAVs, the unchanged manifest, Revision 9 Word master and prior S4 handoff; all matched. All six acquired hardware batches have verified effective restoration, including the two separately preserved recovery receipts. Its closing process snapshot contains no campaign owners or historical model PIDs. The bounded new-run logical-file count is **34,137,724,837 bytes (31.79 GiB)**, below 60 GiB. At the storage observation C: had **86.49 GiB free** and G: **417.47 GiB free**, above the 50/75-GiB floors. C: maps to WD_BLACK SN850X PhysicalDrive2 and G: to KINGSTON SNVS2000G PhysicalDrive3; exact serial/model joins report both Healthy/OK. Logical accounting excludes the audit receipt itself and later compact report/package rewrites, and is not a whole-drive allocation delta.

The final audit history also retains two reporting compatibility issues. Get-Disk did not expose the Kingston entry, while authoritative Win32 associations and the exact matching Get-PhysicalDisk entry established it. A written blocked audit then encountered PID 66428 reused by Windows Group Policy Client, created after the completed H2 job; that observation is preserved. The later final snapshot found the reused PID absent. A strict service/timestamp fallback was fixture-tested but was not exercised by the final live snapshot. Neither issue is an additional physical take failure or a reason to relabel original evidence. No service or disk setting was changed.


## What this stage establishes

The canonical input bank targets 240 new scenes, 180 development and 60 protected reserve in 12 families. The scenes are measured-path simulations, not independent rooms or an enclosure qualification. Each source retains its native transcript, quality partition, pseudonymous identity, preparation scalar and exact schedule. Four microphones share one family headroom scalar. RIRs are not normalized independently, and no extra distance attenuation or artificial generic reverb is added.

The approved RIR set contains 120 HIL-eligible inputs out of 121 canonical records. The clock-sensitive R13 path remains excluded. Only qualified PASS/REVIEW acquisition data is eligible; pilots, retakes, Loeb Caf and historical testing remain excluded. Upper Loeb is an acoustic reserve. The two user-confirmed 100 cm distance corrections remain 1.00 m; no selected distance exceeds 5 m. Manual bearing uncertainty remains ±5 degrees and is separate from XVF directional error. Folded linear-array direction retains front/rear ambiguity.

Source preparation follows the existing active-RMS numerical rule with 12 dB maximum boost and 0.5 FS dry peak cap. Source quality does not certify anechoic audio. HiFiTTS has three clean-branch voices and seven other-only voices; the eight/two split preserves the quality strata. Common Voice age/accent/gender is available self-reported metadata, not inferred identity or a causal age/accent experiment. The roster was frozen before waveform QC; its fourth newly targeted CV reserve contributor failed clip QC and was not replaced after inspection.

CMU ARCTIC recording basenames can repeat across voices while containing different text. The normalized transcript prompt group is the lexical split authority; a bare arctic_a/bNNNN basename is not a globally unique prompt. The final source-coverage review retains this namespace caveat alongside the short-clip, isolated-development, partner and optional-reference gaps. Independent source, spatial/transport and native-H2 review receipts are bound in the local artifact index when available. A first-job native review does not certify completion of the full model set.

Real-noise parents come from verified official MUSAN material and retain per-parent attribution/rights and speech-content evidence. Generic environmental sounds with uncertain speech are not strict speech-free ground truth. DEMAND access was unavailable during bounded official-source attempts; no DEMAND recording or license is invented. Noise SNR is measured over the same target-active windows across all four microphones. Transient timing/excerpts are frozen from source-only evidence. Noise-only/speech pairs reuse an exact noise component. Full rights and corpus/split caveats are in RIGHTS_AND_SPLITS.json and the local catalogues.

Canonical hardware capture uses the frozen S4 PCM24 packed path and simultaneous O0/O1, recaptured microphones and continuous telemetry. Original output files retain all rail samples. Gross saturation is quarantined for downstream task use; residual rails are LIMITED. The numerical recipe is fixed, with O0 +3dB only in the H2 adapter and O1 unity. No target truth steers the device. Reserve files receive only coverage/level/transport/integrity checks. Optional isolated references are separate from 240, unscored and not enrolled.

# Experiment context for the next ChatGPT prompt author

This describes the frozen **S4.5 v2 input design**, not campaign completion. Final acceptance/model receipts supply execution denominators. The Revision 9 Word workbook remains the planning guide; bound manifests supply implemented details. These notes do not authorize execution.

## Cohort, source quality and dependence

The bank schedules 43 corpus-qualified identities from 44 frozen targets. These are metadata identities, not independently verified unique humans across corpora. L2 ARCTIC is excluded by the user.

| Source | Frozen identities | Scheduled identities | Unique scheduled clips | Utterance instances |
| --- | ---: | ---: | ---: | ---: |
| Original CMU ARCTIC | 18 | 18 | 206 | 245 |
| HiFiTTS | 10 | 10 | 122 | 268 |
| English Common Voice 26 | 16 | 15 | 121 | 264 |
| Total | 44 | 43 | 449 | 777 |

The identity split preceded waveform QC: CMU 14 development/4 reserve; HiFiTTS 8/2; Common Voice 12/4. CV reserve contributor `CV_d9893b57a7e090bfcc17` had no clips within the frozen maximum requested 12 dB boost and was not replaced. Thus 34 development and nine reserve identities are usable. The 34 development reference inputs comprise 33 new unused enrollment clips and one unused historical S4 candidate; preparation does not establish capture or enrollment.

The 413 historically excluded Common Voice contributors remain excluded. Original six development/three reserve CV roles remain; two authorized historical S4 development probe clips are explicitly reused.

Dedicated noise-free single-speaker **development** coverage reaches only five of the 34 development identities, through F01's five matched level triples (15 scenes). The five are `CMU_ARCTIC_aew`, `CV_0ec4d6799c8c83a9a047`, `CV_2abbf1ec09fa0aeb6d9b`, `HIFITTS_11614` and `HIFITTS_11697`. Two additional development identities have isolated scenes only in protected Upper Loeb reserve: `CMU_ARCTIC_ahw` in `S45_01_18` and `CV_3b33694cdeb42c66d688` in `S45_01_19`. The coverage CSV's `isolated_speech_scene_count` spans canonical splits and therefore yields seven identities; it must not be read as seven development-only isolated identities. All 34 separate optional references are prepared, but they use disjoint enrollment-reference clips and do not fill the missing canonical probe comparisons or establish capture/enrollment.

Across development scenes alone, every development identity appears in 5–17 conversation scenes and 5–12 distinct measured configuration/angle/distance combinations. Partner breadth is 1–4: five identities have only one partner, 16 have two, nine have three and four have four. Scene-local A/B/C label breadth is 1–3, with nine identities using only one label; these labels are scheduling slots, not social roles. All 34 appear as target/conversation speech, while 20 also appear as a background talker and 14 do not. Thus the bank provides multi-position conversation coverage for all 34, but does not meet an all-identities, multiple-partner, multiple-role or isolated-probe coverage claim. These are frozen scheduling counts, not successful recognition or independent observations.

CMU's studio design is not an anechoic certification. HiFiTTS contributes 35 clean-partition and 87 other-partition clips; its three clean-capable and seven other-only readers are different quality strata. CV contributes self-reported 60-plus real recordings. Age, gender and accent remain documented metadata; accent does not establish first language. Corpus comparisons confound recording conditions, content, speaker composition and quality, and cannot isolate age or accent effects.

The 28 unique whole clips under one second comprise four CMU and 24 HiFiTTS clips, used 40 times. All are development sources; six occurrences are Upper Loeb acoustic reserve. There is **no new-source reserve subsecond coverage**. All 34 unique one-to-under-two-second clips are CMU, used 34 times; **no CV clips are under two seconds**. Whole utterances do not establish spontaneous conversation or word alignment. Prompts/books, people, repeated clips, noise parents, RIRs and matched groups create dependencies. Preserve source-group splits and historical S4-development reuse flags; 777 instances are not independent observations.

## Family allocation and protected reserve

All families contain 20 canonical scenes. The 240 inputs total 10,967 seconds; paired outputs do not double the acoustic scene count. Fresh initialization separates independent scenes; no reset occurs between talkers within a scene.

| Family | Question represented | Development | New-source reserve | Upper Loeb reserve | Joint reserve |
| --- | --- | ---: | ---: | ---: | ---: |
| F01 | Isolated speech; source-level contrasts | 15 | 2 | 2 | 1 |
| F02 | A→B→A and three-person sequential turns | 15 | 2 | 2 | 1 |
| F03 | Complete short replies; rapid handoffs | 15 | 2 | 2 | 1 |
| F04 | Controlled two-talker overlap | 15 | 2 | 2 | 1 |
| F05 | Nearby/separated folded bearings; front/rear ambiguity | 16 | 2 | 2 | 0 |
| F06 | Silent relocation and delayed return | 15 | 2 | 2 | 1 |
| F07 | Matched flat/upright placement | 14 | 2 | 2 | 2 |
| F08 | Matched clear/obstructed placement | 14 | 6 | 0 | 0 |
| F09 | Near conversation with a distant outsider | 16 | 4 | 0 | 0 |
| F10 | Localized appliance/event noise; SNR contrasts | 15 | 2 | 2 | 1 |
| F11 | Multipoint ambience, speech and music proxies | 15 | 2 | 2 | 1 |
| F12 | Noise-only/silence and paired speech-in-noise | 15 | 2 | 2 | 1 |
| Total | | 180 | 30 | 20 | 10 |

Upper Loeb acoustic reserve intentionally reuses development speech/noise. New-source reserve changes source identities or noise parents; joint reserve changes both source partition and acoustic setting. Acoustic reserve therefore does not imply unseen speakers. Upper Loeb was previously inspected during RIR qualification, so this is a downstream acoustic holdout, not independent validation of the RIR method. Reserve checks are limited to coverage, levels, transport and integrity; reserve task performance must not tune later choices.

## Geometry and angle interpretation

The preserved library has 121 records: 120 eligible inputs and the existing clock-sensitive `JPXVF_P1_R02_T01_D01_S02_F00_NAT_CU_R13` exclusion. V2 uses 39 eligible RIRs across five room/table contexts; 81 remain unused. Acquisition evidence is PASS/REVIEW; testing/pilot/retake records remain excluded. Selected distances span 0.46–4.07 m, below the user's 5 m ceiling. Both +20° “Opening Behind Listener” low-table measurements, flat and upright, retain the user-confirmed **1.00 m / 100 cm** correction. Later software must use **`source_distance_m_effective=1.0`** for these records; original 100 m values remain forensic nested metadata.

Simultaneous sources must share room/table, receiver position, orientation and obstruction state. The bank has 230 flat and ten upright scenes, and ten obstructed scenes. Upper Loeb supplies neither an obstructed configuration nor the most distant paths; F08/F09 accordingly use source reserve elsewhere. A silent change of one participant's measured path is not simulated continuous walking or tablet rotation. No IMU, Doppler or body-shadow truth is invented.

Signed laboratory angles remain authoritative nominal labels. The retained linear-array mapping is `native_deg = degrees(acos(-sin(radians(lab_deg))))`, using the reported MIC0-left/MIC3-right orientation. For example, −90°, 0° and +90° map to 0°, 90° and 180°. Folding preserves front/rear ambiguity. Manual **±5°** describes label uncertainty; it is neither an XVF accuracy specification nor permission to relabel signs to improve agreement. Nominal and interval errors remain separate. Different measured bearings can also differ in distance and transfer response, so an apparent angular contrast is not automatically an angle-only intervention.

## Noise actually incorporated

The verified official MUSAN archive supplied 32 prepared parents; 24 occur in v2 canonical audio, comprising 17 development and seven reserve parents.

| Metadata-supported category | Prepared | Actually used |
| --- | ---: | ---: |
| Stationary appliance/cooking/electronic proxies | 4 | 3 |
| Transient events | 16 | 12 |
| Environmental ambience | 6 | 3 |
| Instrumental music | 6 | 6 |

Titles support dishwasher, frying, buzz, footstep, door, paper/metal and environmental examples. Explicit HVAC/fan, chair movement and general cutlery-clatter coverage is unavailable. Optional DEMAND restaurant/cafeteria/kitchen/hallway acquisition failed official metadata access; no alternate recording or license was invented.

Official MD5, archive SHA256 and complete gzip CRC were verified before the parent freeze and decoding. All 32 selected sources were already 16 kHz; preparation retained channel 0, numerical level and the first up to 120 seconds in mono FLOAT32. Per-parent source hashes, crops, rights and attribution are bound. The six music parents use CC BY 3.0 US or CC BY 4.0 evidence; environmental entries preserve their source-declared CC Attribution 3.0 or Public Domain assertions. These are not universal future-training/commercial clearances.

All 26 environmental parents retain unknown speech content. Instrumental eligibility rests on original `vocals=N` annotations, without per-frame phonetic or human-listening certification. Untranscribed ambience prevents ordinary all-speaker WER. Existing source reverberation compounded with a measured RIR is an environmental proxy, not a calibrated diffuse field. Eight prepared parents remain unused.

## Input revision, timing and preserved truth

Source-only v1 QC found F09_20 background energy of approximately `2.769e-12` in the declared target window, producing a 2250.98 gain and a 0.01709 family headroom factor. V2 aligns first target/background longest estimated activity-interval centers before SIR scaling. Prior inputs/code remain preserved. **Zero canonical physical captures and zero H2 jobs preceded this revision**; separate transport checks are not canonical performance evidence. V2 retains sources, splits, RIRs and DSP policy. Its F09 family headroom is 0.951620; other families use unity, with canonical peaks at most 0.25 FS.

Noise/SIR scales act once on each complete four-channel interference image, using mean target energy over the same estimated target-active windows. They are controlled numerical levels, not source SPL. Noise-only SNR references counterfactual paired speech. Long transient excerpts and repeated events retain exact parent/crop/schedule provenance and are intentionally scheduled stressors. No independent microphone normalization, additional inverse-distance law, generic reverb or canonical limiter is introduced.

Keep five timelines distinct: dry source schedule; retained RIR pre-onset convention; recaptured microphone samples; processed-output samples; host telemetry availability. The RIR's 800-sample/50-ms convention is applied once, not interpreted as physical travel time. Estimated activity fields already include it. Telemetry is causal at actual host delivery, with the frozen 250-ms age/transaction limits and unavailable fallback. A constant angle is not automatically stale; a new USB reply does not prove a new DSP observation. Do not fit angle-dependent time shifts.

Full orthographic and normalized references survive suppressed/omitted model words. Overlap, intended target and background references remain distinct; concatenating simultaneous transcripts does not establish valid ordinary WER. Original O0/O1 audio remains untouched; O0's +3 dB applies only in its H2 adapter, with O1 unity.

## Questions for later S5/S6 prompts

Compare O0/O1 on matched accepted inputs with explicit reference denominators, source-quality strata and dry-source limitations. Evaluate causal angle/energy features against audio-only diarization while preserving missingness, censored acquisition and front/rear ambiguity. Choose development-only rules before any reserve evaluation; keep matched groups together. Separate voice identity continuity, spatial continuity and optional enrolled naming. Require completion/quality receipts before reuse, retain full truth when models fail, and do not infer an output winner or authorize training/fusion from source-level validation alone.

Evidence: `COVERAGE_SUMMARY.json`, `SCENE_MANIFEST.json`, `RIGHTS_AND_SPLITS.json`, `INPUT_REVISION_RECEIPT.json`, angle/timing/level policies, and the locally indexed `NOISE_FINAL_RECEIPT.json`/`V2_RENDER_REVIEW.json`.


## Lifecycle repair and preservation

The active versioned H2 repair changes artifact export/lifecycle only: atomic summary replacement, explicit completion, failure propagation and startup terminal-state ordering. Original and intermediate bytes, exact diffs and model-free fixtures remain local and are indexed. Actual new native completion counts are reported separately from failed/quarantined/pending jobs. The four historically reconstructed S4 summaries remain historical reconstructions. Scientific configurations/model assets and the 121 canonical RIRs are preserved.

The versioned supervisor lifecycle fixtures describe model-free exception bookkeeping checks. They remain distinct from actual capture/control interruptions; execution history and current outcomes come from the bound stage, incident and acceptance receipts.

The initial s45_execute.py v1 supervisor ran from 04:34:38 UTC and closed at 09:10:34 UTC with 232 canonical captures accepted. Incident 02 was a pre-playback GPO_PIN_PWM_DUTY query timeout followed by an AEC_FIXEDBEAMSELEVATION_VALUES restoration-readback timeout; its original FAIL and blocked checkpoint are preserved. Bounded recovery with the unchanged S4 restorer verified exact exposed state at 09:12:44 UTC without setting reapplication or audio playback. The already-tested s45_execute_v2.py was launched at 09:13:33 UTC for the same bank and remaining eight canonical scenes.

Incident 03 was the first failed physical take: S45_12_16 timed out during finite capture despite retaining the full frame count and exact payload. The failed take remains ineligible; payload equality alone does not override capture failure. A restoration-readback timeout also occurred. That v2 supervisor closed at 09:23:02 UTC with 235 accepted scenes and one failed physical attempt. Exact exposed-state recovery passed at 09:23:47 UTC, reapplying only PP_AGCGAIN. The same unchanged v2 supervisor resumed at 09:24:53 UTC with five intended scenes remaining, including the one allowed identical retry of S45_12_16. Both blocked checkpoints and original failure/recovery evidence remain preserved; the latest acceptance and job receipts determine the eventual outcome.

HOST_STALL_OBSERVATIONS.json records VSS/shadow-copy and Acronis-related activity around the two observed stall windows. Their temporal association is a possible host-side explanation, not proof of causation. It does not establish that USB, the device or another component was fault-free; no backup/service/security change or scientific retuning followed from this observation.

Every resume retains the original bank, source/scientific policies, deadline and global pass/time budgets. Actual batch errors and failed physical takes are counted separately above; earlier zero-failed-take checkpoints must not be presented as the final run total.

## Limits and reuse

DER, exact phonetic word latency, enrolled-name accuracy and real moving-tablet performance are not established. Causal direction availability uses the frozen 250-ms policy and the retained RIR origin once; host delivery times are not internal DSP sample times. Multi-talker overlap and untranscribed ambient speech remain explicit limitations. This stage does not select an O0/O1 winner, tune fusion, train models or begin S5/S6.

XVF exposed-state restoration: **PASS**. Recorded hardware owner: **None**. See actual stage/failed-attempt receipts in LOCAL_ARTIFACT_INDEX.json before reusing incomplete work.
