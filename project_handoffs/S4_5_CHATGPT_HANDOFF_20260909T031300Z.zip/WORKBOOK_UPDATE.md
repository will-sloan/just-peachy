# Proposed Revision 9 workbook update

Insert only after review, using the requested light-yellow results highlighting. The Word master was not rewritten.

S4 remains COMPLETE_WITH_LIMITATIONS. S4.5: **COMPLETE_WITH_SOURCE_GAPS**.

| Measurement | Actual |
|---|---:|
| planned_canonical | 240 |
| rendered | 240 |
| accepted | 240 |
| development_accepted | 180 |
| reserve_accepted | 60 |
| failed_capture_attempts | 1 |
| recorded_hardware_batch_errors | 3 |
| canonical_analyzed | 240 |
| optional_reference_accepted | 0 |
| physical_passes | 242 |
| charged_active_playback_s | 11020.0 |
| H2_model_wall_s | 882.2679999996908 |
| model_invocation_attempt_receipts | 72 |
| observed_model_child_PIDs | 72 |
| unconfirmed_model_starts | 0 |
| run_elapsed_s | 26763.138726 |
| prepared_new_source_clips | 794 |
| prepared_noise_parents | 32 |

Use the analysis and limitations in S4_5_REPORT.md and the four plot captions, if present. Preserve the distinction between prepared, rendered, physically captured, task-scored and protected reserve. The user-selected original CMU/HiFiTTS/Common Voice scope supersedes the pack's conditional L2 target. DEMAND access and the CV reserve QC gap must remain visible. No O0/O1 winner, fusion benefit or training/generalization result is claimed.

# S4.5 workbook insertion — completed with source gaps

This is proposed text for human review and later light-yellow insertion into Revision 9. The Word master itself has not been edited. S4.5 is **COMPLETE_WITH_SOURCE_GAPS**: all 240 mandatory captures and 72 bounded neural diagnostics are complete, with the source and task limitations below retained.

## What was actually added

| Layer | Planned | Achieved |
|---|---:|---:|
| New canonical scenes | 240 | 240 accepted: 180 development, 60 protected reserve |
| Scenario families | 12 × 20 | 12 × 20 |
| Canonical audio | ≤12,600 s | 10,967 s |
| Physical passes, including diagnostic/retry | ≤320 | 242: 240 accepted canonical, one failed take, one diagnostic |
| Charged active playback | ≤16,200 s | 11,020 s |
| Optional isolated XVF references | Within remaining budget | 34 prepared, zero captured or enrolled; skipped to preserve analysis time |
| Corpus-qualified speaker/contributor IDs used | Roughly 40–55 where available | 43 actual: 18 CMU ARCTIC, 10 HiFiTTS, 15 Common Voice; cross-corpus human uniqueness unverified |
| Unique probes / scheduled utterance instances | Frozen allocation | 449 / 777 |
| Real noise parents used | Official, verified and rights-bound | 24 MUSAN parents; DEMAND official access unavailable |
| Measured paths used | Eligible PASS/REVIEW; no testing/retake | 39 eligible RIRs, 0.46–4.07 m; 81 eligible paths unused |

Original CMU ARCTIC, HiFiTTS and the selected older Common Voice cohort were used. L2 ARCTIC was excluded as requested. The 60 reserve scenes received input/capture integrity, level and coverage checks only. No reserve reference-matched direction or H2 task results were inspected.

## Physical and spatial observations

| Observation | Result and denominator |
|---|---|
| Accepted microphone transport | Zero mismatches / 694,643,004 compared four-microphone scalar samples; zero marker errors |
| Raw O0 rails | Zero / 174,302,480 decoded samples |
| Raw O1 rails | 1,024 / 174,302,480 samples; 93/240 scenes; longest run seven samples |
| Gross output saturation | Zero outputs meet the frozen quarantine threshold; residual O1 rails remain LIMITED |
| Primary development spatial support | 409 eligible turns in 117 scenes; 1,158.1373 s estimated activity support |
| Selected processed cue available | 1,076.6000 / 1,158.1373 s = 92.96% |
| Selected processed nominal-sector match | 544.1402 / 1,158.1373 s = 46.98% |
| Selected automatic nominal-sector match | 287.2309 / 1,158.1373 s = 24.80% |
| Selected processed sustained acquisition | 208/409 turns; 201 censored; acquired-only median 1.0515 s |
| Same cue on repeated-participant turns | Sustained acquisition on 81/183; these are not verified identity trials |
| Instrumental-control cue | Finite selected processed direction for 259.7050/315.0268 s across seven vocals=N controls |

Exact transport demonstrates delivery of the planned microphone signals, not successful speech recognition or identity tracking. Sector matching uses the full support denominator, including unavailable time. Manual bearing uncertainty of ±5° is measurement context, not XVF accuracy or a fitted tolerance. Front/rear ambiguity remains. The 250-ms host transaction/delivery/receipt policies do not establish internal DSP reaction time. Sustained acquisition requires a full second with ≥80% matching occupancy; 37 short envelopes cannot meet that rule.

There are no event-specific noise windows for the 39 development real-noise scenes in the inherited spatial scorer. That metric is unavailable. Finite direction on music also shows that direction alone is not a speech-presence or person-identity label.

## Speech and anonymous-label results

| Metric | O0 | O1 |
|---|---:|---:|
| Completed native output jobs | 24/24 | 24/24 |
| Ordinary nonoverlap WER, 15 common scenes | 47/480 = 9.79% | 41/480 = 8.54% |
| Substitutions / deletions / insertions | 38 / 5 / 4 | 30 / 7 / 4 |
| Common Voice WER, five scenes | 32/178 = 17.98% | 28/178 = 15.73% |
| CMU ARCTIC WER, four scenes | 6/99 = 6.06% | 5/99 = 5.05% |
| HiFiTTS mixed clean/other WER, three scenes | 7/109 = 6.42% | 6/109 = 5.50% |
| HiFiTTS other-only WER, three scenes | 2/94 = 2.13% | 2/94 = 2.13% |
| Strict-control false words | 0 over 89.390875 decoded s | 0 over 89.390875 decoded s |
| Successful embedding decisions | 650 | 728 |
| Reference-supported turns with multiple anonymous labels | 47/68 | 53/68 |
| Return groups: consistent / inconsistent / unknown | 6 / 9 / 7 | 10 / 7 / 5 |

Ordinary WER excludes five overlap-limited and two incomplete-ambient-reference scenes per output. Two empty-reference controls are evaluated by word insertions, not WER. Both outputs have the same eligible denominator. The clean HiFi branch is present in mixed-quality scenes; this subset has no standalone pure-clean scene stratum. Cross-corpus differences remain descriptive, and O1's six fewer word errors do not select a final output.

The 68 speaker-support turns and 22 return groups per output are separate from spatial support. Final transcript labels snapshot concurrent state; underlying reconciled cluster lineage is unavailable. Full DER and enrolled-name accuracy were not established. Label counts and switches are computed within fresh jobs and do not identify the same person across jobs.

All **24 dry controls completed natively**, with **10/169 word errors (5.92%)**: CMU 2/51 across 11 clips, Common Voice 2/27 across five, HiFi clean 3/54 across three, and HiFi other 3/37 across five. These show source-domain difficulty through the same ASR path. None of the 60 associated processed-output contexts has an exact single-clip reference, so no paired causal dry-versus-XVF difference is available. Accelerated offline throughput is not live word latency.

## Comparison with completed S4

| Stage | Canonical scenes | Accepted captures | H2 output jobs | O0 ordinary WER | O1 ordinary WER |
|---|---:|---:|---:|---:|---:|
| S4, preserved | 24 | 26 including repeats | 48 | 72/467 = 15.42% on 18 nonoverlap scenes | 91/467 = 19.49% on the same 18 |
| S4.5, new bank | 240 | 240 canonical | 48 | 47/480 = 9.79% on 15 nonoverlap sentinels | 41/480 = 8.54% on the same 15 |

S4 remains **COMPLETE_WITH_LIMITATIONS**. These stages use different source/scenario selections and denominators, so the numerical WER change is not a matched improvement experiment. S4 retains 44 native and four explicitly reconstructed summaries. All 48 new output summaries are native following the bounded atomic-write and lifecycle repair; no old S4 summary was relabeled or replaced, and H2 scientific configuration remains unchanged.

## Constraints that carry forward

Only five of 34 development identities have dedicated isolated development scenes; two additional identities are isolated only in protected acoustic reserve. Five development identities have one partner, and 14 never act as a background talker. The short-clip branch has 28 unique subsecond clips, but no Common Voice clips below two seconds and no new held-out-speaker subsecond coverage. HiFiTTS clean and other material remain separate; upstream ASR-assisted selection is retained as provenance. These are corpus-domain contrasts, not causal age/accent/gender experiments.

Normalized text, book/artist and byte-identity groups remain the meaningful leakage keys. Thirteen bare CMU arctic_a/bNNNN parent basenames cross roles/splits because those filenames can carry different text in different voices; they must not be treated as globally unique prompts. Exact normalized prompt groups, HiFi books and PCM hashes have no role/split crossings in the reviewed frozen allocation.

Three hardware batches recorded errors: two pre-playback control timeouts and one failed finite capture. Two exact-state recovery operations followed restoration-readback timeouts. The failed scene's single identical retry passed; its failed take remains excluded and preserved. Acronis/VSS activity and Windows I/O-wait events overlap stall windows, but the precise root cause is unresolved. The XVF was restored and its physical owner closed before neural diagnostics. No driver, firmware, backup or security settings were changed.

## Figure captions for later Word insertion

1. **Capture coverage and raw rails.** Twenty accepted canonical scenes per family; raw O0/O1 rail fractions retain silence/padding in their denominators. Reserve contributes only integrity/level information.
2. **Development spatial support.** Time-weighted usable cue and nominal-sector occupancy on eligible complete-reference nonoverlap support. Unavailable time remains in the denominator; these are host-availability observations, not calibrated physical latency.
3. **Nonoverlap ASR by source stratum.** Raw word errors/reference words, reported separately by output and source quality. Overlap and incomplete ambient references are excluded from ordinary WER. Dependent scenes and corpus selection limit comparisons.
4. **Native H2 completion and embedding evidence.** Completed bounded output/dry jobs and successful embedding decisions. Overlapping analysis windows are not independent speakers, and decision counts are not diarization accuracy.

## Retention and runtime

The active 240-scene render bank is **2.61 GiB**. Accepted native/decoded/O0/O1 WAV representations total **6.84 GiB**; the full hardware tree with all attempts and telemetry is **8.68 GiB**. These scopes overlap and must not be added as disjoint storage categories. Recorded model-child intervals total **882.268 s** across 72 jobs; they exclude coordinator/between-job time and are not live latency. Charged playback was **3 h 3 min 40 s**. The supervisor closed after **7 h 3 min 56 s**; final review/packaging elapsed time and the closing storage audit are recorded separately.

All 121 original RIR files, the Revision 9 Word master and the S4 handoff remain preserved. XVF restoration and process closure are required final checks. Scoped keep-awake release is recorded by software, but the cleanup API return was not retained. Storage-provider status is not a comprehensive SSD test.

## Next recommendation

Retain this bank as an expanded, bounded evidence base for a separately authorized S5 plan. First specify the missing noise-event scorer support and the anonymous-label versus reconciled-identity distinction; maintain the frozen reserve and rights gates. Treat optional isolated references, partner/role balance and short Common Voice coverage as explicit future work. Do not infer an O0/O1 winner, tune fusion, start training or begin S5/S6 from this workbook update alone.


Closing audit: **PASS**. All 121 RIRs, Revision 9 master and prior S4 handoff match their preserved hashes; no campaign process remains. New retained logical storage was **31.79 GiB** at the audit; C:/G: free space **86.49 / 417.47 GiB**. Both mapped SSDs report Healthy/OK. Full native review passed all 72 jobs with no reconstructed S4.5 summaries. No mandatory S4.5 execution resume is needed; optional references remain deliberately skipped.
