# Proposed V22 workbook insertion — PROTO1

**After actual execution; closeout audit dated 19 September 2026, 02:38:05 UTC.**
The existing `XVF_Measurement_V22.docx` was not edited. This Markdown is the proposed
continuing-record insertion. Automated software, soak and final release evidence
is complete. Live human and physical CM5 checks remain pending. Earlier research
results and failure records remain unchanged.

## Outcome and interpretation

PROTO1 adapts the corrected S7 scheduler/evidence/presentation into a maintainable
portrait desktop application with a separate live XVF adapter, personal UUID
references and release/update tooling. Native saved-file captions, a focused
regression panel and controlled personal-profile queries execute. This is a new
application condition; it is not another ranking sweep and does not inherit a
blanket accuracy claim from the historical research gallery.

The application has five modes: captions, enrolled names, anonymous conversation,
conversation with names and selected focus. Mode, engine recipe and O0/O1 tap are
separate. Selected focus keeps the full transcript by default; strict filtering
has an explicit warning and Show all captions rescue. Four real recipes are
available: Fast, B36-derived Classic, C065/C088 Balanced and C067/N03 Patient.
C079 spatial assistance and live person arrows remain unavailable without qualified
telemetry/calibration; no unsupported enhanced-ASR alias is offered.

## Measured desktop results

- Six existing source-paced scenes passed the panel's completion checks. Delivered
  frames matched the source; recorded drops were zero; writers drained and no live
  lanes remained. A 15.53-second injected writer stall reached queue depth 597 and
  completed all 3,246 accepted events. Preserve `source_unchanged=false`: the panel
  overlapped integration changes and is not a frozen accuracy benchmark.
- The separately retained C105 native replay preserved all 41 raw words and unique
  tokens, with returning owners 2 → 8 → 2. Lexical WER and anonymous cpWER were
  both 1/41 (2.44%), one substitution and no insertions/deletions. This is actual
  final controller partition evidence, not a new Tk widget acknowledgment or a
  live-direction result. Original S7 failure/correction receipts are unchanged.
- Eleven native personal-fixture checks passed: extraction/save, independent
  restart, duplicate-name/distinct-UUID behavior, rename, disjoint add-reference,
  duplicate-source rejection, actual gallery queries, fresh same-person naming,
  wrong-person Unknown and deletion invalidation. The references had 36.0 and
  20.5 usable seconds; the two held-out queries made 66 and 54 gallery calls.
  These are disjoint dry CMU fixtures, explicitly incompatible with live XVF
  enrollment. They do not establish the user's room-specific naming accuracy.
- The actual Tk client measured 480×800 physical pixels at 96 DPI, per-monitor
  awareness 2. The 47.73-second native UI run displayed three final rows and real
  revisions, reached Mode/People/Settings, and closed its worker. Six casing,
  eight Tk and eleven controller-view fixture tests passed. Application 125%
  comfort zoom measured 600×1000; Windows 100/125/150% display scaling was not swept.
- The final post-change software suite passed all 96 checks in 7.672 seconds,
  with zero failures, errors or skips and unchanged source. This includes eight
  file-tap, ten enrollment-cleanup and one live-stop ownership check. Initial
  aggregate-run import/old-fixture failures remain preserved separately; final
  fixture/harness corrections do not erase that earlier evidence.
- Release 0.1.0 passed relocated path-with-spaces native file inference, actual
  PS/CMD launcher startup/close, healthcheck and synthetic rollback. Its 109-file
  archive was 406,514 bytes. These checks remain attached to 0.1.0 bytes.

## Live, resources and deployment limits

The live input-only path is implemented, with exclusive device ownership, stable
endpoint selection, checked routing/restoration, streaming conversion and once-only
O0 gain. It does not open a render stream or change default Windows output settings.
Read-only inspection detected one XVF, firmware 3.2.1 / `ua-io48-lin` and USB16/16;
DSP reads were limited while the audio loop was inactive. Twenty adapter/bridge
contract tests used fake streams/control. **No physical microphone stream, live
recognition, unplug/replug test or user enrollment was performed.** The user was
unavailable for the spoken check and no live consent was invented. The completed
soak retained 64 observations of all three output roles, unchanged within that run.
Earlier adapter observations used SONY TV; the native UI/soak later used Speakers
for console/multimedia and Hifi headphones for communications. The different
configurations across runs are acknowledged without assigning a cause.

The frozen release-candidate GUI soak **passed**: 1,849.647622 seconds wall time,
1,842.8175 source seconds, 21 epochs and 20 switches. All 29,485,080 source samples
were delivered, 111 final caption rows were retained, no run errors were reported
and bound source was unchanged. Every epoch passed finalization, closed-handle,
no-live-lane, consumer/queue drain and no-capture-loss checks. All 93,823 journal,
111 punctuation and 29,248 policy items completed; maximum depths were 12/1/4.

Thirty-one approximately minute-spaced Windows samples recorded peak RSS
546.414 MiB, last RSS 538.730 MiB, peak 35 threads and peak sampled ASR lag
0.04 seconds. One ASR and one speaker load served the 21 streams. The separate
largest consumer event-queue age was 2.0448 seconds. These are sampled desktop
resources and queue measurements, not instantaneous peaks, word latency, a
leak-rate estimate or CM5 capacity/thermal qualification; some early checks overlapped.

Personal people/settings remain outside replaceable source; profile ZIPs are
explicitly unencrypted. Enrollment uses unique usable-speech goals of 15/30/60
seconds, a 180-second cap and quality-gated Save. O0/O1 require compatible references.
Session retention is bounded; pinned issue records and personal/historical data
are preserved. Audio problem excerpts require a separate explicit consent action.

Windows and x86 WSL release-tool checks passed. Thirteen ARM64/pure-Python wheels
are prepared for the declared Bookworm/CPython 3.11 target, but no ARM64 inference
or CM5 deployment occurred. Supplied XMOS Raspberry Pi binaries are ARM32; matched
AArch64 host/control-map build and live verification remain pending. Exact display
controller/interface/touch mapping, camera connection/driver, BMI270 bus/address/
pins/axes and optional GPIO mappings remain unset. No image, firmware or network
service was changed on a Pi.

## Final release and remaining human/hardware work

**Final 0.1.2 release: PASS**, 410,505 bytes / 110 payload files, at
`G:\Just_Peachy_PROTO1\releases\just-peachy-proto1-0.1.2.zip`.
SHA-256: `a06d167de796277138c2957c35bcdc47b9e5829e161f967949534b868649ec91`.
Runtime 0.1.1 passed relocated native C105 replay (48.0 seconds, three caption
rows, one ASR/zero speaker loads), PS/CMD launch/close, 49 installed-source
contracts, eight shared model hashes and synthetic-data-preserving rollback.
Version 0.1.2 changes one checklist sentence about user availability only;
all 74 execution/config/launcher files remain byte-identical. Its stage,
activation and integrity/schema healthcheck passed without redundant inference.
Enrollment-cleanup and lease-retention fixes are included in the passed 96-check
worktree suite. These later bytes did not run the earlier frozen 0.1.0 soak.
The implemented file-domain guard rejects changing tap during
a running prepared-file replay, which otherwise relabels metadata without changing
audio bytes. Known O0/O1 (including continuous) filename/tap mismatches fail before
allocation; general filenames use an explicit prepared-domain declaration. Eight
focused tap tests passed. Actual live tap changes retain stop/drain/restart behavior.

The 10–15-minute live captions/reference Save/restart/fresh query and consenting-
visitor/Unknown opportunity remains human-pending. Use `docs/LIVE_USER_CHECKLIST.md`.
CM5 and the listed physical interfaces remain hardware-pending. The compact
handback selects two native and four labeled stub screenshots and excludes private
voice material, models and a duplicate workbook; its final packaging record is
separate from these scientific/runtime results.

The final binding audit matched all 110 payloads to repository source, confirmed
all 52 historical S7 files and V22 unchanged, and found no people or app lock in
the real default personal store. Free space was C: 140.88 GiB / G: 137.98 GiB.
The compact handoff is
`<simulation>\handoffs\PROTO1_CHATGPT_HANDOFF_20260919T012911Z.zip`; its external
receipt records size and hash. No training, RIR regeneration, full campaign,
hardware flashing, SSH deployment or automatic Git commit/push occurred.

Completed soak SHA-256:
`7a69149e71cf9f4af42af317a0248444dbb6adb372ecd77813eab3f9716b8023`.
Closeout audit SHA-256:
`f0562ead2a47ecff2d4832827fc5ea7659a53f12570123c24edaac6b0beb3c2c`.
Final software checks SHA-256:
`d6381c783a944826438518cca0b5c37777b483cc8f8dfecb3dfe332550fec56b`.

Launch from the repository directory with `prototype\Start-Prototype.cmd`
(CMD/Anaconda Prompt) or `& .\prototype\Start-Prototype.ps1` (PowerShell). The app
opens idle; consent occurs in the UI. Ordinary PC audio peripherals can remain
connected. The detailed evidence analysis and exact principal bindings are in
`PROTO1_IMPLEMENTATION_RESULTS.md`; user-facing operation is in
`START_PROTOTYPE.md`, `MODE_GUIDE.md`, `docs/ENROLLMENT_GUIDE.md` and
`docs/PI_DEPLOYMENT_WORKFLOW.md`.
