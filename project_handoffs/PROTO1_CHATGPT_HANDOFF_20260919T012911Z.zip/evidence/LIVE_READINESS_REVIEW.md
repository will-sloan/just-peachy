# PROTO1 bounded live-readiness review

Reviewed 2026-09-18 22:22 Toronto (2026-09-19 02:22 UTC). **Code review only; live status remains `LIVE_READY_AWAITING_USER`.** No microphone stream, USB setter, inference run, or application/vendor/config edit was performed for this review. Existing evidence below is identified separately from this review.

**Closeout:** the cleanup findings were subsequently fixed after the frozen
GUI soak ended. See the source-bound resolution addendum at the end. Actual
hardware/user limitations remain unchanged.

## Conclusion and concrete findings

No unconditional normal-start blocker was found in the controller-to-adapter call path. The installed native environment has sounddevice **0.5.5**; read-only Python signature inspection confirms `WasapiSettings(exclusive=True, auto_convert=False)` and the requested `InputStream` arguments exist. This establishes API compatibility, not physical driver success.

Two cleanup findings remain in this reviewed source epoch:

1. **P2 — Enrollment discard can hide an unsuccessful restore/close.** `app/controller.py:318` waits for enrollment workers, calls `self._enroll_live.stop()`, then replaces enrollment state with IDLE and reports cancellation. The adapter normally returns failures inside its receipt rather than raising (`app/live_audio.py:511`), and this branch does not call `summarize_live_integrity`. Consequently a USB/control/stream-close fault can disappear from the visible enrollment result after Discard or application close. The ordinary Stop/save-admission branch does check integrity. Preserve and surface the stop receipt/integrity during cancellation; if a stream remains active, retain its owner and refuse a successful closed state. This is a conditional fault-path finding, not evidence that hardware has failed.

2. **P2 — Discard/save does not release all temporary enrollment memory.** `app/controller.py:313` and `:318` clear `_enroll_audio` and `_enroll_vector`, but retain `_enroll_live` and `_quality`. The stopped source still owns its preallocated raw stereo ring (`app/live_audio.py:398`), containing up to the configured 10 seconds of captured samples; quality still owns per-segment embeddings. The ring is bounded (~3.84 MB at the default 48 kHz stereo float32 setting), and no ambient WAV is written by this code, but the visible “temporary audio discarded” statement is stronger than the cleanup implemented. After confirmed stream/worker shutdown, release source/quality/queue references or explicitly clear their sample/vector arrays while retaining metadata-only receipts. Do not clear arrays concurrently with capture or quality processing.

Also observed in the same fault path: `XVFLiveSource._stop_owned` releases the device lease and marks completion even if both PortAudio stop/close fail. The caption controller separately checks for an active stream; enrollment cancellation lacks that additional check. A close failure should not allow another application instance to acquire a hardware lease while an old stream remains active. This is part of finding 1, not an observed hardware event.

These findings were sent to the parent agent immediately. No fixes were applied during the frozen GUI soak. Any later fixes need their own source binding and focused mocked cleanup checks; this document does not certify a later revision.

## Reviewed integration behavior

| Area | Code evidence and conclusion |
|---|---|
| Consent | `ui.py:449` / `:661`, `controller.py:84` / `:227`, `live_audio.py:376`: normal Start and enrollment each require explicit UI consent; public controller methods reject a false consent argument. App initialization enumerates output defaults without opening capture. Previously granted normal-session consent is retained within the app instance; new enrollment forms reset enrollment consent. |
| Device binding | `live_audio.py:232`: resolve a unique XVF capture endpoint at each launch, require Windows endpoint ID/name agreement, reject multiple boards because the vendor tool cannot address a selected serial number, and never use a PC default-microphone fallback. Desktop config contains a stable endpoint ID/name and WASAPI, not a PortAudio integer index. |
| Ownership | `controller.py:22`, `:153`, `:230`; `live_audio.py:90`, `:376`: exclusive application data owner, existing project hardware lease, serialized controller actions, stopped caption session before enrollment, and one live source. Route operations use timeout-bounded serialized host-tool calls. |
| Route and gain | `live_audio.py:268`: validate 3.2.1 / UA io48 / four microphones, supported topology and unchanged USB bit depth; require device ASR gain 1; ordinary microphone input; O0 left auto-ASR and O1 right processed route. Apply O0 host +3 dB exactly once after conversion; O1 unity. Controller enrollment/query compatibility keys agree on tap, gain policy, preprocessing and waveform domain. Current physical DSP readbacks remain unknown until consented input clock exists. |
| Priming | `live_audio.py:405`: input-only stream first supplies the clock needed by firmware control; pre-verification frames are discarded. Route readback and bounded driver-buffer settling precede sample admission. There is no render stream or default-output setter. |
| Clocks/pacing | `pipeline.py:133` anchors source epoch to the first callback and its USB sample count, not late reader delivery; clamps origin out of the future. `live_audio.py:321` preserves FIR state across blocks, 48→16 kHz conversion, 1 ms declared FIR delay, sample offsets and measured queue lag. These are host/callback clocks, explicitly not calibrated acoustic-arrival timestamps. No sleeps pace accepted live samples. |
| Callback/memory | `live_audio.py:438`: preallocated bounded stereo ring; callback copies samples and records counters/timestamps. No USB, filesystem, model or GUI work runs there. Filtering/allocation happen on the reader. Model journal is separately bounded. Enrollment capture drains independently of inference: unique 10-second chunks, quality queue size 20, maximum 180 seconds captured. |
| Quality and identity | `enrollment_quality.py:14`, `controller.py:250`: each unique block is processed once; accepted nonoverlapping half-second intervals drive usable duration. Silence/overlap/clipping/consistency checks and fixed save thresholds gate storage; no paragraph text is fed into ASR or identity decisions. No claim of perfect single-speaker purity. Personal gallery admission verifies the stored domain instead of silently converting profiles. |
| Gaps and normal Stop | Callback status/overflow, inactive stream and 2-second callback stalls are explicit faults. Normal caption Stop and enrollment Stop check integrity and do not admit a faulty enrollment as successful. Restoration only reverses owned changed controls, does not overwrite a later external change, and runs while the input clock is active. No automatic reconnect/fallback captures speech. Cancellation limitations are listed above. |
| Stable storage | `paths.py:11`: defaults are `Path.home()/JustPeachy/data` and `../shared/models`, with explicit overrides. Desktop `C:\Users\amiri\JustPeachy\data\live_config.json` exists and references the existing matching XMOS executable and `measurement_app/hardware.lock`. Earlier handle-level verification established this location is outside the packaged AppData redirection. |

## Existing evidence, not new live proof

- `evidence/live_adapter/LIVE_ADAPTER_RESULT.json`: 20 mocked adapter/bridge contract tests passed, including consent gating, lease contention, stereo/gain/resampling, callback faults, restoration and bridge clocks. Fake streams/control are explicitly labelled. Actual device observation opened zero streams and used zero setters.
- `evidence/live_adapter/readonly_device_inventory.json`: version 3.2.1, build `ua-io48-lin`, USB bit depth 16/16 and one Windows XVF capture endpoint were observed. DSP reads require an active audio loop and were not physically validated in ordinary microphone mode. The metadata-only default-output observations found no role change; causation is not inferred.
- `tests/evidence/native_people_summary.json`: actual file-based native reference/query persistence and fixed-policy identity checks passed with disjoint consent-safe dry CMU_ARCTIC files. This supports personal-store/native-gallery integration, not a physical microphone or real user enrollment claim.
- `tests/evidence/C105_REGRESSION.json`: final-source native file replay retained exact token partitions and matched pinned S7 lexical/anonymous attribution scores. This does not validate the hardware source.

## Remaining actual hardware/user unknowns

The first opted-in run must still establish that input-only WASAPI exclusive capture provides the firmware's required clock on this desktop, all current DSP route/topology/gain reads succeed, stream format/channel interpretation is correct in practice, useful spoken signal reaches recognition, and normal Stop restores the owned controls without changing playback roles. Actual unplug/replug recovery, a user's saved live reference followed by different fresh speech, and the 10–15-minute human live opportunity remain **NOT_TESTED**. The saved Windows endpoint ID may require explicit re-selection if Windows changes it after reconnection; refusal is intentional, not a default-device fallback. Linux/CM5 capture and performance remain unexecuted.

The short user procedure is already in `docs/LIVE_AUDIO.md`; desktop launch instructions are in the main README. No further unattended capture is appropriate for resolving these unknowns.

## Reviewed source SHA-256

These hashes bind this review, not a blanket pass for future edits:

| File | SHA-256 |
|---|---|
| app/live_audio.py | `016245c20633879c3ed721613e7d0acaa98fe0740b0d630950dba807e7981259` |
| app/windows_audio.py | `f90e3768be13605744e0149be7099b0e77e2efc1267cedc5fd8629572e26c315` |
| app/controller.py | `a7fd1d768b24d8e47e82ef5ec95dc350e65ff4b9e32f5fc002965562169108eb` |
| app/pipeline.py | `45ac3886d830d31bed5c79f6dde95f14da37b06a1658281560b8384926e8dbfa` |
| app/ui.py | `fb9eafda0288548ac038f196ec544bb07af4d821b11eb0982185c5e87e11d352` |
| app/enrollment_quality.py | `5576e1f06dad78873dd16fdefde9fd9c421a851b4e892eb39c219f539360aa0fee3` |
| app/people.py | `bd9df4930c69c07177853863c9acf5cbd1335b2a368d7dfbfeb896558843e1af` |
| app/paths.py | `5a76a7cfe1d6ef3bb501a1ccaf298808e7ed64e7af5f0d3a9f3e06c47ac3cbf1` |

## Resolution addendum — 2026-09-18 22:41 Toronto

After the parent explicitly released the frozen soak source epoch, findings
1 and 2 were corrected with confined lifecycle changes:

- Enrollment cancellation checks and retains metadata-only stop integrity;
  restoration failure becomes visible ERROR, with saving disabled. It does
  not discard an active source/quality owner or admit a replacement session.
- Save/Discard release the stopped capture source/ring, quality accumulator,
  queue and temporary vectors. A failed personal-store commit retains the
  reference for retry. No store schema, identity threshold or inference policy
  changed.
- A quality-constructor/thread-start failure after microphone startup invokes
  cleanup, wakes a waiting quality worker and waits for ownership to finish;
  inability to finish remains explicit instead of overwriting the owner.
- The adapter checks whether the stream is still active after stop/close. If
  so it keeps the existing hardware lease, leaves completion unset, raises a
  visible error and allows a later cleanup retry. The interrupted source keeps
  its fault even when the retry succeeds.

`tests/evidence/enrollment_cleanup_summary.json` records the focused results:
10 controller cleanup/startup tests, 21 adapter/bridge/lease tests and 8 existing
lifecycle tests **PASS (39 total)**. The new tests reproduced eight failing
expectations before the fix. Inputs were fake streams/control/worker/store
objects and synthetic arrays; existing adapter checks include only read-only
Core Audio observation and temporary local lease locking. **No real microphone
capture, USB setters, neural rerun or new human proof occurred.** Run commands,
inputs and outputs are in `tests/README.md`; adapter behavior is updated in
`docs/LIVE_AUDIO.md`.

| Final changed source/test | SHA-256 |
|---|---|
| app/controller.py | `9085149b8d517b76153e05ad2cfe8faa8ad499cbfbd3321b4939b71f8b69ebf0` |
| app/live_audio.py | `c4e89e359f5d33a4ba94cd4b38acdebef3c8473a45ca0bdb064a0ea0b0027cf5` |
| tests/test_enrollment_cleanup.py | `e64c54a35e2a3e92bf2857e8418afede4527fbfef4ca7f53514a1e5085f1905f` |
| tests/test_live_stop_ownership.py | `02af05fe985aa92012f6cc8846cfc618394c8593a64f1624621cede934db7f1d` |

The final controller hash also includes the parent's independently verified
prepared-file tap guard. The earlier 30-minute soak and C105 native replay
remain evidence for their recorded source epochs; these post-soak lifecycle
changes are supported by the targeted software regressions above, not by a
claim that the full soak/hardware proof was repeated.
