# Read-only Windows output observations — corrected comparison

All three render roles were unchanged **within each bounded observation set**.
The recorded defaults differ between the earlier adapter inventory and later
native application runs. No cause is assigned to that cross-run change or to the
user's earlier report of unexpected device switching.

| Evidence | Observed roles | Supported conclusion |
|---|---|---|
| `audio_inventory.json`, `readonly_device_inventory.json`, `defaults_after_adapter_tests.json` | All three roles: SONY TV *30 (NVIDIA High Definition Audio) | Exact IDs agree at the recorded inventory/test endpoints, about 01:39–01:49 UTC on 19 September. |
| `G:\Just_Peachy_PROTO1\tests\ui_native_v1\NATIVE_UI_RESULT.json` | Console/multimedia: Speakers (High Definition Audio Device); communications: Headphones (2- Hifi Audio) | Five native-file UI observations agree from application open through mode/start/stop/exit, about 01:58–01:59 UTC. |
| `prototype/evidence/CLOSEOUT_AUDIT.json` and completed `SOAK_RESULT.json` | Same Speakers/Hifi role configuration as the short native UI check | All three roles were present and unchanged in 64 retained observations during the completed 30-minute GUI soak. The bounded list is not every observation ever taken. |

The exact SONY endpoint was
`{0.0.0.00000000}.{21e55d79-2a39-4586-8d38-04a9a712735e}`.
The later console/multimedia endpoint was
`{0.0.0.00000000}.{ed90777b-63ce-4074-b260-abc4e13885e7}`;
the communications endpoint was
`{0.0.0.00000000}.{963100db-21f5-4294-96df-f0fa853f165f}`.
These are observations, not instructions to change the user's defaults.

## Correction to the early summary

The historical `LIVE_ADAPTER_RESULT.json` has `default_output_observation.roles`
equal to `{}`. Its `UNCHANGED` label alone is incomplete comparison evidence and
must not be treated as proof that the three role IDs were populated and compared.
That original JSON is preserved unchanged. The corrected conclusions above come
from the actual `windows_audio.default_render` objects in the inventory files,
the top-level `default_render` in the post-test snapshot, the five native UI
observations and the explicit 64-observation closeout audit. They do not claim the
SONY endpoint remained selected for the whole task.

The new adapter has no render stream, default-output setter, system-volume setter
or communications-role setter. Core Audio inspection is read-only. The adapter
contracts used fake streams/control; physical inventory opened zero microphone
streams and issued zero device setters. The native file UI and soak also used no
physical microphone. This evidence therefore does not determine whether a future
consented live start, USB arrival, user selection or unrelated software changes
Windows preferences.

A prior scoped source search of the prototype, current measurement application,
simulation scripts and Evaluation Tool found no `SetDefaultEndpoint`,
`SetDefaultAudio`, `PolicyConfig`, `nircmd`, `SoundVolumeView`, `SetMasterVolume`,
`SetMute` or `ducking` hits. This was not a forensic inspection of unrelated Windows
applications. Historical measurement software intentionally used duplex/packed
playback for research; the prototype live adapter does not reuse those render paths.

The prior scoped process snapshot left the H2 storage guardian and storage
maintainers untouched. Its lack of a capture owner did not reserve the device;
every real live start must still acquire the project lease. No peripheral needs
to be disconnected just to use the ordinary live input path.

For the pending human check, record exact role IDs before/after consented Start,
mode changes, Stop and exit. Preserve any difference as an observation with cause
undetermined unless a reproducible application write is identified. Do not change
registry policy, services, device enablement or the user's selected outputs to make
the comparison pass.

Closeout audit SHA-256:
`f0562ead2a47ecff2d4832827fc5ea7659a53f12570123c24edaac6b0beb3c2c`.
Completed soak SHA-256:
`7a69149e71cf9f4af42af317a0248444dbb6adb372ecd77813eab3f9716b8023`.
