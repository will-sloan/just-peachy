# PROTO1 implementation results

**Automated implementation and release checks completed 19 September 2026 UTC
(18 September Toronto evening).** The frozen release-candidate GUI soak passed,
the final runtime passed relocated execution and 49 relocated contracts, and
documentation release 0.1.2 passed staging/activation/integrity checks. The full
110-file release matches the repository. Live human and CM5 checks remain pending;
each executed check below stays attached to its actual source revision.

The application now connects a 480×800 portrait Tk frontend to the retained native
ASR, speaker and final punctuation paths. A small native panel, the C105 regression
and a separate personal-profile fixture demonstrate executable file-based flows.
They do **not** verify speech from the attached microphone or the user's own
enrollment. The live path is implemented and the XVF is detected, but no physical
audio stream or device-setting transaction was performed: the user was unavailable
for the spoken check and had not given in-app microphone/enrollment consent.
CM5 execution is also pending.

## What the evidence establishes

The strongest measured result is a functioning source-paced desktop application
with correctly retained words and explicit identity revisions. The C105 replay
preserves the returning first speaker, rather than giving the whole utterance to
the last speaker. Native personal-profile extraction, restart and held-out queries
also execute, but on a deliberately separate dry test-fixture domain. This supports
proceeding to the short live user check; it does not support an identity-accuracy
guarantee or a claim that the 2 GB CM5 is already qualified.

| Area | Recorded status | Supported conclusion and boundary |
|---|---|---|
| Native six-scene integration panel | PASS with source-history limitation | Six selected file cases completed with exact delivered frame counts, no recorded dropped frames, drained writers and no live lanes at finalization. `source_unchanged=false` is retained; this is not a frozen cross-recipe benchmark. |
| C105 late-evidence regression | PASS, diagnostic scope | Full 41-word/token partition; lexical error and anonymous cpWER both 1/41 (2.44%); return owners 2 → 8 → 2. This is actual final controller projection, not a new Tk widget acknowledgment. |
| Personal enrollment/query fixture | PASS, 11 checks | Native extraction, UUID persistence/restart, disjoint new reference/query, rename/add/delete and Unknown behavior work on dry CMU fixtures. Physical/live enrollment remains untested. |
| Portrait UI | PASS at observed desktop DPI | Actual 480×800 physical client, 96 DPI, per-monitor awareness 2; readable partial/final native file captions, touch controls, menus and close-wait behavior. |
| Final software contracts | PASS, 96 checks | Zero failures/errors/skips in 7.672 seconds with unchanged source. Includes casing, Tk, controller views, buffers, people, lifecycle, tap-domain guards and enrollment/lease cleanup. Fake/synthetic inputs are explicitly labeled; these are not live speech checks. |
| Live adapter | IMPLEMENTED / LIVE_READY_AWAITING_USER | One XVF endpoint detected, firmware 3.2.1 / `ua-io48-lin`, USB16/16. Twenty adapter/bridge contracts passed with fake streams/control. Physical signal, single-gain verification and unplug/replug remain NOT_TESTED. |
| 30-minute mixed-mode GUI soak | PASS on frozen release-candidate bytes | 1,849.6476 seconds wall time, 1,842.8175 source seconds, 21 epochs and 20 switches; all 29,485,080 samples delivered. Every epoch passed finalization, queue/consumer drain and closed-handle checks. Source unchanged throughout. |
| Final relocated Windows runtime / release | PASS with explicit version bindings | 0.1.1 ran a native C105 file, both launchers and 49 focused contracts; update/rollback preserved synthetic private data. Final 0.1.2 changes one checklist sentence only, with all 74 execution/config/launcher files byte-identical and staging/activation/healthcheck passed. |
| Linux / ARM64 / CM5 | LIMITED / ARTIFACT_PREPARED / NOT_TESTED | Windows and x86 WSL release-tool tests passed; ARM64 wheels are prepared. No Pi contact, native ARM64 inference or physical CM5 deployment occurred. |

## Native file results and their limits

The compact panel uses six existing scenes, not a new corpus or all-profile sweep.
Each row below is an actual source-paced native run. “Rows” is the number of final
controller caption rows, not a word-accuracy score.

| Existing scene | Tap | Recipe / mode | Source seconds | Final rows | Result |
|---|---|---|---:|---:|---|
| S45_08_07 | O0 | Balanced / anonymous | 44.6954 | 3 | PASS |
| S45_03_03 | O0 | Classic / anonymous | 44.6954 | 1 | PASS |
| S45_02_10 | O0 | Patient / enrolled names | 44.6954 | 4 | PASS |
| S45_11_03 | O1 | Balanced / conversation + names | 44.6954 | 3 | PASS |
| S45_06_06 | O0 | Fast / captions | 99.6954 | 3 | PASS; 15.53-second writer stall injected |
| S45_12_20 | O0 | Balanced / selected focus | 44.6954 | 1 | PASS |

All six reported zero final ASR lag, zero dropped audio frames and no remaining
live inference lanes. The stalled writer accepted and completed 3,246 events,
with maximum queue depth 597 and no writer error. This tests a bounded stall; it
does not promise lossless operation through unlimited stalls. Panel naming modes
with an empty personal store prove execution, not successful personal recognition.
The final panel cache contained one ASR load and one speaker load over six streams;
caption-only can stop optional speaker calls while previously loaded weights stay
resident. A separate fresh relocated caption-only process recorded zero speaker
loads, one ASR load and three final rows.

The panel's source-history flag is false because integration work changed source
while the panel was being prepared/executed. Preserve that flag and each receipt's
bindings. Do not relabel the panel as a frozen final-release benchmark. Its rolling
journals also no longer retain the complete early C105 partitions, so C105 was
checked with a separate final-source replay that preserved complete controller rows.

That C105 result has 41 reference and 41 hypothesis words, one substitution, no
deletions or insertions, and full unique-token coverage. Anonymous attribution is
1/41 cpWER using meeteval 0.4.3 and the retained supported segments; first/third
utterances return to Speaker_2 with Speaker_8 between. The source-time evidence is
historical-only and does not authorize a current live direction arrow. The replay
ran alongside the separate soak, so its timing is not an isolated performance
benchmark. Historical S7 failure/correction receipts remain unchanged.

The personal fixture is separate from both the panel and the user's private store.
It uses disjoint existing CMU ARCTIC reference/query files with
`waveform_domain=dry_test_fixture` and `gain_policy=fixture_unity`. The first
reference yielded 36.0 usable seconds from 36.4899 seconds; a disjoint additional
reference yielded 20.5 from 20.6799 seconds. Native same-person query confirmed the
saved UUID (66 actual gallery score calls); a wrong-person query confirmed no UUID
(54 calls). All 11 specified checks passed, including a new-process restart,
duplicate display names with distinct UUIDs, rename persistence, duplicate source
rejection, add-reference and deletion invalidating the new gallery. One ASR and
one speaker model load served the two query streams. This small controlled result
is not a population accuracy estimate or live-room recognition proof.

## Implemented application behavior

The five user modes, engine recipe and audio tap are separate. Captions are
neutral and disable optional speaker inference; Enrolled names shows names or
Unknown; Anonymous avoids gallery naming; Conversation + names combines cautious
personal naming with continuity; Selected focus emphasizes a roster while retaining
all words. Strict selected-only visibility requires a warning and has one-touch
Show all captions rescue. Identity matching remains experimental.

Fast uses the accepted greedy caption path; Classic invokes actual B36 tracker
semantics within the corrected scheduler; Balanced uses C065 and C088 where
naming is requested; Patient uses C067/N03 with the short-evidence path. The real
C079 parent is retained but spatial assistance is unavailable because live
alignment/calibration is unqualified. No B28 alias, invented beam result or
ground-truth direction is offered. Models and parents remain bound by
`config/assets.json`, the profile JSONs and `evidence/RECIPE_PARENT_BINDINGS.json`.
This is a new application adaptation, not byte-for-byte equivalence to old runs.

The GUI provides persistent Start/Stop, Mode, People, Settings and full-caption
rescue; touch name entry; scrollable dialogs; stable row updates and Back to live.
Provisional casing leaves raw ASR unchanged and reconciles the whole current
utterance. Final learned punctuation remains authoritative when valid for the
displayed revision. People use UUIDs, explicit consent and private external
storage. Enrollment goals are 15/30/60 unique usable seconds, with Stop/quality/Save
and a 180-second recording limit. O0/O1 references must be compatible with their
query route; a separate accepted reference per used tap is needed.

The live implementation owns an input-only XVF stream and the existing device
lease. It verifies normal live routing, disables substitute packed input/output,
uses explicit 48 kHz stereo → 16 kHz mono conversion and applies O0 +3 dB once
after checking device gain (O1 unity). It contains no default-output setter,
render stream, PC-microphone fallback or implicit reconnect. **These are implemented
contracts; their actual physical transaction is still pending consent.** Idle DSP
reads were limited by the inactive audio loop, so topology/gain/routing must be
verified during the consented input-only start rather than inferred from the build
name. All three default output roles were unchanged in 64 retained soak
observations. Earlier adapter observations used the SONY TV endpoint, whereas the
native UI and soak used Speakers for console/multimedia and Hifi headphones for
communications. These are distinct recorded configurations across runs; no cause
of that change or the user's previously reported switching is established.

RAM history is selectable at 60/120 seconds. Session retention offers 3/10/20
completed sessions and 64/128/256 MiB targets, with a 2 GiB free-space floor.
Personal profiles, pinned problems and historical research are excluded from
automatic rolling cleanup. Mark a problem saves metadata by default; a recent
30-second audio copy requires a separate explicit choice and an available RAM
buffer. No microphone opens on application launch.

## Desktop pixels, completed soak and release boundaries

The short native UI run passed in 47.73 seconds with three final rows, 91 observed
revisions across six transient segment IDs, one ASR/speaker load, reachable menus
and a closed controller worker. The client was measured using native Windows APIs,
not inferred by cropping a picture. Application comfort zoom at 125% measured
600×1000; this is not a test of Windows display scaling. A 100/125/150% system-scale
sweep was **not performed**, global scaling was not changed, and other OS/panel
scaling remains pending. Exactly two native and four clearly labeled stub images
are selected by `docs/SCREENSHOT_MANIFEST.json`.

The source-paced GUI soak passed after 1,849.647622 wall seconds (30.83 minutes)
and 1,842.8175 source seconds. All 29,485,080 input samples were delivered across
21 epochs and 20 controlled mode/recipe switches, with 111 final caption rows,
zero reported run errors and unchanged bound source. The closeout audit checked
all 21 epoch receipts: finalized, no remaining live lanes, closed handles, no
finalization error, consumer drained, all queues drained and no capture loss.

The 31 roughly minute-spaced process samples recorded first RSS 111.01 MiB,
sampled peak 546.414 MiB and last RSS 538.730 MiB; sampled peak thread count was 35.
Sampled ASR lag peaked at 0.04 seconds. One ASR load and one speaker load served
21 streams. These are sampled Windows resource measurements, not instantaneous
peaks or caption word-latency measurements. Some early checks ran concurrently;
the run is not an isolated performance benchmark, a leak-rate estimate or CM5
capacity/thermal qualification.

Across the closeout's epoch queues, all 93,823 journal items, 111 punctuation items
and 29,248 policy items completed. Maximum depths were 12, 1 and 4 respectively;
largest recorded ages were 0.1376, 0.0195 and 0.1377 seconds. The separate consumer
event-queue maximum age was 2.0448 seconds in the first epoch. It must not be
conflated with the 0.04-second sampled ASR lag or called end-to-end word latency.
All three Windows render roles were present and unchanged in the 64 retained soak
observations; the audit records exact first/last endpoint IDs and no causal claim.

**Final release 0.1.2: PASS.** Archive:
`G:\Just_Peachy_PROTO1\releases\just-peachy-proto1-0.1.2.zip`, 410,505 bytes,
110 payload files; SHA-256
`a06d167de796277138c2957c35bcdc47b9e5829e161f967949534b868649ec91`.
The final runtime was exercised in relocated 0.1.1: C105 completed in 48.0 seconds
with three caption rows, one ASR load and zero speaker loads; both actual launchers
opened/closed; 49 focused contracts passed against imported installed paths;
eight model hashes and synthetic-data-preserving update/rollback passed.
Version 0.1.2 only corrects the live checklist wording about user availability.
All 74 execution/config/launcher files and 109 of 110 payload files are unchanged
from 0.1.1. It passed fresh staging, activation and integrity/schema health checks;
no redundant inference was run for a documentation change. Original runtime
receipts are retained in `FINAL_RUNTIME_RESULTS.json` and bound by the final receipt.
The 30-minute soak remains a 0.1.0 source result, followed by the focused final
runtime checks; it is not relabeled as a run on later bytes.

The identified 0.1.1 guard addresses a concrete prepared-file domain issue: changing
the tap during an already-running replay can change gain/gallery metadata without
loading bytes from the other tap. The implemented narrow fix rejects running-file tap
changes and rejects known `O0.wav`/`O1.wav` or `O0_continuous`/`O1_continuous`
filename/tap mismatches before engine/model allocation. General filenames continue
to use the user's explicit prepared-domain declaration. Actual live tap changes
retain stop/drain/restart behavior. Eight focused prepared-file tap tests passed.
Runtime 0.1.1 (unchanged in 0.1.2) also adds enrollment cleanup and lease-retention fixes. The final
software suite passed 96 checks, including eight file-tap, ten enrollment-cleanup
and one live-stop ownership case. The bound source remained unchanged during the
7.672-second run, with zero failures, errors or skips. These later changes do not reinterpret
earlier file bytes and are not silently included in the completed soak claim.
The initial aggregate test-runner import-path/old-fixture failures are preserved
in `UNIT_RUNNER_INITIAL_FAILURE.json/.txt`; the final pass follows harness/fixture
corrections, not deletion of those earlier results.

Release 0.1.0 already built as a 406,514-byte / 109-file archive and passed bounded
relocation under `G:\Just_Peachy_PROTO1\Relocated Windows Application`. Its native
caption-only test completed; actual PS/CMD launchers closed with locks released.
The rollback fixture preserved a synthetic private-data sentinel. These launcher
checks used a hidden-Tk process hook and therefore add no pixel or live evidence.
Windows and x86 WSL standard-library release tests passed, including wrong-architecture
rejection; Linux was x86_64 WSL / Python 3.14.4, not ARM64 inference.

Thirteen ARM64/pure-Python wheels (89,968,134 bytes) are prepared for the declared
Bookworm/aarch64/CPython 3.11 target. Supplied XMOS `rpi` binaries were inspected as
32-bit ARM and are not qualified AArch64 tools; matched host/control-map compilation
and execution remain a bring-up requirement. No SSH deployment or device imaging
occurred. Display controller/interface/driver/touch transform, camera interface,
BMI270 bus/address/pins/axes and optional GPIO mappings remain unset. The desktop
RSS sample cannot establish full-system headroom, latency or thermals on the
2 GB RAM / 32 GB eMMC CM5.

## Launch and next human check

From the repository directory in PowerShell:

```powershell
& .\prototype\Start-Prototype.ps1
```

CMD or Anaconda Prompt:

```bat
prototype\Start-Prototype.cmd
```

The app opens idle. Start requires visible consent; Stop releases capture; close
waits for cleanup. Follow `docs/LIVE_USER_CHECKLIST.md` for 10–15 minutes of actual
speech, reference Save/restart/fresh query and consenting-visitor/Unknown behavior.
Ordinary PC peripherals may remain connected. Do not substitute replay or a silent
room for these pending checks. Use `MODE_GUIDE.md`, `docs/ENROLLMENT_GUIDE.md` and
`docs/PI_DEPLOYMENT_WORKFLOW.md` for mode limits and the eventual wired/USB update route.

Primary existing evidence: `G:\Just_Peachy_PROTO1\acceptance\panel_v1\PANEL_RESULT.json`
(SHA-256 `b2301ddfb126265fbef8fe523cd69530d9b08418e56c76015be752c362aec296`);
`tests/evidence/C105_REGRESSION.json`
(`8c1a9770600c075f7a7aa6788a05653d5439bc77205a66cb17e7ed2a10c3f607`);
`tests/evidence/native_people_summary.json`
(`5ee75f0ef4a21288238081cfbb17d5f63cc6101f5171ca9bbc43e03a8347cf40`);
`tests/evidence/UI_CHECK_SUMMARY.json`; `tests/evidence/CONTROLLER_VIEWS_CHECK.json`;
`evidence/live_adapter/LIVE_ADAPTER_RESULT.json`; and
`release_tools/evidence/actual_release/ACTUAL_RELEASE_RESULTS.json`
(`0ad09a9116423c49b47b44949aa08aee839452f8139858fba0e090fc48538456`).
The completed soak is `G:\Just_Peachy_PROTO1\acceptance\soak_v1\SOAK_RESULT.json`
(SHA-256 `7a69149e71cf9f4af42af317a0248444dbb6adb372ecd77813eab3f9716b8023`),
with `evidence/CLOSEOUT_AUDIT.json`
(`f0562ead2a47ecff2d4832827fc5ea7659a53f12570123c24edaac6b0beb3c2c`).
The mutable progress file is superseded for acceptance by these completed receipts.

## Integrity, storage and handoff

The final binding audit verified all 110 release payloads against current source,
all 52 historical S7 source files against their seed hashes, and the unchanged
Revision 22 workbook. Of the migrated vendor files only `runtime.py` differs;
the diff contains application orchestration hooks. Git HEAD remains unchanged;
no commit or push was performed. The real default personal store has no people
or runtime lock. Owned acceptance/replay/launcher processes have exited.

Available storage at closeout: C: 140.88 GiB and G: 137.98 GiB. This job did not
regenerate RIRs, train models, launch a campaign, flash hardware or contact a Pi.

Analysis handoff:
`<simulation>\handoffs\PROTO1_CHATGPT_HANDOFF_20260919T012911Z.zip`.
Its external receipt supplies the final ZIP size/hash, avoiding a self-referential
checksum. The package contains at most 60 allowlisted files and six labeled
screenshots. Compression keeps it below the nominal 2–10 MiB target; it is not
padded with redundant logs. No private voice/audio/vectors, model weights,
credentials or duplicate Word workbook are included.
Final software checks: `tests/evidence/FINAL_UNIT_CHECKS.json`
(`d6381c783a944826438518cca0b5c37777b483cc8f8dfecb3dfe332550fec56b`).
