# Just Peachy PROTO1 — application and release handoff

This package reports implemented software and executed checks. It is not an
instruction to rerun the previous research campaigns. Read IMPLEMENTATION_RESULTS
first, then the mode guide and evidence appropriate to the next decision.

## Launch on the desktop

Double-click:

`C:\Users\amiri\Documents\GitHub\just-peachy\prototype\Start-Prototype.cmd`

PowerShell from any directory:

```powershell
& 'C:\Users\amiri\Documents\GitHub\just-peachy\prototype\Start-Prototype.ps1'
```

CMD / Anaconda Prompt from any directory:

```bat
"C:\Users\amiri\Documents\GitHub\just-peachy\prototype\Start-Prototype.cmd"
```

The 480 × 800 portrait application opens idle. Start requests microphone
consent; Stop releases capture. The user was unavailable to speak during this
job. No unattended enrollment or physical microphone recording was performed.
Follow `guides/LIVE_USER_CHECKLIST.md` when the user is ready, including fresh
speech after enrollment and restart. Current live status is
**LIVE_READY_AWAITING_USER**, not LIVE_ENROLLMENT_VERIFIED.

Stable desktop private data:
`C:\Users\amiri\JustPeachy\data`

Shared immutable model assets:
`C:\Users\amiri\JustPeachy\shared\models`

Paths deliberately avoid the Codex MSIX-redirected AppData tree. The user's
real People store is separate from all synthetic/file-based test stores.

## Evidence to read

- `IMPLEMENTATION_RESULTS.md`: results, acceptance scope, remaining limits.
- `guides/MODE_GUIDE.md`: five user modes, four executable engine recipes,
  audio taps, explicit Unknown behavior and full-caption rescue.
- `evidence/C105_REGRESSION.json`: retained S7 sentinel, 1 error / 41 reference
  words for both conditioned lexical and anonymous-attribution diagnostics.
  This one scene is not an overall accuracy estimate.
- `evidence/NATIVE_PEOPLE.json`: actual ReDimNet scoring with disjoint public
  source/query files, fresh-process persistence and an unknown speaker. This
  is a dry-fixture domain, not real-room enrollment quality.
- `evidence/CLOSEOUT_AUDIT.json` and `SOAK_RESULT.json`: complete source sample
  accounting, 20 controlled transitions, finalization and desktop resources.
- `evidence/PANEL_SUMMARY.json`: six native scenes and the 15.53-second writer
  stall. This was a development epoch; do not relabel it final-source evidence.
- `evidence/FINAL_RELEASE.json`: immutable final artifact, checksum, tested
  differences from the exact soak-tested release candidate.
- `evidence/LIVE_READINESS_REVIEW.md`: code-level readiness versus physical
  signal path, gain, unplug/replug and restore checks still requiring consent.
- `WORKBOOK_UPDATE.md`: proposed dated addition to Revision 22, which remains
  unchanged on disk.

Source differences and exact hashes are in `manifests` and `review_source`.
The review source is intentionally a subset: run the complete application from
the repository or verified release, not a loose file copied from this handoff.
Small relevant test sources and their commands are in `review_tests`.

## Full local artifacts

Application source:
`C:\Users\amiri\Documents\GitHub\just-peachy\prototype`

Final source release:
`G:\Just_Peachy_PROTO1\releases\just-peachy-proto1-0.1.2.zip`

Exact soak-tested release candidate:
`G:\Just_Peachy_PROTO1\releases\just-peachy-proto1-0.1.0.zip`

Full acceptance receipts and disposable test data:
`G:\Just_Peachy_PROTO1\acceptance`

ARM64 CPython 3.11 wheelhouse:
`G:\Just_Peachy_PROTO1\arm64 cp311 wheels`

The release ZIP intentionally excludes model weights and personal data. See
its manifest and the shared-asset import commands before using it elsewhere.
The handoff excludes audio, embeddings, model binaries, photos, credentials and
the Word workbook. Six screenshot labels distinguish native saved-file captions
from explicitly synthetic UI examples. No screenshot proves live recognition.

## CM5 route and remaining physical checks

The prepared workflow is edit → focused tests → versioned release → wired
Ethernet/SCP or USB → integrity/schema check → safe activation → health check;
rollback preserves personal data. See `guides/PI_DEPLOYMENT_WORKFLOW.md`.

Windows execution and x86 Linux packaging tests are distinct from prepared ARM64
wheels. **CM5_HARDWARE_NOT_TESTED** remains the status. The supplied XMOS Raspberry
Pi executables are 32-bit ARM; matched 64-bit control tools still need to be built
and checked for the actual target. No SSH target was supplied or contacted.
Touchscreen interface/driver, camera setup, BMI270 wiring/orientation and GPIO
mapping remain explicit disabled/null fields.

Do not restart S6/S7 sweeps, regenerate RIRs, retrain models, flash hardware,
invent spatial calibration or promote naming/strict filtering on the basis of
this engineering check. The immediate next step is the user's short live
microphone/enrollment checklist, followed by actual CM5 bring-up when available.

