# S6A all-240 original-settings baseline

Status: **COMPLETE_480_BASELINE**. Scored 480/480 requested outputs across 240 scenes; 360 prior S5 outputs retain exact numerical/population parity.

On primary pooled text counts the conditional preference is **O0**, with O1 minus O0 WER 1.075 percentage points.

This describes the fixed bank and original B0 with O0 +3 dB applied once and O1 unity. It does not choose the final jointly tuned pipeline or establish device-wide superiority. All 240 cases are now observed; the original 180/former 60 contrast is descriptive.

| Population / metric | Requested scenes | Paired scenes | O0 | O1 | Reference words |
|---|---:|---:|---:|---:|---:|
| Primary nonoverlap WER | 156 | 156 | 14.386% | 15.461% | 4560 |
| Complete overlap MIMO-WER | 47 | 47 | 33.379% | 34.478% | 1456 |
| Complete-reference final-label cpWER | 203 | 203 | 58.727% | 61.735% | 6016 |
| Incomplete ambient target-only WER (limited) | 26 | 26 | 29.575% | 30.015% | 683 |

Primary CER: O0 8.461%, O1 9.493%. Counts, substitutions/deletions/insertions, and per-population diagnostics are in BASELINE_RESULTS.json.

The 2,000-replicate paired bootstrap samples 116 whole matched blocks within 5 observed rooms. Conditional 95% interval for O1 minus O0 WER: [0.3726130381525031, 1.8074942928043702] percentage points.
All-dependency primary component sizes: [156]. Shared people/text/books/RIR/noise connect blocks; this interval can be optimistic. Equal-room means, leave-room-out and each dependency component deletion are explicit in PAIRED_UNCERTAINTY.json. Missing primary members exclude the entire matched block; 0 blocks excluded.

## Empty controls, support, continuity and cost

| Tap | Empty inserted words / controls | Words/min | Embedding calls | Unique evidence s | Processed window s | PCM16 rail samples |
|---|---:|---:|---:|---:|---:|---:|
| O0 | 1 / 11 | 0.122 | 7502 | 2136.000 | 3751.000 | 0 |
| O1 | 2 / 11 | 0.244 | 8147 | 2264.000 | 4073.500 | 2027 |

Empty-reference WER is undefined. Short-turn support flags are temporal detection proxies; they do not certify transcript or speaker recognition. SHORT_TURNS.csv retains whole-clip versus active-duration bins, corpus, attribution limits, observed support and misses. RETURN_GROUPS.csv retains consistent/inconsistent/unknown outcomes, with known source schedules used only by evaluation.
SUPPORT_RESULTS.json separates raw and adapter PCM16 levels, headroom/rails, real-noise support, quiet support, overlap, gate reasons and unique-versus-repeated embedding evidence. STRATIFIED_TEXT.csv covers room, family, corpus, quality, pose, obstruction, requested noise/SIR, source level and common headroom. These are uneven descriptive strata, not randomized effects.
COST.csv distinguishes native runs reused from earlier work and fresh S6 native work. Whole-process desktop wall/audio includes process/model startup and historic contention; it is not steady-state inference throughput or a CM5 conversion. Unlogged rejected embedding calls remain unknown.

## Geometry and exclusions

121 canonical RIR records remain bound to the original manifest; 120 are eligible, 39 occur in this scene bank, and 81 are unused by this bank. Eligible effective distances span 0.46–4.07 m; none exceeds 5 m.
The two 100 m raw-entry typos preserve user-confirmed effective 1.00 m overlays. Selected source angle signs, signed values, room/pose/obstruction and nominal folded projection agree exactly with the canonical metadata. This cannot independently prove that a manual angle was measured with the correct sign. Native 0 and 180 degrees are opposite endpoints; front/back remain ambiguous. Manual ±5 degrees is source-label uncertainty.
RIR_GEOMETRY_AUDIT.json lists every eligible and excluded record and the unmodified historical bindings. No raw recording, RIR or source metadata was rewritten or regenerated.

## Interpretation limits

- Primary WER/CER use pooled native-text edit counts; punctuation display is excluded.
- Overlapping speech uses MIMO-WER separately. cpWER is final-label snapshot and not online revision-aware DER.
- Incomplete ambient transcripts are target-only diagnostics, not complete speech WER and never pooled with primary.
- Empty controls have insertion counts/minutes; WER is undefined.
- Short-turn flags and contained embeddings are temporal proxies, not word recognition or verified speaker identity.
- Component boundaries use frozen source support; unknown ambient speech is not relabeled silence.
- Unique embedding evidence is interval union within each output; summing outputs is workload, not independent acoustic evidence.
- Desktop whole-process wall measurements include startup and historic host contention; no conversion to CM5 RTF.
- All240 are now authorized and observed; former60 are not an unseen held-out confirmation.

## Reproduction

See simulation/scripts/README_S6A_BASELINE_RESULTS.md. AGGREGATION_RECEIPT.json binds inputs, code, and outputs. No audio, model payload or embedding vectors are copied into this report.
