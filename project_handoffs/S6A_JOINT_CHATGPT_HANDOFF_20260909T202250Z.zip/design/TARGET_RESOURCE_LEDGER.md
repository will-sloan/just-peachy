# CM5 target resource ledger

Target: 2 GB CM5, 32 GB eMMC, ARM64 CPU. **Not tested on target.** Desktop measurements and analytic payload bounds remain separate.

Bound model/token files total 219,771,544 bytes (209.59 MiB). Disk bytes do not equal resident RAM. The intended runtime shares one instance of each model rather than creating one ASR recognizer per speaker.

| Asset | Disk bytes | Resident bytes |
|---|---:|---|
| sherpa_giga_encoder_int8 | 187,823,992 | Not isolated per model |
| sherpa_giga_decoder_fp32 | 2,092,566 | Not isolated per model |
| sherpa_giga_joiner_int8 | 259,335 | Not isolated per model |
| sherpa_giga_tokens | 5,048 | Not isolated per model |
| sherpa_online_punctuation_int8 | 7,490,500 | Not isolated per model |
| sherpa_online_punctuation_bpe | 149,430 | Not isolated per model |
| redimnet2_b2_fp32 | 16,025,408 | Not isolated per model |
| pyannote_segmentation_3_0_fp32 | 5,925,265 | Not isolated per model |

Controlled paced desktop screen

Four sequential full-engine jobs used the same 89.390875-second measured gained O0 input at unity. OMP/OpenBLAS/MKL/NumExpr were each limited to one thread. Concurrent research load remained on the desktop. Source receipt records parity, model loading and process closure.

| Job | Logged model-phase s | Peak USS MiB | RSS sum upper bound MiB | Private commit MiB | Peak threads | Writes bytes/audio s |
|---|---:|---:|---:|---:|---:|---:|
| CPU_T1_D100 | 12.524 | 383.03 | 440.90 | 416.01 | 28 | 50048.6 |
| CPU_T2_D100 | 10.255 | 385.16 | 443.47 | 418.08 | 33 | 50051.4 |
| CPU_T2_D50 | 10.861 | 384.53 | 442.84 | 417.60 | 33 | 57244.2 |
| CPU_T1_D50 | 13.875 | 383.84 | 441.71 | 416.83 | 28 | 57106.1 |

Logged model-phase times are not exhaustive pipeline compute. Some wrapper preprocessing/postprocessing, gating, tracking, endpoint advice/reset, formatting and event I/O are outside these timers; segmentation timing stops before powerset_posteriors. Keep child/session wall time, loading, paced queue measurements and process resources distinct. The sum of phases is not full-pipeline RTF or calibrated latency.
USS measures private resident pages. RSS sums can double-count shared pages. RSS minus USS is a nonunique shared estimate; PSS is unavailable on this Windows host. Private commit measures committed virtual backing, not resident physical RAM. Per-model allocations are not isolated by these whole-process samples.
Observed backlog maxima are 0.10 seconds for ASR and 0.30 seconds for the speaker lane on this paced fixture; no dropped frames were reported. These bounded desktop queues and compute times do not establish CM5 capacity, sustained thermal behavior or live hardware latency.
V1 with inherited library defaults is retained separately. V1/V2 also used different application revisions, so their differences cannot be assigned solely to numeric-pool limits.

Payload and storage bounds

| Buffer or store | Analytic payload bound | Limitation |
|---|---|---|
| capture raw reserve | 7,680,000 bytes | Numpy/queue objects add overhead; device source rate matters |
| segmentation rolling waveform | 640,000 bytes | Padding/concatenate can transiently duplicate arrays |
| 3s evidence waveform | 192,000 bytes | maximum proposed candidate, not validated as optimal |
| 1s preroll | 64,000 bytes | proposed optional |
| dual mono tap 10s rings | 1,280,000 bytes | research split tap proposal |
| tracks/prototypes | 36,864 bytes | Python metadata, revisions, gallery and conflict matrix additional |
| gallery | 36,864 bytes | explicit enrollment mode only; main S6A anonymous |
| revision queue | Unmeasured / policy dependent | proposed bound |
| baseline SimpleQueue/events and clusters | Unmeasured / policy dependent | Bound in opt-in production candidate without hidden transcript/audio drops; test long-session pressure. |

The current tracker bounds16 prototypes and64 recent revision records; Python objects and total event/journal growth are separate. Multi-prototype, bounded production event queues and retention changes remain proposed work.
Mono16k PCM16 audio alone writes 115,200,000 bytes/hour. A proposed1GiB audio-only cap fills in 9.32 hours before logs. Measured process write counts also include research vectors/events and are not physical eMMC writes.
32GB is the nominal eMMC total. Installed OS, libraries, UI/display, update reserve, writable filesystems, write amplification and endurance are unmeasured on target; no assumed free-space subtraction is used.

Target gates

The ≤1.3GiB application screen and >1.5GiB review level are provisional planning limits, not a qualification. Validate the existing ARM64 exporter/runtime paths in the JSON ledger, exact graph hashes and imports, same-input numerical parity, actual USB no-drop behavior, process/private/shared memory plus OS MemAvailable, sustained queue stability, thermal/power behavior, disk-low recovery and GUI increment. No guessed desktop-to-CM5 speed factor is used.

TARGET_RESOURCE_LEDGER.json contains exact byte formulas, source bindings, V1/V2 rows, model assets, runtime paths and deferred measurements. No board was contacted, flashed or tested.


Completed native panel cost context

The 720 native jobs sum to 10966.959 child-wall seconds, averaging 15.232 seconds per job across these profiles. This includes per-child loading/overhead under concurrent desktop research load. It is not coordinator elapsed, CPU-seconds, summed model-phase cost or CM5 RTF. The JSON retains each profile/tap mean; a fresh balanced recipe pilot still controls B admission.