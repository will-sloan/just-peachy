# Independent skeptical review — S6A joint design

This review concerns the implementation and proposed research, not permission to
run later stages. The 240-scene bank is now exploratory. Existing shared voices,
texts, RIRs, noise parents and matched pairs prevent treating 240 scenes or 480
outputs as independent population samples. Both taps share one physical XVF
trace. The original 180/60 split is historical, not newly untouched validation.

The exact B0 comparator preserves older behavior, including limitations. The
new voice/time tracker is the architecture-matched parent for metadata
comparisons. Compare both: improvement over B0 alone does not isolate XVF
information from a better tracker, gate, evidence duration or endpoint policy.

The 36-scene native panel has 23 primary, six overlap, five incomplete ambient
and two empty scenes. It contains only two subsecond source utterances per tap.
The full-bank reference study has 40 complete-reference subsecond utterances per
tap; its coverage findings cannot be transferred to the different native panel.
Condition presence is not adequate precision for a short-reply success claim.
Confirm retained duration/commitment policies against the full short-turn
denominator, including unknown labels and unavailable mappings.

Instrumented phase times also have a narrower meaning than total pipeline CPU
cost. Segmentation timing stops before powerset_posteriors. Some wrapper
pre/postprocessing, gating, tracking, endpoint advice/reset, formatting and
event I/O are not fully charged by those phase counters. The phase sum must not
be called full-pipeline compute/RTF or calibrated latency. Full child/session
wall time, model loading, actual paced queues, sample coverage and process-tree
resources remain separate observed quantities.

## Code findings and their disposition

- **Baseline onset/offset are inert.** Original runtime uses mean hard powerset
  speech/overlap flags >=0.20. The .46/.45 fields were not consumers in that
  loop. Supported new posterior hysteresis must advertise a changed wrapper,
  verify actual graph output semantics, and retain original hard decoding.
- **Similarity comparator is cosine >=.35.** It is not cosine distance. Changed
  evidence duration changes score distributions, so a reused .35 threshold is a
  control hypothesis rather than calibrated truth.
- **Baseline evidence is elapsed source time.** Original naming uses
  source_end minus first source time, including silence. New tracking uses the
  union of admitted evidence. Overlapping windows are not independent seconds,
  and neither an empty gallery nor anonymous IDs establish naming accuracy.
- **EOF availability omission was found.** Initial research ASR code did not
  charge pending-tail and final-drain compute. Component owner has added
  separate charged events and synthetic-padding disclosure. Final code hashes,
  tests and execution receipts must prove the delivered fix.
- **Fresh delivery did not guarantee fresh observation.** Initial replay
  provider discarded observed source spans and endpoint advice omitted
  sequence rejection. Component owner now retains spans, checks both ages and
  monotonic sequence. Historical device-internal observation time remains
  unavailable; conservative receipt-age inference must not become a sensor
  timing calibration.
- **Cadence/persistence conflict was found.** Initial sustained-angle state
  reset after roughly .36s without an embedding update, while the proposed
  longer-evidence profile emits every .5s. This can make a named cue mechanism
  inoperative. Cue owner was asked for a separated freshness/cadence rule and a
  .5s-cadence fixture.
- **Lineage must record real operations.** Creation/prototype-update/commit
  events are real. A permanently null revision_of field does not demonstrate
  merge, split or delayed revision. Any unimplemented operation must stay
  explicitly deferred; no final-score repair may erase first wrong exposure.

Additional actual-code review found a duration/commit interaction: P1 uses a
1.0-second embedding window and 1.0-second commit requirement, so every newly
created track immediately commits. The provisional-branch merge condition
requires an uncommitted branch; that operation is inactive under P1 even though
its implementation and 0.5-second synthetic fixture exist. Actual split, merge
and revision counts must remain separate. In B, vary confirmation evidence
above the initial window if delayed reconciliation is intended.

The installed checkpoint is PalabraAI ReDimNet2-B2. Its actual frontend binding
and 192-vector graph, rather than the older IDRnD/ReDimNet link in the seed pack,
determine supported interpretation. Dispatch-block RMS is also a real coupled
constraint: changing embedding cadence changes the chunk used by that gate.

These are review findings during implementation, not assertions that the final
delivered code retains each issue. The final review receipt records the tested
disposition after owners finish.

## Failure hypotheses that the score must expose

Completed V2 bounded checks now supplement the code review. The independent
EOF fixture passes exact 1,707-sample delivery and charged tail/drain semantics.
The actual neural prefix fixture used two fresh paced engines with an identical
12-second recorded prefix and different 6-second futures: 18 raw/display
events, 240 dispatch decisions, 24 segmentation results, 10 exact ReDim vectors
with full source/receptive spans, and 10 tracker decisions matched in the prefix.
Later segmentation changed with the different futures. Display invariance was
observed in this fixture; it does not prove invariance under every scheduling
interleaving. CAUSALITY_DELIVERY_RECEIPT.json binds that limited result.

The ten-profile comparison audit also reproduced exact disabled-cue behavior
for voice_time versus reliability_adaptive over 361 existing decisions across 12
cases after excluding only the diagnostic mode field. SEG_X0/P0X0 therefore
tests a segmentation-policy plus cadence bundle; its disabled tracker-mode
difference does not introduce another numerical association mechanism. The
P0/P1 factorial has equal P deltas across X and equal X deltas across P, while X
enables a combined tracking and possible ASR endpoint-advice route. This is not
an isolated final-label cue intervention.

Independent analysis review found and reported false lexical-parity credit when
both MIMO records lacked normalized strings, missing ASR EOF/drain costs,
unpaired interim factorial contrasts, and unavailable memory treated as zero.
The final derived analysis retains prior namespaces and now reports all 720
native V2 scores and the complete paired supplement. INDEPENDENT_FINAL_REVIEW.json
rehashes those 720 score files, checks pooled population/error counts and
factorial arithmetic, and confirms the regular/tail/drain cost identities.
These reporting fixes did not require redoing native recognition.

A stable reflection can give excellent directional persistence and a wrong
spatial prior. Quiet speech can have weak energy and strong voice evidence;
music can have strong energy without target speech. Selected, focused and raw
beams are correlated products of one device. Multiplying their confidences as
independent likelihoods creates false certainty.

Same-bearing replacement must still get audio checks. A scheduler that stops
embedding because location looks stable can suppress the only observation that
would reveal a new voice. A false first association can contaminate the
prototype, then make later voice evidence appear to confirm the false spatial
prior. Quarantine, independent disjoint confirmation, periodic audio-only
probes and clean fallback prototypes are separate safeguards to test; none is
assumed successful.

Longer ReDim windows can improve within-speaker separation but mix rapid
handoffs and remove subsecond replies. Show all reference turns, admitted and
rejected evidence, unique duration, first provisional and committed decisions,
wrong merges and return unknowns. Retaining fewer difficult turns is not an
improvement in speaker recognition. RMS is gain-dependent; O0 +3dB is applied
once, and a gained adapter or journal must be consumed at unity.

Endpoint advice can delete or duplicate words, including when ASR has no final
text yet. Both the continuous-ASR/diarization-only branch and the native
silence-confirmed advice branch need actual recognition comparisons. A
different decoder or endpoint/reset history cannot be evaluated by relabeling
old words. Raw text, original missed words, ambient unknown speech and strict
empty controls retain their appropriate denominators.

A label-only reference replay may preserve exact words and use conservative
modeled availability. That is not calibrated GUI or live latency. A fixed-lag
correction must be emitted when new evidence arrives and preserve original
errors and correction burden. Accelerator speed, historical capture time and
current host wall time cannot be joined as one physical clock.

## Controls and useful disproofs

For every cue-enabled recipe, its matched disabled parent removes all
metadata-dependent changes: final score, window placement, admission,
scheduling, endpoint advice, prototype updates and display delay. If a
component setting changes, run the original/tuned x off/on factorial on the same
panel and both taps. Report all four raw outcomes and the paired interaction;
do not infer randomized population causality.

The all-unknown control should fail useful-coverage metrics. The one-person
control should fail wrong-merge/person-attribution metrics. If either can win,
the selection objective rewards refusal or cosmetic stability. Shuffle true
identity labels without touching predictor inputs, alter future suffixes,
inject missing/stale/reordered metadata, and use two host chunk patterns.
Predictions must obey the declared causal contract, and cache keys must miss on
affected descendants.

A small measured S6A panel supports parameter plumbing and engineering triage.
It does not freeze the best global thresholds. Proposed S6B profiles retain both
taps, difficult cases and failures; finalists need full-bank confirmation and
later independent real conversations. ±5 degrees is manual geometry
uncertainty, not measured device noise or a threshold target.

## Final 720-output outcome review

All final V2 native scores and the paired supplemental report are complete.
The independent result review rehashed all 720 score files, verified 20 unique
profile/tap groups of 36 scenes, reproduced pooled word/cpWER counts, checked
all factorial rows and checked all 720 regular/tail/drain ASR cost identities.
Primary, overlap, incomplete-target and complete-cpWER denominators are
671, 165, 146 and 836 words per profile/tap, respectively. P0X0/B0 lexical
parity is 72/72 in the independently bound supplemental comparison.

Large observed cpWER decreases are not sufficient to select P1. P1X0
versus P0X0 decreases cpWER by 18.421 points on O0 and 10.646 on O1 with
unchanged raw words, while mixed-identity support rises. On the two subsecond
source turns, P1X0 has known modal labels on 1/2 O0 and 0/2 O1, versus 2/2
for P0X0. These are sparse coverage observations, not identity correctness or
a stable population rate. The longer-window EMBED_LONG profile has no fully
contained embedding for either short utterance but retains 2/2 known modal
labels; waveform containment cannot be substituted for label coverage.

The advisory route increases primary word errors by 2/671 O0 and 4/671 O1
under both factorial component bundles. Its lexical interaction is zero on
this panel, while its cpWER interaction has opposite signs on the two taps.
That does not establish that direction generally harms recognition; it
disqualifies this particular combined tracking/advice policy as an automatic
improvement. B should separate tracking-only support from ASR advice and test
silence/false-jump safeguards with continuous ASR retained as an explicit option.

SEG_X1 assistance is active, changes accepted embedding work and lowers unknown
support, but has identical pooled words/cpWER to SEG_X0. Sparse cadence/RMS
reduces ReDim calls while worsening cpWER. These mechanisms remain meaningful
cost/coverage hypotheses, not demonstrations that activation or fewer calls
improves the system. Exact counts and adverse short-turn rows are retained in
INDEPENDENT_FINAL_REVIEW.json and the final S6B plan; all B extensions remain
unexecuted.

## CM5 interpretation

Local model/token disk payload is about 209.59MiB. That number excludes native
inference workspaces, Python and runtime libraries, audio buffers, GUI, kernel,
shared pages and storage caches. The historical sampled desktop RSS is a
different quantity; neither demonstrates 2GB fit.

One resident instance of each selected model, shared ReDim, bounded tracks,
prototypes, queues, revisions and logs is the intended path. The baseline
append-only PCM16 journal grows115.2MB/hour plus logs; 1GiB gives about9.32hours
of audio alone. A future retention policy must be explicit and tested under
disk pressure, with acquisition evidence preserved. Private/USS, RSS and
shared/PSS are separate; summing per-process RSS double-counts shared pages.

The <=1.3GiB target and >1.5GiB review threshold are provisional design screens.
Only native ARM64 tests with the actual OS/UI/drivers, sustained queue load,
thermals and power establish qualification. No GPU dependency or guessed
desktop-to-Pi multiplier is allowed in the intended production profile.
