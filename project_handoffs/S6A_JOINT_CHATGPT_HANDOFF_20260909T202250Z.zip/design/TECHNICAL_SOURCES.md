# Technical source checks

Primary references were checked on 9 September 2026. They motivate interpretation; the installed local implementation, graph inspection and execution receipts determine actual support.

- [Pyannote model card](https://huggingface.co/pyannote/segmentation-3.0): 10 s mono 16 kHz and seven powerset classes; local H2 wrapper, not the full diarization pipeline, governs execution.
- [Pyannote 3.1.1 pipeline source](https://raw.githubusercontent.com/pyannote/pyannote-audio/3.1.1/pyannote/audio/pipelines/speaker_diarization.py): Reference powerset/postprocessing distinction; do not infer the installed custom wrapper API from generic pipelines.
- [ReDimNet2 authors](https://github.com/PalabraAI/redimnet2): Actual model family: PalabraAI ReDimNet2-B2. Local checkpoint, exported graph and wrapper bind the TF-style 72-mel frontend, supported input lengths and 192-vector normalization. The pack's older IDRnD/ReDimNet link is architectural background only.
- [Sherpa online endpoint example](https://raw.githubusercontent.com/k2-fsa/sherpa-onnx/master/python-api-examples/speech-recognition-from-microphone-with-endpoint-detection.py): Endpoint/decoder interface reference; bound installed API determines supported arguments.
- [Sherpa Python documentation](https://k2-fsa.github.io/sherpa/onnx/python/index.html): CPU package and online recognition entry points; no assurance of current target-wheel or CM5 performance.
- [ONNX Runtime threading](https://onnxruntime.ai/docs/performance/tune-performance/threading.html): Intra-op count includes the calling thread; sequential graph mode and spinning affect contention. Installed version must verify supported options.
- [Raspberry Pi CM5 product](https://www.raspberrypi.com/products/compute-module-5/): ARM64 target family; the purchased 2 GB/32 GB/no-wireless configuration is a user/workbook binding, not a desktop measurement.
- [ONNX Runtime Raspberry Pi tutorial](https://onnxruntime.ai/docs/tutorials/iot-edge/rasp-pi-cv.html): Shows a Raspberry Pi deployment path for another model. Does not qualify this speech stack, weights, RAM or timing.
- [Windows process memory counters](https://learn.microsoft.com/en-us/windows/win32/api/psapi/ns-psapi-process_memory_counters_ex): PrivateUsage is private commit, distinct from resident working set. Preserve USS, RSS and private commit separately.
- [psutil memory API](https://psutil.io/api/): USS describes unique process memory; PSS shares pages proportionally where available. Current documentation discusses version8 changes; installed7.2.2 memory_full_info is the local API and is not upgraded here.

No new dependency, model, hardware, board setup or document edit was performed by this builder. The current workbook is separately hash-bound and read for context. Model disk bytes are local file metadata; runtime and ARM64 claims require their own measurements.
