# Independent probe comparison audit

Ten frozen profiles reviewed. 524 existing feature decisions across 12 bounded cases gave exactly equal disabled-cue tracker behavior after removing only the diagnostic mode field. No new neural runs or audio reads.

- With xvf.mode=none, runtime passes spatial=None even when a provider exists. For identical admitted vectors/times, voice_time and reliability_adaptive execute the same voice association, ambiguity, unique-evidence, prototype, capacity, commitment and lineage paths; only diagnostic mode differs.

- SEG_X0 versus P0X0 changes segmentation posterior policy AND segmentation hop .75 to .5 seconds. The disabled-cue tracker mode difference has no numerical association effect. This is a segmentation bundle, not an isolated threshold test.

- SEG_X1 versus SEG_X0 changes only the soft-energy route. Voice_time ignores spatial identity evidence, and no advisor is enabled. Any effect propagates through posterior assistance, changed admission/spans and downstream evidence.

- The P0/P1 x X0/X1 factorial has identical P deltas across X and identical X deltas across P. X enables both spatial association and silence-guarded possible ASR endpoint advice. It is a cue-route bundle; endpoint counts and raw words must distinguish actual activation from nominal availability.

- P1 versus P0 jointly changes segmentation policy/hop, embedding window/hop, endpoint rules1/2 and host journal dispatch. The difference-in-differences estimates that bundle's conditional interaction with the cue route on the same panel/tap, not a single component causal effect.

- EMBED_LONG versus P0X0 changes only contiguous window .5 to1s; longer startup wait, overlapping-span content, compute and immediate1s commitment are real downstream consequences, not an independently calibrated threshold.

- EMBED_CADENCE_QUALITY changes BOTH evidence dispatch .25 to.75s and minimum RMS .002 to.001. RMS is calculated on that dispatch block, so its waveform support changes too. Do not isolate cadence, quality or duration effects from this bundled comparison.

- ENDPOINT_X0 versus P0X0 changes both silence rules and host dispatch100 to50ms. ENDPOINT_X1 additionally enables the same combined tracking/advice route. It is not an endpoint-only spatial treatment.

- B0 versus P0X0 uses different anonymous tracker/evidence logic and research transcript history/instrumentation. Same ASR settings do not prove lexical parity; the root's measured per-case lexical comparison is required.

- Cached tracker equivalence is deterministic for supplied features. Actual first transcript labels also depend on which concurrent speaker events already exist at ASR emission, even after modeled source-age checks. Do not convert this into full-app chunk/prefix invariance or calibrated GUI latency.

- Track label_revision records do not revise native transcript rows, which retain label_revision_of=null and original first labels. Count tracker lineage and actual revised transcript/GUI exposures separately.

- Both taps share one physical XVF trace. Room/speaker/source/prompt/RIR/noise reuse and previously observed cases prohibit independent holdout or population-causal claims.
