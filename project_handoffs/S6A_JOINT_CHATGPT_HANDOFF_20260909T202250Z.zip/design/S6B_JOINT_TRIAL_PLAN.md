# Prospective S6B joint trial plan

This is a costed design, not an executed S6B campaign. S6A executed evidence is attached separately and must determine the exact R1 recipe and adverse-case priorities before B begins.

30 end-to-end profiles, up to 14,400 scene/output/policy results on the existing 240-scene bank. Both taps remain eligible. Eight recipe families are a grouping aid, not eight universal cache keys.

| Profile | Recipe | Mechanism | Cues | Parent |
|---|---|---|---|---|
| B00 | R0 | B0_exact | off | historical_exact_control |
| B01 | R0 | voice_time | off | matched_architecture_parent |
| B02 | R0 | angle_only | on | spatial_diagnostic_not_identity |
| B03 | R0 | sustained_change | on | B01 |
| B04 | R0 | decaying_memory | on | B01 |
| B05 | R0 | reliability_adaptive | on | B01 |
| B06 | R0 | static_fusion | on | B01 |
| B07 | R0 | cusum_change | on | B01 |
| B08 | R0 | uncertain_bearing | on | B01 |
| B09 | R0 | dual_timescale_dormant | off | B01 |
| B10 | R0 | dual_timescale_dormant | on | B09 |
| B11 | R0 | robust_prototypes | off | B01 |
| B12 | R0 | conflict_rollback | off | B01 |
| B13 | R0 | tempered_filter | off | B01 |
| B14 | R0 | tempered_filter | on | B13 |
| B15 | R0 | bounded_revision | off | B01 |
| B16 | R1 | measured_A_component_bundle | off | B01 |
| B17 | R1 | measured_A_component_bundle | on | B16 |
| B18 | R2 | purity_short | off | B01 |
| B19 | R2 | purity_short | on | B18 |
| B20 | R3 | purity_long | off | B18 |
| B21 | R3 | purity_long | on | B20 |
| B22 | R4 | endpoint_dispatch | off | B01 |
| B23 | R4 | endpoint_dispatch | on | B22 |
| B24 | R5 | evidence_debt_budget | off | B01 |
| B25 | R5 | evidence_debt_budget | on | B24 |
| B26 | R6 | gain_RMS | off | B01 |
| B27 | R6 | gain_RMS | on | B26 |
| B28 | R7 | bounded_search_runtime | off | B22 |
| B29 | R7 | bounded_search_runtime | on | B28 |

The exact original B0 is preserved separately from the new voice/time tracker. A matched X0 also removes metadata-dependent scheduling, endpoint advice, evidence admission and prototype changes. For each finalist add remove-angle, remove-energy, original-duration, original-endpoint and no-revision ablations where those are separable; count these additional comparisons explicitly.

| Recipe family | Concrete proposal and recomputation |
|---|---|
| R0 | Original effective audio/ASR/segmentation/embedding recipe; exact B0 separate from new tracker. Reuse compatible original features; missing exact vectors require native feature replay. |
| R1 | Bind the actual S6A joint bundle including adverse findings; do not claim it is optimal. Reuse exact S6A compatible features on panel; recompute remaining all-240. |
| R2 | Supported exclusive-speech policy at .5 s/.25 s, original ASR, no front-end mask. New evidence admissions and affected short embeddings; same tensors only if same contexts. |
| R3 | Same purity policy as R2 with valid 1.0 s/.5 s evidence and duration-aware abstention; short provisional retained. Actual longer vectors and cadence; exact common contexts may share segmentation. |
| R4 | Native endpoint pair 1.6/.8 s, max20s; host dispatch50ms versus100ms where validated; diarization-only alternative. Each distinct reset/chunk/advice history requires full Sherpa; no word re-slicing. |
| R5 | Evidence-debt/floor scheduler: 1s periodic floor, .25s bounded bursts; resident CPU pools1/2 tested. Changed evidence requests/availability need real embedding runs; cue-off must remove request influence too. |
| R6 | Compare baseline gain versus one causal fixed alternative and paired minimum_rms .001/.002/.004; source gain once. Fresh all neural branches for changed audio; policy-only threshold comparison may reuse exact audio segmentation. |
| R7 | Installed modified_beam_search max_active_paths2/4 versus greedy, host50/100ms and pools1/2. Fresh stateful ASR per recipe; paired runtime reprofile and numerical parity mandatory. |

Cost and admission

Historical S5 fresh jobs averaged 15.013 s/job. At that historical rate one 480-job recipe would take about 2.00 serial hours; eight original-cost equivalents about 16.01 hours before validation and packaging. This is a planning reference only: resident reuse may reduce overhead, modified search and separate cue-triggered histories may increase work. The actual S6A/B measured per-recipe throughput replaces these estimates before admission. No desktop-to-CM5 speed factor is used.

B should freeze all concrete profile JSON and exact dependency keys before outcomes, measure the first balanced pilot for every expensive recipe, and stop admitting work before the 24-hour budget minus at least 45 minutes for packaging. Keep atomic complete/failed/pending lists. Partial work stays explicit and resumes by receipt rather than overwriting or silently narrowing the bank.

Use paired O0/O1 counts, raw WER/CER, S/D/I, complete-overlap word recovery, cpWER, false merges, unknown/return/short-turn coverage, actual first/revised label timing, unique admitted evidence, full queue/load and process-tree memory on a Pareto table. Unknown ambient words are unscored, not hallucinations. This reused bank is exploratory; conditional resampling is not independent real-world confirmation.

The requested interactions are bound in S6B_JOINT_PLAN.json. Both taps across segmentation/evidence recipes test tap interactions; a genuinely split ASR/embedding input adds an explicit aligned route tuple and cannot be claimed from whole-tap comparisons. Missing historical AEC/AGC/RT60, focused streams and real motion remain deferred. No current profile is a target-device recommendation.

S6A constraints carried into this plan

- Current powerset log-score semantics and valid graph lengths. Use valid posterior policy and contiguous ReDim windows only. Graph shortening, frame masks and neural pooling changes are unsupported.
- RMS gate reads the dispatch block, not the complete embedding waveform. Treat cadence x RMS as a coupled gate. A full-window RMS gate is a new policy, not an existing binding.
- P1 window1.0s equals commit-evidence1.0s; new branches immediately commit. Current reconciliation requires a provisional branch, so P1 cannot merge/revise through that path. Preserve actual zero counts; B must vary commit evidence above initial window to test delayed reconciliation.
- Sparse observations can show sampled persistence but do not prove continuous DSP stability. Freshness checks retain both observed source age and delivery age; direction-persistence continuity is a separate cadence constraint.
- Stable direction can remain wrong on a shared physical trace. Prioritize wrong-stable-cue quarantine, audio-only fallback and same-bearing speaker replacement controls. Never multiply correlated beam confidence as independent likelihoods.
- Windows private commit is not resident USS. Use measured USS/RSS/shared distinctions and actual controlled library/thread settings. No desktop-to-CM5 conversion.
- Modest R5-vs-R1 aggregate cpWER gain coexists with O1 subsecond known-label loss; angle diagnostic abstention is high. Preserve cpWER, unknown/mixed support, returns and short-reply denominators separately. Prioritize evidence escrow, duration/commitment, wrong-cue quarantine and fallback; do not select a tracker on cpWER or continuity alone.
- P1X0 reduces panel cpWER with unchanged raw words, but short-turn identity coverage and mixed support regress. Challenge the bundle against EMBED_LONG and original cadence/post-policy controls. P1X0 known-modal coverage is only 1/2 O0 and 0/2 O1 versus 2/2 for P0X0. Keep all source turns and wrong-label exposure; no global winner follows.
- Advisory cue routes activate actual endpoints and increase lexical errors on both taps. Preserve continuous audio-only ASR and separate tracking-only from endpoint advice in B. Test false-jump/silence safeguards and circuit-breaker limits, using full raw S/D/I rather than attribution-only gains.
- Soft energy assistance changes admitted embedding work and unknown support, with unchanged aggregate cpWER/words. Measure incremental evidence, purity and short/unknown coverage against its matched SEG_X0 parent. An active assistance counter is capability evidence, not demonstrated lexical/attribution benefit.
- Sparse cadence/RMS reduces embedding calls but worsens aggregate cpWER versus P0X0. Retain it as a cost/coverage tradeoff to challenge with debt scheduling and matched budgets; do not treat fewer calls alone as a deployment improvement.
- No wholly contained 1-second embedding fits the two subsecond utterances, yet EMBED_LONG retains two known modal labels. Report waveform containment, available identity support, modal label and correctness separately. Containment failure is not synonymous with a missed label; only two panel source turns cannot establish a stable short-reply rate.

The exact ten named A profile files are hash-bound in S6B_JOINT_PLAN.json. Recipe R1 binds P1X0/P1X1 as a measured reference to challenge, not an optimum. SEG_X1 positive-energy support remains a separate matched intervention.

Completed original-settings baseline: O0 has lower pooled primary WER on this bank; O1 minus O0 is 1.0745614035087725 percentage points. Both taps remain in B because tuning can change the tradeoff.

Completed reference comparison informing B priorities

R5 changes cpWER versus its matched R1 parent by O0: -2.227 percentage points; O1: -0.682 percentage points. ASR words and accepted embedding spans remain fixed. This modest descriptive gain does not establish short-reply benefit.

| Tap | R1 subsecond known modal / all | R5 subsecond known modal / all |
|---|---|---|
| O0 | 27 / 40 | 28 / 40 |
| O1 | 32 / 40 | 30 / 40 |

Known modal labels measure coverage, not correct identity. Keep every short or unassigned turn in the denominator. Compare cue candidates to their matched cue-off parent with shared availability; B0 remains the original end-to-end benchmark, but B0-to-replay differences combine tracker and availability policies. Prioritize coverage-aware prototype/commitment and fallback checks before treating aggregate cpWER as improvement.

The actual A panel contains 36 scenes: COMPLETE_OVERLAP: 6; INCOMPLETE_REFERENCE: 5; PRIMARY_NONOVERLAP: 23; STRICT_EMPTY_REFERENCE: 2.
It has only 2 subsecond source utterances per tap, compared with 40 complete-reference subsecond utterances per tap in the full-bank reference study. Presence of the short-turn condition is not a precise estimate of short-reply performance. Confirm duration/commitment candidates on the complete source-based short-turn population before promoting them.

Completed A component outcomes carried into B

All 720 final score files were independently rehashed and their pooled counts/factorial arithmetic checked. P0X0/B0 raw normalized words match on all 72 panel outputs. The following are observed screening tradeoffs, not production selections.

| Profile | Tap | Primary WER % | Complete-reference cpWER % | Embedding calls | Advisory endpoints |
|---|---|---:|---:|---:|---:|
| EMBED_CADENCE_QUALITY | O0 | 13.562 | 64.593 | 499 | 0 |
| EMBED_CADENCE_QUALITY | O1 | 13.562 | 64.952 | 513 | 0 |
| EMBED_LONG | O0 | 13.562 | 47.368 | 1158 | 0 |
| EMBED_LONG | O1 | 13.562 | 52.273 | 1292 | 0 |
| ENDPOINT_X0 | O0 | 13.562 | 61.364 | 1158 | 0 |
| ENDPOINT_X0 | O1 | 13.562 | 62.799 | 1292 | 0 |
| ENDPOINT_X1 | O0 | 13.860 | 62.081 | 1158 | 15 |
| ENDPOINT_X1 | O1 | 14.158 | 67.943 | 1292 | 12 |
| P0X0 | O0 | 13.562 | 60.167 | 1158 | 0 |
| P0X0 | O1 | 13.562 | 63.278 | 1292 | 0 |
| P0X1 | O0 | 13.860 | 61.603 | 1158 | 16 |
| P0X1 | O1 | 14.158 | 68.182 | 1292 | 15 |
| P1X0 | O0 | 13.562 | 41.746 | 673 | 0 |
| P1X0 | O1 | 13.562 | 52.632 | 700 | 0 |
| P1X1 | O0 | 13.860 | 46.890 | 673 | 15 |
| P1X1 | O1 | 14.158 | 53.469 | 700 | 12 |
| SEG_X0 | O0 | 13.562 | 63.278 | 1188 | 0 |
| SEG_X0 | O1 | 13.562 | 66.388 | 1291 | 0 |
| SEG_X1 | O0 | 13.562 | 63.278 | 1194 | 0 |
| SEG_X1 | O1 | 13.562 | 66.388 | 1313 | 0 |

Every row has the same 36 scenes, including 23 primary scenes/671 words and 29 complete-reference nonempty scenes/836 words. The six-overlap-scene denominator is 165 words; five incomplete scenes/146 target words stay separate; two empty controls have undefined WER.

P1X0 reduces cpWER versus P0X0 by 18.421 percentage points on O0 and 10.646 on O1 with unchanged raw words, while mixed-identity support rises and subsecond known-modal coverage falls to 1/2 O0 and 0/2 O1. EMBED_LONG retains 2/2 known modal labels despite no wholly contained window for either short utterance: waveform containment is a separate diagnostic, not label correctness.

The advisory cue route increases primary errors by 2/671 O0 and 4/671 O1 under both P0 and P1. The lexical factorial interaction is zero here; cpWER interaction changes sign between taps. Keep tracking-only and ASR-advice branches separate in B, preserve continuous ASR, and test circuit-breaker/false-jump safeguards.

SEG_X1 assistance is active and admits additional embeddings but leaves pooled cpWER and words unchanged versus SEG_X0. Sparse cadence/RMS reduces embedding calls while worsening cpWER. Preserve these as cost/coverage hypotheses with matched parents, rather than declaring improvement from activation or fewer calls.

INDEPENDENT_FINAL_REVIEW.json binds all final sources, exact arithmetic checks, detailed short-turn rows and the limits of this review. It does not repeat neural inference or claim population generalization.
