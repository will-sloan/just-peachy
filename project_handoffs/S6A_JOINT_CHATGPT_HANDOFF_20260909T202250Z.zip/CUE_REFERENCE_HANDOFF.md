# S6A physical cues and six reference trackers

Status: COMPLETE — all 240 scenes, both taps and six reference profiles analyzed.
Generated: 2026-09-09T21:12:50.071037+00:00

On all 203 complete-reference nonempty scenes, reliability-adaptive R5
changes final-label cpWER versus matched voice/time R1 by -2.23
percentage points on O0 and -0.68 on O1. These are descriptive
bank results with unchanged ASR words. The new trackers still have more
unassigned support and generally worse final attribution than the exact
native B0. B0 and new methods also use different availability conventions,
so this is not an isolated tracker or live-latency comparison.

Angle association R2 leaves about 62% of complete-reference sole support
unknown. Its cpWER alone would conceal poor usable identity coverage.
One-person output has perfect return continuity but 30.93% mixed-identity
support; all-unknown output retains 100% unknown support. Neither control
can be described as a successful tracker. The cue variants remain candidates
for joint testing, not selected production settings.


The selected processed direction is frequently available but its nominal
geometry agreement is weak in this bank. On the 545 complete-reference,
non-overlap utterances, it was usable for 92.31%
of estimated source support and occupied the expected coarse sector for
45.01%. Sustained acquisition was
never observed for 282/545 utterances under
the inherited one-second/80%-occupancy physical metric. This supports soft,
qualified use of direction and a working no-metadata fallback. It does not
show that direction cannot help anonymous tracking: an offset or folded
observation can still carry relative change information.

The physical foundation contains exactly 240 shared traces, not 480
independent O0/O1 directional observations. It reuses 180 bound historical
spatial analyses and adds 60 analyses under the new all-bank authorization.
There are 777 utterance references and six directional streams. Summed
per-source support can include simultaneous sources; it is not unique
physical duration. The former 180/60 split is descriptive only.

## Physical cue evidence

| Stream | Usable support | Expected-sector support | Sustained never acquired |
|---|---:|---:|---:|
| selected_processed | 92.25% | 45.04% | 388/777 |
| selected_auto | 49.15% | 23.33% | 630/777 |
| raw_auto | 49.15% | 22.99% | 624/777 |
| focused_1 | 27.29% | 6.05% | 723/777 |
| focused_2 | 21.95% | 15.53% | 678/777 |
| scanning | 13.19% | 8.71% | 760/777 |

`CUE_RELIABILITY_BY_POPULATION.csv` separates complete non-overlap, complete
overlap and known targets in incomplete environmental mixtures. The 15
examples in `CUE_ADVERSE_EXAMPLES.csv` are explicitly posthoc descriptions,
not a tuning panel or independent samples. “Held wrong” means the same
numeric angle persisted in a wrong coarse sector. It does not prove stale
DSP data. No historic DSP frame timestamp, AEC/AGC state, or RT60 has been
invented. Manual +/-5 degrees is geometry uncertainty, not a sensor-accuracy
specification. Native 0/180 endpoints are not adjacent, front/back can fold,
and a beam is not a person.

## Implemented reference profiles

| Profile | Actual mechanism |
|---|---|
| B0 | Exact saved native final words and speaker labels; immutable control. |
| R1 voice/time | New bounded anonymous tracker; unique evidence union, separate association/prototype thresholds, unknown state. |
| R2 angle diagnostic | Anonymous spatial association without voice cosine; shares baseline audio eligibility and qualified delivered-angle checks. It is not an independent speech detector. |
| R3 sustained angle | Sampled persistent direction-change proposals with bounded voice association support; no forced new identity or ASR reset. |
| R4 decaying memory | Position support decays with time; severe voice conflict cannot be overruled by location. |
| R5 reliability adaptive | Voice/location support is moderated by delivery age, positive energy when available and agreement of correlated directional fields. These are engineering confidence checks, not calibrated probabilities. |

All new modes execute `ResearchTracker` from the actual H2 app. The GUI
default remains the original pipeline. The reference study holds baseline
ASR words, segmentation eligibility and exact accepted 0.5-second embedding
spans fixed. A real ReDimNet2 call computes every cached vector; no reference
voice, transcript, room, seat, true speaker count or schedule is supplied to
the tracker. R2 still shares the upstream gate/cost and rejects nonpositive
raw-auto energy when present; “angle-only” describes association, not an
unfiltered sensor-only route. No compute saving is claimed merely from a
cheap policy replay. Separate S6A component probes change real neural and
recognition inputs/settings and must be evaluated separately.

Each track is bounded and carries actual provisional/committed IDs. New
voice evidence updates a prototype only above the separate update threshold.
Overlapping windows add only newly covered seconds; a long silence adds no
identity evidence. Defaults are 16 tracks, 0.35 cosine association, 0.45
prototype update, 0.03 ambiguity margin and 1.0-second anonymous commitment.
These values are not an enrolled-identity probability or naming threshold.

A qualified direction proposal plus voice conflict can split a provisional
branch. Fresh overlapping voice evidence can reconcile it to its established
parent at cosine >=0.65, while it remains provisional and within two seconds.
The uncertain branch vectors are not pooled. A merge emits a forward
`label_revision` referring to the immutable first-decision ID; it does not
rewrite earlier first output or reset ASR. The revision queue is capped at
64 records. Fixture success establishes capability, not real-bank correctness.
With a 1.0-second embedding and 1.0-second commitment threshold, a new branch
commits immediately and this provisional reconciliation cannot run. S6B must
test embedding duration × commitment evidence × revision horizon together.

## Causal availability and cache boundaries

The exact B0 embedding function and ORT session factory execute from the
archived baseline snapshot. Audio comes from the already-gained native PCM16
journal and is read at unity. O0's +3 dB is not applied again. Feature keys
bind audio bytes, accepted-event selection, checkpoint, ORT provider/version,
threads, numeric/frontend recipe, exact source and input spans. A policy
change invalidates tracking; a changed waveform/span/model recipe requires
actual new vectors. Provider/thread changes do not inherit performance.

The reference bridge reads only metadata already received by the historical
callback containing the last input sample. Extra modeled speaker computation
ages that observation; packets arriving during compute are conservatively
omitted. Serial availability is `max(previous_ready, input_end) + measured
call_cost`. Segmentation costs are inherited from exact native calls; new
embedding calls are measured. Accelerated inference wall time is never joined
to the historical capture QPC clock. These are modeled availability/costs,
not measured live end-to-end latency or CM5 RTF.

The actual app probes use separately bound sanitized JSONL: a selected-angle
receipt becomes available at the first containing-or-later copy-complete
audio callback. Only earlier delivered energy/direction is attached. The
unknown native observation span is omitted. Both taps share the same trace.
Callback quantization and the slightly different conservative reference
bridge are explicitly recorded; matched factorial cells use the same JSONL.

Candidate final text uses only the latest decision already available at the
native final source cursor. It preserves all raw final words. B0 preserves
its actual native attribution. This common replay is not a controlled
measurement of the old cross-thread race or true word-level speaker timing.
For B0, the recorded source cursor locates each unchanged native decision;
its historical live decision availability is unknown. R1-R5 use the serial
modeled availability with measured neural costs described above. Their
matched cue comparisons share this rule, but B0-versus-new unknown-support
differences combine tracker and availability policies and do not isolate
the effect of a single component.

## Scoring and current coverage

Completed exact feature outputs: 480/480. Archived B0 label parity: 15,649 windows, 0 mismatches over 480 outputs.

The shared cache contains 15,649 newly computed ReDim vectors, costing 145.38 measured desktop seconds in total. It inherits 919.97 seconds of native segmentation calls without recomputing them. Additional policy evaluation totals range from 0.77 to 1.24 seconds across 480 outputs per new method. These are separate shared neural and added policy costs, not full-pipeline RTF; ASR, capture, I/O and target-device overhead remain outside these totals. Modeled availability includes the recorded neural lane costs, not a calibrated end-to-end measurement.

All 2,880 six-profile outputs and 960 diagnostic control outputs are present.

| Profile | Tap | cpWER, complete nonempty | Unknown sole support | Mixed-identity fraction of known support | Return consistent / inconsistent / unknown |
|---|---|---:|---:|---:|---|
| B0 | O0 | 58.73% | 18.73% | 1.98% | 111 / 108 / 73 |
| B0 | O1 | 61.74% | 18.80% | 1.97% | 96 / 118 / 78 |
| R1_voice_time | O0 | 65.06% | 25.51% | 1.54% | 54 / 76 / 162 |
| R1_voice_time | O1 | 65.08% | 26.33% | 1.70% | 45 / 88 / 159 |
| R2_angle_diagnostic | O0 | 59.18% | 62.10% | 8.15% | 39 / 8 / 245 |
| R2_angle_diagnostic | O1 | 59.92% | 61.50% | 8.49% | 43 / 9 / 240 |
| R3_sustained_angle | O0 | 64.59% | 25.07% | 1.42% | 53 / 78 / 161 |
| R3_sustained_angle | O1 | 64.86% | 25.99% | 1.54% | 42 / 88 / 162 |
| R4_decaying_memory | O0 | 63.28% | 25.13% | 1.43% | 51 / 95 / 146 |
| R4_decaying_memory | O1 | 64.16% | 25.73% | 1.57% | 47 / 95 / 150 |
| R5_reliability_adaptive | O0 | 62.83% | 25.05% | 1.39% | 53 / 91 / 148 |
| R5_reliability_adaptive | O1 | 64.39% | 25.67% | 1.48% | 47 / 93 / 152 |
| CONTROL_ONE_PERSON | O0 | 71.68% | 0.00% | 30.93% | 292 / 0 / 0 |
| CONTROL_ONE_PERSON | O1 | 72.47% | 0.00% | 30.93% | 292 / 0 / 0 |
| CONTROL_ALL_UNKNOWN | O0 | 71.68% | 100.00% | unavailable | 0 / 0 / 292 |
| CONTROL_ALL_UNKNOWN | O1 | 72.47% | 100.00% | unavailable | 0 / 0 / 292 |

Complete-reference short turns, using whole native clip duration bins:

| Profile | Tap | <1 s: known modal / all turns | 1-<2 s: known modal / all turns |
|---|---|---:|---:|
| B0 | O0 | 30 / 40 | 32 / 34 |
| B0 | O1 | 33 / 40 | 32 / 34 |
| R1_voice_time | O0 | 27 / 40 | 31 / 34 |
| R1_voice_time | O1 | 32 / 40 | 31 / 34 |
| R2_angle_diagnostic | O0 | 16 / 40 | 15 / 34 |
| R2_angle_diagnostic | O1 | 19 / 40 | 16 / 34 |
| R3_sustained_angle | O0 | 27 / 40 | 31 / 34 |
| R3_sustained_angle | O1 | 32 / 40 | 31 / 34 |
| R4_decaying_memory | O0 | 28 / 40 | 32 / 34 |
| R4_decaying_memory | O1 | 31 / 40 | 30 / 34 |
| R5_reliability_adaptive | O0 | 28 / 40 | 32 / 34 |
| R5_reliability_adaptive | O1 | 30 / 40 | 31 / 34 |
| CONTROL_ONE_PERSON | O0 | 40 / 40 | 34 / 34 |
| CONTROL_ONE_PERSON | O1 | 40 / 40 | 34 / 34 |
| CONTROL_ALL_UNKNOWN | O0 | 0 / 40 | 0 / 34 |
| CONTROL_ALL_UNKNOWN | O1 | 0 / 40 | 0 / 34 |

A known modal label is coverage, not correct identity. On O1 subsecond turns, R5 falls from R1’s 32/40 known modal labels to 30/40 despite its aggregate cpWER improvement. On O0 it rises from 27/40 to 28/40. Thus the modest aggregate gain does not establish short-reply benefit. All missing/unassigned turns remain in the denominator.

Actual operation counts across all reference scene/tap outputs:

- R1_voice_time: 0 provisional splits, 0 merges, 0 forward revisions.
- R2_angle_diagnostic: 0 provisional splits, 0 merges, 0 forward revisions.
- R3_sustained_angle: 244 provisional splits, 0 merges, 0 forward revisions.
- R4_decaying_memory: 258 provisional splits, 1 merges, 1 forward revisions.
- R5_reliability_adaptive: 230 provisional splits, 0 merges, 0 forward revisions.


Tracking integrates actual first-decision states over integer sample
intervals and estimated source support. It removes other simultaneously
active source supports from sole-speaker diagnostics, expires old states
0.75 seconds after input end, and preserves unavailable alignment and every
short/unassigned turn. “Mixed identity” counts known support outside each
predicted label's dominant reference identity. Fragmentation and returns are
reported separately. This is not DER, named identity, or exact phonetic
timing. Incomplete environmental mixtures retain limited known-target
diagnostics and are excluded from complete-reference identity pooling.

cpWER groups actual final text by predicted label and uses one global
assignment. Empty references keep WER undefined. One-person and all-unknown
controls expose degenerate continuity/abstention: their combined unknown and
conflation fixture must fail. No opaque total score chooses a winner; use the
separate lexical, attribution, coverage, return, latency and cost columns.

## Verification and handoff files

`CUE_TEST_RECEIPT.json` records 41 fixture tests and 60 actual-feature policy trials over 12 selected outputs. Empty-feature test cases remain explicit. The checks cover cache dependencies, different future suffixes, truth renaming, stale/missing/reordered metadata, two host chunk patterns, unique evidence, linear angles, bounded state, and real forward lineage.

`CUE_PROVENANCE_RECEIPT.json` records PASS across 240 physical captures and 534,288 raw telemetry rows. It checks accepted-capture flags, continuous frame ranges, copy-completion chronology, per-field reply counts and sanitized-input hashes. `CUE_CODE_ARCHIVE.json` resolves the exact extraction source bytes recorded by the smoke and bulk feature receipts; their numerical feature functions are identical. A rejected Windows line-ending archive attempt is preserved but never used as executable or selected source.

`CUE_REFERENCE_COVERAGE_PARITY.json` records PASS: all 777 inserted utterances remain in every method/tap, producing 12,432 turn rows and identical summed short-bin coverage. All 2,880 reference outputs preserve native final word sequences. All 480 B0 cpWER results exactly match the independent original-setting scorer. `CUE_OBSERVED_REVISIONS.json` preserves the one observed forward revision (R4, S45_11_12, O1), including its preceding immutable decision; revised identity correctness is not inferred.


Compact tables: `REFERENCE_PROFILE_RESULTS.csv`, per-scene and per-turn
results, `REFERENCE_SHORT_TURN_RESULTS.csv`, `CUE_RELIABILITY_SUMMARY.csv`,
population strata and adverse examples. Receipts bind all local artifacts.
Full event traces and vectors remain local and are not handoff ZIP contents.
`README_S6A_CUES.md` gives exact PowerShell, Anaconda Prompt and Command Prompt
commands, inputs, outputs, cache/resume behavior, and rollback.

This sub-study does not select a production configuration, prove causal
population benefit, or qualify CM5. S6B should preserve the voice-only
fallback and test supported component interactions with matched cue-off
parents, including short/overlap evidence, commit/revision timing, direction
persistence and persistent wrong cues. The independent real-conversation
validation remains later work.
