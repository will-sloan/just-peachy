# Evidence versions and provenance

This guide separates current S6A results, reused observations and preserved intermediate work. Read the final `START_HERE.md` and `S6A_JOINT_REPORT.md` first. Source names and paths in a historical receipt describe the bytes at that time; a path now containing revised application code is not automatically evidence that the old run used that revision.

## Authoritative results

| Claim | Authoritative evidence | Scope |
|---|---|---|
| All original-setting baseline outputs and exact old-score parity | `BASELINE_SCORE_RECEIPT.json`, `baseline_results/AGGREGATION_RECEIPT.json` and their bound results | 480 outputs; 360 prior S5 numerical/population matches plus120 newly completed original-setting outputs |
| Baseline source identity, words, schedules and coverage | `TRANSCRIPT_COVERAGE_RECEIPT.json`, `TRANSCRIPT_COVERAGE.csv`, local `support/FROZEN_SUPPORT_INDEX.json` | All240 scenes and777 intentional utterances; incomplete environmental speech stays unknown |
| Actual component comparison | `PROBE_JOB_MANIFEST_V2.json` locally; final `PROBE_ANALYSIS_RECEIPT.json`, `COMPONENT_PROBE_RESULTS.csv`, `JOINT_FACTORIAL_RESULTS.csv` | Ten fixed profiles ×36 fixed scenes ×two taps,720 native outputs; use `probe_metrics_v4` scores |
| Paired effects, short-turn evidence and lineage | `probe_results/PROBE_REPORT_RECEIPT.json` and its tables | Same output pairs and explicit population denominators; native model/event evidence is retained locally |
| Exact six reference profiles and degenerate controls | `REFERENCE_PROFILE_RECEIPT.json`, `CUE_REFERENCE_HANDOFF.md`, `CUE_REFERENCE_COVERAGE_PARITY.json` | 2,880 reference outputs plus960 controls; fixed baseline words and exact shared upstream vectors |
| Physical directional evidence | `CUE_PHYSICAL_INTEGRITY.json`, `CUE_FOUNDATION.json`, reliability CSVs | One physical trace per scene,240 traces; paired taps are not independent sensor recordings |
| Current application interfaces | `COMPONENT_API_TESTS_V2.json`, `COMPONENT_MAP.md`, `PARAMETER_BINDINGS.json`, `COMPONENT_PLUMBING_RECEIPT.json` | Actual supported optional controls; graph constraints and unsupported interfaces remain explicit |
| Controlled paced desktop costs | `RUNTIME_EXPERIMENT.json`, `RUNTIME_RESOURCE_NOTES.md` | Four V2 runs with numeric pools explicitly limited; separate from accelerated four-worker panel throughput |
| Causal and cache checks | `CAUSALITY_DELIVERY_RECEIPT.json`, cue fixture/real-feature receipts, `NATIVE_CACHE_MUTATION_RECEIPT.json`, `PROBE_RESUME_GUARD_TESTS.json` | Distinct actual neural, cached-policy and native completed-result checks; each has its stated boundary |
| Future research choices | `design/IDEA_REGISTRY_EXTENDED.json`, S6B plan, target ledger and independent reviews | Design proposals and structural/API checks; S6B execution and target-device qualification are not results of S6A |
| Final closure and package integrity | `FINAL_COMPLETION_AUDIT.json`, `LOCAL_ARTIFACT_INDEX.json`, ZIP `HANDOFF_MANIFEST.json`; adjacent `PACKAGING_RECEIPT.json` | Final evidence hashes, complete counts, process ownership, member hashes, CRC and payload limits |

## Preserved revisions

The current run is `20260909T202250Z`. `execution_contract.json` binds the original application snapshot and baseline inputs. The S0/S2 canonical RIRs, accepted S4.5 v2 recordings and old S5 report roots remain unchanged. The former180/60 split remains historical metadata after all240 were authorized; it is not an unseen holdout.

The first48 completed native component jobs use the older `probes` namespace. They were closed and excluded after review found that displayed overlap could follow the latest accepted non-overlap embedding instead of a separate segmentation history. `PROBE_V1_CLOSURE.json` and `staging/s6a/20260909T202250Z/probe_revision_v1/ARCHIVE_RECEIPT.json` preserve the old code, receipts and output locations. The ten profile settings and selected panel were unchanged. Those48 outputs must not be added to the final720 or treated as failed V2 runs.

The corrected comparison uses `probes_v2`. Its initial two-worker invocation stopped gracefully after118 valid outputs so four workers could resume after baseline completion. `PROBE_WORKER_ALLOCATION.json`, the archived two-worker receipts under `staging/s6a/20260909T202250Z/probe_invocations`, and the final guard/coordinator/cleanup receipts describe both resource epochs. Reusing those118 identical results is not a new numerical experiment or a changed profile. Final native identities remain unchanged across the resume.

Earlier interim component score namespaces remain preserved. The final namespace is `probe_metrics_v4`: it includes EOF tail/drain ASR cost, explicit missing memory values and shared source-support scoring. Interim unmatched factorial estimates are suppressed. `staging/s6a/20260909T202250Z/probe_analysis_v3/ARCHIVE_RECEIPT.json` identifies the previous analysis source. Final tables do not pool older metric versions.

`RUNTIME_EXPERIMENT_V1_LIBRARY_DEFAULTS.json` preserves four earlier paced observations with numeric library pools left at defaults. Thread/private-commit differences between V1 and V2 include environment and implementation changes and are not an isolated thread-setting effect. Use the controlled V2 matched experiments for their declared comparisons.

`COMPONENT_PLUMBING_RECEIPT_V1.json` and `COMPONENT_PLUMBING_RECEIPT_V2_PRE_RUNTIME.json` are historical snapshots. `COMPONENT_PLUMBING_RECEIPT.json` and `COMPONENT_API_TESTS_V2.json` are authoritative for the current implementation. Intermediate API aliases are excluded from the compact ZIP to reduce ambiguity; their original local files remain preserved.

## Preflight corrections and operational events

Preparation added missing source-alignment evidence for the previously deferred60 scenes without changing raw audio. An initial scorer guard mismatch and a transient hash mismatch during unfinished metadata repair were corrected before final metrics. Exact S5 tuple/list assignments were canonicalized as JSON for parity comparison; numerical values were not changed to force agreement. `SCORER_PREFLIGHT_CORRECTION.json`, `METRIC_DERIVATION.json` and staging archives retain those operations.

Two owned helper processes were observed in a Windows suspended state. One timed out without progress and was terminated after matching PID and creation time; the other resumed and completed the metadata repair. `PREFLIGHT_HELPER_TIMEOUT.json` records the first. Their cause was not established. No global services, security settings, drivers or unrelated processes were changed.

The supported component resume entry point is `s6a_probe_resume.py`. It verifies full bytes for every declared dependency before invoking the frozen native runner. The original internal completed-result path assumes those declared dependencies remain immutable; its cache mutation tests alone did not close the unchanged-size/mtime content gap. The wrapper and nine additional guard cases cover that gap at invocation boundaries. They do not protect against an authorized dependency edit made concurrently after verification. No dependency may be edited while its jobs run.

## Finite hash dependencies

Final analyses and design outputs are upstream of component maps/plumbing; the required-validation audit then binds those completed artifacts. Plumbing records only an informational path to the downstream audit. This avoids circular hashes that could never simultaneously verify.

The design's exact component-document inputs are preserved under `design/component_inputs/`. It binds those immutable copies rather than a mutable final plumbing report that would in turn bind the completed design. Current root component maps remain the human-facing authority; the copies show the precise document versions used by the design builder.

`CUE_COMPLETION_CHECK.json` separately rehashes the complete frozen cue/feature/reference evidence and declares the few historical source-path resolutions through the B0 and extraction-code archives. It is not regenerated merely to change wording in unrelated final documents. The final package gate rechecks its compact index and current included artifact bindings.

`LOCAL_ARTIFACT_INDEX.json` lists packaged source bindings and local-only manifests. `HANDOFF_MANIFEST.json` hashes ZIP members. `PACKAGING_RECEIPT.json` is stored beside the report and outside its own ZIP so the archive does not attempt to hash itself recursively. A final package status means the bounded S6A checkpoint is complete; it does not make the proposed S6B profiles, live latency calibration or CM5 deployment complete.
