# Next-stage inputs — S6A to the later joint comparison

Run: **20260909T202250Z**  
S6A status: **COMPLETE_S6A_JOINT_WITH_LIMITATIONS**

This document is the machine/human context boundary for the next ChatGPT-generated Codex prompt. S6B remains proposed and unexecuted. The current pack authorizes inference-time component and orchestration changes in named candidates while preserving model families/weights and an exact original H2 control. Older statements that froze every H2 threshold or allowed only O0 do not override that new scope.

## 1. Local roots and source authority

| Role | Exact local path |
|---|---|
| Repository | C:\Users\amiri\Documents\GitHub\just-peachy |
| Actual H2 package | C:\Users\amiri\Documents\GitHub\just-peachy\Software Validation from Datasets\Evaluation Tool\app\edge_speech_pipeline |
| Simulation | C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation |
| S6A reports | C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6A\20260909T202250Z |
| S6A staging/snapshot | C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s6a\20260909T202250Z |
| S6A large payload | G:\Just_Peachy_S6A\20260909T202250Z |
| Original physical capture payload | G:\Just_Peachy_S4_5\20260909T031300Z |
| Existing S5 gained/native outputs | G:\Just_Peachy_S5\20260909T130308Z\h2 |
| Dataset root | C:\Users\amiri\Documents\GitHub\just-peachy\Software Validation from Datasets |
| Current single Word master | C:\Users\amiri\Downloads\XVF_Measurement_V14.docx |
| Revised S6 pack | C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\Just_Peachy_S6_Joint_Pipeline_Pack_V2\Just_Peachy_S6_Joint_Pipeline_Pack_V2 |

The next pack prompt is **prompts/Codex_S6B_Joint_Component_and_Cue_Comparison.md**, read together with USER_SCOPE_OVERRIDE_V4.json, S6_JOINT_RESEARCH_CONTRACT.md and this analyzed handoff. This is a pointer for later reviewed execution, not an instruction to launch B while reading A.

Important immutable input identities:

| Input | Relative path under simulation, unless noted | SHA256 |
|---|---|---|
| 240-scene bank | scene_bank/s45_v2_20260909T031300Z/SCENE_MANIFEST.json | 69131a703ffc631b461bbf3c46c12de50ecdae2afd77d357d61c72ebf306fd18 |
| Canonical RIR manifest | rir_library/v1/RIR_MANIFEST.json | 468b2b306f994937a7d02db611080d38c7a4bcc7dc89ce7dc73d93762380f546 |
| Revision 14 workbook | C:\Users\amiri\Downloads\XVF_Measurement_V14.docx | 1307fd03f8772a99f5542bfaafa23c8b73527111b7bdb8864eaa1c73505442c3 |

Use execution_contract.json, JOB_MANIFEST.json, PROBE_JOB_MANIFEST_V2.json and LOCAL_ARTIFACT_INDEX.json for complete path/hash chains, including large local-only manifests. The exact original B0 application is the staging **baseline_app/edge_speech_pipeline** snapshot, not the current mutable application tree. Old source bindings can refer to paths now containing candidate code; resolve the declared B0/extraction archives rather than silently rebinding an old result to current bytes.

## 2. Completed evidence and open result slot

- Baseline: 480 original-setting scene/tap outputs; 360 S5 numerical/population matches and 120 newly completed native outputs. BASELINE_SCORE_RECEIPT.json and baseline_results/AGGREGATION_RECEIPT.json bind scoring and aggregation.
- Sources: 777 inserted utterances; TRANSCRIPT_COVERAGE.csv and TRANSCRIPT_COVERAGE_RECEIPT.json preserve source identity, original/normalized text, native duration/crop/schedule and all reference populations.
- Cues: 240 physical traces, 534,288 received telemetry rows; CUE_FOUNDATION.json, CUE_PHYSICAL_INTEGRITY.json and CUE_DELIVERY_INDEX.json bind physical analyses and predictor-facing delivery.
- References: 480 exact accepted-feature outputs, 15,649 real ReDim vectors, 2,880 six-reference outputs and 960 degenerate controls. REFERENCE_PROFILE_RECEIPT.json and CUE_REFERENCE_COVERAGE_PARITY.json bind all tables and zero B0-label/metric mismatches.
- Native component panel: 36 frozen scenes × ten profiles × two taps. **720/720 V2 outputs complete and scored; zero failed jobs; all 72 P0X0/B0 normalized word sequences match**
- Resource/prefix: RUNTIME_EXPERIMENT.json is the controlled V2 paced screen; CAUSALITY_DELIVERY_RECEIPT.json records real neural prefix/delivery checks. V1 library-default observations remain separately identified.

On the native panel, P1X0 lowers final-label cpWER versus P0X0 by 18.421 points on O0 and 10.646 on O1 while primary WER stays13.562%. However, the two subsecond turns lose known modal-label coverage from 2/2 on each tap to 1/2 O0 and 0/2 O1, and mixed-identity support increases. The advisory cue route adds2/4 primary word errors (0.298/0.596 points) and worsens matched cpWER. Soft energy assistance activates 465 times per tap and modestly improves support coverage without changing pooled WER/cpWER. These are measured tradeoffs, not a selected production configuration; see the detailed report and paired tables.

At original settings, O0 primary WER is 14.386% versus O1 15.461%; complete-overlap MIMO-WER is 33.379% versus 34.478%. Both taps remain eligible. The R5-versus-R1 reference cpWER gains of 2.227/0.682 points coexist with an O1 subsecond known-modal coverage loss, 32 to 30 of 40. Do not promote a candidate using one aggregate metric.

For per-condition details use baseline_results/STRATIFIED_TEXT.csv, paired uncertainty and support tables; REFERENCE_PROFILE_RESULTS.csv, REFERENCE_PROFILE_SCENE_RESULTS.csv, REFERENCE_PROFILE_TURN_RESULTS.csv and REFERENCE_SHORT_TURN_RESULTS.csv; COMPONENT_PROBE_RESULTS.csv, JOINT_FACTORIAL_RESULTS.csv and probe_results/PAIRED_SCENE_DELTAS.csv. Keep their own population and completion fields authoritative. Final result-dependent conclusions above must agree with the final 720 receipt.

## 3. Exact control and measurement contract

**B0** preserves the historical implementation, checkpoint hashes, original settings and original native labels. **P0X0** is a research candidate using original neural settings with a new anonymous tracker. It does not replace B0. Reference R1 is the matched new voice/time parent for spatial policy comparisons.

O0's scalar **1.4125375446227544** is applied once; O1 uses unity. A gained FLOAT adapter or native PCM16 journal already includes this recipe and is consumed at unity. A new gain is a named input intervention with new descendants. Do not apply the prior physical mic gain 10, SYS_DELAY −32 or RIR 800-sample/50-ms origin again.

All 240 scenes are authorized exploratory evidence. Preserve historical 180/60 fields without calling former reserve scenes unseen. Scored populations are 156 complete non-overlap, 47 complete overlap, 26 incomplete environmental references and 11 empty controls. Keep missed and unknown turns. Incomplete ambient speech is not a complete-reference identity population; empty WER is undefined.

Only approved original CMU ARCTIC, HiFiTTS, Common Voice and the existing environmental/MUSAN policy are included. No L2-ARCTIC or DEMAND is assumed. Preserve source rights, actual quality labels and hashes. Loeb Caf and canonical RIR JPXVF_P1_R02_T01_D01_S02_F00_NAT_CU_R13 remain excluded; Upper Loeb is included. Existing canonical eligibility remains the authority for pass/review versus testing/retake.

The 39 used RIRs are a subset of 120 eligible paths. Validated effective distances are 0.46–4.07 m. Keep the two user-confirmed 1.00 m overlays without overwriting raw 100 m entries. Metadata sign/projection agreement is not an independent physical angle-sign measurement. Native folded direction has distinct 0/180 endpoints; a beam is not a person, and ±5 degrees is source-label uncertainty.

## 4. Implemented interfaces and important limitations

COMPONENT_MAP.md and PARAMETER_BINDINGS.json bind actual consumers, comparators, ranges, graph/front-end constraints and tests. The effective profile files under profiles/ are authoritative. The research CLI is explicit opt-in; the GUI default was not switched. Omit the research flag for the ordinary current path, and use the archived B0 launcher for the scientific original control.

- **Pyannote:** fixed [1,1,160000] waveform input; [1,589,7] powerset log-probabilities. Local slots are not persistent identities. Baseline hard argmax fractions use 0.20 tail gates; nominal onset/offset do not affect that old policy. Supported posterior hysteresis is a wrapper change; a shorter graph input or arbitrary frame mask is unsupported.
- **ReDim:** actual PalabraAI ReDimNet2-B2, 192-dimensional normalized vectors and inspected checkpoint frontend. Duration/cadence/purity changes must use real corresponding waveforms. RMS currently reads the dispatch block, so cadence and RMS support interact. Use interval union for unique evidence.
- **Sherpa:** original encoder/decoder/joiner weights and installed online API; 39 feature frames/32-frame decode chunk differs from 50/100-ms host reads. Changed endpoint/reset histories require actual stateful ASR. A tentative speaker change alone does not reset recognition.
- **Cue routes:** the P0/P1 factorial X route combines tracking with possible silence-qualified endpoint advice. SEG_X1 adds soft energy assistance separately. Component P is also a bundle, not an isolated threshold intervention.
- **Tracking:** anonymous IDs, bounded prototypes/state and explicit forward lineage are implemented. A 1.0-second initial embedding immediately satisfies the 1.0-second commitment threshold and prevents the provisional reconciliation path. Actual transcript labels remain first labels; tracker revisions are not rewritten GUI text.
- **Clocks:** source, callback receipt, receptive context, model compute and wall time remain separate. New reference policies use conservative serial modeled availability; original B0 retains historical source-cursor attribution. Actual accelerated native first labels can depend on cross-worker history. Do not call these calibrated live latency or exact word-speaker timing.

Unknown fields and specified unsupported/no-op combinations are rejected. Effects remain mode-dependent; parser acceptance alone does not prove a new mechanism has executed. Separate mathematical extensions in design/S6B_JOINT_PLAN.json are explicitly unimplemented even when their native foundation validates.

## 5. Cache, provenance and required checks

Cache reuse requires exact audio/rate/channel/gain, weights, frontend/spans/context, inference settings, provider/numeric mode, code, telemetry/delivery and availability semantics. Tracker-only changes may reuse exact vectors plus added policy compute. New waveforms/spans require new vectors; changed stateful ASR history requires recognition from the corresponding delivered audio, not relabeling old text. Runtime claims need fresh timing even when numerical parity passes.

NATIVE_CACHE_MUTATION_RECEIPT.json records one exact actual reuse plus 28 identity/stale-key rejections. PROBE_RESUME_GUARD_TESTS.json records nine checks, including seven byte mutations with unchanged size/mtime/manifest. The public resume wrapper rehashes every declared dependency before runner entry. Dependencies must remain immutable afterward; this is not a file-lock guarantee or a minimal optimized DAG cache.

Review COMPONENT_API_TESTS_V2.json, COMPONENT_PLUMBING_RECEIPT.json, CUE_FIXTURE_TEST_RECEIPT.json, CUE_REAL_FEATURE_CAUSALITY.json, CAUSALITY_DELIVERY_RECEIPT.json, design/INDEPENDENT_EOF_REVIEW.json and design/PROBE_COMPARISON_AUDIT.json. Preserve different-future, truth-rename, stale/missing/reordered/old-source-redelivery, gain, exact sample delivery and empty/one-person controls in B. Wrong first labels retain their exposure even if revised later.

The first 48 V1 native component completions are preserved and excluded after the overlap-display correction. PROBE_V1_CLOSURE.json identifies their archive. Use frozen V2 receipts, not a mixture of implementations. Derived scorer corrections have their own preserved namespaces. No blanket process termination, source cleanup or old-receipt overwrite is part of resumption.

## 6. Local inspection and resumption

These commands target the existing local repository, not a standalone extracted ZIP. Existing environments are already available; do not install a new framework to read or resume evidence.

PowerShell:

~~~powershell
$s6Sim = 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
$s6Report = Join-Path $s6Sim 'reports\S6A\20260909T202250Z'
Set-Location (Join-Path $s6Sim 'scripts')
& 'C:\Users\amiri\anaconda3\python.exe' .\s6a_probe_resume.py --verify-only
~~~

Anaconda Prompt or Windows Command Prompt:

~~~bat
set "S6SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
set "S6REPORT=%S6SIM%\reports\S6A\20260909T202250Z"
cd /d "%S6SIM%\scripts"
"C:\Users\amiri\anaconda3\python.exe" s6a_probe_resume.py --verify-only
~~~

Verify-only rehashes declared files and writes a new guard receipt; it does not run models. If the final checkpoint is PARTIAL_RESUMABLE and the coordinator/owned workers have closed, the same public entry point with **--workers 2** resumes the frozen 720 manifest. It honors STOP_REQUEST.json and existing coordinator ownership; do not remove a stop marker or change active inputs merely to force progress. Inspect preserved failures first. A fully complete checkpoint needs no native rerun.

The existing EDGE environment is **C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe**. Text-metric scoring uses **simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe**. Maintained README_S6A*.md files under simulation/scripts document exact baseline, analysis, reference, probe, guard, test and packaging inputs/outputs. Follow their supported commands and final namespaces rather than reconstructing invocation flags from prose.

## 7. Finding-driven S6B design

The 30-profile plan groups expensive work into eight feature/ASR recipe families, then tests meaningful policy variants. B00 is exact B0; other rows contain a valid native base and any separate prospective extension. Do not run a base alone and claim its missing extension was evaluated. Keep both same-settings cue ablations and original-versus-tuned controls.

Prioritize short-reply coverage and wrong-label exposure; duration × commitment × revision horizon; RMS/gain × eligibility; cadence × prototype thresholds; direction persistence × endpoint advice; stable wrong cues and voice-only recovery; memory decay × return; decoder/chunking × actual queues; and tap/segmentation/embedding alignment. A split ASR/embedding tap requires a real aligned route and is not established by comparing whole-tap O0 and O1 runs. Do not freeze broad B/C ranges around a single A score.

Measure the first balanced pilot for every expensive recipe before admitting the full bank. The design's historical 15.013 s/job, approximately two serial hours per 480 original-cost jobs and 16 hours for eight such equivalents are planning references, not guaranteed throughput. B has its own 24-hour invocation budget with at least 45 minutes for reporting. Retain atomic complete/failed/pending counts; do not silently narrow to easy cases when time runs short.

Refresh SSD free space and active process ownership before any later admission. The pack's new-output cap is 120 GiB, with at least 50 GiB free on C: and 75 GiB on G:, or a safer existing reserve. Bound the research worker count and inner numeric pools, initially cap research RAM at 40 GiB and preserve OS headroom. Use one owning coordinator per run namespace, creation-time checks for owned cleanup, atomic receipts and visible throughput/ETA. These are research controls, not the CM5 deployment process layout.

Target design remains CM5 CPU/ARM64, 2 GB total RAM, 32 GB eMMC, no wireless/GPU dependency. Use one resident model set and shared ReDim, bounded state and an explicit logging/journal retention policy. Model/token disk payload is 219,771,544 bytes, distinct from runtime memory. Mono 16 kHz PCM16 writes 115.2 MB/hour before logs; a proposed 1 GiB audio cap lasts 9.32 hours before logging. Controlled desktop USS/RSS/private-commit/write measurements are in the ledger. Target OS/UI/driver headroom, ARM64 parity, queues, thermals and physical eMMC writes/endurance remain untested.

General-use candidates retained after B/C require all 240 confirmation on both taps where applicable, separate accuracy/attribution/coverage/latency/resource columns and later independent real-conversation validation. No neural weight training, new model families, firmware/driver changes, hardware transport or automatic Git publication is implied by this handoff.

## 8. Workbook and package handling

Use WORKBOOK_UPDATE.md as reviewed yellow insertion text in Revision 14. Keep one master; do not create a parallel Word planning guide. The compact ZIP carries analysis, exact touched code/configs, tests and readable figures, while audio, full vectors, models and full native logs stay local.

The final FINAL_COMPLETION_AUDIT.json and PACKAGING_RECEIPT.json establish closure and archive integrity. HANDOFF_MANIFEST.json binds the ZIP members; LOCAL_ARTIFACT_INDEX.json retains exact larger-artifact locations. The archive target is 10 MiB, maximum 20 MiB, with at most six scientific plots.
