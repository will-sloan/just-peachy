# Paced runtime resource findings

The controlled V2 study completed four full native 89.390875-second sessions with zero dropped audio. Each produced five final utterances, 119 segmentation calls and 44 real embeddings. The audio was identical across settings. The exact receipts are RUNTIME_EXPERIMENT.json and staging/s6a/20260909T202250Z/runtime_cpu_v2/MANIFEST.json. Frozen V2 application code and all model weights were unchanged during these jobs.

| Model threads | ASR dispatch | Sampled CPU seconds | Peak private resident USS | Peak RSS sum upper bound | Peak Windows private commit | Peak OS tree threads | Writes per audio second |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | 100 ms | 19.56 | 383.03 MiB | 440.90 MiB | 416.01 MiB | 28 | 50,049 bytes |
| 2 | 100 ms | 60.20 | 385.16 MiB | 443.47 MiB | 418.08 MiB | 33 | 50,051 bytes |
| 2 | 50 ms | 62.63 | 384.53 MiB | 442.84 MiB | 417.60 MiB | 33 | 57,244 bytes |
| 1 | 50 ms | 21.42 | 383.84 MiB | 441.71 MiB | 416.83 MiB | 28 | 57,106 bytes |

ASR source backlog peaked at 0.10 seconds and speaker backlog at 0.30 seconds. These are sampled cursor differences, including ordinary block cadence, rather than measured speech-to-display latency. No sustained queue growth appeared in this 89-second workload. Source duration and final ASR cursor matched exactly. Startup took 2.07–3.04 seconds; whole-session elapsed time was 92.33–93.20 seconds. The host retained at least 44.39 GiB available RAM while other S6A jobs ran. This measured desktop result does not qualify multi-hour behavior or CM5 throughput/thermal limits.

USS means unique private resident pages across the complete application process tree. RSS sums are an upper bound because shared pages can be counted repeatedly. RSS minus USS gives a nonunique estimate of shared resident pages, approximately 57.9–58.3 MiB here. Proportional shared memory (PSS) is unavailable on this Windows host. Windows private commit is committed virtual memory, not physical resident RAM; it must not be substituted for RAM in a 2 GB deployment budget. The small hidden Windows conhost child is included. The external research coordinator is sampled separately and excluded from the application totals.

All four worker processes, their four conhost children and the coordinator were verified closed by PID plus creation time in runtime_cpu_v2/OWNED_CLOSURE_AUDIT.json. No unrelated process was stopped.

## Thread accounting

OMP_NUM_THREADS, OPENBLAS_NUM_THREADS, MKL_NUM_THREADS and NUMEXPR_NUM_THREADS were explicitly set to 1 before imports. These limits and the model thread parameters are not a cap on total operating-system threads.

At representative peak samples the Python application had 26 OS threads for model setting 1 and 31 for setting 2; the hidden conhost child contributed two. Existing code creates the main Python execution thread plus wav-source, edge-asr, edge-speaker and edge-session-watcher. The error-cleanup thread is conditional and was not required in these successful sessions. File playback does not use the microphone audio-normalizer.

The code gives each of the two direct speaker ONNX sessions an explicit intra-op count and inter-op=1 with sequential execution. Sherpa receives the configured ASR thread count for its encoder/decoder/joiner and a separate fixed one-thread punctuation configuration. The observed five-thread increase is consistent with the three ASR graphs plus two speaker graphs each gaining an additional worker, but this is an inference from configuration and aggregate counts. Per-thread native names, stack origins, CPU activity and allocation lifetimes were not recorded. The remaining native/runtime threads cannot be reliably assigned to specific permanent or active pools from these samples. Idle OS thread count must not be interpreted as simultaneous core use.

The preserved V1 library-default screen used unset numerical-library limits and observed 58/63 total OS threads. It also predates the V2 overlap-display fix and model-loading instrumentation. Therefore V1/V2 differences cannot be attributed solely to pool settings. The exact V1 runner and README remain under runtime_cpu_v1/EXECUTED_V1_*. V2 is the controlled comparison used above.

## Numerical and delivery checks

Every thread/dispatch pair produced identical native PCM16 and exact final utterance text. Across one versus two model threads, all 44 matched embedding vectors differed by at most 9.09e-7 per coordinate; changing dispatch alone produced identical vectors. Equality here is parity for this workload, not recognition accuracy.

The 100 ms runs delivered 894 distinct contiguous ASR spans, and the 50 ms runs delivered 1,788. Both covered exactly 0–89.390875 seconds with no duplicate spans, gaps, or overlap. Every run logged 30 native endpoint detections and five nonempty final utterances; endpoint detections include silent/empty segments. The counts and words match for this workload. Other inputs may expose differences in endpoint polling semantics.

The actual-neural prefix fixture in CAUSALITY_DELIVERY_RECEIPT.json also passed. Two fresh P1X0 engines processed the same exact 12-second prefix and different six-second futures. Through the cutoff, 18 raw partial/final events, 240 ASR dispatch decisions, 24 segmentation results, 10 actual embedding vectors, 10 tracker decisions and 18 first displayed labels matched. Vectors were exactly equal, receptive spans stayed within the prefix and the different futures changed later segmentation outputs. Both 18-second native journals exactly matched their prepared inputs.

First displayed label invariance is only an observed result of this fixture. The concurrent ASR and speaker workers can expose different already-computed histories under other scheduling interleavings. The fixture preserves that limitation and compares labels separately. Both neural workers, their conhost children and the fixture coordinator were verified closed in neural_causality_v1/OWNED_CLOSURE_AUDIT.json.

## Reproduction

Use simulation/scripts/README_s6a_runtime_profile.md for exact PowerShell and Anaconda/CMD runtime commands, inputs, outputs, limits and resume behavior. Use simulation/scripts/README_s6a_causality_checks.md for the two-file prefix and delivery check. Keep waveform files, full native event logs and speaker vectors local; the compact receipts and this analysis are sufficient for the handoff.

