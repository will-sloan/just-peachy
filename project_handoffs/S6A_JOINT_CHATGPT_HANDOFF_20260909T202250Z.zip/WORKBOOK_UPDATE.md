# Proposed yellow insertion — S6A results for the single master

**Master:** C:\Users\amiri\Downloads\XVF_Measurement_V14.docx  
**Insertion status:** text prepared for review and yellow highlighting; the Word master has not been rewritten.  
**Evidence run:** 20260909T202250Z  
**S6A checkpoint status:** COMPLETE_S6A_JOINT_WITH_LIMITATIONS

Insert this as the S6A analyzed-results update after the Revision 14 S6A plan/results section. Preserve the original planning text and prior measured results, and mark this addition yellow. This Markdown file is not a competing planning master. Use the run identity and compact handoff when following any referenced machine evidence.

## S6A purpose and completed scope

S6A tested the physical XVF3800 audio/metadata together with supported inference-time settings and orchestration inside the actual Just-Peachy H2 application. Sherpa Giga streaming ASR, Pyannote segmentation-3.0, PalabraAI ReDimNet2-B2 and final-only punctuation retain their selected weights. The original code/configuration remains B0; optional named candidate profiles may differ.

The existing accepted bank contains 240 scenes and 480 O0/O1 audio outputs, sharing 240 physical telemetry traces. All 777 inserted utterance references remain present. Scene populations are 156 complete non-overlap, 47 complete overlap, 26 incomplete ambient-reference and 11 empty controls. The old 180/60 split is historical only; these data are exploratory and no longer an unseen holdout.

All 480 original-setting baseline outputs are scored. The 360 prior S5 results retain exact numerical/population parity and 120 missing outputs were completed. The six reference policies contribute 2,880 results, plus 960 one-person/all-unknown controls. All 12,432 expected turn rows are retained; the sum of source-turn counts across the 11,520 short-bin rows is also 12,432.

The actual component panel requests 36 preselected scenes × ten profiles × two taps = 720 native executions. **720/720 V2 outputs complete and scored; zero failed jobs; all 72 P0X0/B0 normalized word sequences match**

## Original H2 output comparison

| Metric | Paired scenes | O0, historical +3 dB once | O1, unity | Denominator |
|---|---:|---:|---:|---:|
| Primary non-overlap WER | 156 | 14.386% | 15.461% | 4,560 words |
| Primary CER | 156 | 8.461% | 9.493% | 20,247 characters |
| Complete-overlap MIMO-WER | 47 | 33.379% | 34.478% | 1,456 words |
| Complete-reference final-label cpWER | 203 | 58.727% | 61.735% | 6,016 words |
| Incomplete ambient target-only WER, limited | 26 | 29.575% | 30.015% | 683 target words |
| Empty-control inserted words | 11/tap | 1 | 2 | 491.650 decoded seconds/tap |

O0 has 49 fewer primary word errors, 656 versus 705, and lower pooled primary WER in every observed room. O1−O0 is +1.075 percentage points. A 2,000-replicate paired within-room bootstrap over 116 whole matched blocks gives a conditional 95% interval of [+0.373, +1.807] points. Shared speaker/source/text/RIR/noise dependencies connect all 156 primary scenes; the interval is not independent population evidence.

Empty-reference WER remains undefined; the rates are 0.122 and 0.244 inserted words/minute. O1 has 2,027 PCM16 rail samples versus none on O0. This level diagnostic does not establish clipping as the cause of any recognition difference.

O0 has 7,502 accepted baseline embeddings and O1 has 8,147. Their unique within-output evidence is 2,136 and 2,264 seconds, whereas overlapping processed windows total 3,751 and 4,073.5 seconds. Repeated windows are not independent identity evidence. Both taps remain in later joint trials because output preference can change with component settings.

## Physical directions and reference tracking

Selected processed direction is usable for 92.31% of estimated source support among 545 complete-reference non-overlap utterances, but occupies the expected coarse sector for 45.01%. Sustained expected-sector acquisition is never observed for 282/545 under the inherited one-second/80%-occupancy metric. Across all 777 inserted utterances the usable/sector fractions are 92.25%/45.04%, and 388 never acquire that sustained sector.

These are nominal sector-association measures, not calibrated angular accuracy. Repeated wrong-sector values do not prove stale DSP data. Manual ±5 degrees is loudspeaker-position uncertainty; native 0 and 180 are distinct folded-coordinate endpoints, front/back can be ambiguous, and a beam is not a person.

Reference R1 uses new voice/time association; R2 is an angle-association diagnostic; R3 uses sustained direction proposals; R4 decaying position memory; R5 reliability-adaptive voice/location/energy. Their accepted baseline speech/embedding schedule and raw ASR words are fixed. R2 still shares upstream audio eligibility and qualified delivered-angle checks, so it is not an independent unfiltered sensor detector.

R5 versus its matched R1 parent reduces cpWER by 2.227 percentage points on O0 and 0.682 on O1. However, O1 subsecond known-modal coverage falls 32/40 to 30/40; O0 changes 27/40 to 28/40. A known modal label is coverage, not correct identity. R2 has approximately 62% unknown support despite superficially competitive cpWER. One-person output has 30.93% mixed-identity sole support; all-unknown has 100% unknown support. These controls cannot be selected as successful trackers.

Original B0 and new replay trackers use different availability conventions: historical native source-cursor attribution versus serial modeled availability. Their differences do not isolate tracker quality. Matched new cue-on/cue-off comparisons share the latter convention.

One real forward R4 tracker revision occurs in S45_11_12/O1, with its first decision preserved. No retroactive correctness is inferred. Tracker lineage does not rewrite the native transcript/GUI labels. A 1-second embedding satisfies a 1-second commitment immediately and suppresses the provisional reconciliation path; duration, commitment and revision horizon must be tested together.

## Actual component implementation and results

Typed opt-in profiles bind real input/gain, ASR, segmentation, embedding, tracker, XVF, punctuation and runtime consumers. Unknown fields and specified unsupported/no-op combinations are rejected; mode-specific behavior remains explicit. The ordinary GUI default was not changed.

The ten panel profiles comprise the P0/P1 × X0/X1 factorial, paired posterior segmentation with/without soft energy assistance, a longer embedding window, a cadence/RMS bundle, and endpoint/dispatch variants with/without the advisory cue route. P0 is original neural settings with the new tracker; it is not exact B0. X combines spatial association with possible qualified endpoint advice. P and X effects are declared bundles, not isolated individual parameters.

On the native panel, P1X0 lowers final-label cpWER versus P0X0 by 18.421 points on O0 and 10.646 on O1 while primary WER stays13.562%. However, the two subsecond turns lose known modal-label coverage from 2/2 on each tap to 1/2 O0 and 0/2 O1, and mixed-identity support increases. The advisory cue route adds2/4 primary word errors (0.298/0.596 points) and worsens matched cpWER. Soft energy assistance activates 465 times per tap and modestly improves support coverage without changing pooled WER/cpWER. These are measured tradeoffs, not a selected production configuration; see the detailed report and paired tables.

The actual fixed Pyannote graph consumes 10 seconds and emits 589 frames of seven powerset log-probabilities. Baseline hard speech/overlap fractions use 0.20; its nominal onset/offset fields were inactive. A supported posterior wrapper makes onset/offset meaningful without changing the graph input by guesswork. Local slots are not global speakers.

The actual ReDimNet2-B2 frontend/output was verified, including real 0.5/0.75/1/1.5/2/3-second calls and 192-dimensional normalized vectors. Changed spans require new embeddings; arbitrary frame masking is unsupported. RMS uses the dispatch block, coupling cadence with evidence eligibility.

Sherpa host 50/100-ms reads differ from the exported 39-feature-frame/32-frame decode chunk. Endpoint changes run fresh stateful recognition and retain lost/duplicated words; tentative identity changes alone do not reset ASR. Raw ASR words are scored before final punctuation.

## Verification and timing limits

The V2 API suite passes 13 focused checks, six existing tests and a real-model application smoke. Reference fixtures include 41 logic tests and 60 actual-feature causal trials. A separate real neural test uses two fresh engines with the same 12-second prefix and different 6-second futures: 18 raw/display events, 240 dispatch decisions, 24 segmentation results, 10 vectors with exact full spans and 10 tracker decisions match in the prefix. Later outputs differ; this is a bounded fixture, not a universal scheduling proof.

The native completed-result suite passes one exact reuse and 28 changed-identity/stale-key rejections. Nine separate resume-guard tests include seven changed-byte cases retaining old size, modification time and supplied identities. The public wrapper hashes 225 unique declared files before runner entry; those files must remain immutable afterward.

The first 48 V1 native component completions are preserved and excluded following an overlap-display defect. V2 uses separate causal segmentation history and consistent cue flags/profile validation. Derived-score corrections preserve earlier namespaces. Failures and process identities remain in receipts rather than being deleted.

Source time, receipt/callback time, receptive context, compute availability and elapsed wall time are distinct. Accelerated first-label results can depend on worker interleaving. Reference clocks are modeled, and first-partial timestamps from file origin are not phonetic-onset delay. Neither the study nor this workbook update establishes frame-exact word attribution, named-person accuracy or full diarization DER.

## Desktop resource results and CM5 boundary

Four paced CPU runs used 89.390875 seconds of two complete concatenated native O0 journals at unity after historical gain. All retained exact samples, matching words, five finals and 44 embeddings. Dispatch-only vectors matched exactly; maximum thread-change vector difference was 9.09e-7. Observed ASR/speaker backlog maxima were 0.10/0.30 seconds with no drops.

Controlled peak process-tree USS was 383.0–385.2 MiB; summed RSS upper bound 440.9–443.5 MiB; Windows private commit 416.0–418.1 MiB. USS, RSS/shared estimates and committed virtual backing are different quantities. PSS was unavailable. Numeric pools were limited to one; observed tree thread counts were 28/33, including conhost, not merely the configured one/two model threads. V1 library-default results remain separate and also differ in application revision.

Model/token disk payload is 219,771,544 bytes, approximately 209.59 MiB. This does not equal resident RAM. PCM16 mono 16 kHz audio alone writes 115.2 MB/hour; a proposed 1 GiB audio cap fills in 9.32 hours before logs. Measured desktop process writes include research events/vectors and do not measure physical eMMC wear.

The intended CM5 design remains CPU/ARM64, 2 GB total RAM, 32 GB eMMC, one resident model set, shared ReDim and bounded state/logging. The 1.3 GiB app screen and 1.5 GiB review level are provisional. Actual ARM64 imports/parity, OS/UI/driver headroom, sustained queues, thermals, power and storage endurance remain untested. No desktop-to-Pi speed multiplier or target qualification is claimed.

## Measurement integrity carried forward

All 121 canonical RIRs remain preserved; 120 are eligible and 39 are used here. Effective eligible distances are 0.46–4.07 m, none over 5 m. The two raw 100 m Opening Behind Listener, +20°, flat/upright R05 entries retain the user's 1.00 m overlay without raw metadata changes. Pass/review eligibility and prior testing/retake exclusions remain intact.

Selected angle signs/projections match canonical metadata but cannot independently prove the original manual physical sign. Preserve the 800-sample/50-ms RIR origin once and all four-channel relationships. No new RIR extraction, XVF transport/hardware campaign, L2-ARCTIC, training or firmware change was performed for S6A.

## Proposed next stage

The registry contains all 60 seed ideas plus eight new hypotheses. The S6B design specifies 30 profiles in eight expensive recipe families, 29 parser-valid native foundations and unchanged B00. Separate unimplemented extensions remain proposals and cannot be silently dropped while claiming the candidate was tested.

S6B should preserve both taps and cue-off parents, prioritize short-turn/unknown/wrong-merge denominators, test component interactions and confirm retained general-use profiles on all 240 scenes. Use measured recipe throughput, bounded state and explicit cost/latency before expansion. Later independent real conversations are still required. S6B/C/D and full CM5 qualification have not started.

The compact S6A handoff, its exact local-artifact index and source receipts are the evidence for this insertion. Update the existing single master after review; do not create another Word guide or describe the entire S6 research program as complete.

