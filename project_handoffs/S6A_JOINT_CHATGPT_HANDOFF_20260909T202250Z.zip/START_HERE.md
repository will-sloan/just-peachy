# Start here — S6A joint XVF/H2 handoff

Run: **20260909T202250Z**  
Checkpoint status: **COMPLETE_S6A_JOINT_WITH_LIMITATIONS**

This is the analyzed S6A checkpoint for the existing physical XVF3800 scene bank and actual H2 application. The original model families and weights are preserved. Optional, named research profiles now exercise component settings and XVF cue routing inside H2. S6B/C/D, training and CM5 deployment remain later work.

## Read in this order

1. **S6A_JOINT_REPORT.md** — results, regressions, causal/metric limits, implementation corrections and final completion state.
2. **NEXT_STAGE_INPUTS.md** — exact local roots, authoritative evidence, controls, cache rules, resumption and the boundary for the next prompt.
3. **CUE_REFERENCE_HANDOFF.md** and **baseline_results/BASELINE_ANALYSIS.md** — full-bank reference tracking, physical direction quality and original-setting O0/O1 comparisons.
4. **COMPONENT_MAP.md**, **PARAMETER_BINDINGS.json**, **profiles/** and **probe_results/** — actual graph/API semantics, effective tested profiles and matched component comparisons.
5. **design/S6B_JOINT_TRIAL_PLAN.md**, **design/S6B_JOINT_PLAN.json** and **design/IDEA_REGISTRY_EXTENDED.json** — 30 proposed profiles and 68 distinct ideas; inspect unsupported extensions before implementing a candidate.
6. **design/TARGET_RESOURCE_LEDGER.md/.json** and **WORKBOOK_UPDATE.md** — measured desktop resource evidence, untested CM5 requirements and text for yellow insertion in the single Word master.

## Evidence and the main decision

| Evidence unit | Result available in this handoff |
|---|---|
| Existing scene bank | 240 accepted physical scenes; two audio taps share one telemetry trace |
| Original H2 baseline | 480/480 outputs; 360 compatible S5 results retain exact numerical/population parity; 120 missing outputs completed |
| Source references | All 777 inserted utterances retained; 156 complete non-overlap, 47 complete overlap, 26 incomplete ambient and 11 empty scenes |
| Reference policies | 2,880 six-reference outputs plus 960 one-person/all-unknown controls; all 480 B0 cpWER values match the independent scorer |
| Actual component panel | 36 preselected scenes × 10 profiles × two taps = 720 requested native outputs |
| Component completion | 720/720 V2 outputs complete and scored; zero failed jobs; all 72 P0X0/B0 normalized word sequences match |
| Runtime engineering | Four paced full-engine CPU/thread/dispatch runs; separate actual-neural prefix and delivery checks |
| Future design | 60 preserved seed ideas + eight new hypotheses; 30 proposed S6B profiles, 29 native foundations parser-validated, B00 unchanged B0 |

Under original settings, O0 at its historical +3 dB scalar has **14.386% primary WER**, versus **15.461% for O1 at unity**. The 156 paired scenes contain 4,560 reference words. O0 also has lower pooled primary WER in every observed room. This is a conditional finding on the existing bank, not a reason to remove O1 from joint tuning.

Matched reference R5 versus R1 reduces final-label cpWER by **2.227 percentage points on O0** and **0.682 on O1**, while keeping native ASR words and accepted embedding spans fixed. O1 subsecond known-modal coverage falls **32/40 → 30/40**; O0 changes **27/40 → 28/40**. A known label is coverage, not correct identity. The original B0 benchmark generally has better attribution than the new replay trackers, but their availability conventions differ; this is not an isolated tracker-quality comparison.

On the native panel, P1X0 lowers final-label cpWER versus P0X0 by 18.421 points on O0 and 10.646 on O1 while primary WER stays13.562%. However, the two subsecond turns lose known modal-label coverage from 2/2 on each tap to 1/2 O0 and 0/2 O1, and mixed-identity support increases. The advisory cue route adds2/4 primary word errors (0.298/0.596 points) and worsens matched cpWER. Soft energy assistance activates 465 times per tap and modestly improves support coverage without changing pooled WER/cpWER. These are measured tradeoffs, not a selected production configuration; see the detailed report and paired tables.

Selected processed direction is usable over **92.31%** of estimated support for the **545 complete-reference non-overlap utterances**, and occupies the expected coarse sector over **45.01%**. Stable wrong bearings remain possible. Directional confidence must be qualified, and a no-metadata voice path remains necessary. Manual ±5 degrees is geometry uncertainty, not measured XVF angular accuracy.

## Do not lose these distinctions

- **Word accuracy versus attribution versus coverage:** use separate raw WER/CER, overlap MIMO-WER, cpWER, unknown/mixed support, returns and short-turn results. Empty-reference WER is undefined. Unknown ambient words cannot be declared hallucinations solely because they lack a transcript.
- **B0 versus P0X0:** B0 is exact historical H2. P0X0 uses original neural settings with the new anonymous tracker. A cue benefit requires its same-settings cue-off parent, not just a comparison with B0.
- **Physical traces versus scores:** 480 audio outputs do not create 480 independent directional observations. Shared speakers, sources, text, rooms, RIRs and noise also induce dependence. The former 180/60 split is descriptive; it is no longer an unseen holdout.
- **Observed execution versus modeled timing:** native accelerated first labels can depend on worker interleaving. Reference availability is conservatively modeled. First-partial timestamps from file origin are not phonetic-onset latency. Tracker revisions retain earlier decisions and do not rewrite the GUI transcript.
- **Desktop versus target:** controlled paced peak USS is approximately 383–385 MiB and RSS sum upper bound 441–443 MiB. These are distinct from Windows private commit and model disk bytes. CM5 2 GB/32 GB eMMC fit, ARM64 throughput, thermals and sustained I/O remain untested.

## Existing measurement integrity

The canonical library preserves 121 RIRs, with 120 eligible and 39 used in this bank. Eligible effective distances are **0.46–4.07 m**, with none above 5 m. The two raw 100 m Opening Behind Listener, +20°, flat/upright R05 values retain the user's **1.00 m** correction overlay. Accepted pass/review records and prior exclusions remain authoritative; retake/testing measurements were not reintroduced. Angle signs and projections match canonical metadata; this cannot independently prove the original physical angle sign.

## How to use this package

Give ChatGPT the ZIP and the current master **C:\Users\amiri\Downloads\XVF_Measurement_V14.docx** when generating the next Codex prompt. Treat completed observations, implemented capabilities and prospective S6B extensions as different evidence classes. Ask the next prompt to retain both taps, same-settings controls, full-bank confirmation for retained candidates and all failed/unassigned denominators.

The expected archive is **S6A_JOINT_CHATGPT_HANDOFF_20260909T202250Z.zip** under the local simulation/handoffs directory. The final report-root PACKAGING_RECEIPT.json supplies the archive hash, size and integrity outcome; HANDOFF_MANIFEST.json binds archive members. LOCAL_ARTIFACT_INDEX.json points to the larger local evidence. Raw audio, vectors, model weights, full event logs and the Word file are deliberately outside this compact package.

WORKBOOK_UPDATE.md is insertion text for the single master, not another Word guide. Reading this handoff does not launch S6B or change the current GUI default. Exact execution and rollback instructions are in the maintained script/application READMEs.

