# Regenerating the actual component map

The component_map_builder.py script reads current application dataclasses and source files, COMPONENT_API_TESTS_V2.json when available (otherwise COMPONENT_API_TESTS_READY.json), and REDIM_FRONTEND_BINDING.json. It writes COMPONENT_MAP.md and PARAMETER_BINDINGS.json with exact current hashes. It does not run models, edit application code, change historical evidence or claim probe accuracy. The map documents the preserved V1 closure and unchanged named profiles alongside V2 bindings.

Run from PowerShell:

~~~powershell
& "C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe" "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6A\20260909T202250Z\component_map_builder.py" --repo "C:\Users\amiri\Documents\GitHub\just-peachy" --report "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6A\20260909T202250Z"
~~~

In Anaconda Prompt or ordinary CMD, enter the same quoted command without the initial PowerShell &.

The model API and real-model smoke can be reproduced with the commands in the application's README_RESEARCH_PROFILES.md. Rebuilding this map after code changes produces new current hashes; preserve earlier versioned reports when a historical run depends on them.

When present, the builder also reads RUNTIME_EXPERIMENT.json, the preserved RUNTIME_EXPERIMENT_V1_LIBRARY_DEFAULTS.json, and CAUSALITY_DELIVERY_RECEIPT.json. It appends their measured findings and binds both versioned runtime manifests plus the exact V1/V2 runner files. Missing optional experiment receipts are omitted rather than invented. Run it again after the bounded experiments finish to include their final evidence. No additional neural inference is started by this builder.

Provenance is a finite directed graph: frozen inputs and tests feed the component map/parameter bindings; the plumbing receipt hashes those upstream reports; the final requirement audit hashes final plumbing; the package hashes the completed audit. Plumbing links back to the audit only by an informational path and scope, without a hash. Otherwise the two reports would require impossible mutually current hashes. The builder refreshes plumbing after writing its maps but never finalizes the requirement audit. After all 720 probes and final design/analysis complete, rebuild the maps/plumbing first, then refresh the coverage audit, then package. Do not rebuild upstream reports after binding the final audit without refreshing its descendants.
