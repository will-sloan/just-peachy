# S6A joint pipeline study — analysis and handoff

Run: `20260909T202250Z`. Final status: **COMPLETE_S6A_JOINT_WITH_LIMITATIONS**. This is the bounded S6A checkpoint. S6B, training, firmware changes and a production/CM5 deployment have not been started.

## What the next decision should use

The complete original H2 control favors O0 with its historical +3 dB scalar: primary pooled WER is 14.386%, versus 15.461% on O1 at unity. This is an observed-bank result under original settings. Both taps remain necessary in the component study and proposed S6B trials.

The full-bank reference study shows a useful but limited cue effect. Reliability-adaptive fusion R5 improves final-label cpWER over its matched voice/time parent R1 by 2.227 percentage points on O0 and 0.682 points on O1. The new trackers still generally trail actual native B0. B0 retains historical source-cursor attribution, while R1–R5 use serial modeled availability, so this is not an isolated tracker-quality contrast. Moreover, O1 subsecond turns with a known modal label fall from 32/40 to 30/40; O0 rises from 27/40 to 28/40. These are coverage counts, not proof of correct identity. Aggregate cpWER is insufficient to promote a tracker.

On the native panel, the joint cue-off bundle P1X0 lowers cpWER from 60.167% to 41.746% on O0 and from 63.278% to 52.632% on O1 relative to P0X0, while primary WER stays13.562% on both. This is promising attribution evidence, with a clear regression: the two subsecond turns retain a known modal label on only 1/2 O0 and 0/2 O1, versus 2/2 on both with P0X0. Complete-reference mixed-identity support rises from 1.881% to 2.690% on O0 and 1.077% to 2.495% on O1, even though overall unknown support falls.

The tested advisory cue route increases primary word errors by 2 on O0 and 4 on O1 (0.298 and 0.596 percentage points), under both original and joint component settings. It also worsens cpWER within each matched factorial parent. The segmentation-only energy assist is a different route: it activates 465 times per tap and improves support coverage modestly without changing pooled word or cpWER scores. None of these results selects a production profile.

The implementation, graph semantics and parameter controls are now exercised in the actual application. The next stage should use these measured tradeoffs, preserve cue-disabled parents, and retain short-turn, unknown and wrong-merge denominators. No production default is selected by this screening checkpoint.

## Completed scope and evidence units

| Required evidence | Completed scope |
|---|---|
| Original baseline |480/480 outputs; 360 prior exact S5 numerical/population matches and 120 new original-setting outputs |
| Source coverage |240 scenes; 777 intentional utterances; unknown ambient references unfilled |
| Physical cues |240 shared traces; 534,288 received rows; 180 compatible historical analyses plus 60 new |
| Baseline vectors |480 feature outputs; 15,649 actual vectors; 15,649/15,649 B0 labels match |
| Six references and controls |2,880 reference outputs +960 degenerate controls |
| Native component study |720/720 V2 outputs, ten profiles ×36 scenes ×two taps; zero failed jobs |
| Paired scoring |720 scored outputs; 720 planned paired contrast rows; 72/72 P0X0/B0 normalized word matches |
| Runtime and causality |Four controlled paced runs; two full-neural prefix/future runs; cached-policy and native-cache fixtures |
| Research plan |68 ideas; 30 proposed profiles in eight expensive recipe families; 29 native foundations parser-validated |
| Delivery |Four visually inspected scientific PNGs, source/metric tables, exact code/READMEs, proposed master-workbook insertion |

The 240 scenes are the existing accepted S4.5 v2 physical captures. There are 156 complete non-overlap scenes, 47 complete overlap scenes, 26 scenes with incomplete environmental references and 11 intentionally empty controls. All 777 intentionally inserted utterances retain their native source identity, words, normalized text, hashes, sample crops and schedules. Untranscribed environmental speech remains unknown. The old 180/60 division is historical metadata; all 240 are now authorized and observed, so the former 60 cannot be described as an unseen test set.

O0 is the ASR-oriented output, recorded with device `AEC_ASROUTGAIN=1`; O1 is the postprocessed auto output. O0 receives scalar `1.4125375446227544` (+3 dB) exactly once. O1 is unity. Already gained FLOAT adapters and native PCM16 journals are read at unity. Every native job consumes the entire saved output, including its partial final host block and decoder drain. Native journal/sample verification refers to the complete accepted capture file; it does not claim that the output file has exactly the nominal rendered scene duration.

Sensor telemetry is one shared physical trace per scene, not two independent observations because two audio taps were scored. Full-bank cue statistics use 240 traces and 534,288 received telemetry rows. Summed source-support seconds can count simultaneous source utterances more than once; they are not independent physical recording duration.

## Full original-settings baseline

| Population / metric | Paired scenes | O0 | O1 | Reference words |
|---|---:|---:|---:|---:|
| Primary non-overlap WER | 156 | 14.386% | 15.461% | 4,560 |
| Complete overlap MIMO-WER | 47 | 33.379% | 34.478% | 1,456 |
| Complete-reference final-label cpWER | 203 | 58.727% | 61.735% | 6,016 |
| Incomplete ambient target-only WER, limited | 26 | 29.575% | 30.015% | 683 |

Primary CER is 8.461% for O0 and 9.493% for O1. O0 has lower pooled primary WER in each of the five observed rooms. The paired difference is +1.075 percentage points for O1 minus O0. A 2,000-replicate bootstrap over 116 whole matched blocks within the five observed rooms gives a conditional interval of [+0.373,+1.807] points. No block is excluded in the final analysis. Shared speakers, clips, text/books, RIRs and noise connect all 156 primary scenes into one combined dependency component; this interval is conditional and potentially optimistic, not evidence of independent room/speaker generalization or equivalence.

The empty controls contain one inserted word on O0 and two on O1, over 11 controls per tap. Empty-reference WER is undefined. Insertions/minute are 0.122 and 0.244. O1 has 2,027 PCM16 rail samples in the adapter/journal level analysis; O0 has none. This is retained as a diagnostic, without changing either recipe. There are 7,502 accepted baseline embeddings on O0 and 8,147 on O1. Their unique within-output evidence totals 2,136 and 2,264 seconds; processed overlapping windows total 3,751 and 4,073.5 seconds. Repeated windows are not independent seconds of identity evidence.

All 360 existing S5 outputs retain exact numerical/population parity. The missing 120 original-setting outputs were computed under the preserved B0 application. Detailed room, family, corpus, quality, pose, obstruction, source-level, requested noise/SIR and headroom strata are in `baseline_results/STRATIFIED_TEXT.csv`. Source-based short/return/region support and conditional uncertainty are retained in the other baseline tables.

![Original-setting room results and empty-control insertions](baseline_results/baseline_room_and_empty.png)

## Actual component profiles and matched contrasts

The ten explicit profiles run on the same preselected 36 scenes, three from every scenario family, and both taps. The panel was chosen from input conditions before new panel outcomes. It covers all five rooms, three speech corpora and four quality labels (`clean`, `other`, `self_reported_60plus_real_recording`, `studio_project_design`), both poses, obstruction states, short and longer turns, level conditions, overlap, noise and all reference populations. It is a screening panel, not a new withheld test split. `PROBE_PANEL.json` records selection, prior knowledge and any coverage limits.

`B0` means the exact old implementation. `P0X0` means original neural/component settings with the new reliability tracker and cues disabled; it is not a renamed exact B0. Under missing/disabled cues, voice/time and reliability modes have matching numerical paths for identical vectors/times; 361 cached decisions and final tracker snapshots verified that equivalence, apart from the diagnostic mode field.

| Profile | Principal supported changes | Cue treatment |
|---|---|---|
| P0X0 | Original component settings; new reliability tracker | Disabled |
| P0X1 | Same original component settings and tracker | Advisory tracking/endpoint route |
| P1X0 | Posterior segmentation at 0.5s stride; 1.0s embeddings at 0.5s cadence; 1.6/0.8s endpoint rules; 50 ms host dispatch | Disabled |
| P1X1 | Exactly the same tuned component bundle as P1X0 | Same advisory route as P0X1 |
| SEG_X0 | Posterior speech/overlap policy and 0.5s stride; voice/time tracker; continuous original ASR | Disabled |
| SEG_X1 | Same segmentation and tracker as SEG_X0 | Soft energy assistance only |
| EMBED_LONG | 1.0s evidence windows at original 0.25s cadence | Disabled |
| EMBED_CADENCE_QUALITY | 0.5s windows, 0.75s cadence and 0.001 RMS threshold | Disabled |
| ENDPOINT_X0 | 1.6/0.8s silence rules and 50 ms host dispatch | Disabled |
| ENDPOINT_X1 | Same endpoint/dispatch settings as ENDPOINT_X0 | Advisory tracking/endpoint route |

The exact JSON profiles are authoritative. The factorial X treatment is a tracking-plus-possible-endpoint route, not a final-label-only change. Segmentation policy/stride, cadence/RMS, and endpoint/dispatch are declared bundles; their internal factors are not separately identified by these contrasts. The four factorial cells have matching P changes across X and matching X changes across P.

The panel contains 23 primary non-overlap scenes, six complete overlap scenes, five incomplete ambient scenes and two empty controls, with 115 intentionally inserted utterance instances. Primary WER therefore uses 23 scenes per tap and complete-reference cpWER uses 29. Only two inserted utterances are shorter than one second. Their exact counts remain visible, but this panel cannot provide broad subsecond-turn validation; the full-bank reference study has 40 such turns per tap. Repeating the panel across ten profiles and two taps does not create additional independent utterances.

| Profile | Tap | Primary WER | Final-label cpWER | Unknown sole support | Embedding calls |
|---|---|---:|---:|---:|---:|
| P0X0 | O0 | 13.562% | 60.167% | 28.20% | 1,158 |
| P0X0 | O1 | 13.562% | 63.278% | 27.82% | 1,292 |
| P0X1 | O0 | 13.860% | 61.603% | 27.85% | 1,158 |
| P0X1 | O1 | 14.158% | 68.182% | 27.17% | 1,292 |
| P1X0 | O0 | 13.562% | 41.746% | 24.31% | 673 |
| P1X0 | O1 | 13.562% | 52.632% | 25.24% | 700 |
| P1X1 | O0 | 13.860% | 46.890% | 24.84% | 673 |
| P1X1 | O1 | 14.158% | 53.469% | 25.45% | 700 |
| SEG_X0 | O0 | 13.562% | 63.278% | 27.26% | 1,188 |
| SEG_X0 | O1 | 13.562% | 66.388% | 27.60% | 1,291 |
| SEG_X1 | O0 | 13.562% | 63.278% | 26.83% | 1,194 |
| SEG_X1 | O1 | 13.562% | 66.388% | 26.84% | 1,313 |
| EMBED_LONG | O0 | 13.562% | 47.368% | 24.50% | 1,158 |
| EMBED_LONG | O1 | 13.562% | 52.273% | 23.05% | 1,292 |
| EMBED_CADENCE_QUALITY | O0 | 13.562% | 64.593% | 30.36% | 499 |
| EMBED_CADENCE_QUALITY | O1 | 13.562% | 64.952% | 30.42% | 513 |
| ENDPOINT_X0 | O0 | 13.562% | 61.364% | 28.16% | 1,158 |
| ENDPOINT_X0 | O1 | 13.562% | 62.799% | 27.98% | 1,292 |
| ENDPOINT_X1 | O0 | 13.860% | 62.081% | 27.81% | 1,158 |
| ENDPOINT_X1 | O1 | 14.158% | 67.943% | 27.19% | 1,292 |

Primary rates use671 words; complete-reference cpWER uses836 words. Unknown support uses complete-reference sole-speech support, a different denominator. Exact paired B0 on this panel is 13.562% primary WER on both taps, and 53.230%/58.254% cpWER on O0/O1. P0X0 preserves all 72 B0 normalized word sequences but changes attribution policy. The same unchanged words are observed for all seven cue-off/segmentation-only profiles; each advisory endpoint profile differs from B0 in 7/72 output sequences.

![Matched component panel word and final-label errors](figures/S6A_COMPONENT_ACCURACY.png)

### What the paired interventions show

- **Joint components, cues off:** P1X0 versus P0X0 changes cpWER by−18.421 points on O0 and−10.646 on O1. Primary WER and all 72 normalized word sequences are unchanged. Embedding calls fall1,158→673 and 1,292→700, while segmentation calls rise2,124→3,204 per tap. Instrumented model-call sums rise195.89→232.86s and 196.70→234.79s per 36 scenes; fewer embedding calls do not imply lower total work. These sums omit the documented wrapper costs.
- **Longer embeddings alone:** EMBED_LONG improves cpWER by 12.799/11.005 points versus P0X0, with the same number of embedding calls. One-second windows double processed window duration but grow unique evidence only 332.75→397.25s and 357.75→416.00s. Instrumented embedding time rises 18.10→29.63s and 19.73→32.82s. Known-file-envelope cross-person windows rise42→75 and 44→79 among mapped outputs. The improvement therefore comes with longer waits and more potentially mixed windows. On O1 its52.273% cpWER is slightly below P1X0's52.632%, illustrating that the preferred bundle can depend on the tap.
- **Cadence plus quality threshold:** EMBED_CADENCE_QUALITY reduces calls to 499/513 and instrumented embedding time to 7.48/7.61s. Its cpWER worsens 4.426/1.675 points and unknown support rises to 30.36%/30.42%. Reduced computation is measurable; preservation of coverage is not established.
- **Posterior segmentation and energy assistance:** SEG_X0 versus P0X0 worsens cpWER by 3.110 points on both taps. Adding soft energy assistance in SEG_X1 leaves WER/cpWER unchanged, but adds6/22 embeddings and reduces unknown support from 27.26%→26.83% and 27.60%→26.84%. The 465 positive assistance events per tap demonstrate that this was an exercised policy, not an inactive option. Some support differences can still depend on measured availability timing.
- **Endpoint/advisory routes:** ENDPOINT_X0 preserves all 72 baseline word sequences. Advisory variants trigger12–16 endpoints per 36-scene/tap run and differ in 7/72 lexical output sequences per profile. For primary speech, the increased errors occur at S45_03_01: O0 goes1→3 errors and O1 goes1→5, out of22 reference words. Overlap MIMO errors also increase2/4 out of165 words. The limited ambient target-only rate increases one error out of146 target words on each tap. Both strict-empty scenes retain one inserted word per tap for every profile, over 89.390875s (0.671 words/minute); WER remains undefined.

The cpWER cue increments are+1.435/+4.904 points under P0 and+5.144/+0.837 under P1, for O0/O1 respectively. Thus the difference-in-differences interaction is+3.708 points on O0 and−4.067 on O1. Both tuned cue increments are adverse; the negative O1 interaction means a smaller cue penalty after tuning, not a beneficial cue effect. Primary-WER interactions are zero because both bundles receive the same 2/4 additional word errors.

### Short replies, evidence wait and actual lineage

For the two subsecond primary turns, P0X0 has 2/2 contained windows and 2/2 known modal labels on each tap. P1X0 and EMBED_LONG have no fully contained one-second window for either turn. Nevertheless, EMBED_LONG retains 2/2 known modal labels, while P1X0 retains 1/2 and 0/2. Their support can come from earlier or boundary-crossing observations; a contained vector and a known label are different diagnostics. Subsecond unknown support for P1X0 is 49.71%/70.71%, versus 20.86%/4.77% with P0X0. The sample is too small for broad subsecond conclusions, but these observed failures cannot be hidden by aggregate cpWER.

Among the 16 primary turns lasting 1–<2s, P0X0 has a contained window for all 16 on both taps. P1X0 misses 2/16 on O0 and 3/16 on O1. Median first-contained-window wait among the remaining measured turns rises from 0.711/0.709s to 1.248/1.210s, measured from aligned file start with warm modeled availability. Missing-window turns are excluded from those medians and remain explicit in the table. These are not phonetic-onset or calibrated live delays.

All 2,300 expected input-turn rows are represented by the short-table identity denominators across 115 instances ×ten profiles ×two taps. The four unmapped scene/tap inputs appear as 40 unmapped profile outputs across the ten profiles, all belonging to the two empty scenes; no inserted utterance is lost. Actual native lineage contains creation, commitment, prototype updates and cue-driven provisional splits. There are no observed native merge/revision events in this panel; the one full-bank R4 forward revision and the reconciliation fixtures remain separate evidence. With one-second evidence and one-second commitment, all 155/173 P1X0 new tracks commit on creation; this suppresses the provisional reconciliation path and is a specific candidate mechanism to revisit.

The five ambient scenes contain 164 known inserted words in the coverage inventory, but the inherited target-only score uses146 designated target words. The 18 designated non-target words remain in the full reference/source inventory; this metric intentionally scores against targets only. Known non-target or unknown environmental speech can therefore appear as insertions in this limited diagnostic. No intentional utterance was removed from coverage.

Every endpoint-changing profile runs fresh stateful Sherpa recognition; old words are never re-sliced to pretend a decoder/endpoint change occurred. Changed segmentation and embedding spans are actually recomputed. `COMPONENT_PROBE_RESULTS.csv`, `JOINT_FACTORIAL_RESULTS.csv` and `probe_results/PAIRED_SCENE_DELTAS.csv` retain the results and exact denominators. Purely lexical B0/P0 comparison always checks actual normalized word strings, including overlap. Final ASR costs include regular dispatch, partial tail dispatch and EOF drain; punctuation and model loading are separate.

The phase-cost columns are instrumented call elapsed sums. They omit some wrapper/postprocessing, tracker/gate, advisory/reset and formatting work; in particular, segmentation's timer stops before powerset-posterior conversion. The plot is consequently an incomplete cost breakdown, not full component work, serial pipeline duration or target real-time factor. Whole-process paced measurements provide the separate desktop queue and memory evidence.

![Instrumented model-call elapsed sums with omitted costs stated](figures/S6A_COMPONENT_COMPUTE.png)

## Directional foundation and six references

Selected processed directions are usable over 92.25% of summed source support but match the coarse expected source sector over only 45.04%. Stable wrong-sector values are common: 890.04 summed source-support seconds are classified as held and numerically wrong, and 388/777 turns never acquire the sustained expected sector under this diagnostic. Across 545 complete-reference non-overlap utterances the sector match is 45.01%, so overlapping-source ambiguity is not the only explanation. Unchanged wrong-sector values do not prove stale DSP data; this metric describes repeated numeric bearings. These are broad-sector association diagnostics, not a calibrated sensor angular accuracy estimate.

Raw-auto/selected-auto/focused/scanning streams have different availability and association. Keep all stream definitions, population breakdowns and 15 explicitly post hoc adverse examples. Manual ±5 degrees describes nominal source-label uncertainty; it is not an optimized sensor threshold. Native 0 and 180 are distinct ends of the folded coordinate, and front/back remain ambiguous.

The six references keep ASR words fixed: exact native B0; new voice/time R1; angle-association R2; sustained change-proposal R3; decaying position memory R4; and reliability-adaptive voice/location/energy R5. They share exact upstream baseline features. R2's association does not use voice cosine to merge angle clusters, but its observation schedule still shares speech/non-overlap/RMS/accepted-window eligibility, and delivered-angle qualification can reject nonpositive raw-auto energy. It is not an unfiltered sensor-only detector. Feature reuse does not by itself establish compute savings.

All 15,649 actual recomputed ReDim vectors reproduce 15,649 native B0 labels with zero mismatches. The six references produce 2,880 scene/tap/profile outputs; one-person and all-unknown add 960 controls. All 12,432 expected turn rows remain present; the 11,520 scene/tap/method/bin rows sum to 12,432 in their `source_turns` column. B0 cpWER matches the independent scorer on all 480 outputs. The one-person control has 30.93% mixed-identity sole-speech support; all-unknown has 100% unknown support. Neither can be declared successful by looking only at the other error category. R2 retains roughly 62% unknown support despite superficially competitive cpWER.

One actual R4 forward tracker revision occurs at S45_11_12/O1. It is retained with its original first decision and receives no retroactive correctness credit. Tracker split/merge/revision lineage is implemented and observed where triggered; transcript events still preserve their first labels and are not rewritten into a revised GUI transcript. With 1.0s evidence windows and 1.0s commitment, new tracks commit immediately, suppressing the provisional merge path. This interaction is a specific S6B design issue, not evidence that unit-fixture reconciliation necessarily runs in every profile.

`CUE_REFERENCE_HANDOFF.md` contains full per-profile results, short-turn regressions, cost and clock qualifications. The stacked diagnostic figure uses the same sole-speech denominator for unknown and mixed-identity support, rather than hiding unknown speech behind a known-only rate.

![Reference unknown and mixed-identity support on a shared denominator](CUE_REFERENCE_DIAGNOSTIC.png)

## Real interfaces, model semantics and clocks

```mermaid
flowchart LR
    A[Saved XVF O0 or O1 audio] --> G[Bound gain-once adapter]
    G --> J[Complete PCM16 journal and dispatch]
    J --> ASR[Stateful Sherpa ASR]
    J --> SEG[Pyannote speech and overlap policy]
    SEG --> EMB[Eligible ReDim waveform windows]
    EMB --> T[Anonymous tracker and name gate]
    X[Saved physical telemetry] --> D[Causal callback delivery]
    D -. configured assistance .-> SEG
    D -. configured advisory endpoint .-> ASR
    D -. configured cue evidence .-> T
    ASR --> RAW[Raw transcript and first labels]
    T --> RAW
    RAW --> P[Final-only display punctuation]
    RAW --> S[Evaluation]
    Q[Reference words, identities and source schedules] --> S
```

Reference annotations enter evaluation only. Optional arrows depend on the exact tested profile. A tentative identity change alone does not reset recognition. `METRIC_INTERPRETATION.md` explains the table denominators and clock boundaries; `EVIDENCE_VERSION_GUIDE.md` identifies current and preserved versions.

The typed research profile is opt-in through the actual application CLI. It validates sections for input, ASR, segmentation, embeddings, tracking, XVF, punctuation and runtime, applies supported configuration changes and emits effective settings. Unknown fields and specified unsupported or no-op combinations are rejected; parameter effects are mode-dependent. For example, voice/time mode accepts spatial parameters that it does not use, while a tracking-only cue mode paired with a non-spatial tracker is rejected. Defaults remain the old GUI behavior; omit the research flag for the current application's ordinary path, or use the exact archived B0 launcher for the scientific control.

Pyannote's exported graph has fixed 10s waveform input `[1,1,160000]` and seven powerset log-probabilities over 589 frames, not seven independent speaker logits. The frame step is 0.016875s and receptive duration 0.0619375s. Local voice slots are local to each invocation, not persistent identities. B0 uses hard argmax-derived speech/overlap fractions with 0.20 tail thresholds; its nominal onset/offset fields were previously inactive in that hard policy. The new supported posterior policy makes those thresholds operative without guessing a shorter graph input or claiming full Pyannote diarization clustering.

The local ReDim checkpoint is PalabraAI/redimnet2 B2, with a 192-dimensional normalized output and the checkpoint's own waveform/frontend processing. Real checks cover supported 0.5, 0.75, 1, 1.5, 2 and 3 s waveforms. Input spans change when duration/RMS/cadence changes, so vectors are recomputed. Arbitrary frame masking is not exposed by this graph and is not claimed. Overlapping-window evidence is tracked by interval union.

Sherpa uses the installed online recognizer and existing encoder/decoder/joiner weights. The exported encoder's 39 feature frames and 32-frame decode chunk are different from 50/100 ms host journal reads. Endpoint changes alter actual recognizer reset history. Tentative identity changes alone do not reset ASR. Punctuation is learned final-only display processing; raw ASR text is the lexical scoring input.

Source samples, host receipt/callback availability, model compute and wall elapsed time are separate clocks. The native research logs describe a warm-resident serial source-axis availability model; model loading is separately measured before source start. Fresh-process model loading does not establish uncached storage or cold-boot latency. Accelerated native first-label results also depend on which speaker-history entries the concurrent worker has appended. They are desktop execution observations, not a deterministic source-clock scheduler or calibrated live latency. First-partial summary values are timestamps from file origin among outputs with a nonempty partial, not delays from a phonetic speech onset.

Historic telemetry lacks a validated DSP source timestamp. Sanitized app delivery maps a received value to its first containing completed audio callback and carries only causally available sensor evidence. Unavailable source/receptive timestamps are omitted instead of invented. The reference replay bridge and app JSONL delivery have explicit, separately bound quantization rules. Matched factorial cells use the same app delivery protocol. Historic AEC/AGC/RT60 states remain unavailable.

## Runtime and target boundary

Four paced CPU runs compare one/two model threads and 50/100 ms host dispatch on 89.390875s of exact complete native O0 audio concatenated for engineering. All have zero drops, five final utterances and 44 embeddings. Words and delivered samples match; dispatch-only vectors match exactly, and thread-change maximum vector difference is 9.09e-7. Sampled ASR backlog is at most 0.10s and speaker backlog 0.30s under concurrent study load.

Private resident USS peaks at 383.0–385.2 MiB; RSS upper bounds at 440.9–443.5 MiB; Windows private committed memory at 416.0–418.1 MiB. Those are different quantities. Shared-resident RSS-minus-USS is a nonunique estimate, and PSS is unavailable on this Windows host. Numeric pool environment variables are explicitly 1 before imports. Actual tree thread counts are 28/33, including a two-thread conhost child, and cannot be equated with the one/two configured model-thread settings. Unattributed native pools remain a limitation. Earlier library-default runtime evidence is preserved as V1 and is not silently pooled with controlled V2.

The 2 GB CM5 target still constrains the design: one resident instance per selected model, one shared embedding representation, bounded buffers/prototypes/tracks/revision windows, controlled logging and a storage/write ledger for 32 GB eMMC. The desktop resident-memory measurement is below the provisional 1.3 GiB screen; it does not establish ARM64 speed, full device RAM fit, thermal behavior, sustained I/O endurance or real-time margin. No Ryzen-to-CM5 speed multiplier is used. Four concurrent desktop research workers are not the proposed deployment architecture.

The native V2 panel finished at 2026-09-09 21:48:14 UTC, 85.40 minutes after the overall study start. Its final four-worker invocation completed 602 fresh outputs and reused 118 exact outputs in 38.59 minutes, with zero failures. Summed child wall time for those 602 fresh outputs is 152.91 minutes; all 720 V2 outputs total 10,966.959 child-wall seconds (182.78 minutes). Neither is coordinator elapsed or CPU time. Final 720 scoring completed at 21:49:09 UTC.

At the 21:51:09 UTC closure checkpoint, C: had 89.79 GiB free, G: had 413.93 GiB free, available RAM was 46.13 GiB, and versioned new output occupied3.334 GB (decimal). The C:/G: SSDs report Healthy/OK through Windows; this is an OS health/status observation, not an independent wear or surface test. An exact-script-name scan found no active study compute processes. Final package verification additionally checks recorded PID/creation identities and rehashes current declared native inputs/models. No files are deleted to recover space.

The Git branch is codex/edge-component-expansion, with HEAD 830009cc9fa9ef996e4668f53441c2b858ce6b42. Candidate application changes remain local and uncommitted. The B0 snapshot captures the original working application, including pre-existing changes; the packaged application diff is against that snapshot rather than assuming every difference from Git HEAD belongs to S6A.

## Validation, revisions and preserved failures

The authoritative V2 API suite has 13 focused checks plus six existing tests and a real 12.037s application smoke. A full neural prefix test uses two fresh paced engines with the same 12s prefix and different 6s futures. Eighteen raw/display events, 240 endpoint-dispatch decisions, 24 segmentation summaries, 10 real vectors and 10 tracker decisions match within the prefix; the futures differ, making the check nonvacuous. Displayed labels also match in that fixture. This is separate from 41 logic fixtures and 60 actual-feature causal replay trials, including renamed truth labels and missing/stale/reordered telemetry.

The completed-result cache suite exercises the actual reuse path: one exact native reuse plus 28 changed-dependency/stale-key rejections. A separate guard suite verifies nine cases, including seven actual changed-byte cases with the old size, modification time and supplied identity preserved. The public resume wrapper fully hashes 225 unique declared files before delegating to the frozen runner. This is conservative full-result invalidation, not proof of a minimal optimal cache DAG. New features, endpoint histories, code/providers and input changes require compatible new identities/versioned outputs. Concurrent edits after verification are prohibited.

The first 48 completed component jobs are preserved and excluded after a reviewed overlap-display defect was found: final transcript overlap state had followed the latest accepted non-overlap embedding. V2 uses a separate bounded causal segmentation history. It also makes the first cue-enabled event consistent, rejects invalid no-op profiles and labels warm/model-loading clocks. The ten numeric profile files and selected panel remain unchanged. This was an implementation correction before the final comparison, not a search for favorable outcomes.

Earlier scorer preflight corrections are also preserved: all-bank guard plumbing, a transient input-hash failure during an unfinished metadata repair, and JSON tuple/list canonicalization for exact S5 assignment parity. Two owned helper processes were found suspended by Windows; one was terminated after a bounded nonprogress interval and one resumed after exact PID/creation verification. Their cause is unknown. No global service/security setting was changed. Independent review corrected EOF compute totals, nonvacuous overlap lexical comparison, unequal-denominator pooling, interim unmatched factorial estimates, null unavailable memory and parent score hash checks before the final analysis. These corrections do not count as successful native outputs or disappear from provenance.

All 24 required validation rows are COMPLETE, with 720 native outputs in the final requirement snapshot and no missing required fixtures. The independent review rehashed all 720 scores, checked 20 profile/tap groups, 18 factorial rows and 720 ASR phase identities. The final component review checked 96 nested requirement/plumbing bindings after preserving immutable design inputs, with no remaining provenance cycle. Four analysis fixtures cover unequal-denominator pooling, population separation, empty-reference rates and retained unknown/missing short-turn support.

The final machine authority is FINAL_COMPLETION_AUDIT.json: it rehashes scored results and native event/summary/resource evidence, verifies all 225 declared native dependency files again, checks zero-drop counters, and checks exact coordinator/child PID creation identities after cleanup. PACKAGING_RECEIPT.json records archive size, CRC and member-SHA verification. The compact bundle is only published under its final ZIP name after those gates succeed. The receipt remains outside its own ZIP to avoid a recursive hash.

The completion status is COMPLETE_S6A_JOINT_WITH_LIMITATIONS. The bounded A requirements are complete, while live-clock calibration, an isolated attribution-scheduler comparison, broad short-turn candidate confirmation, retrospective transcript/GUI revision, and CM5 product qualification remain outside the demonstrated scope. No training, firmware change, hardware playback or S6B execution was performed.

## Geometry, source exclusions and what validation cannot prove

All 121 canonical RIR records remain bound; 120 are eligible and 39 appear in this bank. The other 81 eligible paths are unused here. Effective eligible distances span 0.46–4.07m, with none above 5m. The two original 100m entries at Opening Behind Listener, +20 degrees, flat/upright R05 retain the user-confirmed 1.00m overlay; raw metadata is unchanged. Earlier testing and retake measurements remain excluded through the canonical accepted library. No RIR extraction or hardware transport campaign was repeated.

Selected angle values/signs and nominal projections match the canonical metadata. This consistency check cannot independently prove that a manual angle was physically measured with the right sign. The handoff preserves that distinction instead of silently flipping a direction to make sensor results look better. Only the approved original CMU Arctic, HiFiTTS and Common Voice sources are used with the existing environmental/noise policy; no L2 Arctic is added.

## Proposed S6B work, not executed

The extended registry keeps all 60 seed ideas and adds eight distinct mechanisms, including XVF-to-neural-component interactions and a CM5 cost path. The plan has 30 end-to-end profiles grouped into eight expensive recipe families. Twenty-nine native foundations validate against the actual profile parser; B00 remains unchanged B0. Extensions not implemented by the current parser are explicitly prospective and cannot be silently omitted.

Use P1X0 and EMBED_LONG as attribution candidates, not selected defaults. First separate window length, segmentation cadence and commitment/reconciliation thresholds while retaining the exact cue-off parents. Require all-bank short/1–2s coverage, unknown and mixed-identity support before accepting their cpWER gains.

Keep the advisory endpoint route as an adverse case requiring isolation: retain its actual S45_03_01 word losses, separate tracking assistance from reset permission, and test a continuous-ASR alternative. The SEG_X1 energy route has a smaller, exercised support benefit worth comparing with its exact SEG_X0 parent. Its unchanged pooled cpWER is also part of the result.

Retain the cadence/quality branch as a measured cost/coverage tradeoff. Evaluate total paced process work and bounded state alongside instrumented model calls. Both O0 and O1 remain in S6B; the panel's lexical tie, different best attribution bundles and full-bank original-setting O0 preference do not justify deleting a tap. Preserve all 30 proposed profiles and their eight recipe families, including prospective mechanisms not implemented in the current parser.

Required interactions remain speech/overlap policy × embedding duration; RMS/gain × evidence yield; cadence × prototype thresholds; direction persistence × endpoint/revision; seat-memory decay × return; decoder/chunking × runtime budget; and taps × segmentation/embedding input. Keep exact same-settings cue ablations and original-versus-tuned controls. Do not promote an aggregate cpWER improvement that removes short replies or increases unknown/wrong-merge support. Do not claim frame-exact word-speaker timing, named-person recognition, full diarization DER, CM5 qualification or new unseen-data validation from this checkpoint.

## Where to continue

`NEXT_STAGE_INPUTS.md` lists authoritative files, local roots and the boundary for the next ChatGPT-generated Codex prompts. `WORKBOOK_UPDATE.md` is a proposed yellow insertion in the single Revision 14 master, not a competing Word guide. The model files and full audio/vectors/native event traces stay local; the compact ZIP contains analysis, tables, tests, profile JSON, exact code and readable figures. `LOCAL_ARTIFACT_INDEX.json` and the manifest/receipts retain hashes and paths for the larger evidence.

Use the maintained READMEs under `code/scripts` and the actual application research READMEs for PowerShell and Anaconda/Command Prompt steps, inputs and outputs. Exact B0 code is preserved separately from optional S6A application changes. Historical source paths that now contain candidate code are verified against their declared B0/extraction archives. No automatic Git commit/push, source deletion, training or S6B launch has occurred.
