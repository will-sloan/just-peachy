"""Generate the read-only component map from actual code and bound API receipts."""
from __future__ import annotations
import argparse
from dataclasses import asdict, fields
from datetime import datetime, timezone
import hashlib
import inspect
import json
from pathlib import Path
import sys

def refresh_plumbing_receipt(report):
    """Bind upstream evidence only; the downstream coverage audit binds this receipt."""
    path=report/"COMPONENT_PLUMBING_RECEIPT.json"
    if not path.exists():
        return
    receipt=json.loads(path.read_text(encoding="utf-8"))
    def binding(p):
        return {"path":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"bytes":p.stat().st_size}
    receipt["requirement_coverage_snapshot"]={
        "path":str(report/"S6A_REQUIRED_VALIDATION_AUDIT.json"),
        "scope":"Separately finalized downstream audit; informational path only. The audit hashes final plumbing, so no reverse hash is stored."}
    for field,name in (("component_map","COMPONENT_MAP.md"),("parameter_bindings","PARAMETER_BINDINGS.json"),
                       ("technical_appendix","IMPLEMENTATION_AND_VALIDATION.md")):
        if (report/name).exists():
            receipt[field]=binding(report/name)
    if (report/"PARAMETER_BINDINGS.json").exists():
        receipt["frozen_v2_source_files"]=json.loads((report/"PARAMETER_BINDINGS.json").read_text(encoding="utf-8"))["source_files"]
    receipt["provenance_order"]="Frozen inputs/tests -> component map and parameter bindings -> plumbing -> final coverage audit -> package; informational reverse links carry no hashes."
    receipt["updated_utc"]=datetime.now(timezone.utc).isoformat()
    temporary=path.with_name(path.name+".refresh.tmp")
    temporary.write_text(json.dumps(receipt,indent=2),encoding="utf-8")
    temporary.replace(path)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--repo",type=Path,required=True)
    ap.add_argument("--report",type=Path,required=True)
    args=ap.parse_args()
    app=args.repo/"Software Validation from Datasets/Evaluation Tool/app/edge_speech_pipeline"
    sys.path.insert(0,str(app.parent))
    from edge_speech_pipeline.config import PipelineConfig
    from edge_speech_pipeline.research_profiles import ResearchProfile,_SECTIONS
    config=PipelineConfig()
    baseline=asdict(config)
    baseline=json.loads(json.dumps(baseline,default=str))
    report=args.report
    test_receipt = report / ("COMPONENT_API_TESTS_V2.json" if (report/"COMPONENT_API_TESTS_V2.json").exists() else "COMPONENT_API_TESTS_READY.json")
    checked=json.loads(test_receipt.read_text())
    frontend=json.loads((report/"REDIM_FRONTEND_BINDING.json").read_text())
    specs={}
    def add(key,field,kind,symbol,units,bounds,comparator,semantics,effect,availability,test):
        specs[key]=(field,kind,symbol,units,bounds,comparator,semantics,effect,availability,test)
    common_asr="ordered mono16k normalized waveform -> stateful raw hypothesis + endpoint boolean; no truth/hotwords"
    add("input.tap",None,"input binding declaration","cli.py:main","tap","mono/O0/O1","prepared mono file, no automatic channel selection","declares caller-selected mono source","must bind actual file/tap externally","source sample time","real mono input smoke; declaration itself is not DSP")
    add("input.gain","input_gain","wrapper preprocessing","runtime.py:PipelineEngine._asr_loop/_speaker_loop","linear amplitude","0.25..4; unity if already_gained","multiply float after nativePCM16 journal","one scalar on both model branches; no peak-derived normalization","all neural consumers and RMS eligibility","no future samples; whole ReDim window waits until complete","validation test_double_gain + mapped config; S6 uses unity on gainedinput")
    add("input.already_gained",None,"validation guard","research_profiles.py:ResearchProfile.validate","boolean","true/false","true implies gain==1","asserts upstream gain ownership","prevents doublegain","before model load","test_fixed_shape_and_cadence_and_double_gain_rejected")
    for key,field,bounds in [("endpoint_rule1_silence_sec","endpoint_rule1_silence_sec","0.1..5"),("endpoint_rule2_silence_sec","endpoint_rule2_silence_sec","0.1..5"),("endpoint_rule3_utterance_sec","endpoint_rule3_utterance_sec","5..60")]:
        add("asr."+key,field,"native installed Sherpa control","models.py:SherpaStream.__init__","seconds",bounds,"native endpoint rule satisfaction; wrapper resets only explicit endpoint",common_asr,"changes finalization/reset history and therefore ASR words","online chunk availability + actual decode; final drain charged","installed1.13.4signature; real candidate smoke; ENDPOINT_X0/X1 panel")
    add("asr.decoding_method","asr_decoding_method","native installed Sherpa control","models.py:SherpaStream.__init__","enum","greedy_search/modified_beam_search","exact native string",common_asr,"decoder branch/CPU/words","stateful run must be recomputed","local signature + config binding; modifiedbeam supported but not selected in current panel")
    add("asr.max_active_paths","asr_max_active_paths","native conditional control","models.py:SherpaStream.__init__","paths","1/2/4/8 only modifiedbeam; baselinegreedy retains4","beam path limit",common_asr,"beam search cost/words; ineffective undergreedy","new stateful run","test_conditional_noop_knobs_rejected; no modifiedbeam accuracy claim")
    add("asr.blank_penalty","asr_blank_penalty","native installed Sherpa control","models.py:SherpaStream.__init__","log score offset","-2..2","native blank penalty",common_asr,"insertions/deletions/endpoint timing","new stateful run","installed signature + mapped config; not selected in current panel")
    add("asr.journal_read_ms","journal_read_ms","host wrapper dispatch","runtime.py:PipelineEngine._asr_loop","milliseconds","20/50/100/200","consume fixed source blocks and one exact remainder","host buffering differs from encoder[N,39,80],decode_chunk_len32","call timing/endpoint polling; no changed tensor shape","read end + serial measureddecode; EOF residueandpadding explicit","real50ms smoke240dispatch+37mstail; independent EOF[1600,107]")
    add("segmentation.window_sec","segmentation_window_sec","fixed graph constraint","models.py:SpeakerModels.segment","seconds","exact10","sample_count==160000","float32[1,1,160000] -> logprob[1,589,7]","full supplied context, fixed weights","trailing10s; earlyleftzero padding; no sourcefuture","actualORTshape+shortrejection")
    add("segmentation.hop_sec","segmentation_hop_sec","wrapper inference schedule","runtime.py:PipelineEngine._speaker_loop","seconds",".25..1.5 and integer multiple embeddinghop","since_segment>=hop","schedule full fixed10sgraph; tail fraction lengthround(hop/.016875)","neuralcost and gate availability; changed scheduleinvalidatesseg","serial speaker lane withallsegcostcharged","smoke24calls/12s at.5; B0.75; panelSEG_X0/X1")
    add("segmentation.post_policy","segmentation_post_policy","wrapper powerset postprocessing","research_profiles.py:segmentation_gate","enum","hard_argmax_fraction/posterior_hysteresis","hardbinaryfraction vs validpowersetprobability","P(speech)=1-p0;P(overlap)=p4+p5+p6;no thresholdonclassIDs","embeddingeligibility; changedgate invalidatesaffectedembeddings","same rawtensor reusableonlyexactsameinputcontext","known7classfixture+posteriorgatefixture+actualsmoke")
    for key,field in [("onset","segmentation_onset"),("offset","segmentation_offset")]:
        add("segmentation."+key,field,"wrapper conditional threshold","research_profiles.py:segmentation_gate","probability","0..1;offset<=onset;inertB0","mean tail P(speech)>=onset ifinactive elseoffset; minusqualifiedcueassist","B0 values.46/.45 are unused historicalfields;nondefaultrejectedforhardpolicy","gating and evidence yield","frame context ends at sourcecursor; no earlier claim","test_posterior_hysteresis_and_assistance_change_actual_gate")
    add("segmentation.speech_fraction_threshold","segmentation_speech_fraction_threshold","wrapper conditional threshold","research_profiles.py:segmentation_gate","fraction","0..1;hardpolicyonly",">=","mean hard argmax speech flags inlastNframes; baseline.20","speech eligibility","same fixedcontext; scalarpostprocess","harddefaultfixture matches oldmean>=.20")
    add("segmentation.overlap_fraction_threshold","segmentation_overlap_fraction_threshold","wrapper threshold","research_profiles.py:segmentation_gate","fraction/probability","0..1",">=","hardtailoverlapfraction forB0, tailmeanpowersetoverlapprob forposterior","overlap excludesembedding inexistinglane","doesnotidentifywhichtalker","7classfixture + actualsmoke")
    add("embedding.window_sec","embedding_window_sec","wrapper neural input span","runtime.py:PipelineEngine._speaker_loop;models.py:SpeakerModels.embed","seconds",".5..3","rolling.size>=window","contiguous waveform[1,N] ->192raw ->unitL2","recompute actualchangedvectors; no maskingAPI","mustwaitwindowend; onsetwait andwholecontextcost retained","actual.5/.75/1/1.5/2/3svalidunitnorm;longpanel")
    add("embedding.hop_sec","embedding_hop_sec","wrapper dispatch/cadence","runtime.py:PipelineEngine._speaker_loop","seconds",".25..1 and<=seghop;dividesseghop","consume one hop at a time","embedding eligibility tested eachhop; noindependent-count assumption","evidence count/compute/shortturnretention","unionof actualspans; clean evidenceunion","actualsmoke.5hop; cadencequalitypanel.75")
    add("embedding.minimum_rms","minimum_rms","wrapper audio quality gate","runtime.py:PipelineEngine._speaker_loop","normalized waveform RMS","0..0.02",">=","RMS ofcurrentdispatchblock; NOT whole embeddingwindow","eligibility & gaininteraction; lowenergyshortturns may disappear","usesonlycurrentblock; newgate affects downstreamvectors","actualsmoke block_rms;cadencequalitypanel.001 vs.002")
    for key,field in [("identity_score_threshold","identity_score_threshold"),("identity_margin_threshold","identity_margin_threshold"),("identity_minimum_evidence_sec","identity_minimum_evidence_sec")]:
        add("tracker."+key,field,"baseline identity wrapper conditional","speakers.py:SpeakerTracker.update","seconds" if "evidence" in key else "cosine/margin","0..10 seconds; score[-1,1];margin[0,2]",">=","baseline enrolledprofile match; evidence elapsedfirst-to-current includesgaps","naminggateonly; researchanonymous mode rejectschange","historical elapsed-span evidence is not uniquevoice duration","existingtest_frozen_identity_requires_score_margin_and_evidence; nonew namingclaim")
    for key in [f.name for f in fields(_SECTIONS["tracker"]) if f.name not in {"identity_score_threshold","identity_margin_threshold","identity_minimum_evidence_sec"}]:
        field="clustering_threshold" if key=="cosine_threshold" else None
        units="seconds" if key.endswith("_sec") else "degrees" if key.endswith("_deg") else "count" if key=="max_tracks" else "cosine/weight" if "cosine" in key or "threshold" in key or "margin" in key or "weight" in key or "floor" in key else "enum/boolean"
        add("tracker."+key,field,"anonymous tracking wrapper" if key!="cosine_threshold" else "baseline/research cosine association","research_tracking.py:TrackingConfig;ResearchTracker.update",""+units,"bounded validation inResearchProfile.validate andTrackingConfig.__post_init__","mode-specific cosine>=,ambiguitymargin,age/decay andvoiceconflictguard","192Dunitvector +causallydeliveredoptionalspatial ->anonymousprovisional/committeddecision","no namedidentities; boundedbranch split/merge andlaterrevisionlineage","available_at>=inputend+serialseg/embedcost; originaldecisionsneverrewritten","29independenttrackingfixtures;actualresearchsmoke8embeddings; sixrefs/panel")
    for key in [f.name for f in fields(_SECTIONS["xvf"])]:
        add("xvf."+key,None,"cross-component wrapper policy","research_profiles.py:EndpointAdvisor;spatial_is_fresh;runtime.py:PipelineEngine._speaker_loop","seconds" if key.endswith("_sec") else "probability/enum","mode none/tracking_only/soft_energy/advisory/soft_energy_advisory;delta[0,.15];reliability[0,1];silence[.1,1]","fresh positiveenergysupport; sustaineddirectionchange AND actualsilence forreset","metadata never speakertruth; softenergyrequiresvalidpowersetpostpolicy","ASRhistoryand/orsegmentation/identity; none disablesallmetadata","observation&deliveryagechecked;orderedsequence;syntheticpadexcluded","advisorypersistence/silence/stale/source-redelivery/sequencefixtures;SEGandENDPOINTpairs")
    add("punctuation.mode",None,"fixed wrapper behavior","models.py:SherpaStream.punctuate;runtime.py:PipelineEngine._asr_loop","enum","final_only","runonceperfinal","rawtextpreserved;learneddisplaypunctuation","no modelorlexicaltruth change","punctuationcomputechargedafterfinalASR","existingtextformat tests+realfinalsmoke")
    add("punctuation.partial_display_min_interval_sec","partial_display_min_interval_sec","display wrapper cadence","runtime.py:PipelineEngine._asr_loop","seconds","0..1",">=elapsed source interval","throttle unstablepartial display only; finaltextretained","fewerpartialevents; noASRstatechange","doesnotdelayaudio orwaitforidentity","configbinding;default0parity; no throttlingaccuracyclaim")
    for key in [f.name for f in fields(_SECTIONS["runtime"])]:
        add("runtime."+key,key,"native CPU pool control" if "threads" in key else "host capture wrapper","models.py:_ort_session/SherpaStream.__init__" if "threads" in key else "audio.py:MicrophoneSource","threads" if "threads" in key else "ms" if key.endswith("_ms") else "seconds","1/2/4threads;capture10/20/50/100ms;reserve10..120s","positiveintegerbounded","oneCPUprovider,ORTsequential,inter_op1;fileproducerfixed100ms independentofcaptureblock","cost/footprint/queues;capturefieldsdo notalterfileproducer","actual paced/fulltreecost required, no guessedCM5translation","actualORTprovider+configbinding; capturehardwareunchanged/unprobed")
    records=[]
    defaults=ResearchProfile().to_dict()
    for section,cls in _SECTIONS.items():
        for item in fields(cls):
            key=section+"."+item.name
            field,kind,symbol,units,bounds,comparator,semantics,effect,availability,test=specs[key]
            records.append({"profile_field":key,"baseline_value":defaults[section][item.name],"config_field":field,"implementation_kind":kind,"actual_binding":symbol,"units":units,"supported_range":bounds,"comparator":comparator,"input_output_semantics":semantics,"downstream_effect":effect,"availability_lookahead":availability,"effect_test":test,"qualification":"actual code/graph/engineering evidence; accuracy outcomes separately incomponentprobe tables"})
    sources=[]
    for name in ["config.py","models.py","runtime.py","cli.py","audio.py","speakers.py","enrollment.py","xvf.py","contracts.py","text_format.py","gui.py","research_profiles.py","research_tracking.py","research_profile_checks.py","research_profile_smoke.py","README_RESEARCH_PROFILES.md"]:
        p=app/name
        sources.append({"path":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"bytes":p.stat().st_size})
    result={"schema_version":"s6a-actual-parameter-bindings.v2","created_utc":datetime.now(timezone.utc).isoformat(),"baseline_config":baseline,"baseline_default_parity":"ResearchProfile().apply()==PipelineConfig();historical B0 appcopy remains independent","fixed_sample_rate":16000,"parameters":records,"source_files":sources,"graph_api_test_receipt":str(test_receipt),"redim_frontend":frontend,"public_context_sources":[{"title":"Pyannote powerset model card","url":"https://huggingface.co/pyannote/segmentation-3.0"},{"title":"Installed Sherpa source is execution authority; public Python reference","url":"https://k2-fsa.github.io/sherpa/onnx/python/index.html"},{"title":"Actual ReDimNet2 authors (pack generic ReDimNet1 link is not exact backend)","url":"https://github.com/PalabraAI/redimnet2"}]}
    simulation=report.parents[2]
    staging=simulation/"staging/s6a"/report.name
    support_paths=[report/"RUNTIME_EXPERIMENT_V1_LIBRARY_DEFAULTS.json",report/"RUNTIME_EXPERIMENT.json",
                   report/"CAUSALITY_DELIVERY_RECEIPT.json",staging/"runtime_cpu_v1/MANIFEST.json",
                   staging/"runtime_cpu_v2/MANIFEST.json",staging/"runtime_cpu_v1/EXECUTED_V1_s6a_runtime_profile.py",
                   simulation/"scripts/s6a_runtime_profile.py",simulation/"scripts/s6a_causality_checks.py"]
    result["supporting_experiment_bindings"]=[{"path":str(p),"sha256":hashlib.sha256(p.read_bytes()).hexdigest(),"bytes":p.stat().st_size} for p in support_paths if p.exists()]
    (report/"PARAMETER_BINDINGS.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    lines=["# Actual S6A component map","", "This map describes the application that executes the named S6A profiles. Historical B0 remains separately preserved; no GUI defaults or model weights changed. All outcome claims belong to the completed probe tables, not the candidate descriptions here.","",
    "## Runtime flow","",
    "Prepared mono file or microphone â†’ normalization/resampling â†’ append-only PCM16 journal â†’ independent ASR and speaker cursors. ASR owns one native streaming recognizer, endpoint state and final punctuation. The speaker lane owns a fixed 10-second Pyannote session, contiguous ReDim calls and the selected anonymous tracker. Source-clock events feed the shared CLI/GUI. Default GUI uses the baseline tracker. Explicit profiles add bounded telemetry, component logging and real forward lineage.","",
    "The predictor receives waveform, numeric timing, optional sanitized spatial/energy observations and embeddings. It has no reference text, true source identity, room/scenario/seat labels or future sample array. Existing baseline enrollment is separate from the anonymous research modes.","",
    "## What the installed models actually do","",
    "Pyannote: the bound ONNX graph is float32 [1,1,160000] â†’ [1,589,7] log probabilities. Actual exp(log-score) normalization error was below 2.4e-7 in the initial graph probe. Seven classes encode silence, three local singles and three local pairs. Slots are local to a 10-second invocation; there is no global diarization/clustering pipeline here. The public model card agrees with this contract. [Pyannote model card](https://huggingface.co/pyannote/segmentation-3.0)","",
    "Historical onset=0.46 and offset=0.45 were unused by the actual H2 runtime. It argmaxed powerset classes, converted to binary speech/overlap and compared both tail fractions with >=0.20. The new optional posterior policy computes speech probability as 1-p0 and overlap probability as p4+p5+p6, then applies hysteresis to mean tail speech probability. Changing thresholds on class IDs is never supported.","",
    "The verified frontend frame step is 0.016875 seconds and receptive duration is 0.0619375 seconds; for index i, the nominal frontend interval is [i*0.016875, i*0.016875+0.0619375] relative to graph input. These are frontend frame coordinates, not full neural causality: the bidirectional network depends on its supplied 10-second context. Early trailing calls contain left zero-padding. The last 44 baseline frames approximate 0.7425 seconds; no exact phonetic boundary is claimed.","",
    "ReDim: the actual bound backend is PalabraAI ReDimNet2-B2, not the older ReDimNet architecture linked generically in the pack. Checkpoint metadata was read locally with weights_only=True and its hash matched existing provenance. Configuration: 72 TF-style mel bins, 160-sample hop, waveform normalization, 0.97 pre-emphasis, 512 FFT / 400-sample Hamming window, 20â€“7600 Hz frontend defaults, log features and mean subtraction, global-context ASTP pooling, 192-dimensional raw embedding. The application L2 normalizes before cosine scoring. The dynamic-time ONNX input has no mask input. [ReDimNet2 authors](https://github.com/PalabraAI/redimnet2)","",
    "Actual existing-graph calls at 0.5, 0.75, 1, 1.5, 2 and 3 seconds produced finite unit vectors. Inputs shorter than 8000 samples are rejected by the wrapper. Longer windows use whole contiguous waveforms, incur wait and compute cost, and may mix speakers; overlapping windows cannot count as independent evidence. The current RMS gate reads the dispatch block, not the full embedding interval.","",
    "Sherpa: installed sherpa-onnx 1.13.4 provides the native OnlineRecognizer.from_transducer parameters bound in PARAMETER_BINDINGS.json. Encoder input is [N,39,80], metadata decode_chunk_len=32 and left context lengths 64,32,16,8,32. A 50/100-ms journal read does not resize this graph. Endpoint or decoder changes require a fresh stateful run. Existing reset_endpoint resets the recognizer only at an actual endpoint/advisory request; a tentative speaker change alone never resets it. The terminal 0.66-second zero padding is synthetic drain context and is excluded from observed source duration. [Sherpa Python reference](https://k2-fsa.github.io/sherpa/onnx/python/index.html)","",
    "## Control bindings","", "| Profile field | B0 value | Kind and binding | Range / comparator |", "|---|---:|---|---|"]
    for r in records:
        value=json.dumps(r["baseline_value"],ensure_ascii=False)
        lines.append(f'| {r["profile_field"]} | {value} | {r["implementation_kind"]}; {r["actual_binding"]} | {r["supported_range"]}; {r["comparator"]} |')
    lines.extend(["","PARAMETER_BINDINGS.json additionally records units, full input/output semantics, downstream effects, availability and the exact effect-test evidence for every field. Supported API plumbing is not a promise of accuracy or production suitability.","",
    "## Revision and reproducibility","", "Forty-eight completed V1 probe jobs are preserved and superseded, not relabelled as V2. PROBE_V1_CLOSURE.json binds their exact archived code and data. V2 fixes the separate causal overlap-display history, initial cue-enabled flag, positive revision-horizon validation and ineffective tracking-only rejection. All ten named profile JSON files remain byte-identical. The exact model weights and baseline B0 snapshot remain unchanged.","", "V2 separately measures model loading in research_models_ready. Modeled source-clock availability begins after loading, so it is a warm-resident lane model rather than cold button-to-first-decision latency. Actual concurrent worker scheduling can still affect first displayed labels; the neural-prefix, tracker-decision and first-display invariance checks must be reported separately.","", "## Clocks, lineage and cache consequences","",
    "Measured process elapsed times stay separate from historical physical-capture clocks. Model-availability fields use an explicit serial lane model: max(previous ready, input end) plus measured neural compute. Segmentation and embedding are both charged; ASR partial tails, final drain and punctuation are charged. This supports comparable source-clock scheduling without pretending accelerated wall time is live latency. Candidate transcript labels only use already delivered speaker evidence; original first outputs remain logged. Tracker branch split/merge and label_revision records are later events, never retroactive success.","",
    "Changed audio/tap/gain invalidates every consumer. Changed segmentation stride/context invalidates neural tensors; changed post-policy can reuse only exactly matching tensors and recomputes changed descendant embedding spans. Changed ReDim span/hop invalidates vectors. Changed Sherpa audio/decoder/endpoint/reset/dispatch requires stateful recognition. Tracker-only changes can reuse exact normalized vectors at their charged availability. CPU/provider changes require fresh performance and parity evidence. Cache and causality receipts are owned by the main S6A coordinator.","",
    "## Supported alternatives and remaining limitations","",
    "- Fixed 10-second Pyannote graph shortening, full Pyannote clustering, arbitrary encoder chunk sizes, frame-level ReDim masks and changed neural pooling are unsupported. Supported alternatives are inference stride, valid powerset postprocessing, contiguous embedding durations/cadence and native endpoint/host dispatch.","- Anonymous trackers have no names or enrollment oracle. Baseline identity evidence is elapsed span; new tracking evidence counts unique support. No all-unknown or one-person control may be interpreted as successful diarization.","- Spatial energy is positive-support evidence with unknown calibration, not ground-truth VAD. The native angle is folded 0..180 degrees. Stale observation time cannot be refreshed by a new delivery timestamp.","- The initial graph-check process observed Windows private commit much larger than resident USS/RSS. Private commit/address reservation must not be treated as CM5 resident physical RAM. Full paced process-tree measurement and actual ARM64 qualification remain separate.","- The actual runtime still produces growing disk journals and local vector-bearing research logs. Production retention, eMMC write policy and long-session bounded-state qualification remain later work.","",
    "## Executed plumbing evidence","",
    "COMPONENT_API_TESTS_V2.json: 13 focused fixtures passed, plus actual graph/provider/length checks. Six existing edge runtime tests passed. The real-model engineering smoke used the first 12.037 seconds of an existing native gained O0 journal with a explicitly synthetic constant cue: 24 segmentation calls, eight real embeddings, 240 full 50-ms ASR dispatches, one residual tail, one final drain, one durable completion and zero dropped frames. It is not part of the accuracy panel.","",
    "Independent review found and resolved missing EOF cost accounting and stale observation redelivery. Its reproducible 1707-sample actual-loop fixture delivered exactly [1600,107], preserved the terminal text and excluded synthetic drain padding from observed source duration. See design/INDEPENDENT_EOF_REVIEW.json and later independent review receipts.","",
    "Run instructions, inputs/outputs and rollback are in the actual application's README_RESEARCH_PROFILES.md. The component report builder is read-only; README_COMPONENT_MAP_BUILDER.md provides its exact invocation."])
    if (report/"RUNTIME_EXPERIMENT.json").exists():
        runtime=json.loads((report/"RUNTIME_EXPERIMENT.json").read_text())
        lines.extend(["","## Paced resident-process evidence","",
                      "RUNTIME_EXPERIMENT.json contains the controlled V2 full-pipeline study: four sequential 89.390875-second paced files, ASR/speaker threads 1 or 2 crossed with host ASR dispatch 50 or 100 ms. OMP, OpenBLAS, MKL and NumExpr are each limited to one before numerical imports. Other study jobs ran concurrently, so these are observed desktop costs under contention.","",
                      "| Model threads | Dispatch ms | Private resident USS MiB | RSS upper bound MiB | Private commit MiB | Observed tree threads | Sampled CPU seconds | ASR / speaker backlog max s |",
                      "|---:|---:|---:|---:|---:|---:|---:|---|" ])
        for row in runtime["rows"]:
            lines.append(f'| {row["threads"]} | {row["dispatch_ms"]} | {row["peak_private_resident_uss_sum_bytes"]/2**20:.1f} | {row["peak_rss_sum_upper_bound_bytes"]/2**20:.1f} | {row["peak_windows_private_commit_sum_bytes"]/2**20:.1f} | {row["peak_observed_tree_threads"]} | {row["process_cpu_sec_sampled"]:.2f} | {row["asr_backlog_sec"]["max"]:.2f} / {row["speaker_backlog_sec"]["max"]:.2f} |')
        lines.extend(["","USS is unique private resident memory. RSS sums are an upper bound because shared pages can be counted repeatedly. RSS minus USS is a nonunique shared-page estimate; PSS is unavailable on this Windows host. Private commit is committed virtual memory, not physical resident RAM. Full receipts include OS headroom, startup, write bytes/rates, process identities and closure. This does not qualify a CM5 2 GB target or translate desktop throughput to ARM.","",
                      "The preserved RUNTIME_EXPERIMENT_V1_LIBRARY_DEFAULTS.json is an adverse library-default screen: its numeric pools were unset and its observed process thread count was much larger. The V1 app revision also predates the overlap-display fix and loading instrumentation, so cross-version resource differences cannot be attributed solely to numeric pool limits. V1 and V2 manifests and runner hashes are included in PARAMETER_BINDINGS.json; the ten named candidate profiles remain unchanged."])
    if (report/"CAUSALITY_DELIVERY_RECEIPT.json").exists():
        causal=json.loads((report/"CAUSALITY_DELIVERY_RECEIPT.json").read_text())
        lines.extend(["","## Actual neural prefix and delivery evidence","",
                      "CAUSALITY_DELIVERY_RECEIPT.json compares two fresh full native P1X0 engines with an identical 12-second recorded prefix and different six-second futures. Actual native audio, raw ASR, endpoints, segmentation posteriors/gates, ReDim vectors, tracker lineage and native first labels are checked separately. Measured compute and availability clocks remain in raw logs and are excluded only from semantic comparison.","",
                      f'Engineering prefix check passed: {causal["engineering_prefix_check_pass"]}. First displayed label invariance observed: {causal["first_displayed_label_invariance_observed"]}. These are bounded regression findings, not universal causality or scheduling proofs. The same receipt reports the real 50/100-ms delivery pairs, including sample continuity, words, endpoints and vector parity.'])
    (report/"COMPONENT_MAP.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    refresh_plumbing_receipt(report)
    print(json.dumps({"parameters":len(records),"output":str(report/"PARAMETER_BINDINGS.json"),"source_files":len(sources)}))

if __name__=="__main__":main()
