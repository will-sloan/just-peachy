# Reading the S6A tables

Use the complete baseline tables for the original-setting all-bank O0/O1 comparison. Use the component tables for the fixed36-scene screening panel. Candidate panel results and full-bank B0 results have different input populations; compare a candidate with the paired B0 rows for that same panel before attributing a difference to a method.

## Text and attribution

WER is `(substitutions + deletions + insertions) / reference_words`. Pooled WER sums those counts across the declared population before division. CER follows the equivalent character-count definition. Per-scene percentages are not averaged to produce the pooled headline rate. A percentage-point delta is100 times the difference between rates, not a relative percentage improvement.

Primary non-overlap WER/CER, complete overlap MIMO-WER, incomplete environmental target-only WER and empty controls are separate populations. MIMO-WER uses the complete overlap reference structure and permits the metric's sequence assignment; it is not the primary single-sequence WER. Unknown environmental words are not invented to complete a reference. Target-only ambient results remain limited diagnostics. Empty references have no WER denominator; report inserted words and inserted words/minute instead.

The panel's five incomplete ambient scenes contain164 known inserted words in the full coverage inventory, while the inherited target-only metric uses146 designated target words. The18 non-target words remain in the full reference and source inventory. A target-only score can therefore count known non-target speech as insertions as well as untranscribed environmental speech; it must not be described as an all-speaker error or hallucination rate.

Final-label cpWER is permutation-invariant concatenated word error using the actual final transcript speaker labels. It includes lexical and attribution errors; it is neither DER nor an isolated identity-quality measurement. The baseline historical attribution path differs from the new modeled-availability tracker path. Original first labels are not rewritten to credit later tracker lineage. The reference comparison fixes lexical words across its policies; component profiles can change actual stateful recognition and are scored on their new words.

`BASELINE_COMPONENT_COMPARISON.csv` compares every native profile output with the exact B0 result for the same case/tap. `exact_normalized_words` compares actual normalized strings, including overlap and controls; matching error counts alone is insufficient. `P0X0` retains original neural settings with the new tracker, so its cpWER is not assumed equal to exact B0 even when its words match.

## Paired components and interactions

`PAIRED_SCENE_DELTAS.csv` is candidate minus its named parent. The population table pools paired counts and also retains lower/equal/higher-error scene counts. Both taps use the same selected scene panel. Effects for the posterior/stride, cadence/RMS, endpoint/dispatch and joint-component bundles do not identify each internal parameter separately.

For the two-by-two table, `P` is the declared component bundle and `X` is the advisory cue route. The X route can affect tracking and supported endpoint proposals, so it is not a labels-only intervention. The interaction is `(P1X1 − P1X0) − (P0X1 − P0X0)` for the stated metric. Its sign describes this selected panel; it does not establish significance, generalization or the causal mechanism of each constituent parameter. Full-panel tables are withheld until all four cells contain the same36 scenes per tap.

## Identity support and source timing

All777 intentionally inserted utterances remain in full-bank reference turn tables, including missed speech. The shared support scorer maps their original schedules/activity estimates into the output using the frozen alignment estimate. Missing alignment is unavailable, not zero error or an omitted successful turn. Exact source identity is available to evaluation only; the predictor receives audio and causally delivered sensor values.

Sole-speech support subtracts other known source activity. Unknown support is the part of that denominator with no available label. The mixed-identity/false-merge diagnostic measures the non-dominant true-identity support attached to a predicted label. It is an evaluation proxy, not verified named-person recognition. Unknown fraction and mixed-identity fraction on the same sole-speech denominator must be considered together. The known-only false-merge fraction alone can make an all-unknown system look deceptively good.

`tracking_false_merge_fraction_of_known` uses known labeled support as its denominator. `tracking_unassigned_or_conflated_fraction` uses total sole-speech support and includes both unknown and conflated support. Return consistency compares anonymous modal labels under the declared support rule; consistency is not evidence that the label names the correct person. A known modal label on a short turn is coverage, not necessarily correct identity.

First-available decisions use delivered/model availability and the fixed source-end plus0.75s expiry rule. A fixed-lag revision remains a delayed revision and receives no retroactive first-decision credit. The reference bridge and application delivery have separately documented callback quantization; they cannot be treated as calibrated DSP timestamps.

## Embedding evidence, short turns and segmentation

`embedding_total_window_s` sums all accepted window durations. `embedding_union_s` measures their within-output interval union, so overlapping windows do not count as independent seconds of evidence. Union totals can be summed across outputs for workload description, but repeated scenes/taps are not independent people or recording sessions.

Source-specific contained-window analysis is restricted to complete-reference turns whose mapped source file envelope does not overlap another inserted source envelope. Whole-clip bins are `<1s`, `1-<2s` and `>=2s`; they are not bins of oracle phonetic speech duration. The table preserves eligible turns without a contained window. Its wait statistic is measured from the aligned source file start to the first contained embedding's warm modeled availability; it excludes missing observations and therefore must be read with `waits_measured` and `eligible_without_contained_window`. It is not live voice-onset latency.

Window-purity categories describe overlap with known source file envelopes. A fully contained single-source window can still include silence, reverberation or unknown environmental speech; the category is not oracle acoustic purity. Cross-person windows are retained as adverse evidence. Coarse segmentation speech/overlap flags use trailing output spans and source activity/alignment estimates, not frame-exact segmentation truth. Both observed and total support samples remain in the tables.

## Cost and memory

The ASR instrumented call totals include regular host dispatch, the final partial host block and EOF drain. Segmentation, embedding, final-only punctuation and fresh-process model loading are separate. These are instrumented call elapsed sums, not complete component costs: the segmentation timer ends before powerset-posterior conversion, and wrapper/postprocessing, tracker/gate, advisory/reset and formatting work are not all timed in the stacks. Summing instrumented calls across concurrent lanes does not produce wall time or steady-state real-time factor. The720 offline runs used two worker-allocation epochs under concurrent desktop load; they are screening cost observations. The separate paced thread/dispatch experiment is the matched desktop queue experiment.

The first nonempty partial timestamp is measured from file origin among outputs that actually emit one. It is not phonetic onset latency. Modeled availability assumes warm resident models; fresh-process loading does not mean uncached storage or a cold boot. Native speaker-history scheduling also depends on concurrent worker execution, so reported first labels are not a deterministic real-time scheduler benchmark.

USS is private resident memory; RSS is a resident upper bound that includes shared pages; Windows private commit is allocated private committed memory. RSS-minus-USS is not a unique process-tree shared-memory total, and PSS is unavailable here. Missing measurements remain null. No desktop time or memory number is a CM5 speed multiplier, thermal qualification or proof that the complete2GB device image fits.
