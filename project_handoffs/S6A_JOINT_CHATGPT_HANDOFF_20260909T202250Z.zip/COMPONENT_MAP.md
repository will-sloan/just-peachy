# Actual S6A component map

This map describes the application that executes the named S6A profiles. Historical B0 remains separately preserved; no GUI defaults or model weights changed. All outcome claims belong to the completed probe tables, not the candidate descriptions here.

## Runtime flow

Prepared mono file or microphone â†’ normalization/resampling â†’ append-only PCM16 journal â†’ independent ASR and speaker cursors. ASR owns one native streaming recognizer, endpoint state and final punctuation. The speaker lane owns a fixed 10-second Pyannote session, contiguous ReDim calls and the selected anonymous tracker. Source-clock events feed the shared CLI/GUI. Default GUI uses the baseline tracker. Explicit profiles add bounded telemetry, component logging and real forward lineage.

The predictor receives waveform, numeric timing, optional sanitized spatial/energy observations and embeddings. It has no reference text, true source identity, room/scenario/seat labels or future sample array. Existing baseline enrollment is separate from the anonymous research modes.

## What the installed models actually do

Pyannote: the bound ONNX graph is float32 [1,1,160000] â†’ [1,589,7] log probabilities. Actual exp(log-score) normalization error was below 2.4e-7 in the initial graph probe. Seven classes encode silence, three local singles and three local pairs. Slots are local to a 10-second invocation; there is no global diarization/clustering pipeline here. The public model card agrees with this contract. [Pyannote model card](https://huggingface.co/pyannote/segmentation-3.0)

Historical onset=0.46 and offset=0.45 were unused by the actual H2 runtime. It argmaxed powerset classes, converted to binary speech/overlap and compared both tail fractions with >=0.20. The new optional posterior policy computes speech probability as 1-p0 and overlap probability as p4+p5+p6, then applies hysteresis to mean tail speech probability. Changing thresholds on class IDs is never supported.

The verified frontend frame step is 0.016875 seconds and receptive duration is 0.0619375 seconds; for index i, the nominal frontend interval is [i*0.016875, i*0.016875+0.0619375] relative to graph input. These are frontend frame coordinates, not full neural causality: the bidirectional network depends on its supplied 10-second context. Early trailing calls contain left zero-padding. The last 44 baseline frames approximate 0.7425 seconds; no exact phonetic boundary is claimed.

ReDim: the actual bound backend is PalabraAI ReDimNet2-B2, not the older ReDimNet architecture linked generically in the pack. Checkpoint metadata was read locally with weights_only=True and its hash matched existing provenance. Configuration: 72 TF-style mel bins, 160-sample hop, waveform normalization, 0.97 pre-emphasis, 512 FFT / 400-sample Hamming window, 20â€“7600 Hz frontend defaults, log features and mean subtraction, global-context ASTP pooling, 192-dimensional raw embedding. The application L2 normalizes before cosine scoring. The dynamic-time ONNX input has no mask input. [ReDimNet2 authors](https://github.com/PalabraAI/redimnet2)

Actual existing-graph calls at 0.5, 0.75, 1, 1.5, 2 and 3 seconds produced finite unit vectors. Inputs shorter than 8000 samples are rejected by the wrapper. Longer windows use whole contiguous waveforms, incur wait and compute cost, and may mix speakers; overlapping windows cannot count as independent evidence. The current RMS gate reads the dispatch block, not the full embedding interval.

Sherpa: installed sherpa-onnx 1.13.4 provides the native OnlineRecognizer.from_transducer parameters bound in PARAMETER_BINDINGS.json. Encoder input is [N,39,80], metadata decode_chunk_len=32 and left context lengths 64,32,16,8,32. A 50/100-ms journal read does not resize this graph. Endpoint or decoder changes require a fresh stateful run. Existing reset_endpoint resets the recognizer only at an actual endpoint/advisory request; a tentative speaker change alone never resets it. The terminal 0.66-second zero padding is synthetic drain context and is excluded from observed source duration. [Sherpa Python reference](https://k2-fsa.github.io/sherpa/onnx/python/index.html)

## Control bindings

| Profile field | B0 value | Kind and binding | Range / comparator |
|---|---:|---|---|
| input.tap | "mono" | input binding declaration; cli.py:main | mono/O0/O1; prepared mono file, no automatic channel selection |
| input.gain | 1.0 | wrapper preprocessing; runtime.py:PipelineEngine._asr_loop/_speaker_loop | 0.25..4; unity if already_gained; multiply float after nativePCM16 journal |
| input.already_gained | false | validation guard; research_profiles.py:ResearchProfile.validate | true/false; true implies gain==1 |
| asr.endpoint_rule1_silence_sec | 2.4 | native installed Sherpa control; models.py:SherpaStream.__init__ | 0.1..5; native endpoint rule satisfaction; wrapper resets only explicit endpoint |
| asr.endpoint_rule2_silence_sec | 1.2 | native installed Sherpa control; models.py:SherpaStream.__init__ | 0.1..5; native endpoint rule satisfaction; wrapper resets only explicit endpoint |
| asr.endpoint_rule3_utterance_sec | 20.0 | native installed Sherpa control; models.py:SherpaStream.__init__ | 5..60; native endpoint rule satisfaction; wrapper resets only explicit endpoint |
| asr.decoding_method | "greedy_search" | native installed Sherpa control; models.py:SherpaStream.__init__ | greedy_search/modified_beam_search; exact native string |
| asr.max_active_paths | 4 | native conditional control; models.py:SherpaStream.__init__ | 1/2/4/8 only modifiedbeam; baselinegreedy retains4; beam path limit |
| asr.blank_penalty | 0.0 | native installed Sherpa control; models.py:SherpaStream.__init__ | -2..2; native blank penalty |
| asr.journal_read_ms | 100 | host wrapper dispatch; runtime.py:PipelineEngine._asr_loop | 20/50/100/200; consume fixed source blocks and one exact remainder |
| segmentation.window_sec | 10.0 | fixed graph constraint; models.py:SpeakerModels.segment | exact10; sample_count==160000 |
| segmentation.hop_sec | 0.75 | wrapper inference schedule; runtime.py:PipelineEngine._speaker_loop | .25..1.5 and integer multiple embeddinghop; since_segment>=hop |
| segmentation.post_policy | "hard_argmax_fraction" | wrapper powerset postprocessing; research_profiles.py:segmentation_gate | hard_argmax_fraction/posterior_hysteresis; hardbinaryfraction vs validpowersetprobability |
| segmentation.onset | 0.46 | wrapper conditional threshold; research_profiles.py:segmentation_gate | 0..1;offset<=onset;inertB0; mean tail P(speech)>=onset ifinactive elseoffset; minusqualifiedcueassist |
| segmentation.offset | 0.45 | wrapper conditional threshold; research_profiles.py:segmentation_gate | 0..1;offset<=onset;inertB0; mean tail P(speech)>=onset ifinactive elseoffset; minusqualifiedcueassist |
| segmentation.speech_fraction_threshold | 0.2 | wrapper conditional threshold; research_profiles.py:segmentation_gate | 0..1;hardpolicyonly; >= |
| segmentation.overlap_fraction_threshold | 0.2 | wrapper threshold; research_profiles.py:segmentation_gate | 0..1; >= |
| embedding.window_sec | 0.5 | wrapper neural input span; runtime.py:PipelineEngine._speaker_loop;models.py:SpeakerModels.embed | .5..3; rolling.size>=window |
| embedding.hop_sec | 0.25 | wrapper dispatch/cadence; runtime.py:PipelineEngine._speaker_loop | .25..1 and<=seghop;dividesseghop; consume one hop at a time |
| embedding.minimum_rms | 0.002 | wrapper audio quality gate; runtime.py:PipelineEngine._speaker_loop | 0..0.02; >= |
| tracker.mode | "baseline" | anonymous tracking wrapper; research_tracking.py:TrackingConfig;ResearchTracker.update | bounded validation inResearchProfile.validate andTrackingConfig.__post_init__; mode-specific cosine>=,ambiguitymargin,age/decay andvoiceconflictguard |
| tracker.cosine_threshold | 0.35 | baseline/research cosine association; research_tracking.py:TrackingConfig;ResearchTracker.update | bounded validation inResearchProfile.validate andTrackingConfig.__post_init__; mode-specific cosine>=,ambiguitymargin,age/decay andvoiceconflictguard |
| tracker.ambiguity_margin | 0.03 | anonymous tracking wrapper; research_tracking.py:TrackingConfig;ResearchTracker.update | bounded validation inResearchProfile.validate andTrackingConfig.__post_init__; mode-specific cosine>=,ambiguitymargin,age/decay andvoiceconflictguard |
| tracker.commit_evidence_sec | 1.0 | anonymous tracking wrapper; research_tracking.py:TrackingConfig;ResearchTracker.update | bounded validation inResearchProfile.validate andTrackingConfig.__post_init__; mode-specific cosine>=,ambiguitymargin,age/decay andvoiceconflictguard |
| tracker.prototype_update_threshold | 0.45 | anonymous tracking wrapper; research_tracking.py:TrackingConfig;ResearchTracker.update | bounded validation inResearchProfile.validate andTrackingConfig.__post_init__; mode-specific cosine>=,ambiguitymargin,age/decay andvoiceconflictguard |
| tracker.max_tracks | 16 | anonymous tracking wrapper; research_tracking.py:TrackingConfig;ResearchTracker.update | bounded validation inResearchProfile.validate andTrackingConfig.__post_init__; mode-specific cosine>=,ambiguitymargin,age/decay andvoiceconflictguard |
| tracker.direction_match_deg | 25.0 | anonymous tracking wrapper; research_tracking.py:TrackingConfig;ResearchTracker.update | bounded validation inResearchProfile.validate andTrackingConfig.__post_init__; mode-specific cosine>=,ambiguitymargin,age/decay andvoiceconflictguard |
| tracker.direction_change_deg | 35.0 | anonymous tracking wrapper; research_tracking.py:TrackingConfig;ResearchTracker.update | bounded validation inResearchProfile.validate andTrackingConfig.__post_init__; mode-specific cosine>=,ambiguitymargin,age/decay andvoiceconflictguard |
| tracker.direction_persistence_sec | 0.75 | anonymous tracking wrapper; research_tracking.py:TrackingConfig;ResearchTracker.update | bounded validation inResearchProfile.validate andTrackingConfig.__post_init__; mode-specific cosine>=,ambiguitymargin,age/decay andvoiceconflictguard |
| tracker.direction_max_age_sec | 0.25 | anonymous tracking wrapper; research_tracking.py:TrackingConfig;ResearchTracker.update | bounded validation inResearchProfile.validate andTrackingConfig.__post_init__; mode-specific cosine>=,ambiguitymargin,age/decay andvoiceconflictguard |
| tracker.position_decay_sec | 12.0 | anonymous tracking wrapper; research_tracking.py:TrackingConfig;ResearchTracker.update | bounded validation inResearchProfile.validate andTrackingConfig.__post_init__; mode-specific cosine>=,ambiguitymargin,age/decay andvoiceconflictguard |
| tracker.spatial_weight | 0.12 | anonymous tracking wrapper; research_tracking.py:TrackingConfig;ResearchTracker.update | bounded validation inResearchProfile.validate andTrackingConfig.__post_init__; mode-specific cosine>=,ambiguitymargin,age/decay andvoiceconflictguard |
| tracker.conflict_cosine_floor | 0.2 | anonymous tracking wrapper; research_tracking.py:TrackingConfig;ResearchTracker.update | bounded validation inResearchProfile.validate andTrackingConfig.__post_init__; mode-specific cosine>=,ambiguitymargin,age/decay andvoiceconflictguard |
| tracker.reconciliation_enabled | true | anonymous tracking wrapper; research_tracking.py:TrackingConfig;ResearchTracker.update | bounded validation inResearchProfile.validate andTrackingConfig.__post_init__; mode-specific cosine>=,ambiguitymargin,age/decay andvoiceconflictguard |
| tracker.revision_horizon_sec | 2.0 | anonymous tracking wrapper; research_tracking.py:TrackingConfig;ResearchTracker.update | bounded validation inResearchProfile.validate andTrackingConfig.__post_init__; mode-specific cosine>=,ambiguitymargin,age/decay andvoiceconflictguard |
| tracker.reconciliation_cosine | 0.65 | anonymous tracking wrapper; research_tracking.py:TrackingConfig;ResearchTracker.update | bounded validation inResearchProfile.validate andTrackingConfig.__post_init__; mode-specific cosine>=,ambiguitymargin,age/decay andvoiceconflictguard |
| tracker.identity_score_threshold | 0.5128856897354127 | baseline identity wrapper conditional; speakers.py:SpeakerTracker.update | 0..10 seconds; score[-1,1];margin[0,2]; >= |
| tracker.identity_margin_threshold | 0.03 | baseline identity wrapper conditional; speakers.py:SpeakerTracker.update | 0..10 seconds; score[-1,1];margin[0,2]; >= |
| tracker.identity_minimum_evidence_sec | 2.0 | baseline identity wrapper conditional; speakers.py:SpeakerTracker.update | 0..10 seconds; score[-1,1];margin[0,2]; >= |
| xvf.mode | "none" | cross-component wrapper policy; research_profiles.py:EndpointAdvisor;spatial_is_fresh;runtime.py:PipelineEngine._speaker_loop | mode none/tracking_only/soft_energy/advisory/soft_energy_advisory;delta[0,.15];reliability[0,1];silence[.1,1]; fresh positiveenergysupport; sustaineddirectionchange AND actualsilence forreset |
| xvf.speech_assist_delta | 0.05 | cross-component wrapper policy; research_profiles.py:EndpointAdvisor;spatial_is_fresh;runtime.py:PipelineEngine._speaker_loop | mode none/tracking_only/soft_energy/advisory/soft_energy_advisory;delta[0,.15];reliability[0,1];silence[.1,1]; fresh positiveenergysupport; sustaineddirectionchange AND actualsilence forreset |
| xvf.minimum_reliability | 0.5 | cross-component wrapper policy; research_profiles.py:EndpointAdvisor;spatial_is_fresh;runtime.py:PipelineEngine._speaker_loop | mode none/tracking_only/soft_energy/advisory/soft_energy_advisory;delta[0,.15];reliability[0,1];silence[.1,1]; fresh positiveenergysupport; sustaineddirectionchange AND actualsilence forreset |
| xvf.advisory_silence_sec | 0.3 | cross-component wrapper policy; research_profiles.py:EndpointAdvisor;spatial_is_fresh;runtime.py:PipelineEngine._speaker_loop | mode none/tracking_only/soft_energy/advisory/soft_energy_advisory;delta[0,.15];reliability[0,1];silence[.1,1]; fresh positiveenergysupport; sustaineddirectionchange AND actualsilence forreset |
| xvf.advisory_min_utterance_sec | 0.5 | cross-component wrapper policy; research_profiles.py:EndpointAdvisor;spatial_is_fresh;runtime.py:PipelineEngine._speaker_loop | mode none/tracking_only/soft_energy/advisory/soft_energy_advisory;delta[0,.15];reliability[0,1];silence[.1,1]; fresh positiveenergysupport; sustaineddirectionchange AND actualsilence forreset |
| punctuation.mode | "final_only" | fixed wrapper behavior; models.py:SherpaStream.punctuate;runtime.py:PipelineEngine._asr_loop | final_only; runonceperfinal |
| punctuation.partial_display_min_interval_sec | 0.0 | display wrapper cadence; runtime.py:PipelineEngine._asr_loop | 0..1; >=elapsed source interval |
| runtime.asr_threads | 2 | native CPU pool control; models.py:_ort_session/SherpaStream.__init__ | 1/2/4threads;capture10/20/50/100ms;reserve10..120s; positiveintegerbounded |
| runtime.speaker_threads | 2 | native CPU pool control; models.py:_ort_session/SherpaStream.__init__ | 1/2/4threads;capture10/20/50/100ms;reserve10..120s; positiveintegerbounded |
| runtime.punctuation_threads | 1 | native CPU pool control; models.py:_ort_session/SherpaStream.__init__ | 1/2/4threads;capture10/20/50/100ms;reserve10..120s; positiveintegerbounded |
| runtime.capture_block_ms | 20 | host capture wrapper; audio.py:MicrophoneSource | 1/2/4threads;capture10/20/50/100ms;reserve10..120s; positiveintegerbounded |
| runtime.raw_capture_reserve_sec | 120 | host capture wrapper; audio.py:MicrophoneSource | 1/2/4threads;capture10/20/50/100ms;reserve10..120s; positiveintegerbounded |

PARAMETER_BINDINGS.json additionally records units, full input/output semantics, downstream effects, availability and the exact effect-test evidence for every field. Supported API plumbing is not a promise of accuracy or production suitability.

## Revision and reproducibility

Forty-eight completed V1 probe jobs are preserved and superseded, not relabelled as V2. PROBE_V1_CLOSURE.json binds their exact archived code and data. V2 fixes the separate causal overlap-display history, initial cue-enabled flag, positive revision-horizon validation and ineffective tracking-only rejection. All ten named profile JSON files remain byte-identical. The exact model weights and baseline B0 snapshot remain unchanged.

V2 separately measures model loading in research_models_ready. Modeled source-clock availability begins after loading, so it is a warm-resident lane model rather than cold button-to-first-decision latency. Actual concurrent worker scheduling can still affect first displayed labels; the neural-prefix, tracker-decision and first-display invariance checks must be reported separately.

## Clocks, lineage and cache consequences

Measured process elapsed times stay separate from historical physical-capture clocks. Model-availability fields use an explicit serial lane model: max(previous ready, input end) plus measured neural compute. Segmentation and embedding are both charged; ASR partial tails, final drain and punctuation are charged. This supports comparable source-clock scheduling without pretending accelerated wall time is live latency. Candidate transcript labels only use already delivered speaker evidence; original first outputs remain logged. Tracker branch split/merge and label_revision records are later events, never retroactive success.

Changed audio/tap/gain invalidates every consumer. Changed segmentation stride/context invalidates neural tensors; changed post-policy can reuse only exactly matching tensors and recomputes changed descendant embedding spans. Changed ReDim span/hop invalidates vectors. Changed Sherpa audio/decoder/endpoint/reset/dispatch requires stateful recognition. Tracker-only changes can reuse exact normalized vectors at their charged availability. CPU/provider changes require fresh performance and parity evidence. Cache and causality receipts are owned by the main S6A coordinator.

## Supported alternatives and remaining limitations

- Fixed 10-second Pyannote graph shortening, full Pyannote clustering, arbitrary encoder chunk sizes, frame-level ReDim masks and changed neural pooling are unsupported. Supported alternatives are inference stride, valid powerset postprocessing, contiguous embedding durations/cadence and native endpoint/host dispatch.
- Anonymous trackers have no names or enrollment oracle. Baseline identity evidence is elapsed span; new tracking evidence counts unique support. No all-unknown or one-person control may be interpreted as successful diarization.
- Spatial energy is positive-support evidence with unknown calibration, not ground-truth VAD. The native angle is folded 0..180 degrees. Stale observation time cannot be refreshed by a new delivery timestamp.
- The initial graph-check process observed Windows private commit much larger than resident USS/RSS. Private commit/address reservation must not be treated as CM5 resident physical RAM. Full paced process-tree measurement and actual ARM64 qualification remain separate.
- The actual runtime still produces growing disk journals and local vector-bearing research logs. Production retention, eMMC write policy and long-session bounded-state qualification remain later work.

## Executed plumbing evidence

COMPONENT_API_TESTS_V2.json: 13 focused fixtures passed, plus actual graph/provider/length checks. Six existing edge runtime tests passed. The real-model engineering smoke used the first 12.037 seconds of an existing native gained O0 journal with a explicitly synthetic constant cue: 24 segmentation calls, eight real embeddings, 240 full 50-ms ASR dispatches, one residual tail, one final drain, one durable completion and zero dropped frames. It is not part of the accuracy panel.

Independent review found and resolved missing EOF cost accounting and stale observation redelivery. Its reproducible 1707-sample actual-loop fixture delivered exactly [1600,107], preserved the terminal text and excluded synthetic drain padding from observed source duration. See design/INDEPENDENT_EOF_REVIEW.json and later independent review receipts.

Run instructions, inputs/outputs and rollback are in the actual application's README_RESEARCH_PROFILES.md. The component report builder is read-only; README_COMPONENT_MAP_BUILDER.md provides its exact invocation.

## Paced resident-process evidence

RUNTIME_EXPERIMENT.json contains the controlled V2 full-pipeline study: four sequential 89.390875-second paced files, ASR/speaker threads 1 or 2 crossed with host ASR dispatch 50 or 100 ms. OMP, OpenBLAS, MKL and NumExpr are each limited to one before numerical imports. Other study jobs ran concurrently, so these are observed desktop costs under contention.

| Model threads | Dispatch ms | Private resident USS MiB | RSS upper bound MiB | Private commit MiB | Observed tree threads | Sampled CPU seconds | ASR / speaker backlog max s |
|---:|---:|---:|---:|---:|---:|---:|---|
| 1 | 100 | 383.0 | 440.9 | 416.0 | 28 | 19.56 | 0.10 / 0.30 |
| 2 | 100 | 385.2 | 443.5 | 418.1 | 33 | 60.20 | 0.10 / 0.30 |
| 2 | 50 | 384.5 | 442.8 | 417.6 | 33 | 62.62 | 0.10 / 0.30 |
| 1 | 50 | 383.8 | 441.7 | 416.8 | 28 | 21.42 | 0.10 / 0.30 |

USS is unique private resident memory. RSS sums are an upper bound because shared pages can be counted repeatedly. RSS minus USS is a nonunique shared-page estimate; PSS is unavailable on this Windows host. Private commit is committed virtual memory, not physical resident RAM. Full receipts include OS headroom, startup, write bytes/rates, process identities and closure. This does not qualify a CM5 2 GB target or translate desktop throughput to ARM.

The preserved RUNTIME_EXPERIMENT_V1_LIBRARY_DEFAULTS.json is an adverse library-default screen: its numeric pools were unset and its observed process thread count was much larger. The V1 app revision also predates the overlap-display fix and loading instrumentation, so cross-version resource differences cannot be attributed solely to numeric pool limits. V1 and V2 manifests and runner hashes are included in PARAMETER_BINDINGS.json; the ten named candidate profiles remain unchanged.

## Actual neural prefix and delivery evidence

CAUSALITY_DELIVERY_RECEIPT.json compares two fresh full native P1X0 engines with an identical 12-second recorded prefix and different six-second futures. Actual native audio, raw ASR, endpoints, segmentation posteriors/gates, ReDim vectors, tracker lineage and native first labels are checked separately. Measured compute and availability clocks remain in raw logs and are excluded only from semantic comparison.

Engineering prefix check passed: True. First displayed label invariance observed: True. These are bounded regression findings, not universal causality or scheduling proofs. The same receipt reports the real 50/100-ms delivery pairs, including sample continuity, words, endpoints and vector parity.
