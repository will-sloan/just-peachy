# Decision log

2026-09-08 / S0 20260908T181703Z

1. User clarification supersedes ±4–5% with approximately ±4–5 degrees or less. Applied conservative half-width 5° as a versioned context overlay; no raw central angle edit or calibration claim.
2. Bind the supplied current V5 at its actual attached filename, retaining its hash and extracted context. Keep the reference pack and prior audit immutable.
3. Both distance corrections assign 1.00 m only after exact original-record and manifest checks. Original 100 m evidence remains.
4. Preserve supplied 12-case pilot including difficult conditions. All 127 allowlisted inputs remain captured-valid / locally-bound / RIR-unqualified / simulation-not-ready.
5. Preserve current H2 assets and thresholds. One offline empty-gallery smoke completed; enrolled names and spatial integration remain untested.
6. Desktop CPU is 5700X3D. Replace provisional broad cache plan with bounded 5 GiB S1 scratch and 50 GiB free-space floor; no broad storage action.
7. Current physical board is firmware 3.2.1, USB 16/16. Inventory only; leave settings unchanged until S3 authorization.
8. READY_WITH_LIMITATIONS for a later S1 prompt. Stop after S0 packaging.
