# S1. Qualify timing and RIR extraction on a small subset

**Purpose:** prove the extraction method on approximately 12 informative records before applying it to the library. Use clear high-margin cases, left/right/front/rear coverage, a pose/obstruction comparison and noisy Loeb cases. The companion pilot manifest is a proposed development subset, not a qualification result.

Use the exact archived 48 kHz excitation and the recorded −6 dB software scalar. The source is not assumed identical to a regenerated or separately supplied 16 kHz sweep. Convert sample rate with documented antialiasing and scaling. Preserve the fixed KRK/room/table/microphone transfer rather than silently applying source EQ. [S1]

### Timing method

Fit a common playback-to-capture mapping using consistent acoustic marker and sweep evidence. Separate offset from relative clock-rate error. Compare no-drift and justified common-drift variants; do not force a correction based solely on a coarse 14-second marker interval. Apply the same mapping to all four microphones, retain uncertainty and the original diagnostic result.

A common time origin may remove bulk recording latency, but it must not align each microphone separately. Do not claim calibrated propagation distance from onset time. Keep the included 32-sample microphone delay and any removed common delay explicit in provenance.

### Extraction method

Start with a documented exponential-sweep inverse; use one regularized frequency-domain method as a cross-check where necessary. Test the implementation first with inexpensive synthetic known-FIR fixtures containing known gain, delay, clock mismatch and added noise. Linear-response extraction and any harmonic separation must be versioned. [S3, S5]

| Metric | What it tells us |
| --- | --- |
| Common alignment residual and clock uncertainty | Whether timing assumptions smear the response or remain below useful resolution. |
| Direct-path evidence and six pairwise mic delays | Whether channel timing and spatial relationships survived processing. |
| Gain ratios and useful spectral band | Whether channels retain relative levels without unstable inversion. |
| Pre-arrival energy / ringing | Whether alignment, inversion or filtering creates implausible artifacts. |
| Reconstructed-sweep residual | Internal consistency only; not independent acoustic validation. |
| Noise intersection and decay fit limits | How much of the late response can be trusted. |

**Gate:** choose one extraction policy, explicit limited-use categories, and failure reasons. Do not require every noisy pilot to become a full-band RIR. S2 expands the method, not the search space.

---

# S1 detail. Background noise is not part of the desired RIR

**Recommendation:** estimate the acoustic response conservatively, retain trustworthy reflections, and add realistic ambience separately when synthesizing scenes. Do not treat background noise contaminating an estimated impulse response as a faithful recreation of that noise.

The measurement model is `y_m = x * h_m + n_m`. If estimation gives `h_hat = h + e`, later convolution gives `speech * h + speech * e`. The error becomes speech-dependent filtering/ringing; it is not independent restaurant ambience. This is why “leave all noise in because the XVF will cancel it” is not a sound extraction policy. [S5; application to this campaign is a methodological inference]

### Use the silence carefully

Inspect pre-excitation quiet windows to estimate frequency-dependent noise and its stationarity. The interval immediately after the sweep is room decay and must not automatically be used as a noise-only reference. End-marker responses also exclude windows. Compare pre/late noise only where the late interval has actually decayed and is free of markers, voices or impacts. [S1]

### Conservative processing policy

Keep an untrimmed estimate. For the simulation derivative, use regularized inversion over a justified band and a smooth common four-channel tail taper where the decay is no longer distinguishable from noise. A conservative common cutoff may lose useful late energy in better channels; report that tradeoff instead of hiding it. Per-band noise-compensated decay estimates are diagnostics, not a newly invented spatial tail.

Do not use a speech-enhancement neural network on sweeps, independently denoise each mic, remove the strongest reflection as “noise,” or subtract a preceding unrelated noise waveform. Shared operations still require before/after delay, level and spectrum checks. No algorithm can certify recovery of a reflection buried below the measured noise floor from one take.

| Product | Permitted role |
| --- | --- |
| Full extracted response | Immutable derived diagnostic; may contain late contamination. |
| Qualified response | Main simulation input, with useful-band/tail limits and extraction version. |
| Limited response | Restricted stress/short-tail study; not silently pooled as fully qualified. |
| Noise profile / eligible ambience excerpt | Separate noise evidence; short excerpts do not certify minutes of natural ambience. |

All six eligible Loeb Caf captures are in the audit’s low-margin triage set. Review them carefully, but do not reject them using the descriptive 15 dB line alone. Excluded RETAKE data stays excluded. [S1]

---

# S2. Extract and qualify the measured response library

**Purpose:** turn the curated 127 captures into a reproducible library with honest per-condition usability. At most this produces 127 four-channel response sets, or 508 individual channel responses; it does not create 508 independent acoustic conditions.

Apply the S1 policy with bounded parallel workers. Retain source hashes, correction-overlay identity, exact excitation/scalar, common timing mapping, inversion settings, useful band, time origin, included gain/delay and all quality findings. Export a multichannel response as the primary artifact; mono files are optional conveniences, not new observations.

### Qualification is additive

Keep original_status=REVIEW and capture_audit_pass=true unchanged. Add a separate RIR status such as QUALIFIED, LIMITED_BAND, LIMITED_TAIL or HOLD, with allowed uses and reasons. The exact status vocabulary and thresholds are finalized from S1 before expansion. A processing exception or missing field is never converted to PASS by default.

| Evaluation | Technical result / interpretation |
| --- | --- |
| Counts by room, pose and obstruction | Shows which comparisons remain possible after qualification and whether noise exclusions bias coverage. |
| Per-band usable response and decay range | Avoids claiming the nominal 80–7500 Hz is equally reliable everywhere. |
| Mic delay/relative-level preservation | Ensures the spatial input to XVF has not been rewritten by preprocessing. |
| Common-window and timing sensitivity | Tests whether conclusions depend on a fragile extraction choice. |
| EDT/T20 or other decay estimates where supported | Descriptive acoustics with fit ranges and noise limits; no forced T60 value. |
| Regeneration identity | Same inputs, software and settings reproduce the recorded derivative within the declared numeric tolerance. |

**Outputs:** rir_manifest.json, qualification_summary.csv, RIR WAVs, compact per-record plots, exclusion/limited-use reasons, and S2_REPORT.md. Record stable IDs for compatible receiver configurations and matched pose/obstruction groups.

**Gate:** enough qualified compatible source paths exist to construct informative scenes. One poor room need not block a clear-room proof, but a result based only on easier rooms must be labelled accordingly. Missing real repeatability remains an evidence limitation, not a reason to manufacture repeats.

A small independent same-setup speech capture later is more informative than repeatedly optimizing reconstruction of the fitting sweep. Keep that independent validation in S8, or bring it forward if S1 exposes a serious mismatch.

---

# S3. Prove physical XVF injection and capture

**Purpose:** establish an auditable desktop hardware-in-the-loop path before long runs. Use the physical board as the DSP under test, not a software imitation. [S3, S4]

Acquire exclusive ownership of the device, snapshot configuration and verify the actual desktop endpoints. Do not flash firmware or replace working drivers automatically. Disconnect/mute the physical loudspeaker during packed-vector injection: the packed carrier is not ordinary listenable stereo audio.

### Critical signal contract

Build the six-channel 16 kHz input as `[far-end reference, ignored, MIC0, MIC1, MIC2, MIC3]`, then pack to the supported 48 kHz stereo/24-bit Windows transport. For ordinary near-end captioning tests, both leading channels are zero. The campaign capture’s first channel is digital continuity—not a valid reference to replay indiscriminately. [S1, S3]

The recorded RIRs include Category 3 gain/delay. Prove the documented replay configuration with microphone/reference gains at unity and system delay zero; otherwise gain/delay can be applied twice. Restore the live configuration after tests. If common trimming changes the response time origin, reflect that explicitly in the timing contract rather than adding a guessed propagation delay. [S3]

### First proofs

Run channel-tagged deterministic fixtures and a direct Category 3 vector before RIR-generated speech. Compare injected vs recaptured DSP-input channels for order, level and common alignment. Then run one-talker speech and an A→B→A scene. Capture actual ASR and communications outputs simultaneously when supported, plus native angle/energy and timestamp receipts.

| Metric | Gate / meaning |
| --- | --- |
| Packing, channel order, payload continuity | Zero unexplained transport mismatches or gaps. |
| DSP-input waveform, scale and delay | Matches expected quantization/timing tolerance; no double gain/delay. |
| O0/O1 route verification | Actual selected signals, not merely command success. |
| Output-audio and telemetry lag/jitter/age | Enough evidence for causal alignment and stale-data rules. |
| Repeated independent replay variation | Measures hardware/adaptive-run variability, not RIR measurement repeatability. |
| Restoration/recovery | Device returned to a documented state; failed trials kept and retried with new attempt IDs. |

Use one device owner. Reset between independent scenes, never between turns within a continuous conversation. The evaluation kit has an eight-hour processing limit; schedule recovery between scenes well before it. [S4]