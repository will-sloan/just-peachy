# Current project context — post measurement

## Immediate goal

Generate qualified four-channel RIRs from the **already capture-audited** formal recordings, then develop and evaluate physical XVF3800 integration with the selected H2 pipeline. Work stage-by-stage. Do not restart acquisition validation, model selection or training as an unrelated project.

## Source precedence

Current user instructions and confirmed correction overlays govern intent; the 8 September audit governs campaign facts; matching XMOS v3.2.1 docs govern device behavior; the supplied DOC.docx retains earlier plans and newer user edits. Do not silently reconcile conflicts. Preserve unknowns as null with reasons.

## Known campaign facts

- Explicit allowlist: 127 formal KRK_FORMAL_RIR recordings, all original REVIEW, each capture_audit_pass=true.
- Excluded: 52 initial pilots/diagnostics, RETAKE, INVESTIGATE or other disallowed records. No RETAKE noise windows.
- No final RIRs or simulation-ready captures exist in the audited source tree.
- Canonical audio: four-channel MIC0–MIC3, 16 kHz PCM24, 350,647 frames, 21.9154375 s.
- Capture domain: **Category 3**, mic gain **10**, SYS_DELAY **−32** (32-sample mic delay). Do not reinterpret the actual capture as Category 1.
- Real acoustic playback used **Realtek**, not the XVF clock; all same_clock_as_capture flags are false.
- Digital continuity validates sample transport, not the separate acoustic playback clock.
- Six room/table labels, eight receiver-position labels, 55 geometry groups, 127 different complete conditions; no eligible same-condition repeats.
- 55 flat clear, 52 upright clear, 20 flat obstructed; no upright-obstructed recordings.
- Two bound distances corrected from 100 m to 1.00 m; effective distances 0.46–4.07 m, positive and <=5 m.
- Linear topology confirmed at capture; raw beam angles are radians and front/rear ambiguous.
- Left/right sign supported for 109 informative points; 18 near-axis points inconclusive. Precise angle/yaw/elevation not verified.
- Average telemetry rate ~57–62.5 Hz per field, occasional ~587 ms gaps. Queries not necessarily atomic or freshly updated.
- No recorded IMU, no complete XYZ/heights/photos. Do not synthesize those as measurements.
- Source: wired KRK GoAux 4, software −6 dB, Windows 70%, KRK maximum according to operator metadata. EMM-6 reference disabled. No absolute SPL/source-flatness claim.

## New operator statements

The speaker faced the tablet in all takes. Append this as user-reported campaign context; do not rewrite NAT filename tokens or invent a yaw. The user's “Carlton Library” description likely concerns Library Conference Room / Square Table End, but retain an explicit unresolved alias until confirmed. It is a square table in an enclosed room according to the user, not an independently measured reverberation classification.

Angle uncertainty was described as “±4–5%.” Its denominator is unresolved. Do not silently convert it to ±4–5°. Sensitivity at ±5/10/20 degrees may be reported as assumptions pending clarification.

## H2 stays selected

Sherpa-ONNX Giga streaming ASR; Pyannote ONNX segmentation; one shared ReDimNet2-B2 embedding worker for anonymous tracking and enrolled identification; session memory; conservative Unknown/name decisions; lossless journal; final-only Sherpa punctuation; GUI.

ASR and speaker analysis are parallel consumers of timestamped audio, not a mandatory serial ASR→segmentation→embedding chain. Display text immediately; name promotion is asynchronous. Inventory **actual current** checkpoint hashes, including existing fine-tuned versions; never revert to older parent models because older notes said training was paused.

No H5, new embedding model or additional model fine-tuning is authorized by this planning pack. Optional caption-only, memory fallback and best fusion are configuration profiles, not new model families.

## Workstation and target

Desktop: user-reported Ryzen 5800X3D, 64 GB RAM, RTX 3080 10 GB. C and a second 2 TB SSD are preferred fast storage; discover exact drive letters/free space.

Target: CM5 2 GB RAM / 32 GB eMMC / no wireless. Use Ethernet and USB initially. Model export is not hardware qualification.

## Physical HIL invariants

Use one actual XVF; no software imitation of its voice DSP. Pack [zero far-end, zero ignored, MIC0, MIC1, MIC2, MIC3] for ordinary near-end scenes. **Do not replay the campaign continuity channel as an AEC reference.** Category 3 vectors already include gain/delay; validate unity replay mic/ref gain and zero system delay, then restore live settings.

The board processes scenes at real-time audio rate; GPU/CPU parallelism cannot make that single hardware path process many conversations at once. Cache verified output audio/telemetry per scene+firmware+settings+initial-state identity, then replay compatible software fusion cheaply.

Reset between independent scenes, not inside dinner turns. Keep cold startup separate from warm/re-entry tests. Prevent eight-hour evaluation-board expiry by controlled resets between scenes. Do not flash/reset/reconfigure until the current phase authorizes it and a recovery plan exists.

## Key experiment policy

RIR estimation disturbance and separately added ambience are different. Preserve real reflections, use conservative common four-channel operations, and keep noisy/limited RIR status explicit. No aggressive independent denoising, per-mic normalization, inferred geometry, or automatic loudspeaker correction.

Use compatible measured receiver/pose/obstruction paths within one scene. Use each physical speaker identity as exactly one actor. Counterbalance identities/positions, split before synthesis, and retain excluded/missing conditions in reports.

Angle is location evidence, not identity. Energy is speech/confidence evidence, not identity or calibrated SPL. Two beams are not guaranteed two separated speakers. Selected-gallery modes retain stranger rejection. Fixed RIRs support silent relocation tests but cannot prove walking behavior.

## Next step

S0 is a small input/software/resources binding step. S1 is the first substantive extraction task. Read PHASE_PLAN.md; do not execute S2–S9 before their inputs and decisions are accepted.
