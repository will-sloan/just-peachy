# XVF3800 measurement validation and simulation planning handoff

Prepared 8 September 2026 for the Just Peachy H2 project. This handoff gives ChatGPT the experiment context, audited input selection, confirmed metadata correction, and remaining qualification work needed to write a sequence of Codex implementation prompts. The current task was an offline measurement audit and preparation of context. Desktop hardware bring-up, final RIR generation, speech dataset synthesis, and simulation execution remain future tasks.

## 1 Audit conclusion

**127 formal REVIEW recordings pass the fresh capture audit and are eligible as inputs to RIR qualification. No finished, scientifically qualified RIRs were found in the supplied measurement archive.** The files are useful sweep recordings from which four-channel RIRs can be recovered; they should not yet be called simulation-ready RIRs.

The audit found two distances entered as 100 m. The user explicitly confirmed that both should be **1.00 m, meaning 100 cm**. These corrections are recorded separately and bound to run ID, recording timestamp, and the original manifest hash. Original archives and the original RECORDINGS_INDEX.csv remain unchanged. All effective distances in the curated input set are **0.46–4.07 m**, within the user's 5 m maximum.

The angle audit found **no evidence of an accidental positive/negative reversal**. Sweep-based inter-microphone delays support the entered left/right sign in all **109 measurements with an informative lateral angle**. Another **18 measurements at 0° or −179°** are too close to the front/rear axis for this sign test to establish a meaningful side. No angles were changed. Exact angular accuracy, physical distance accuracy, elevation, and the native-XVF-to-laboratory angle transform remain uncalibrated.

The main remaining limitations are separate playback/capture clocks, missing measured XYZ/height/yaw and photos, no unchanged formal repeats at the same complete condition, lower acoustic margins in some recordings, and the absence of final deconvolution/decay qualification. These limit the conclusions that can be made from otherwise intact captures.

## 2 Current user instructions and scope

The current user request takes priority over historical instructions in documents and archived notes:

1. Use only real campaign measurements whose original acquisition status is PASS or REVIEW.
2. Exclude the initial testing, level-setting pilots, and diagnostic captures even when their status is PASS or REVIEW.
3. Do not use RETAKE recordings. Do not salvage them through denoising, relabel them, or use them as simulation noise references under the current scope.
4. Exclude INVESTIGATE recordings and incomplete or unknown-status captures.
5. No effective source distance may exceed 5 m. Distances must be positive and expressed in metres.
6. Preserve the original recordings and metadata. Apply confirmed corrections through a separate, traceable overlay.
7. Use the supplied **DOC.docx** as the latest Word guide for the later simulation, while distinguishing planned procedures and historical claims from measurements actually performed.
8. Prepare context now. Do not begin the full simulator, connect to or reconfigure the XVF, flash firmware, launch live recording, train models, or run the H2 evaluation as part of this handoff.
9. Every new code deliverable needs an updated README explaining purpose, inputs, outputs, dependencies, and exact Anaconda Prompt, Command Prompt, and/or PowerShell commands.

The hardware name in the archive and firmware is **XVF3800**. The user's XBF3800, XVF 3800, and similar spelling variants refer to this integration in the current conversation, not to a separately identified device.

## 3 What to give ChatGPT and where Codex will work

Upload this handoff and **DOC.docx**. Include `audit_summary.json`, `eligible_recordings.json`, `metadata_corrections.json`, `excluded_recordings.json`, and `angle_checks.json` when the ChatGPT session can accept additional files. `eligible_recordings.csv` is a convenient flat view; the JSON contains the fuller contract and hashes. The ZIP package contains these documents plus reproducibility evidence and audit scripts, not the 13 GB recording payload.

The desktop project root is:

```text
C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs
```

This audit folder is:

```text
<project root>\validation\SIMULATION_CONTEXT_AUDIT_20260908
```

The source recordings remain at:

```text
<project root>\XVF_MEASUREMENT_WORK\experiments\<run_id>
```

ChatGPT does not automatically have access to the desktop C: drive. It should use the uploaded context to generate prompts for Codex, which can inspect the local files. Do not invent results for local paths that the planning conversation cannot read.

The supplied current Word file was `C:\Users\amiri\Downloads\DOC.docx`. A byte-identical copy is included here. SHA-256:

```text
137643afd9990286e42501dac05892be05b534a0c1d387e64c8399150b40b549
```

The older `reference_documents/Just_Peachy_H2_XVF3800_Master_Workbook_and_Experiment_Plan_V4.docx` has a different hash, `2cdac98e42a2ee157e7e7ba95045388de2a4a7538b2c9169cf90deb45f376348`. Do not silently substitute that older copy for DOC.

## 4 Input selection and exclusions

The original index contains **179 request-bearing runs**. It is an inventory, not an approved RIR manifest.

| Population | Count | Treatment |
|---|---:|---|
| Formal KRK_FORMAL_RIR, original REVIEW | 127 | Eligible for further RIR qualification after the correction overlay |
| Formal KRK_FORMAL_RIR, original RETAKE | 16 | Excluded |
| Formal KRK_FORMAL_RIR, original INVESTIGATE | 5 | Excluded |
| Early named pilots | 18 | Excluded irrespective of status |
| Other request-bearing diagnostics | 13 | Excluded irrespective of status |
| Total | 179 | 127 candidates and 52 exclusions |

Across all 179 entries, the original statuses are 141 REVIEW, 23 RETAKE, 10 INVESTIGATE, and 5 PASS. **All five PASS entries are early diagnostics and are excluded.** Filtering only by PASS/REVIEW would incorrectly retain 19 early test recordings. Filtering only by P1 would also be wrong: some early pilot and diagnostic captures use P1.

The conservative campaign filter is an explicit allowlist derived from `setup.trial_label == KRK_FORMAL_RIR`, original result status in `{PASS, REVIEW}`, passing fresh capture/integrity checks, reconciled metadata, and valid effective distance/angle. The authoritative selected paths and hashes are in `eligible_recordings.json`. Do not recreate eligibility by globbing every WAV in the project.

Formal eligible captures span **2026-09-06 19:22:31 UTC to 2026-09-07 20:33:48 UTC**. The first formal take is `JPXVF_P1_R01_T01_D01_S01_UPR_NAT_CU_R04`. The earlier upright R01/R02/R03 at that recorder position remain pilot evidence and are excluded. The three initial P1 pilots are included in the 18 early named pilots above; their names alone do not identify their scientific role.

The five previously annotated Loeb Caf background-noise takes are all RETAKE and remain excluded:

- `JPXVF_P1_R04_T01_D01_S01_UPR_NAT_CU_R06`
- `JPXVF_P1_R04_T01_D01_S01_F00_NAT_CU_R07`
- `JPXVF_P1_R04_T01_D01_S01_F00_NAT_CU_R06`
- `JPXVF_P1_R04_T01_D01_S01_UPR_NAT_CU_R05`
- `JPXVF_P1_R04_T01_D01_S01_UPR_NAT_CU_R04`

The earlier note to retain them for future noise analysis is historical context. Retaining their files as evidence does not grant permission to use them in this simulation dataset.

## 5 Campaign coverage

| Room and table label | Eligible takes | Flat unobstructed | Upright unobstructed | Flat obstructed | Geometry groups | Effective distance range m |
|---|---:|---:|---:|---:|---:|---|
| Arise Kitchen Main Table | 23 | 12 | 11 | 0 | 12 | 0.65–4.07 |
| Arise 5th floor low table | 26 | 13 | 13 | 0 | 13 | 0.53–3.23 |
| Upper Loeb | 12 | 6 | 6 | 0 | 6 | 0.46–1.37 |
| Loeb Caf | 6 | 4 | 2 | 0 | 4 | 0.80–2.08 |
| Arise Floor 2 Kitchen | 21 | 7 | 7 | 7 | 7 | 0.67–1.65 |
| Library Conference Room | 39 | 13 | 13 | 13 | 13 | 0.58–1.86 |
| Total | 127 | 55 | 52 | 20 | 55 | 0.46–4.07 |

A geometry group here means the same room/table label, recorder position, effective source distance, and entered source angle. It is a metadata grouping, not a reconstructed three-dimensional coordinate. There are eight recorder-position labels across the six room/table labels. Room labels do not establish six statistically independent buildings or sites.

There are **127 distinct full recorded conditions** when pose and obstruction are added. None has two eligible measurements at exactly the same complete recorded condition. A flat take and an upright take are separate acoustic conditions, not unchanged repeats. An obstructed take is not a repeat of its unobstructed counterpart. The Rxx suffix increments within filename conditions while source distance/angle can change; it must not be interpreted as a repeat at a fixed source seat.

Most geometry groups have paired poses, and the final two rooms also have obstruction comparisons. The Word guide's proposed full matrix and two-repeat plan are not an accurate description of a completed factorial dataset. Do not report repeatability confidence intervals from this selection. Earlier excluded pilot repeats may be cited as historical acquisition-development evidence, but must not be imported into the simulation set or used as substitutes for missing formal repeats.

## 6 Fresh integrity and recording validation

The fresh local audit completed at **2026-09-08T13:28:19Z**. Evidence is in `audit_results.json`; `audit_summary.json` is the compact version. Original manifests were read without modification.

| Check | Result and scope |
|---|---|
| Manifest SHA-256 verification | 57,977 entries checked, representing 31,034 distinct local file paths and 13,018,441,923 bytes hashed |
| Missing or mismatched manifested files | Zero within those checked entries |
| Index/request/result and geometry-copy reconciliation | Zero detected conflicts |
| Formal eligible audio read errors | Zero across 127 takes |
| Fresh per-take capture audit failures | Zero across 127 takes |
| Canonical audio | All 127 are 4-channel, 16 kHz, PCM24, 350,647 frames, 21.9154375 seconds |
| Mono versus multichannel copies | MIC0–MIC3 equal the corresponding channels of microphones_4ch.wav sample-for-sample |
| Packed transport decode | Independently decoded native carrier equals saved six-channel payload; payload columns 2–5 equal the four canonical microphones |
| Framing | Startup framing and clean retained [0,1,1] framing groups verified |
| Digital continuity | 44,188,415 compared known-sequence samples across the 127 takes, zero mismatches, complete active sequence captured |
| Signal validity | Four varying microphones, no fully zero one-second channel windows, no microphone rail samples |
| Largest microphone peak | −26.66 dBFS, so digital clipping is not a concern in this input set |
| Saved channel statistics | Independently recomputed peak and RMS values match the archived QC values |
| Capture/playback receipts | Clean callback records and completed, drained playback verified from saved receipts |
| Campaign configuration | Category 3, gain 10, SYS_DELAY −32; after-capture gain/delay readbacks match |
| Telemetry | Fresh JSONL parsing, finite four-value replies, sequence continuity, increasing transaction times, and host capture bracketing pass |

Parent and nested manifests overlap, which is why entry count exceeds unique file count. This is an audit of the indexed recordings and their available manifests, not a claim that every file in the entire transferred software/development tree was rehashed. One excluded diagnostic, `TAKE_20260906T020708_770949Z_0cda06`, lacks a parent SHA256SUMS.txt. All selected formal takes have parent manifests. Unmanifested files are not certified by a manifest check.

The stored acoustic-marker status/gates were re-read and checked for consistency, and new inter-channel delay diagnostics were computed from the audio. The original marker detector was **not rerun** in this audit. Its stored coarse PASS-for-review gates, even when hash-verified, are not a sample-accurate clock or direct-path qualification. None of the original `scientific_measurement_qualified: false` flags was changed.

File identity and digital continuity validate preservation and transport. They do not independently establish exact loudspeaker position, room decay quality, analog loudspeaker linearity, or simulation realism.

## 7 Confirmed distance correction and remaining distance limits

Both corrected takes belong to **Arise 5th floor low table**, recorder position **Opening Behind Listener**, entered source angle **+20°**:

| Run | Recorded UTC | Original distance | Effective distance |
|---|---|---:|---:|
| JPXVF_P1_R02_T01_D01_S02_F00_NAT_CU_R05 | 2026-09-06T20:45:18.320408+00:00 | 100 m | 1.00 m |
| JPXVF_P1_R02_T01_D01_S02_UPR_NAT_CU_R05 | 2026-09-06T20:46:07.275902+00:00 | 100 m | 1.00 m |

The user confirmation was **“1.00 m (100 cm)”**. `metadata_corrections.json` records the exact source field, original/effective values, authority, timestamps, and original manifest hashes. Apply this overlay before enforcing the 5 m constraint. Do not silently replace every occurrence of 100 elsewhere in the project or edit historical manifests.

All 127 effective distances are present, positive, and at most 4.07 m. That establishes a consistent range under the user's constraint; it is not an independent tape-measure verification. The archived values are operator entries. Complete source/receiver XYZ, source height, array yaw, measurement photos, and an independently calibrated acoustic latency are absent. Absolute arrival time includes playback/host/capture latency, so multiplying an uncalibrated onset time by sound speed would not verify the distances.

Future code should keep `source_distance_m_original` and `source_distance_m_effective` separate. If a correction's run ID, timestamp, original value, or manifest hash does not match, stop applying that correction to the record and request a new review. Never infer centimetres for other values just because these two entries were a unit error.

## 8 Angle convention and the sign audit

The actual acquisition metadata uses this operator convention:

- 0°: protocol forward, away from the seated user.
- +90°: seated user's left.
- −90°: seated user's right.
- ±180°: toward the seat, behind the forward arrow.
- Positive angles increase counterclockwise when viewed from above.
- Store signed laboratory angles in [−180°, +180°].

The user-reported physical microphone order is MIC0, MIC1, MIC2, MIC3 from seated left to right. The firmware reports a linear array with nominal 33.3 mm pitch and 99.9 mm end-to-end span. The firmware's own geometry coordinates place that line on its internal X axis. The workbook's laboratory frame defines +X forward and +Y left. These are different coordinate descriptions and must not be equated without a measured transform.

For the sign diagnostic, under the reported physical order and an approximately horizontal array, a source to the left reaches MIC0 before MIC3. Define tau03 = arrival at MIC3 minus arrival at MIC0. A positive laboratory side therefore predicts positive tau03; a negative side predicts negative tau03. The approximate plane-wave projection used for a sense check was:

```text
tau03_samples ≈ (0.0999 m / 343 m/s) × 16000 Hz × sin(theta_lab)
              ≈ 4.66 × sin(theta_lab)
```

This calculation assumes nominal spacing, sound speed, orientation, and negligible elevation. It is not a measurement of the true room geometry.

The audit used a Hann-windowed GCC-PHAT cross-correlation of the sweep from onset+0.2 s to onset+9.8 s, limited to 300–6000 Hz, with a 1/16-sample lag grid and an aperture-bounded search. Positive delay was checked with known synthetic delayed signals and again with the channel order reversed. Interpolating the correlation grid does not create physical sub-sample accuracy or a confidence interval.

The diagnostic rule recorded in the helper is `abs(sin(angle)) >= 0.15` for a sign-informative point. This is an audit interpretation rule, not a preregistered acquisition gate. All **109/109** such points have the expected sign. There are **13 front-axis records at 0° and five near-rear-axis records at −179°**, giving 18 inconclusive near-axis cases. The largest absolute measured sweep end-to-end lag is 4.5625 samples, within the nominal roughly 4.66-sample aperture limit. No global channel-order reversal or isolated clear angle-sign reversal is suggested by these results.

All entered angles lie between −179° and +135°. Values such as +100°, +110°, +135°, −120°, −165°, −170°, and −179° are valid rear-side angles in the signed laboratory convention, not out-of-range errors. Replacing a negative angle with its absolute value would corrupt these labels. Likewise, −179° is close to +180° around the angular wrap, not an implausible 359° physical movement.

The complete per-run evidence is in `angle_checks.json`. The sign result is supporting evidence, not proof that every entered angle is numerically exact. A linear array observes a projection: front/rear locations can share the same delay. Near the 0°/180° axis, a small angle error, physical yaw, or reflection can dominate the side indication.

### Geometry points deserving closer review before exact angular scoring

These examples have the correct sign but a notable difference from the simplified horizontal far-field prediction:

| Condition | Entered angle | Approximate expected tau03 samples | Measured sweep tau03 samples | Interpretation |
|---|---:|---:|---:|---|
| Upper Loeb, Center Booth, upright R07 | −120° | −4.04 | −2.50 | Same-side evidence; review elevation, source position, and effective arrival |
| Upper Loeb, Center Booth, flat R07 | −120° | −4.04 | −2.69 | Similar deviation in the paired pose |
| Low table, Opening Behind Listener, upright R08 | +95° | +4.64 | +3.38 | Correct side; reduced lateral projection |
| Low table, Opening Behind Listener, flat R09 | +95° | +4.64 | +3.44 | Similar paired behavior |
| Low table, Opening Behind Listener, flat R13 | −165° | −1.21 | −2.25 | Rear case with uncertain arrival/pose |
| Arise Floor 2 Kitchen, obstructed flat R03 | +33° | +2.54 | +3.56 | Obstruction can alter the strongest arrival |
| Library Conference Room, upright R09 | +16° | +1.28 | +0.38 | Flat counterpart is +1.38; check upright yaw/placement if precise labels matter |

Do not “correct” those angles by inverting an arcsine. Unknown elevation, source reference point, board pose, room reflections, near-field effects, and per-microphone transfer phase can all affect the observed delay. Keep their original labels and mark precise angular ground truth unverified.

Short-marker delay estimates are less consistent than the long sweep. A diagnostic screen flags **27 takes** where at least one marker lag differs from the sweep by more than 1.5 samples or exceeds nominal aperture plus 0.25 sample. Some marker estimates select an opposite-sign or boundary peak while the long sweep remains consistent. These are new arrival-review flags, not confirmed angle mistakes or replacements for the acquisition status. The exact rule and per-marker values are preserved in the JSON. They reinforce the need to qualify the direct path and clock model rather than blindly align each microphone to a marker peak.

## 9 What RIR products exist and what still has to be done

The archive contains no named RIR/impulse-response WAV products under the measurement tree. The 166 named-run `03_derived/*/provenance.json` records all specify byte-identical demultiplexed channel copies with **no RIR deconvolution**. Their `05_analysis` directories contain reserved-workflow README placeholders. The original DATA_HANDOFF.md and the per-trial reports make the same distinction.

An excitation file containing the word IMPULSE is not itself a room impulse response. In this campaign it is the playback signal containing short timing bursts and a long exponential sine sweep. Similarly, `MIC0.wav` through `MIC3.wav` in `03_derived` are complete microphone recordings, not h0–h3.

Later RIR work must first establish a reproducible extraction method on a small subset, then run it over the allowlist. Required steps are:

1. Bind the input to run ID, timestamp, manifest hash, four-channel WAV hash, source WAV hash, and metadata-correction version.
2. Use the exact archived played excitation and the recorded playback scalar. Inspect the actual signal timing. Do not substitute a nominal regenerated sweep or the separate 16 kHz asset without verifying sample and filter equivalence.
3. Estimate the common playback-to-capture offset and sample-rate relationship. All 127 formal takes used a separate Realtek playback clock. Preserve uncertainty and validate the same acoustic arrival across markers and the sweep.
4. Apply any justified drift compensation uniformly to all four microphone channels. Keep the original audio and uncompensated diagnostic result. Do not independently warp or peak-align microphones.
5. Recover four linear channel responses using a documented ESS inverse or appropriately regularized deconvolution. Document antialiasing, inversion band, regularization, scaling, nonlinear-response separation if used, and the time reference.
6. Retain the full fixed path: KRK source, room/table/objects, microphone/board/capture response. Source correction remains an explicit later choice, not an automatic preprocessing step.
7. Keep untrimmed responses. If removing common host/playback latency, use one common trim for all four and preserve inter-microphone arrival differences. Do not add or remove physical propagation delay twice in scene ground truth.
8. Assess per-band usable response and noise floor, direct-path visibility, pre-arrival artifacts, decay extent, tail contamination, clipping, stability, and inter-channel coherence. The nominal 80–7500 Hz sweep does not guarantee a reliable response throughout that band.
9. Validate extraction independently, for example by checking prediction on held-out signal segments or an independent same-condition capture when available. Reconvolving the same fitting sweep is a useful consistency check but is not independent acoustic validation.
10. Assign a separate RIR qualification status and reasons. Keep `original_status` unchanged. Only promote records to the simulation RIR manifest after the defined gates pass.

No final RIR, deconvolution, common trimming, source correction, denoising, or RIR audio export was performed in this context audit.

## 10 Acoustic margins and noise

The fresh diagnostic compares mean-removed RMS in the interior sweep interval against the mean-removed RMS of microphone samples corresponding to 0.25–1.25 s at the beginning of the saved recording. The sweep interval is estimated from the stored start marker plus the documented one-second gap, then excludes 0.2 s from each sweep end. This is a **broadband sweep-to-background margin**, not calibrated SPL, final RIR SNR, or a frequency-dependent decay qualification.

Across the 127 runs, the worst microphone per run has a margin from **10.35 to 27.79 dB**, with median **21.48 dB**. A 15 dB line is used only as a descriptive triage threshold introduced by this audit. It is not a validated acceptance criterion and did not change eligibility or original statuses.

Ten records fall below that triage line:

| Run | Worst-channel margin dB |
|---|---:|
| JPXVF_P1_R01_T01_D01_S01_UPR_NAT_CU_R10 | 14.99 |
| JPXVF_P1_R01_T01_D01_S02_F00_NAT_CU_R07 | 14.29 |
| JPXVF_P1_R03_T01_D01_S01_F00_NAT_CU_R01 | 14.08 |
| JPXVF_P1_R03_T01_D01_S01_UPR_NAT_CU_R01 | 14.69 |
| JPXVF_P1_R04_T01_D01_S01_F00_NAT_CU_R01 | 10.38 |
| JPXVF_P1_R04_T01_D01_S01_F00_NAT_CU_R02 | 14.92 |
| JPXVF_P1_R04_T01_D01_S01_F00_NAT_CU_R04 | 14.54 |
| JPXVF_P1_R04_T01_D01_S01_F00_NAT_CU_R05 | 10.35 |
| JPXVF_P1_R04_T01_D01_S01_UPR_NAT_CU_R02 | 12.74 |
| JPXVF_P1_R04_T01_D01_S01_UPR_NAT_CU_R03 | 14.53 |

All six eligible Loeb Caf captures appear here. They passed digital and stored coarse marker checks, but need careful frequency/decay review before a clean RIR claim. This does not mean other takes are noiseless or that these six are unusable.

Use initial quiet windows from eligible captures only if appropriate for the later processing objective. Post-sweep room decay is signal of interest, not automatically a noise-only reference. Any proposed late quiet interval needs inspection for residual decay and markers. Nonstationary speech noise cannot be assumed removable by subtracting an unrelated waveform, and aggressive per-channel denoising may damage spatial relationships. Store any processed variant separately with its method, parameters, source hashes, and before/after evidence.

## 11 Hardware, audio domain, and actual playback

All 127 selected records report firmware version **3.2.1**, a **linear** array (`AEC_MIC_ARRAY_TYPE = 1`), four microphones, and USB bit depth **24/24**. The archived build identity is the UA 48 kHz linear configuration. These are recording-time readbacks, not a claim about hardware currently connected to the desktop.

The physical measurement source was the user-reported **KRK GoAux 4**, wired. Working settings in the formal metadata are software playback **−6 dB**, Windows output **70%**, KRK volume **maximum**, Windows Voice Clarity off, and speaker enhancements off. Only the software scalar is directly represented as an applied digital setting; the analog controls and Windows processing state are user-reported. EQ/ARC state, exact physical cable/cabinet routing, source facing angle, and photographs remain unverified or blank. Do not fill those fields with invented defaults.

The optional reference microphone is a **Dayton Audio EMM-6**. It was disabled for all normal formal captures. No calibrated absolute SPL or flat loudspeaker response is established. Later local campaign notes supersede older Edifier and external-array hardware assumptions still present in DOC.

The canonical measurement domain is **Category 3, amplified/delayed microphones before beamforming/AEC**. The fixed gain is 10×, approximately +20 dB. SYS_DELAY is −32 in the saved command convention; the project documents this as a 32-sample, 2 ms microphone delay relative to raw. Preserve the domain and the command convention explicitly. The eventual physical injection test must prove that gain/delay are not applied twice.

| File | Interpretation |
|---|---|
| microphones_4ch.wav | Primary four simultaneous microphones in order MIC0–MIC3, 16 kHz PCM24 |
| MIC0.wav through MIC3.wav | Mono equivalents on the same sample timeline |
| decoded_six_channels.wav | 16 kHz six-channel payload: digital continuity, processed_auto, MIC0, MIC1, MIC2, MIC3 |
| native_packed.wav | 48 kHz stereo transport carrying packed six-channel 16 kHz data; not ordinary stereo sound |
| processed_auto.wav | Additional adaptive DSP output for diagnostics; not a four-channel RIR input |
| excitation_original.wav | Exact archived mono 48 kHz PCM16 playback source |
| usb_playback.wav and continuity_source_16k.npy | Digital transport/continuity evidence; not proof of a shared acoustic playback clock |
| capture.json and playback.json | Actual stream, callback, route, device, and host timestamp receipts |
| telemetry/received_telemetry.jsonl | Authoritative complete parsed/native reply records |

The packed PCM24 carrier supplies 23 audio payload bits after the framing bit. This is numeric transport width, not a claim of 23-bit effective acoustic resolution. All four microphones share one capture time base. A 48 kHz transport header does not mean each microphone was acoustically sampled at 48 kHz.

**Actual formal acoustic playback used Speakers (Realtek(R) Audio), with `same_clock_as_capture: false` in all 127 takes.** The XVF WDM-KS duplex stream carries the digital continuity mechanism; it does not make the separate KRK acoustic source clock-coherent with capture. The older recommendation to prefer XVF LINE OUT is a plan, not the route that was used here.

## 12 Excitation timing and clock qualification

Every selected take uses the same exact source hash:

```text
cba5b09d4d3963d508340711210804d2dd80cf62741a60a2544120e60acbf488
```

Source filename:

```text
JP_XVF_IMPULSE_1S_GAP_PLUS_ESS_80-7500Hz_10s_48k_PCM16.wav
```

| Event | Time in source WAV |
|---|---:|
| Initial marker onset | 2.00 s |
| Sweep onset | 3.00 s |
| Sweep end | 13.00 s |
| Post-sweep decay interval ends and first end marker starts | 16.00 s |
| Second end marker onset | 16.20 s |
| Source file duration | 17.22 s |

Read the per-pass `signal_timing.json`, not just this table. Source and microphone recordings start on different timelines. The saved microphone recording length is 21.9154375 s, not the nominal requested 30 s and not the source's 17.22 s. The native capture includes startup frames that were consistently excluded during unpacking; that does not imply missing formal sweep audio.

The stored start-to-first-end marker interval error ranges from **−0.5625 ms to +0.3125 ms**, with median **−0.125 ms**. The original detector leaves `automatic_alignment_accepted` and `clock_drift_qualified` false. Do not turn these coarse errors into a final ppm correction simply by dividing by the 14-second interval: burst shape, multipath, selected peak, and sample-grid effects can bias that estimate. They are evidence for a small interval discrepancy, not proof of a calibrated common clock.

Final extraction must distinguish the common hardware/host offset, relative sample-rate mismatch, channel-specific physical delays, and the desired room decay. A correction must use a common mapping for the microphone vector and retain the mapping parameters and uncertainty.

## 13 Direction and energy telemetry

The fresh audit parsed **181,329 AEC_AZIMUTH_VALUES replies** and **181,329 AEC_SPENERGY_VALUES replies** from the selected set: **362,658 replies in total**. Each reply contains four finite values. The firmware beam order is focused beam 1, focused beam 2, free-running scan beam, and auto-selected beam. These are algorithm beam observations, not four physical microphone bearings. XMOS documents the semantics and linear-array folding in its [host application guide](https://www.xmos.com/documentation/XM-014888-PC/html/modules/fwk_xvf/doc/user_guide/03_using_the_host_application.html).

Directions are stored in **radians**. Speech energy is in the vendor's native metric, not SPL. All four energy values are zero in **119,824 of 181,329 energy replies, about 66.1%**. This is consistent with the need to treat sweep-time speech-energy behavior cautiously; it does not establish absent microphone sound or a broken logger. Direction values can exist while speech energy is zero, and a sweep is not an ordinary speech stimulus.

The per-take mean reply rate is about **56.95–62.51 Hz per field**. The largest observed response-completion gap is **587.3 ms** for direction and **586.4 ms** for energy. Thus an average near 62 Hz must not be encoded as an uninterrupted uniform sampling guarantee.

Keep sequence, cycle, command, units, finite/parse flags, raw replies, host request/response bounds, and line-arrival timestamps. Host transaction completion is not a device sample timestamp. Angle and energy are queried separately; their shared cycle does not prove an atomic same-DSP-frame observation. A fast repeated query does not prove a fresh algorithm result. Later synchronization needs a tested mapping from the actual output-audio timeline to telemetry, explicit staleness/lag rules, and safe fallback when metadata is missing or late.

The standard linear firmware has front/rear ambiguity and native 0–180° bearings in its board frame. Preserve native radians separately from entered signed laboratory degrees. Do not unconditionally wrap native values into [−180°,180°], assign each beam to a source seat, or manufacture a 360° ground truth. Any provisional mapping should carry a transform ID, calibration evidence, ambiguity class, and validity flag.

## 14 Data contract for the next implementation

Use `eligible_recordings.json` as the explicit starting manifest. Every entry preserves original acquisition status and marks:

```text
capture_audit_pass = true
eligible_for_rir_qualification = true
qualified_rir_available = false
simulation_ready = false
precise_angle_ground_truth_verified = false
absolute_distance_independently_verified = false
```

These different states are deliberate. A capture can be intact and useful while its final RIR or exact geometry remains unqualified. Do not collapse them into one overloaded PASS field.

The future RIR manifest should add, rather than overwrite:

- A stable RIR ID and extraction version.
- Input run/timestamp/hash bindings and correction-overlay hash.
- Four-channel output path/hash, sample rate, channel order, dtype, and length.
- Original and effective geometry, pose, obstruction, source/array coordinate revisions, and unknown-value reasons.
- Excitation hash and exact gain/scaling convention.
- Offset, drift ratio, common trim, window/filter/inversion settings, and uncertainty.
- Capture domain and included gain/delay.
- Per-band and per-channel QC, direct-path/decay findings, and qualification decision with reasons.
- Data split/group identity and permitted evaluation uses.

Maintain null for unknown geometry. Do not replace missing heights, yaw, or XYZ with zero; that would assert measurements that were never made. The available data can support empirical fixed-path RIR selection without a full room model, but exact geometric simulation and calibrated direction scoring need stronger metadata.

Never independently normalize microphone channels or RIRs. If a synthesized scene needs headroom, apply one documented global scalar to the complete multichannel mixture. Never treat raw and derived copies as independent measurements. Do not group unrelated measurements by matching Rxx suffixes alone.

## 15 The experiment and the H2 software context

The central experiment is whether actual XVF3800 output audio, directional information, speech energy, and temporal/session history can improve diarization and safe speaker attribution. The planned simulator creates synchronized four-microphone signals from measured paths and sends those signals through the physical XVF. It does not assume that a software beamformer reproduces the XVF's DSP, gating, or adaptive state.

DOC describes the H2 architecture as Sherpa ONNX Giga streaming ASR, Pyannote ONNX segmentation, one shared ReDimNet2-B2 speaker worker for anonymous clustering and enrolled identification, session memory, conservative known-name assignment, lossless audio journaling, and final-only Sherpa Edge-Punct-Casing INT8 punctuation. Preserve the selected H2 architecture and its safe audio-only fallback. Do not add H5 or a second identity model as an unrelated redesign.

The existing desktop software location referenced in DOC is:

```text
C:\Users\amiri\Documents\GitHub\just-peachy\Software Validation from Datasets\Evaluation Tool
```

That directory exists on this desktop. Its current Git revision, model assets, launch behavior, and tests were not requalified during this measurement audit. A later baseline prompt should inspect its current README and state before making changes. The launcher recorded in DOC is `scripts/run_edge_speech_pipeline.ps1 gui`; it is historical context, not a command run by this audit.

DOC reports historical baseline examples including raw WER 9.16%, memory-mode DER 56.57%, speaker confusion 20.09%, recurring-unknown consistency 89.81%, stranger FPIR 0.578% (2/346 episodes), and speaker-attributed WER 159.12%. Those are reported baseline figures under their original evaluation definitions, not fresh results from this campaign. Their denominators, dataset partitions, normalization, and scoring policy must be recovered before a matched comparison.

### Changes in the latest DOC that must not be lost

Compared with the older bundled workbook, DOC adds the idea that gyroscope information should help distinguish a moving device from a moving speaker, and says fine-tuning improved accuracy in earlier work without the XVF. It also retains other sections that say to freeze models initially and defer additional training until timing, output-path, and synthetic-versus-real questions are resolved.

Preserve the newer fine-tuning observation as a reported project result. Do not claim this audit independently reproduced it, and do not revert any existing tuned model merely because older sections say models are frozen. For later implementation, inventory the actual current model/version and freeze that baseline for a controlled comparison. Resolve the timing and scope of any additional training in its own future prompt. The current request authorizes no training.

Likewise, the gyroscope idea is future planning. The measurement archive says `imu.recorded: false`; it cannot retrospectively reconstruct device yaw. An IMU can support motion gating and relative attitude estimation, but the later implementation must demonstrate its frame, time alignment, and drift behavior before treating it as world-direction truth.

## 16 Planned physical simulation and hardware-in-the-loop behavior

DOC sections 13 and 14 provide the intended sequence. Use the current KRK/onboard-array campaign facts when those differ from older hardware descriptions.

1. **Clean source preparation.** Start with a small, labelled set of approximately 50 suitable utterances for the initial proof. Preserve speaker ID, transcript, source file hash, sample rate, source timing, enrollment/unknown state, and source-level procedure. Verify dataset rights and actual local availability when that task starts.
2. **Four-channel synthesis.** Convolve each talker with the four qualified responses for one measured source condition. Sum talkers/noise on a common microphone timeline. Use exact source scheduling and record any propagation/trim convention in ground truth.
3. **Packed input preparation.** The documented six-channel 16 kHz HIL input is far-end reference, ignored channel, MIC0, MIC1, MIC2, MIC3, packed into 48 kHz stereo transport. Near-end-only tests normally have zero far-end reference. Do not confuse this input vector with the capture vector whose first two payload channels in this campaign are continuity and processed_auto.
4. **Physical XVF processing.** Discover and verify the actual desktop device, firmware, endpoints, supported precision, mux, packed injection mode, and restoration procedure. Prove packing order and scale with small deterministic fixtures. Do not flash, reset, or reuse a laptop device index merely because an old script contains it.
5. **Gain/delay accounting.** The measured responses already include Category 3 gain/delay. DOC proposes unity mic/reference gains and zero system delay during packed injection to avoid double application. Treat this as a required behavior to prove on the physical path, using current documentation and readbacks, before batching.
6. **Capture output and telemetry.** Capture actual XVF output streams plus relevant native metadata and timestamps. Preserve continuous adaptive state within a synthetic conversation.
7. **H2 evaluation.** Feed the captured output into the existing H2 pipeline, preserve the evaluation events and ground truth, and compare matched conditions.

For independent replay cases, establish the documented known initial XVF state and retain the reset/configuration receipts. For a continuous dinner scene, do not reset between speakers or turns; that would remove the adaptive history being evaluated. A disconnect ends the affected trial and preserves evidence; it is not an excuse to silently bridge missing PCM.

The XMOS [testing guide](https://www.xmos.com/documentation/XM-014888-PC/html/modules/fwk_xvf/doc/programming_guide/04_testing_the_software.html) and local v3.2.1 programming guide describe the supported packing/injection mechanisms. Re-read the relevant sections during implementation and verify the actual firmware behavior. This handoff is not a substitute for that physical proof.

## 17 Scene design, noise, and evaluation splits

Begin with one speaker at one measured condition, then a second speaker taking over, return after silence, rapid turns, short interjections, partial overlap, nearby angles, rear cases, and near/far or quiet/loud source-level differences. Expand only after a small complete chain produces interpretable results.

Use a separate source path for each localized interferer. A clean competing voice or dish sound convolved through its own source-position RIR has a defined spatial origin. Diffuse ambience requires appropriate coherent multichannel noise or a documented spatial model. Independent random noise on each microphone is a transport stress fixture, not an automatically realistic room-noise field. Avoid treating noisy speech from another room as clean source material because it carries an additional acoustic path and noise location.

The current measurements already include environmental noise. Document how extraction prevents that noise from becoming an unintended fixed convolution artifact or being double-counted when synthetic noise is added. RETAKE data and its background windows remain excluded under the user's rule.

Keep related geometry groups, poses, obstruction variants, recording sessions, source utterances, and speaker identities together as appropriate when creating train/development/test partitions. In particular, do not put a flat response into development and its paired upright response into an allegedly independent held-out acoustic test without explaining that relationship. A single RIR used for many speech files does not create many independent room measurements.

With only six room/table labels, report the actual grouping and uncertainty. Do not infer full unseen-room generalization from random utterance splits. Freeze tuning rules on development data and reserve a small untouched real-human/device validation set to test whether synthetic-HIL rankings and failure patterns predict reality.

## 18 Output-path and cue comparisons

First compare XVF audio paths under matched scenes. DOC proposes:

| ID | Candidate output | Purpose |
|---|---|---|
| O0 | ASR stream, Category 7 source 3 with AEC_ASROUTONOFF enabled | Candidate before communications postprocessing |
| O1 | Postprocessed auto-select, Category 6 source 3 | Noise suppression/AGC/limiting comparison |
| O2 | Simultaneous O0/O1 capture when supported | Diagnostic comparison; verify actual mux/bandwidth |
| O3 | Raw/amplified microphone or AEC-residual control | Diagnose the source of a failure |

These are planned routing choices from DOC, not outputs proven to work on this desktop in the current audit. Verify each route before comparing it. `processed_auto.wav` in the sweep archive does not stand in for a future O0/O1 speech evaluation.

Then run the guide's cue conditions with explicit implementations:

| Condition | Cues |
|---|---|
| D0 | ReDimNet embedding only |
| D1 | Embedding plus temporal/session memory |
| D2 | Embedding plus angle |
| D3 | Embedding plus energy |
| D4 | Embedding plus angle and energy |
| D5 | Embedding plus angle, energy, temporal tracking, and IMU gating |

Treat D0 as an ablation branch, not a reason to delete session memory from the production baseline. To isolate gains against the existing memory-based baseline, supplementary D1+angle and D1+energy comparisons may be useful; define and name them explicitly rather than silently changing D2/D3. D5 cannot claim measured IMU behavior until an actual synchronized IMU stream is available. Static motion-state fixtures should be labelled as such.

Angle is a soft continuity/location observation, not permanent identity. Energy supports activity/dominance/confidence, not speaker identity. Preserve known-name safeguards and stable Unknown_N behavior. Missing, invalid, stale, or motion-corrupted spatial data must fall back to the audio-only path without blocking text or dropping the recoverable audio journal.

## 19 Metrics and success criteria for future prompts

| Outcome | Required measurements |
|---|---|
| Audio and transport | Sample continuity, clipping, actual rates, queue age, drops, output/capture/telemetry timing, configuration readbacks |
| RIR quality | Useful band, noise/decay limits, direct-path evidence, coherent four-channel timing/scale, extraction reproducibility |
| ASR | WER/CER with fixed text normalization, empty output, first partial/stable prefix/finalization latency |
| Segmentation | Speech miss/false alarm, overlap recall, boundary error, usable clean-evidence yield by utterance duration |
| Anonymous diarization | DER components, JER, switches, fragmentation, contamination, re-entry consistency |
| Known identity | Correct-known time, wrong-known seconds, stranger FPIR, cold acquisition, warm reacquisition |
| Unknown identity | Rejection, stable Unknown_N continuity, split/merge behavior |
| Direction | Folded linear-array error, lag/stability, valid/stale fraction, separate front/rear ambiguity reporting |
| Attributed transcript | Speaker-attributed WER/cpWER under documented definitions, correction and relabel delay |
| Runtime | RTF, CPU, process-tree memory, queue growth, thermal behavior and lossless recovery |

Avoid choosing the best cue combination from one aggregate score. Report tradeoffs in diarization improvement, false-known safety, latency, and missing-metadata robustness using matched scenes and fixed scoring definitions. Preserve per-room/condition results so one easy geometry does not hide failures elsewhere.

The later target is the purchased **2 GB RAM, 32 GB eMMC, non-wireless CM5**, according to DOC. Desktop generation and physical XVF validation come first. CM5 testing should replay the same hashed representative vectors and qualify the complete H2/XVF process tree under the native memory limit. That is a later deployment task, not work performed here.

## 20 Suggested sequence of later Codex prompts

Each prompt should define its inputs, output files, acceptance evidence, expected README updates, and the boundary before the next stage. Generate those prompts from this context; do not assume the steps below have happened.

1. **Inventory the existing H2 and desktop hardware environment.** Read local AGENTS/README files, record current Git/model/runtime state, identify the actual XVF and available tools, and preserve an audio-only baseline. Distinguish read-only inventory from any later authorized hardware state changes.
2. **Implement the curated dataset loader.** Consume the explicit 127-run allowlist, verify source hashes, apply the two bound distance corrections, preserve unknown geometry, and reject excluded statuses/tests. Produce a deterministic catalogue without altering raw files.
3. **Qualify timing and RIR extraction on a small subset.** Include a clear front case, opposite sides, a rear case, and a noisy/obstructed case. Resolve common timing/drift and expose failure reasons before expanding. Start with several high-margin unobstructed candidates, not solely the hardest cases.
4. **Extract and qualify the four-channel RIR set.** Save parameterized, hashed outputs, diagnostics, and a separate simulation-ready manifest. Do not call all 127 qualified by inheritance from this audit.
5. **Generate deterministic clean four-microphone scenes.** Build one-talker and two-talker proof vectors with exact ground truth, preserved relative channel timing/level, and a documented global scaling convention.
6. **Prove physical packed injection and capture.** Verify channel order, gain/delay accounting, supported precision, actual O0/O1 routes, configuration restoration, and telemetry/audio synchronization on a small vector.
7. **Connect actual XVF output to unchanged H2.** Preserve journaling, fallback, session memory, identity safeguards, and output events. Reproduce the baseline before adding cues.
8. **Run matched output and cue ablations.** Freeze development/test partitions and parameter policies, run O0/O1 then D0–D5 as supported, and report functional tradeoffs with room/condition stratification.
9. **Validate against small real-person recordings.** Test whether synthetic-HIL ranking and characteristic errors predict the real device. Resolve any source mismatch and exact angle calibration needs using new evidence.
10. **Plan additional training and CM5 qualification separately.** Preserve the latest DOC fine-tuning observation and current model history. Choose additional training only within an explicitly scoped future experiment, then replay the frozen workload on the target hardware.

No step should quietly use RETAKE takes, initial pilots, guessed metadata, or independent per-microphone normalization to make the result look better. A failed qualification should remain an explicit result that informs the next prompt.

## 21 Open evidence needs

| Need | Current evidence | What resolves it |
|---|---|---|
| Final RIRs | Not present | Documented deconvolution and per-RIR qualification |
| Clock model | Separate Realtek playback, coarse marker intervals | Common offset/drift estimation and validation with uncertainty |
| Exact angle calibration | Correct left/right sign supported; numerical labels uncalibrated | Known-position/pose calibration and native-to-lab transform |
| Absolute distance accuracy | Operator entries, two user-confirmed corrections, valid bounds | Measurement notes/photos or new physical verification if required |
| Geometry and pose | Distance, azimuth, FLAT/UPRIGHT and obstruction labels | Actual XYZ/heights/yaw/pitch/roll and physical frame documentation |
| Same-condition repeatability | No eligible duplicate full conditions | New unchanged formal repeats if repeatability must be established |
| Usable decay in noisy rooms | Coarse margins and intact capture | Per-band RIR/noise/decay review; retain honest usable-band limits |
| Source response and level | Relative fixed KRK setup, no EMM-6 reference | Real-versus-synthetic comparison; optional justified reference calibration |
| Desktop HIL | Not tested in this audit | Small verified physical injection/capture proof |
| Motion compensation | No recorded IMU | Synchronized IMU integration with tested attitude/frame behavior |
| Current H2 model baseline | Described in DOC; actual current state not rebenchmarked | Read current repo/assets and reproduce baseline |

These are limitations of what can currently be certified. They do not erase the value of the capture-validated measurement set, and they are not permission to replace the user's measured conditions with invented values.

## 22 Source and evidence map

| Source | What it supports |
|---|---|
| DOC.docx, sections 1–3 | H2 architecture, research purpose, guardrails, latest gyro/fine-tuning notes |
| DOC.docx, sections 7–9 | Output inventory, signal/angle planning, coordinate conventions |
| DOC.docx, sections 11–14 | Planned repeats, RIR recovery, real-XVF replay, scene design, D0–D5 and metrics |
| DOC.docx, sections 15–17 | CM5 deployment and later validation/training program |
| Root DATA_HANDOFF.md | Transfer layout and explicit statement that no final RIRs were generated |
| Root PROJECT_CONTEXT.md and SECTION_6_NEXT_STEPS.md | Later KRK/onboard-array decisions and historical acquisition state |
| Root MEASUREMENT_GUI_GUIDE.md and measurement_app/README.md | Recorder semantics, status meanings, workflow and saved paths |
| RECORDINGS_INDEX.csv | Original 179-run inventory; not the corrected simulation allowlist |
| Per-run request.json and 00_admin/trial_metadata.json | Operator geometry, acquisition labels, timestamp and planned domains |
| Per-pass result.json, quality.json and configuration/readback files | Capture gates, marker candidates, domain, gain/delay and device identity |
| Per-run SHA256SUMS.txt and derived provenance | Original byte identity and operation history |
| Per-pass WAVs, continuity source and telemetry JSONL | Freshly decoded/compared signal evidence and native replies |
| validation/P1_REFERENCE_PAIR_20260906 | Historical excluded pilot repeat evidence only |
| validation/LAST_FIVE_NOISE_REVIEW_20260907 | Historical noise annotations; all five annotated takes excluded now |
| audit_results.json and audit_summary.json | Fresh audit measurements and scope |
| eligible_recordings.json and metadata_corrections.json | Selected future extraction inputs and user-confirmed effective distances |
| excluded_recordings.json | Explicit exclusions and reasons |
| angle_checks.json | Per-run sweep/marker lag diagnostics and sign-screen assumptions |

External primary references, checked during this audit, are the XMOS [host application guide](https://www.xmos.com/documentation/XM-014888-PC/html/modules/fwk_xvf/doc/user_guide/03_using_the_host_application.html), [control command appendix](https://www.xmos.com/documentation/XM-014888-PC/html/modules/fwk_xvf/doc/user_guide/AA_control_command_appendix.html), and [testing guide](https://www.xmos.com/documentation/XM-014888-PC/html/modules/fwk_xvf/doc/programming_guide/04_testing_the_software.html). For ESS background, Angelo Farina's [swept-sine measurement paper](https://angelofarina.it/Public/Papers/134-AES00.PDF) describes recovery of linear and harmonic responses. It does not certify this particular campaign or supply its missing calibration evidence.

Use the README in this folder to rerun the local audit. Source recordings, original metadata/statuses, and the supplied Word document were not edited. Any later data or implementation changes require the selection, audit, and narrative handoff to be refreshed together.
