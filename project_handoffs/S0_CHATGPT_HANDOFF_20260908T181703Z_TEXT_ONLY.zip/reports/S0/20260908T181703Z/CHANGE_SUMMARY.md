# S0 local changes

Added simulation/scripts (catalogue, baseline smoke wrapper, dataset inventory, read-only device wrapper, receipts, validation and packaging), eight focused tests, README, active context/decision log, angle overlay and this evidence run. No tracked H2 code or model edits. Original acquisition/Word/reference-pack files remain in place. Existing untracked measurement directories and nested unborn repository were preserved. Git status before/after is included. Local cache receipts and the H2 smoke journal stay outside the ZIP.

No automatic commit or push. No later phase has started.
