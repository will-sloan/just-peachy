# S0 evidence handback — 20260908T181703Z

**READY_WITH_LIMITATIONS.** The 127 eligible recordings, their required extraction references, both distance corrections and the proposed 12-record pilot are bound locally. There are no critical RIR-input blockers in the inspected set. S1 may be requested next, but has not been started. RIR usability, precise direction, movement and CM5 operation remain unqualified.

## Authority and scope

The actual supplied workbook is `C:\Users\amiri\Downloads\XVF_Measurement_V5.docx`, SHA256 `c9a6badcd83065ae9f865de841c077f00668a480e1f0170c115c514e30a99db6` (1,321,341 bytes). Its title identifies master workbook Revision 5, 8 September 2026. This resolves the difference from the name in the pasted request; no older workbook was substituted. It was read as context and not rewritten. Its extracted text is included. Historical DOC sections describe plans where they differ from the audit/current instruction.

The existing intentionally nested reference pack remains at `C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\Just_Peachy_Post_Measurement_Codex_Pack_V1\Just_Peachy_Post_Measurement_Codex_Pack_V1`. Sixteen consumed pack documents were checked against its SHA256SUMS; the sums file itself and the current user request were fingerprinted. Original pack, audit, recordings, metadata and Word documents were not edited. The current user request supersedes the old percentage wording. User-provided AGENTS instructions require this implementation's updated run README; no additional AGENTS file was found in the inspected project/H2 ancestors and source trees.

## Input and geometry contract

All 179 indexed records reconcile: **127 eligible formal REVIEW**, **52 excluded**. Eligibility comes only from `eligible_recordings.json`. The exclusions comprise 31 early pilots/diagnostics and 21 formal records (16 RETAKE, 5 INVESTIGATE); no excluded noise windows are admitted. The five historical PASS records are diagnostics, not eligible formal captures.

The initial bounded pass hashed 1,670 unique consumed files (836,633,754 bytes) in 15.64 s. It verified canonical MIC0–MIC3 files, the exact archived excitation, parent SHA manifests, request/result/trial metadata, playback/timing and capture configuration/gain/identity/quality sidecars. It did not rehash every nested manifest or repeat packed carrier decoding and transport continuity analysis. The archive capture audit remains the authority for those checks. A subsequent catalogue formatting/cache check reused all 1,670 receipts and hashed zero source bytes.

Each canonical WAV header matches four channels, 16 kHz, PCM24 and 350,647 frames (21.9154375 s). Original capture domain remains Category 3, microphone gain 10, SYS_DELAY −32 (a 32-sample microphone delay). All inspected playback summaries retain separate Realtek playback/capture clocks and −6 dB software gain. Digital continuity is not evidence of a shared acoustic clock.

Both corrected rows retain original 100 m and effective 1.00 m. Each correction is checked against exact run ID, recorded UTC, parent-manifest hash and original request value, then assigned once rather than rescaled. The rows are flat `JPXVF_P1_R02_T01_D01_S02_F00_NAT_CU_R05` and upright `JPXVF_P1_R02_T01_D01_S02_UPR_NAT_CU_R05`, low table / Opening Behind Listener / +20°. Effective distances are **0.46–4.07 m**, all positive and <=5 m; physical distances are still operator-reported, not independently surveyed.

`user_context_overlay.v2.json` records **approximately ±4–5 degrees or less**, with a conservative 5° half-width, authority `user_clarification`, and `independently_calibrated=false`. Central labels/signs are unchanged. Circular intervals wrap correctly at ±180°. The old percentage/denominator fields survive only in a named superseded-history object. ±10°/±20° are labelled future artificial robustness tests, never assumed measurement uncertainty. These are placement/label estimates, not DoA performance, a standard deviation, confidence interval or hard algorithm-error bound. Native radians remain distinct from laboratory degrees and linear-array front/rear ambiguity remains.

Prior sign evidence is carried forward: 109 informative sweep-side checks supported the entered side; 18 near-axis cases were inconclusive. This S0 did not rerun that acoustic analysis or claim precise angular calibration. Unknown XYZ, heights, yaw, pitch, roll and photographs remain unknown. User-reported source-facing-tablet context and the unresolved Carlton Library alias are retained without changing NAT tokens or inventing yaw.

All 12 proposed pilot IDs and their hashes match the allowlist; order and difficult/noisy selections are retained. There are no unchanged same-condition repeats; Rxx suffixes, pose changes and obstruction changes are not repeatability evidence. All records remain `rir_qualification=NOT_EXTRACTED`, `qualified_rir_available=false`, `simulation_ready=false`.

No unmanifested newer files were found in the eligible records' 03_derived/04_hil_exports/05_analysis directories. A filename inventory of project validation/tmp/planning found only existing packing fixtures, not qualified RIR outputs. This is a project-scoped search, not a claim about all files on the desktop. Archived 03_derived microphone copies and analysis placeholders are not RIRs.

## Actual H2 baseline and one fresh smoke

Main repository: commit `830009cc9fa9ef996e4668f53441c2b858ce6b42`, branch `codex/edge-component-expansion`. No tracked H2 edits were present initially or made by S0. Two pre-existing untracked XVF directories remain. The measurement folder is also a nested unborn Git repository on `master`, with its existing contents untracked; S0 adds `simulation/`. No commit, add, push, stash, reset or history operation was performed. Before/after receipts and source hashes are included.

The established launcher selects `C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe` (Python 3.11.16). Active runtime is Sherpa-ONNX 1.13.4 and ONNX Runtime 1.29.0; available ORT providers are AzureExecutionProvider, CPUExecutionProvider. Active inference uses CPU. No model, threshold, provider or global dependency was changed.

| Active component | SHA256 |
| --- | --- |
| sherpa_giga_encoder_int8 | `32c98281c7bd8b63e3e142d007251b37f120572e8fdea9a4f5a79ce22b10ec4f` |
| sherpa_giga_decoder_fp32 | `9da02b77cb08826756ec6a88635f35a40374e4164e7c6359121a9145958a6ceb` |
| sherpa_giga_joiner_int8 | `831477d390e59a61f1b6a6f763b9903e6c6366ff6034f1ddba613be82637122f` |
| sherpa_giga_tokens | `49e3c2646595fd907228b3c6787069658f67b17377c60aeb8619c4551b2316fb` |
| sherpa_online_punctuation_int8 | `9d611f445fe4a46186080fe161be6059d87d72eb88d3a8cb00c1a06e83a6067e` |
| sherpa_online_punctuation_bpe | `e118b7ad88c54db562517df49e1cffd4836d166c34fb190fd311d7f34eb238f5` |
| redimnet2_b2_fp32 | `5c1a8635cba0d4648463f3b6d30c5a6137bc38d1200ab00c5944400aaa7b5609` |
| pyannote_segmentation_3_0_fp32 | `b4b65085bbf2cc455565696604c87fedade1359aa6ddfac5d726d69124d5069a` |

All eight actual assets passed the unmodified runtime's checksum validation before this fresh inference. Configuration and model source/export manifests are separately fingerprinted in `baseline_manifest.json`. Export provenance points to ReDimNet `b2-vox2-lm.pt` and Pyannote segmentation-3.0; no resolver-selected newly fine-tuned path was identified. The user-reported earlier tuning benefit is preserved as context, not independently established checkpoint ancestry. S0 retained the active bytes; it did not revert anything based on older no-training text.

Audio is float32 mono at 16 kHz after existing channel averaging/resampling, then PCM16 journal storage with independent consumer cursors. This 16 kHz mono fixture did not exercise resampling. Sherpa uses 80-dimensional features and greedy decoding; token and punctuation BPE files are hash-bound. Pyannote uses 10 s windows / 0.75 s hop and 0.46/0.45 onset/offset; ReDimNet uses 0.5 s / 0.25 s windows and normalized 192-dimensional vectors. Exact endpoint/thread parameters are in the manifest.

Anonymous memory is a session-local normalized running centroid, cosine threshold 0.35. Enrollment uses the same ReDimNet backend, checkpoint hash and vector-shape gate. Names require score 0.5128856897, margin 0.03 and 2 s evidence; tentative naming can occur before the evidence threshold. Evidence is elapsed time since the cluster first appeared, not calibrated independent speech duration. There was one existing profile metadata/vector pair; personal names, vectors and audio were not exported or changed. The smoke used a new empty profile directory through the existing EDGE_SPEECH_DATA_ROOT override.

Exact command (working directory `C:\Users\amiri\Documents\GitHub\just-peachy\Software Validation from Datasets\Evaluation Tool`):

```powershell
$env:EDGE_SPEECH_DATA_ROOT = 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S0\20260908T181703Z\smoke_data'
$env:PYTHONDONTWRITEBYTECODE = '1'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe' -m app.edge_speech_pipeline file 'C:\Users\amiri\Documents\GitHub\just-peachy\Software Validation from Datasets\Evaluation Tool\artifacts\realtime_test_audio\aew_rxr_eey_arctic_a0301_concat.wav' --accelerated
```

The existing 8.8975625-second mono WAV completed in **6.282 s subprocess wall time**; runtime telemetry reports 4.833 s. `--accelerated` feeds the source at four times real time; these times are not pure model compute benchmarks. Both consumers reached 8.8975625 s, dropped frames and residual cursor lag were zero. The speaker analysis stops at 8.75 s, leaving a reported 0.1475625 s short tail. Fresh events: 21 partials, one final transcript, 11 segmentation events, 27 speaker decisions. Learned punctuation completed, with one terminal-period fallback and zero punctuation inference failures. The expected repeated phrase was emitted; no corpus WER/DER was calculated.

The tracker produced 6 anonymous cluster labels on this short concatenated fixture. Completion does not establish correct speaker count or identity continuity. Enrollment/name accuracy, GUI behavior, live capture, XVF audio effects, spatial fusion and CM5 performance were not exercised. Historical test counts were not reported as newly passed.

## Local datasets and identity/rights limits

Counts below are current index counts, not a recursive validation of every audio file. The first five distinct paths per indexed audio-path field were checked and existed. Three sample enrollment/probe pairs for each promising clean corpus were bound to local hashes; no embeddings were calculated and no split was frozen.

| Dataset | Indexed recordings / utterances | Indexed speaker keys | Clean-source use |
| --- | --- | --- | --- |
| CMU Arctic | 15,583 / 15,583 | 18 | All indexed utterances are candidates; 18 IDs have multiple distinct files |
| LibriSpeech | 292,367 / 292,367 | 2,484 total | 137,876 clean rows; 1,252 clean speaker IDs with separate files |
| HiFiTTS | 323,978 / 323,978 | 10 total | 126,439 clean rows; only 3 clean reader IDs with separate files |
| AMI | 2,034 / 834,429 | 190 | Already recorded room/meeting audio; not dry speech by default |
| CHiME-6 | 540 / 98,432 | 48 recording-table IDs | Real conversations; not clean speech or noise-only by default |
| VOiCES | 19,200 / 19,200 | 300 | Deduplicate source branch; distant branch already has acoustics |

CMU speaker_id/speaker_code, LibriSpeech speaker_id/chapter/utterance and HiFiTTS reader_id permit within-corpus scene identity separation and disjoint enrollment/probe files. Namespacing prevents identifier collisions but does not prove different humans across corpora. LibriSpeech, HiFiTTS and VOiCES source provenance can overlap; reserve identities and deduplicate utterances before combining them. CMU's README logs 20 extra WAVs lacking per-speaker transcripts; these are outside the emitted normalized transcript set. HiFiTTS's large historical warning count concerns metadata gaps and must not be equated automatically with corrupted audio.

AMI has a 1,207,406-row word-timing table. The other five indexes have no word-timing table; utterance start/end fields do not establish word times. AMI has 742,873 nonempty indexed transcript rows and CHiME-6 98,431; the three clean candidates have nonempty text for all emitted rows. Full path/hash/schema/group details are in `dataset_inventory_details.json`.

Local licence statements: LibriSpeech and HiFiTTS say CC BY 4.0; CHiME-6 says CC BY-SA 4.0. AMI contains older CC BY-NC-SA 2.5 audio/annotation copies and a newer CC BY 4.0 annotation manual; per-file applicability must be resolved. No CMU Arctic or VOiCES licence was found in the bounded local scan, so their rights are UNKNOWN here. These observations are not a clearance decision for later redistribution or voice synthesis. HiFiTTS's local README also discusses speaker consent for TTS sample selection.

No independently qualified noise-only source bank was established. Campaign pre-excitation windows must first pass S1 timing/stationarity/contamination checks; excluded recordings remain prohibited. AMI/CHiME/VOiCES mixtures are not automatically ambience. Common Voice and MIT RIR raw roots exist but are not in this six-dataset normalized inventory and were not recursively inventoried.

## Resources and connected XVF

Observed CPU is **Ryzen 7 5700X3D**, 8 cores / 16 logical processors; this corrects the reported 5800X3D. RAM visible is 63.93 GiB, with 37.22 GiB available at snapshot. RTX 3080 has 10,240 MiB VRAM, about 7,032 MiB free at snapshot, driver 610.62. Existing Conda paths are recorded; base has parquet tooling and the H2 environment has the needed CPU inference packages. No CUDA installation was attempted.

| Drive | Volume | Free GiB at snapshot |
| --- | --- | --- |
| C: | WD850X | 90.11 |
| D: | Backup | 0.00 |
| F: | 4TB HDD | 25.48 |
| G: | 2TB SSD | 78.04 |

Use C: for the small S1 pilot with inputs read in place, four CPU workers, one inner BLAS/FFT thread, 16 GiB application RAM cap and at least 16 GiB available RAM. Cap temporary cache at 5 GiB and stop before free disk drops below 50 GiB. G: is the second 2 TB SSD, but it also lacks capacity for the proposed 200 GiB broad cache. D: is effectively full; F: is a low-space HDD. This deliberately replaces the pack's provisional cache/reserve proposal for the bounded pilot; storage must be reconsidered before larger stages. No S1 extraction ETA is justified until its first cases are timed.

Read-only control reused `measurement_app.core.Control`, its existing Windows byte-range hardware lock and `tools/xvf321/binary/host_v3.0.0/win32/xvf_host.exe`; raw getter receipts are included. Eleven getter calls succeeded with no setters, streams, reset or flash. Current board: firmware 3.2.1 `ua-io48-lin`, array type 1, four microphones at native x positions −0.04995, −0.01665, +0.01665, +0.04995 m; gain 10, reference gain 1.5, delay −32, packed input 0, DAC DSP enable 0. **Current USB_BIT_DEPTH is 16/16**, distinct from the archived 24-bit capture state. S3 must explicitly qualify the desktop format/configuration later; S0 left it untouched.

Fresh WASAPI endpoint observations identify output index 22 and input index 25, each with two-channel capacity and default 48 kHz. These are inventory observations, not permanent indexes or a negotiated stream format. Other APIs expose different host API IDs/defaults. Re-enumerate at S3 and bind by device/API identity. Initial read-only probing with the H2 environment hit an incompatible recorder dependency import before any device command; the established bundled recorder Python resolved it without installation.

## Validation, execution issues and handoff boundary

Eight fresh failure-oriented unit checks passed (hash mismatch/missing file, cache invalidation, path escape, duplicate manifest, correction identity/idempotence, invalid distance and angular wrap). 15/15 integration contract checks passed. The compact ZIP is independently checked for CRC, file inventory, all listed SHA256 hashes and forbidden heavy artifacts after assembly.

Task wall time through this evidence preparation: **16.98 min**; catalogue and smoke timings above isolate actual automated work. `package_receipt.json` records final elapsed time through ZIP validation. Most time was bounded inspection, implementation and evidence review, not numerical processing. One broad fixture-discovery search was stopped and replaced by its known session receipt; one transient report-file lock and one wrong-runtime import were recovered. Details/earlier attempt receipts are preserved. No unrelated Python process was terminated; the device lock was released. No extraction, denoising, source EQ, scene synthesis, HIL, cue fusion, training or deployment ran.

No user decision is required to resolve an S1 input blocker. The next prompt should authorize only the unchanged 12-record timing/RIR/noise pilot. Independently calibrated angles/distances, missing geometry, no same-condition repeats, noisy Loeb responses and separate acoustic clocks constrain interpretation but do not prevent trying that bounded method. Dataset rights/splits, active checkpoint training ancestry, current USB width, native-to-lab mapping, enrolled identity accuracy, motion evidence and CM5 qualification affect later stages and remain explicit limitations.

Read `NEXT_PHASE_INPUTS.md` for exact accepted artifact paths/hashes and the S1 stopping boundary. S0 stops after this package.
