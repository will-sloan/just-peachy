# Accepted S0 inputs for a separately requested S1

S0 status: READY_WITH_LIMITATIONS. No critical RIR-input blockers. Authorize only the supplied 12-record timing/RIR/noise qualification pilot; stop before S2 library expansion or S3 hardware work.

| Artifact (absolute local path) | SHA256 |
| --- | --- |
| `C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S0\20260908T181703Z\input_catalog.json` | `4f272903b86d02193b9934439cd77b0e478ce048a6a0c0d451048b3d581dced2` |
| `C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S0\20260908T181703Z\resolved_pilot.json` | `ecffdb9477704f394baf85e8ef8e49984ac90005bd32f25fdbc3f4f7fe1ac844` |
| `C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S0\20260908T181703Z\metadata_corrections.json` | `469832e0547549788fce35fa1ae39276e3e2a7a46e1a52c8f0307a08db846169` |
| `C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S0\20260908T181703Z\user_context_overlay.v2.json` | `b0e25bc18fc84a08d8f9a5fa7f071bfec51db1c4a3ab26cf68afc053e3b8b711` |
| `C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S0\20260908T181703Z\baseline_manifest.json` | `f7620b82685a34a002a7b2a93365c58493ac9265d07c1dd52f761939ab8eda42` |
| `C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S0\20260908T181703Z\resource_plan.json` | `5afe8bb35ce742db91a6da3787f878b7e4c3eee784d1179024cb94ac92b678b9` |

The catalogue contains exact local canonical audio, original excitation and needed sidecar paths with saved/observed hashes for every allowed record. The pilot is unchanged and all 12 rows are BOUND. Use its four-channel 16 kHz PCM24 files and the exact archived 48 kHz PCM16 excitation with SHA256 `cba5b09d4d3963d508340711210804d2dd80cf62741a60a2544120e60acbf488`; apply recorded −6 dB playback scalar once. Do not regenerate or replace the excitation with a 16 kHz variant.

S1 should test the extractor first on inexpensive known-FIR synthetic fixtures with known delay/gain/clock mismatch/noise; then run only the 12 selected measurements. Compare common no-drift and justified clock-mapping variants, preserving all intermicrophone timing and levels. Use the same four-channel mapping/taper, do not individually align microphones, force label agreement, remove source EQ, or reinterpret Category 3 gain/delay. Preserve diagnostic untrimmed estimates and uncertainty. A reconstruction residual is internal consistency, not independent acoustic proof.

Select noise windows using acoustic timing evidence; post-sweep decay and end markers are not automatically noise-only. Assess noisy Loeb cases with explicit limited-use/failure states; do not replace them or require every case to become full-band. Preserve all excluded records/noise exclusions. Define usable band/tail, alignment residual, common clock uncertainty, six mic delays, gain ratios, pre-arrival ringing, reconstruction residual and decay/noise limits. Thresholds/policy should be justified from this pilot before expansion.

Use ±5° only as user-estimated label half-width, preserve centers and signs, and keep native radians separate. No independent exact angle/distance, XYZ, yaw, heights, photos, unchanged repeats or recorded IMU exist. These are limitations, not fields to synthesize.

Use four CPU workers at most, one inner thread, a 16 GiB application budget, 5 GiB scratch cap and 50 GiB minimum free disk. Read inputs in place. Reuse unchanged hash receipts with stat checks. Report item progress/elapsed/throughput and 15-second heartbeat; estimate runtime only after measuring the first fixtures/cases.

No additional user input is necessary for the RIR-input binding. The next prompt must choose/authorize the S1-only implementation scope and require a compact report/plots/metrics/manifest/next-input handback. Later concerns (not S1 input blockers): dataset licence/identity split review; active checkpoint training ancestry; anonymous over-clustering and enrollment validation; desktop USB currently 16/16 and unqualified injection; native-to-lab calibration; motion evidence; CM5 deployment.

Current V5 workbook: C:\Users\amiri\Downloads\XVF_Measurement_V5.docx, SHA256 c9a6badcd83065ae9f865de841c077f00668a480e1f0170c115c514e30a99db6. Matching copied phase/context references are under evidence/reference_context; they guide a future request and do not themselves authorize execution.
