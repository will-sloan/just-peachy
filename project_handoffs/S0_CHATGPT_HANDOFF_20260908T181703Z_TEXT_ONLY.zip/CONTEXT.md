# Active post-measurement context

Latest completed stage: S0, run `20260908T181703Z`, READY_WITH_LIMITATIONS. See `reports/S0/20260908T181703Z/S0_REPORT.md` and `NEXT_PHASE_INPUTS.md`. S1 has not started.

Authority order: current user corrections; recorded audit facts; matching XMOS interface documentation; current V5 workbook for goals/plans. Workbook resolved to `C:\Users\amiri\Downloads\XVF_Measurement_V5.docx`, SHA256 c9a6badcd83065ae9f865de841c077f00668a480e1f0170c115c514e30a99db6.

Use only the explicit 127 formal REVIEW allowlist and preserve 52 exclusions including their noise windows. Both original 100 m entries are bound by exact identity to effective 1.00 m. Never rescale the effective field twice.

Active angle context is `config/user_context_overlay.v2.json`: approximately ±4–5 degrees or less, conservative half-width 5 degrees, user_clarification, independently_calibrated=false. This replaces the percentage/denominator question. Preserve signed centers, native radians separately, circular wrap and linear front/rear ambiguity. No precise angle ground truth is established. ±10/20 are only possible future artificial robustness tests.

Preserve user-reported source-facing-tablet context, unresolved library alias, NAT tokens and unknown XYZ/height/yaw/photos. Do not fabricate geometry or enforce delays to match labels. Preserve Category 3 gain 10/delay −32 and separate Realtek acoustic clock. No qualified RIR exists in the audited/inspected project outputs.

Keep the current eight H2 assets exactly as bound. Active model ancestry and user-reported earlier tuning benefits are different kinds of evidence; do not swap to parent weights based on older prose. Current board read-only state is USB 16/16; no setters were sent. Physical format and HIL qualification belong to S3.

S1 recommended resources: 4 workers, inner threads 1, CPU only, 16 GiB RAM budget, 5 GiB scratch cap, >=50 GiB free disk. Larger cache plans do not fit observed C/G capacity. No automatic later-phase execution.
