# S3 physical XVF proof — preflight checkpoint

Status: **BLOCKED before playback**. This is an analysis-first checkpoint dated 2026-09-08T22:00:46.023842+00:00. The user-required confirmation that the KRK and all other analog monitors are off/disconnected remains pending. A software mute cannot establish this condition because it may corrupt the packed carrier.

## Observations

| Capability | Status | Evidence and denominator |
|---|---|---|
| Pack/master input binding | PASS | S3 checksum entries and exact Revision 6 workbook SHA-256 checked |
| Current device discovery | PASS | One XVF WDM-KS input/output pair; firmware 3.2.1, linear, four mics |
| Offline packing/integrity | PASS | 8 pack/equivalence checks plus 9 recapture/failure checks |
| Physical transport and unity/zero replay | NOT_TESTED | 0/6 physical cases attempted |
| O0/O1 processed routing | NOT_TESTED | No captured output |
| Speech telemetry behavior | NOT_TESTED | Snapshot availability only |
| Repeatability and timeline alignment | NOT_TESTED | No repeat captures |
| Unchanged H2 O0/O1 smoke | NOT_TESTED | No physical mono output files |
| Restoration | NOT_NEEDED | Zero setters/streams; byte-range lease released |

The live USB width is 16/16. Existing mic gain 10, reference gain 1.5, SYS_DELAY -32, packed input 0 and ASR output disabled were preserved. Snapshot telemetry getters responded, including the optional selected-azimuth command; NaN in the no-speech selected field is not a failure. Snapshot responses establish neither an achieved logging rate nor telemetry freshness. The intended 24/24 packed transport is not yet negotiated or physically qualified.

The selected Library Conference Room / Square Table End / flat-clear RIRs are front R01 (0°, 1.70 m), left R12 (+75°, 0.74 m), and right R04 (-80°, 0.90 m). All three exact hashes match the S3 bindings and belong to S2's HIL-input-eligible subset. The deferred clock-sensitive low-table R13 is absent. No earlier test, RETAKE, excluded Loeb Caf or additional measurement is introduced. S2's broader 121-record results are reused, not re-audited or upgraded by S3.

LibriSpeech dev-clean utterances 1272-128104-0000 (5.855 s), 1272-128104-0003 (9.900 s), and 1462-170138-0006 (8.580 s) were checked against exact local audio and transcript files. Speaker keys 1272 and 1462 are distinct in the dataset. Both identities and all three utterances are reserved as development fixtures. The local corpus license states CC BY 4.0; attribution and alteration details are in run_manifest.json. No speech or private enrollment audio is bundled.

## Prepared method and interpretation

The fixed source drive is original clean PCM times 0.25 (-12.0412 dB). Four-channel convolution uses the canonical Category 3 RIRs without another -6 dB factor, division by gain 10, delay compensation, independent normalization or alignment. All speech cases share one headroom factor; its value is 1.0 because additional attenuation was unnecessary. RIR pre-onset of about 50 ms remains, and no guessed distance/c delay is inserted.

Input slots are [zero far-end, zero ignored, MIC0, MIC1, MIC2, MIC3]. Each width is quantized directly from the numerical vector once to its available payload grid (23 bits for PCM24, 15 for PCM16). Both offline packings match the supplied XMOS implementation. Negative tests detect sign flips, channel swaps, an individual-mic delay, single-sample corruption, missing/duplicate groups and bad interior framing. Common-offset recovery permits no per-mic lag/gain fitting. Passing these software checks cannot establish a working physical transport.

The planned output mux is 3 0 / 3 2 / 7 3 / 3 1 / 3 3 / 6 3, in L_PK0/L_PK1/L_PK2/R_PK0/R_PK1/R_PK2 argument order. Unpacking produces MIC0, MIC1, MIC2, MIC3, O0 ASR-auto, O1 postprocessed-auto. This ordering follows the supplied implementation; simultaneous physical capture remains to be demonstrated. Expected physical tolerances are zero payload mismatches and zero interior marker errors after comparison to the quantized vector, with only one common integer offset. Boundary padding is reported separately.

The six planned cases take 123 seconds: tagged transport 8 s, front/left/right 13 s each, and two 38 s A-left/B-right/A-left conversations. Conversation source starts are exactly 3, 12 and 24 seconds, with full tails and surrounding silence. There is no reset between turns; resets and complete frozen settings apply between independent cases. The runner stops at an integrity failure. One diagnosed retry is available, with failed attempts retained and total playback below 15 minutes.

## Limits and next gate

Fresh device ownership and 50 GiB reserve checks are enforced on physical execution. The existing persistent telemetry logger records native radians/energy and host transaction bounds; subsequent analysis must keep source, recaptured input, processed audio and telemetry timelines separate. No device sample timestamp or causal audio/metadata alignment has been proven. Linear-array front/rear ambiguity and operator-estimated ±5° labels remain.

The initial static configuration will be snapshotted and restored with readback. Adaptive DSP history cannot be reconstructed from settings. That restoration path has not yet run, so this checkpoint is not a restoration proof. The existing H2 file path must receive explicitly isolated mono O0 and O1 only after all board handles close, using empty profile roots and unchanged assets/configuration. No H2 invocation was made here.

The safety confirmation is the immediate gate. After it arrives, continue S3 and replace this checkpoint with actual per-attempt findings and the compact final handoff. Do not start training, change H2, regenerate RIRs, select a production output, or launch the full simulation campaign.
