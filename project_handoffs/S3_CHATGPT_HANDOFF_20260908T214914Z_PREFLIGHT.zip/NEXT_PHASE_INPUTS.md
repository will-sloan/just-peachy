# Resume bounded S3, not the next simulation phase

First receive the explicit analog-monitor confirmation. Save the actual user response and UTC time in speaker_safety.json; never invent a confirmation. The physical runner requires `all_analog_monitors_off_or_disconnected: true` and nonempty `user_confirmation_text`.

Input manifest: `simulation\reports\S3\20260908T214914Z\inputs_manifest.json`

SHA-256: `802e51fe6fe852b2e1310d301e593f8f4fe35442ffe463bd8a284d0d8449f69c`

Canonical manifest: `C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\rir_library\v1\RIR_MANIFEST.json`

SHA-256: `468b2b306f994937a7d02db611080d38c7a4bcc7dc89ce7dc73d93762380f546`

Exact selected RIR, speech, code and expected-vector bindings are in run_manifest.json and the local input manifest. Keep all prepared scales and hashes. Re-read live endpoints/settings when ownership is acquired. The hardware runner is implemented and offline-tested; its physical path is untested.

PowerShell (from `C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs`):

```powershell
& 'C:\Users\amiri\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' simulation\scripts\s3_hardware.py --report simulation\reports\S3\20260908T214914Z --speaker-safety-receipt simulation\reports\S3\20260908T214914Z\speaker_safety.json
```

Anaconda Prompt / Command Prompt: use the same executable and arguments without PowerShell's leading `&`. Exact setup commands and inputs/outputs are in `C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\README_S3.md`.

After valid physical captures and restored settings, analyze four timelines, O0/O1 routing/levels, telemetry rate/gaps/held values and the two conversation repeats. Then run one paired mono O0/O1 case through unchanged H2 with isolated empty profile roots. No physical capture exists yet; do not substitute old recordings or the dry input for this smoke.

Return the completed compact S3 handoff with every attempted case, restoration readback, metrics, up to four plots and a revised workbook section. No output winner, enrollment or moving-person accuracy, or CM5 claims. No new RIRs, H2 edits, training or full campaign.
