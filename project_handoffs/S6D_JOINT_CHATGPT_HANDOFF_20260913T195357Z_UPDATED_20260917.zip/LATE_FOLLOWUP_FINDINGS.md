# S6D final follow-up: timing, label stability and beam opportunity

Added 17 September 2026 at the user's request for useful immediate analysis before the next phase. Read this alongside the original S6D_REPORT.md. The original results and delivered ZIP remain preserved. This revision adds saved-data analysis; it does not promote a configuration or alter audio, defaults, thresholds, enrollment, firmware or the Word master.

## What was checked

| Follow-up | Fixed population | Verification |
|---|---|---|
| Actual event clocks | All 2 host, 12 C-calibration and 4 continuous native logs | Accepted SHA256 bindings, full-source audits, completed/drained results; 105 matched host first-text rows and 1,296 unique saved C candidate events |
| Online speaker-label behavior | All 960 native jobs; 2,642 saved utterance rows, including 38 empty jobs | All score-to-latest-transcript bindings verified; missing/reference-limited strata retained |
| Lexical concentration | All 5 same-pass stream contrasts; each has 63 actor-scene rows, 31 scenes and 881 actor-exclusive reference-token occurrences | Gains, losses, zeros, actor totals, within-pass redundancy and all 155 leave-one-scene-out contrasts retained |
| Initial/final text structure | All 2,642 matched saved native utterance rows | Same start and nested source spans; explicit token-prefix rules, separate partial-token extension |

Two initial clock-audit checks stopped on a result-schema assumption and the distinction between pilot/native publication clocks. Their plans remain local; the final analyzer uses the accepted host scorer's clock convention, explicitly retains the native timestamp offset, and passes exact readback. No original experimental output was modified by these checks. Analysis runtime was approximately 16 seconds for clocks and 13 seconds for the independent metadata analyses; investigation and review took longer. No new inference or hardware run occurred.

## 1. Recorded latency does not isolate intrinsic model or naming cost

For each actual event the saved clocks satisfy:

    consumer elapsed time - evidence source end
      = (publication elapsed time - committed producer cursor)
      + (committed producer cursor - evidence source end)
      + (consumer receipt time - publication time)

The first term is a wall-time/source-progress discrepancy. It is not an exact audio-commit timestamp, isolated disk cost, or pure model time. Publication uses the saved pilot monotonic clock when available, consistent with the accepted host scorer; the later native publication offset is retained. ASR's separately modeled serial availability is not substituted for actual publication/consumption.

Across the 1,296 unique mature events that appeared in the C feature candidates:

| Clock quantity, seconds | Mean | Median | p95 |
|---|---:|---:|---:|
| Actual consumer receipt minus evidence source end | 46.4398 | 43.6410 | 94.2732 |
| Publication elapsed minus committed producer cursor | 46.2547 | 43.4840 | 94.1354 |
| Producer cursor minus evidence source end | 0.1506 | 0.1000 | 0.2000 |
| Publication-to-consumer queue | 0.0345 | 0.0057 | 0.2468 |

The cursor-relative evidence backlog ranges from approximately 0.1 to 0.3 seconds. All 1,296 events still exceed the original 0.75-second source-age limit at their actual availability. The original 5,882 repeated candidate observations remain ineligible. The four overlap/source-swap C jobs contributed zero mature candidate IDs to this population and remain present as zero denominators; 1,296 does not represent all possible embeddings or independent trials.

Inspection of the pinned paired and multistream file producers shows that each reads/appends a block and then waits a full block duration. Any read, append, callback or scheduling time therefore adds to the nominal playback duration. The saved logs do not time each input commit or append, so they cannot apportion the observed discrepancy between pacing, write/lock contention, operating-system scheduling, model contention or publication work. Small evidence-to-cursor backlog does not prove that embeddings would meet a live deadline.

The same pattern is relevant outside C: the median actual first-text age relative to that first hypothesis's source end is 16.95 seconds in the C065 host run, 18.40 seconds in C088, and 52.01–59.70 seconds across the four continuous native conditions. These are source-end-relative event ages, not speech-onset response time or actual GUI exposure. See all 18 job summaries in followup/clock/CLOCK_SUMMARY.csv.

The 105 matched host first-text rows reproduce the earlier C088-minus-C065 delivery difference exactly: median 1.2608 seconds, p95 1.5846 seconds. Its mean decomposition is 1.152457 seconds total = 1.151997 seconds publication/cursor residual + 0 producer-relative backlog + 0.000460 seconds consumer queue. Separate quantiles do not add. These are two observational runs with 105 correlated utterances, not 105 randomized naming-cost trials.

**Decision consequence:** retain the observed latency failures, but do not describe the 1.26-second difference as isolated intrinsic naming overhead or all C age as embedding compute. Qualify source pacing and event clocks before choosing an optimization target. The incomplete negative calibration support and physical beam/person alignment limitations are independent problems that a clock fix would not solve.

## 2. A bounded revision counter misses substantial online label activity

Across all 960 native jobs:

- Ongoing display-label changes: 6,826 across 2,373 of 2,642 utterance rows.
- Separately bounded reconciliation revisions: 1,450 across 1,073 rows.
- Rows with ongoing changes despite revision_count = 0: 1,412.
- First versus latest explicit numbered anonymous label differs in 854 of 1,164 comparable rows; 310 agree.

These counters have different source-defined meanings and must not be added or treated as interchangeable. Ongoing changes are recorded on subsequent ASR observations, whereas revision_count covers a separately bounded reconciliation mechanism. Values may involve Unknown or names. The numbered-anonymous comparison is restricted to comparable Speaker_N endpoints within the same utterance; it does not invent anonymous identity for a named endpoint.

This demonstrates label instability that a revision-only report misses. It does not by itself prove a wrong-person attribution, count independent speakers, measure Tk exposure, or establish the time users saw a label. Four native configurations reuse each scene; utterances and configurations are correlated. Complete-reference, incomplete-reference, scoring-disallowed and empty strata are retained in followup/metadata/NATIVE_STRATA.json rather than silently discarded.

**Decision consequence:** make stable, evidence-backed identity a separate acceptance target from word accuracy. Preserve captions while identity is unresolved. Future evaluation should report label changes and duration of actual displayed wrong/unknown identity, not just final agreement or bounded revisions.

## 3. Scanner opportunities are not explained by a single scene

All comparisons below are candidate versus its own same-pass auto-ASR control. MAIN and SCAN are different physical passes.

| Pass / stream | Extra / lost token occurrences | Scenes with any gain | Net after omitting any one scene |
|---|---:|---:|---:|
| MAIN focus0 | 10 / 50 | 7/31 | -42 to -31 |
| MAIN focus1 | 14 / 24 | 7/31 | -13 to -1 |
| SCAN focus0 | 13 / 22 | 8/31 | -12 to -4 |
| SCAN focus1 | 11 / 33 | 8/31 | -25 to -12 |
| SCAN scanner | 15 / 6 | 9/31 | +6 to +10 |

Scanner gains remain net positive under every scene omission; all four focus contrasts remain net negative. Scanner's three largest gain scenes account for 8 of its 15 extras. Gains are not independent across streams: MAIN focus0/focus1 share 7 count-bounded extra token occurrences; SCAN focus0/scanner share 10 of their 13/15 extras.

This is a robustness diagnostic on actor-exclusive token occurrences, not statistical significance, acoustic source separation, exact event timing, or an executable selector. It does not change the whole-recording panel WER result: SCAN scanner has 142 edits versus 153 for its auto control on 965 complete-reference words, while MAIN auto has 142 edits and its focus streams 187/157. The 31-scene panel is not a full 240-scene scanner test. Do not select a runtime threshold using these Q results.

**Decision consequence:** scanner is the more defensible next experimental secondary-word source; focused streams remain exploratory identity/evidence sources or carefully bounded diagnostics. There is still no validated reason to replace the primary transcript wholesale. The missing dynamic second-ASR/switching implementation remains deferred; this audit does not implement or validate it.

## 4. First text mostly grows; it is not a final transcript

Of 2,642 rows, 2,032 have normalized token-prefix growth, 584 extend the last initially partial token, and 26 retain the same token sequence. None has a nonprefix first-to-latest change under the declared punctuation-insensitive, casefolded tokenization.

This check supports keeping first-text delivery and final-transcript correctness separate. It does not show that intermediate hypotheses never retract, that either endpoint is correct, or that final WER is low. It would be misleading to score an early prefix against words that occur later as if those words had already been missed.

## Handoff interpretation and next action

S6D remains complete as a bounded research stage, with negative and unavailable efficacy findings. No production configuration is certified. The most useful next work is a small, instrumented clock/pacing and stability qualification before another broad comparison, followed by fixed controls for unfiltered captions, optional naming and an isolated scanner side experiment. NEXT_PHASE_PIPELINE_PRIORITIES.md gives concrete priorities and gates.

The updated package includes scripts, run instructions, compact scalar evidence, all-case tables and hash provenance. The original delivered ZIP remains immutable. The scheduled S6D check-in was already deleted and was not restarted. No additional S6D computation is pending.
