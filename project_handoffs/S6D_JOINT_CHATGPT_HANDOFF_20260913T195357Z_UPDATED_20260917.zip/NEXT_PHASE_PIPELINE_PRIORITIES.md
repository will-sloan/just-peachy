# Next-phase pipeline priorities

This is a proposed next experiment, not a started campaign or a new default. It combines the measured S6D outcomes with engineering hypotheses. Exact input/profile/source/gallery bindings are in PROFILE_EPOCH_GALLERY_MANIFEST.json and the included configurations. The recommendations preserve the previous default while providing explicit research controls.

## Configuration roles to keep

| Role | Fixed starting condition | Why it remains useful | What still needs qualification |
|---|---|---|---|
| Primary caption control | Exact C065 / O0 / T0; full unfiltered transcript and full source journal | Known, measured anonymous baseline with no enrolled-name requirement | Source pacing, real delivery latency, attribution continuity; C105 regression stays in the negative panel |
| Optional enrolled naming | Exact C088 / A15 / O0 / T0; preserve every caption when identity is unknown | Separates word delivery from optional recognition of an enrolled person | Wrong-name exposure, abstention, stability and causal incremental latency/cost |
| Scanner side experiment | Same-pass SCAN auto as primary; scanner considered only as secondary evidence | Panel word opportunities survive every single-scene omission | Independent calibration, timing, trigger reliability, compute budget, whole-transcript regressions and new held-out scenes |
| Focused-beam identity experiment | MAIN auto-ASR primary with separately timestamped focus evidence | Keeps available beam evidence without replacing a stronger primary transcript | Valid calibration positives and negatives, live freshness, overlap abstention and person/beam association |
| Direction display | Separate physical spatial observation from any retrospective person label | Avoids presenting old name evidence as a current pointing decision | Observable eligible person-direction associations; useful coverage as well as error |

T0 is the unfiltered display control. T1/T2 are selected-person presentation policies and are not suitable default caption paths given the measured withholding. A15 refers to the exact existing naming condition; do not silently rebuild a gallery or apply a different enrollment pipeline. New device-domain galleries were evaluated conditionally, not promoted.

The legacy O0 model input already contains its historical +3 dB once. S6D raw mono outputs are unity-gain saved signals. Preserve those bindings; do not apply another generic gain or normalize beam streams merely to make listening levels similar. Compare streams against their own same-pass controls.

## Priority 1: qualify file playback, clocks and independent text delivery

The late follow-up establishes a large elapsed-time versus committed-source discrepancy. It does not establish which component caused how much of it. Before a broad benchmark:

1. Instrument source-block read start/end, each journal append/commit, committed frame cursor, producer deadline/overrun, model dispatch start/end, event publication, consumer receipt and actual GUI exposure. Keep source sample time, monotonic wall time and modeled readiness distinct. Measure observer overhead.
2. Compare the frozen producer with a proposed absolute-deadline file replay. A relative full-block wait after processing accumulates non-wait work. An absolute schedule can avoid that accumulation only while the workload keeps up; it must report misses, preserve every sample and aligned stream, and never hide overload by dropping audio or silently accelerating delivery.
3. Use a small predeclared pair of representative sources, one short and one sufficiently long to reveal drift, with both C065 and C088 and swapped execution order. Repeat only enough to distinguish startup effects, ordering and drift. Reuse captured WAVs and compatible cached references. Freeze comparison cells before execution.
4. Check first text separately from final transcript, source-end event age separately from speech-onset latency, and consumer receipt separately from actual rendered text. Record full source coverage and exact admitted frames.
5. Require no missing/dropped frames, bounded queues, clean shutdown/drain and stable resource use. Preserve the existing latency/freshness gates unless a separate requirement is explicitly approved before testing. A clock correction must produce a fresh measured run; never subtract the old residual to declare past runs successful.

A file replay fix would not prove hardware live-input timing or CM5 performance. Validate the actual live capture-to-display path separately when hardware is available. The current task does not assume the device is connected.

## Priority 2: make identity stability a first-class result

Keep ASR word delivery independent of optional identity decisions. An unresolved identity should retain its text, source span and evidence trail; it should not suppress speech. Preserve a durable anonymous turn/track identity while presenting names only from admissible evidence. These are proposed product behaviors, not proven new configurations.

Evaluate ongoing ASR-associated label changes and separately bounded reconciliation revisions. Report first correct name, time confirmed, time stably correct, wrong-name exposure, Unknown exposure, track fragmentation and return-to-speaker consistency. Record actual display events if claiming UX performance. Do not use the final anonymous label alone to infer the path to it.

Use complete-reference word accuracy alongside attribution measures, with conditioned/incomplete truth clearly separate. Include difficult C105 and long-session failures rather than selecting only clean demonstrations. Treat source scenes/speakers as clustered observations, and include censored/never-correct opportunities.

Late valid voice evidence can support a retrospective caption-name correction within an explicit policy. That must not extend a spatial observation's live age. A live arrow and a historical transcript label need distinct clocks and acceptance tests.

## Priority 3: repair calibration support before enabling beam/person association

The existing C set has no timely eligible association rows and no unambiguous negative support for calibration. Clock qualification alone does not supply negatives or prove physical association.

Predeclare a compact C-only calibration contrast with identifiable source support and both positive and negative examples. Include one speaker, alternating/reappearing speakers, overlap, silence/target absent, competing voices and similar-direction sources as feasible. Specify ambiguous support handling and expected source/beam relationships before scoring. Keep enrollment E, calibration C and held-out Q separate; do not retune using the scanner or identity failures already inspected on Q.

Retain freshness, overlap, confidence and abstention checks. Report usable coverage and the distribution of rejected reasons, as well as precision on accepted events. Zero associations or arrows must remain unavailable efficacy, not perfect accuracy.

Hardware data collection is warranted only for a clearly missing support/geometry contrast, with the established analog-output safety check and bounded capture plan. Reuse valid recordings where possible. Do not regenerate RIRs or recapture the whole bank because the file replay clock changed.

## Priority 4: test scanner complementarity without gambling the primary transcript

Start by isolating whether a second stream adds correct words while preserving primary words and attribution. Keep its ASR and source timing separate, measure extra compute and retention cost, and log every proposed merge/replacement with evidence. A diagnostic oracle may estimate opportunity but must never be reported as a deployable decision rule.

A secondary decoder or dynamic stream trigger remains an implementation proposal. Its parameters must be set with independent C support and then frozen. Score the complete resulting transcript, including false additions, duplicated words, speaker errors, missed speech and boundary transitions. Compare against the same-pass primary; report MAIN and SCAN separately.

The scanner's positive net token evidence across all scene omissions makes it a sensible next exploratory branch, not a selected champion. Focus streams' negative net lexical contrasts argue against indiscriminate primary replacement. Any focused-beam benefit must be demonstrated for the specific intended use.

## Priority 5: promote only after a small realistic acceptance panel

After the clock and calibration prerequisites pass, test a fixed panel spanning single speaker, overlap, long pauses, speaker return, target absence, short answers, distant/off-axis voices, room changes and enrollment mismatch where truth permits. Include continuous sequences; independently scored short clips do not test state persistence.

Use separate reporting axes:

- Full unfiltered caption word accuracy, complete/conditioned reference coverage and omissions.
- Attribution/name accuracy, abstention, wrong-name duration, continuity and explicit censored cases.
- Added beam/scanner word benefit versus false additions/losses using same-pass controls.
- Source-to-event and source-to-display latency percentiles, deadlines, queue backlog and producer drift.
- CPU, memory, storage, model/API time and total pipeline cost; source minutes including silence versus active-speech minutes clearly labeled.
- Useful direction coverage, valid alignment and wrong-person/direction association.

Preserve the original simulated silence for continuity and latency tests. Optional cropped snippets are suitable for a separately labeled lexical diagnostic, not for claiming equivalent state behavior or a faster real-time pipeline. The approximately 44-second scene pattern is an experiment schedule/container choice, not a universal minimum imposed by the RIR.

Record accuracy/latency/resource tradeoffs rather than choosing a configuration on one mean score. Define promotion gates before new held-out testing. Desktop evidence does not qualify CM5 memory, ARM64 dependencies, storage endurance or sustained thermal behavior; the included CM5 material remains preparation.

## Stop point for this handoff

The immediate saved-data analyses are complete. No further broad S6D replay is needed to make this handoff reviewable. The first next-phase decision is to authorize a bounded producer/clock and identity-stability qualification with the exact controls above. This proposal is not authorization to automatically start S7–S9, resume paused H2, fit Q thresholds, train models or change defaults.
