"""Immutable, bounded S6D saved-clock decomposition. See README.md."""
import csv
import hashlib
import json
import math
import time
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

import psutil

HERE = Path(__file__).resolve().parent
R = HERE.parent.parent
START = time.perf_counter()
PROVENANCE = {}


def require(ok, why):
    if not ok:
        raise RuntimeError(why)


def bind(path):
    p = Path(path)
    before = p.stat()
    digest = hashlib.sha256()
    with p.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    after = p.stat()
    require((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns),
            f"Changed while hashing: {p}")
    return {"path": str(p), "bytes": after.st_size, "sha256": digest.hexdigest()}


def verified(binding):
    actual = bind(binding["path"])
    require(actual["sha256"] == binding["sha256"] and actual["bytes"] == binding["bytes"],
            f"Hash mismatch: {actual['path']}")
    PROVENANCE[actual["path"]] = actual
    return Path(actual["path"])


def read(path):
    return json.loads(Path(path).read_bytes())


def read_bound(binding):
    return read(verified(binding))


def save(name, obj):
    with (HERE / name).open("x", encoding="utf-8") as stream:
        json.dump(obj, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")


def stats(values):
    x = sorted(values)
    if not x:
        return {"n": 0}
    require(all(math.isfinite(v) for v in x), "Nonfinite statistic")
    def q(p):
        i = (len(x) - 1) * p
        a = int(i)
        return x[a] + (x[min(a + 1, len(x) - 1)] - x[a]) * (i - a)
    return {"n": len(x), "min": x[0], "mean": sum(x) / len(x),
            "p50": q(.5), "p95": q(.95), "p99": q(.99), "max": x[-1]}


FIELDS = ["consumer_age_sec", "publication_cursor_residual_sec",
          "producer_evidence_backlog_sec", "publication_consumer_queue_sec"]


def publication(payload):
    # Match the accepted host scorer's observer clock; retain native offset below.
    return payload.get("pilot_publication_monotonic_sec", payload["publication_monotonic_sec"])


def summarize(rows):
    return {k: stats([x[k] for x in rows]) for k in FIELDS}


def decompose(event, origin):
    p = event["payload"]
    pub = publication(p)
    con = event["actual_consumed_monotonic_sec"]
    cursor = p["publication_source_cursor_sec"]
    end = p["source_end_sec"]
    vals = [pub, con, cursor, end, origin]
    require(all(math.isfinite(v) for v in vals) and con >= pub, "Invalid clocks")
    row = {"source_start_sec": p["source_start_sec"], "source_end_sec": end,
           "publication_elapsed_sec": pub - origin, "consumption_elapsed_sec": con - origin,
           "publication_source_cursor_sec": cursor,
           "consumer_age_sec": (con - origin) - end,
           "publication_cursor_residual_sec": (pub - origin) - cursor,
           "producer_evidence_backlog_sec": cursor - end,
           "publication_consumer_queue_sec": con - pub,
           "native_minus_pilot_publication_sec": p["publication_monotonic_sec"] - pub}
    error = abs(row[FIELDS[0]] - sum(row[k] for k in FIELDS[1:]))
    require(error < 1e-8, "Clock identity failed")
    row["identity_error_sec"] = error
    return row


def main():
    psutil.Process().cpu_affinity([12])
    inputs = {
        "host": R / "application/host_correctness_final_v1/RESULT.json",
        "calibration": R / "application/beam_C_zero_eligibility_analysis_v1/COUNTS.json",
        "continuous": R / "continuous/native_comparison_v1/READBACK.json",
        "paired_source": R / "source_epochs/application_direction_gui_v3/edge_speech_pipeline/research_audio_v3.py",
        "beam_source": R / "application/beam_C_source_origin_proposal_v2/source/edge_speech_pipeline/research_beams_s6d.py",
        "runtime": R / "source_epochs/application_direction_gui_v3/edge_speech_pipeline/runtime.py",
    }
    plan = {"utc": datetime.now(timezone.utc).isoformat(), "population": "2 host + 12 C + 4 continuous; all cases",
            "inputs": {k: bind(p) for k, p in inputs.items()}, "script": bind(__file__),
            "readme": bind(HERE / "README.md"), "model_calls": 0, "hardware_calls": 0,
            "scope": "Saved metadata only; no gates, sources, Q configuration or prior results changed."}
    save("PLAN.json", plan)
    for b in plan["inputs"].values():
        verified(b)
    host = read(inputs["host"])
    calibration = read(inputs["calibration"])
    continuous = read(inputs["continuous"])
    require(len(host["provenance"]) == 2 and len(calibration["cases"]) == 12
            and len(continuous["rows"]) == 4, "Population changed")
    jobs = []
    for p, score_row in zip(host["provenance"], host["rows"]):
        jobs.append({"group": "host", "result": p["result"], "audit": p["audit"],
                     "consumer_events": p["consumer_events"], "score": score_row["score"]})
    for c in calibration["cases"]:
        f = read_bound(c["feature"])
        completion = read_bound(f["completion"])
        require(completion["status"] == "COMPLETE", "C incomplete")
        candidates = {}
        for probe in f["probes"]:
            for x in probe["candidates"]:
                key = x["event_id"]
                compact = {k: x[k] for k in ["event_id", "source_start_sec", "source_end_sec", "available_at_sec"]}
                require(key not in candidates or candidates[key] == compact, "Repeated candidate clocks disagree")
                candidates[key] = compact
        require(len(candidates) == c["unique_mature_event_ids"], "C denominator mismatch")
        audit = read_bound(f["full_source_audit"])
        jobs.append({"group": "calibration", "result": completion["result"], "audit": f["full_source_audit"],
                     "consumer_events": audit["consumer_events"], "candidates": candidates})
    for c in continuous["rows"]:
        audit = read_bound(c["audit"])
        jobs.append({"group": "continuous", "result": c["result"], "audit": c["audit"],
                     "consumer_events": audit["consumer_events"]})
    all_jobs = []
    host_scores = {}
    for job in jobs:
        result = read_bound(job["result"])
        audit = read_bound(job["audit"])
        require(not audit.get("errors"), "Accepted audit contains errors")
        require(result.get("status") == "COMPLETE", "Result not complete")
        require(result.get("event_consumer_drained") is True, "Consumer not drained")
        path = verified(job["consumer_events"])
        file_stat = path.stat()
        job_id = result["job"]["job_id"]
        source_count = 0
        origin = None
        first_text = {}
        beam = {}
        dispatch = {}
        api = defaultdict(list)
        event_counts = Counter()
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for line in stream:
                digest.update(line)
                e = json.loads(line)
                kind = e["event_type"]
                p = e["payload"]
                event_counts[kind] += 1
                if kind == "source_started":
                    source_count += 1
                    origin = publication(p)
                if kind == "research_asr_dispatch":
                    dispatch[round(p["source_end_sec"] * 16000)] = p
                    api["asr_decode_sec"].append(p["compute_ms"] / 1000)
                if kind in ("s6d_beam_speech", "s6d_beam_identity"):
                    if "model_api_elapsed_sec" in p:
                        api[kind + "_api_sec"].append(p["model_api_elapsed_sec"])
                    if "identity_policy_elapsed_sec" in p:
                        api["beam_identity_policy_sec"].append(p["identity_policy_elapsed_sec"])
                if kind == "s6d_text_ready" and p.get("text", "").strip() and p["utterance_id"] not in first_text:
                    require(origin is not None, "Text before source origin")
                    row = decompose(e, origin)
                    row.update(utterance_id=p["utterance_id"], raw_text=p["text"],
                               modeled_available_at_sec=p["available_at_sec"],
                               decode_ms=p.get("asr_decode_ms"))
                    d = dispatch.get(round(p["source_end_sec"] * 16000))
                    if d and publication(d) <= publication(p):
                        row["dispatch_to_text_publication_sec"] = publication(p) - publication(d)
                    else:
                        row["dispatch_to_text_publication_sec"] = None
                    first_text[p["utterance_id"]] = row
                if kind == "s6d_beam_identity" and p.get("event_id") in job.get("candidates", {}):
                    key = p["event_id"]
                    require(key not in beam and p["evidence_kind"] == "mature", "Duplicate/nonmature C event")
                    x = job["candidates"][key]
                    require(all(abs(p[k] - x[k]) < 1e-7 for k in ["source_start_sec", "source_end_sec", "available_at_sec"]),
                            "Candidate/event timestamp disagreement")
                    row = decompose(e, origin)
                    row.update(event_id=key, stream_id=p["stream_id"],
                               actual_available_at_sec=p["available_at_sec"],
                               available_minus_source_end_sec=p["available_at_sec"] - p["source_end_sec"],
                               availability_vs_publication_sec=p["available_at_sec"] - row["publication_elapsed_sec"])
                    beam[key] = row
        after = path.stat()
        require((after.st_size, after.st_mtime_ns) == (file_stat.st_size, file_stat.st_mtime_ns)
                and digest.hexdigest() == job["consumer_events"]["sha256"], "Consumer log changed")
        require(source_count == 1, "Ambiguous source origin")
        require(len(beam) == len(job.get("candidates", {})), "Unmatched C candidates")
        if job["group"] == "host":
            score = read_bound(job["score"])
            expected = score["names"]["first_text_rows"]
            require(len(first_text) == len(expected) == 105, "Host first-text population not 105")
            for s in expected:
                x = first_text[s["utterance_id"]]
                require(x["raw_text"] == s["raw_text"], "Host text disagreement")
                for k in ["source_start_sec", "source_end_sec"]:
                    require(abs(x[k] - s[k]) < 1e-7, "Host source disagreement")
                require(abs(x["consumption_elapsed_sec"] - s["consumption_sec"]) < 1e-7
                        and abs(x["publication_elapsed_sec"] - s["publication_sec"]) < 1e-7,
                        "Existing host score clock mismatch")
            host_scores[job_id] = first_text
        duration = result["job"]["audio_duration_sec"]
        rows = list(first_text.values())
        crows = list(beam.values())
        compact = {"job_id": job_id, "group": job["group"], "source_origin_monotonic_sec": origin,
                   "duration_sec": duration, "event_counts": dict(event_counts),
                   "first_text_summary": summarize(rows), "unique_C_mature_summary": summarize(crows),
                   "api_costs": {k: {"sum_sec": sum(v), "sec_per_source_minute_including_silence": sum(v) / duration * 60,
                                     **stats(v)} for k, v in api.items()},
                   "first_text": rows, "unique_C_mature": crows}
        all_jobs.append(compact)
    require(len(all_jobs) == 18, "Incomplete population")
    require(sum(len(j["unique_C_mature"]) for j in all_jobs) == 1296, "C unique population changed")
    left = host_scores["C065_HOST_CONTINUOUS_O0_delivery_repair"]
    right = host_scores["C088_HOST_CONTINUOUS_O0_delivery_repair"]
    require(left.keys() == right.keys(), "Host unmatched IDs")
    paired = []
    for key, a in left.items():
        b = right[key]
        require(a["raw_text"] == b["raw_text"] and all(a[k] == b[k] for k in ["source_start_sec", "source_end_sec"]),
                "Host source/text not paired")
        row = {"utterance_id": key, "source_end_sec": a["source_end_sec"],
               **{k: b[k] - a[k] for k in FIELDS}}
        require(abs(row[FIELDS[0]] - sum(row[k] for k in FIELDS[1:])) < 1e-8, "Paired identity failed")
        paired.append(row)
    save("PER_JOB_CLOCKS.json", all_jobs)
    save("HOST105_PAIRED_CLOCKS.json", {"direction": "C088 minus C065", "n": 105,
                                      "summary": summarize(paired), "rows": paired})
    with (HERE / "CLOCK_SUMMARY.csv").open("x", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=["job_id", "population", "metric", "n", "min", "mean", "p50", "p95", "p99", "max"])
        writer.writeheader()
        for j in all_jobs:
            for pop in ["first_text", "unique_C_mature"]:
                for metric, summary in j[pop + "_summary"].items():
                    writer.writerow({"job_id": j["job_id"], "population": pop, "metric": metric, **summary})
    crows = [x for j in all_jobs for x in j["unique_C_mature"]]
    summary = {"status": "COMPLETE_SAVED_CLOCK_FOLLOWUP", "utc": datetime.now(timezone.utc).isoformat(),
               "jobs": len(all_jobs), "unique_C_events": len(crows), "pooled_C": summarize(crows),
               "C_producer_backlog_within_0_75_sec": sum(0 <= x["producer_evidence_backlog_sec"] <= .75 for x in crows),
               "C_already_stale_at_actual_availability": sum(x["available_minus_source_end_sec"] > .75 for x in crows),
               "C_availability_minus_publication": stats([x["availability_vs_publication_sec"] for x in crows]),
               "host_paired_C088_minus_C065": summarize(paired),
               "all_clock_identity_max_error_sec": max(x["identity_error_sec"] for j in all_jobs for pop in ["first_text", "unique_C_mature"] for x in j[pop]),
               "checks": {"population_complete": True, "host105_existing_score_clocks_match": True,
                          "all_C1296_candidate_timestamps_match": True, "all_bound_logs_sha256_verified": True},
               "provenance": list(PROVENANCE.values()), "plan": bind(HERE / "PLAN.json"),
               "outputs": [bind(HERE / n) for n in ["PER_JOB_CLOCKS.json", "HOST105_PAIRED_CLOCKS.json", "CLOCK_SUMMARY.csv"]],
               "model_calls": 0, "hardware_calls": 0, "elapsed_sec": time.perf_counter() - START,
               "limits": ["Cursor residual is not exact commit lag or isolated disk cost.",
                          "ASR modeled readiness is not actual delivery.",
                          "No eligibility or prior result is changed; no thresholds fit.",
                          "API sums are wall durations, not CPU or full pipeline, normalized by source including silence.",
                          "Paired run differences do not identify causal naming overhead.",
                          "Pooled events are correlated; per-job summaries retained."]}
    save("RESULT.json", summary)
    print(json.dumps({k: v for k, v in summary.items() if k not in ["provenance", "outputs", "plan"]}, indent=2))


if __name__ == "__main__":
    main()
