# S6D late clock follow-up

Purpose: decompose actual saved event latency into publication-minus-producer-cursor residual, evidence backlog behind the producer cursor, and publication-to-consumer queue time. This is a bounded metadata audit of all 2 host, 12 calibration and 4 continuous cases. It makes no model calls, reads no audio, changes no pipeline or threshold, and preserves the original metrics.

Inputs: the hash-bound host correctness result, calibration zero-eligibility counts, continuous readback, their accepted consumer logs/results/audits, host scores and frozen source files. Outputs: PLAN.json, PER_JOB_CLOCKS.json, HOST105_PAIRED_CLOCKS.json, CLOCK_SUMMARY.csv and RESULT.json. Scalar event times are included; embeddings are excluded. Existing outputs cannot be overwritten.

PowerShell:

    Set-Location -LiteralPath 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6D\20260913T195357Z\application\late_clock_followup_v1'
    & 'C:\Users\amiri\anaconda3\python.exe' .\Analyze.py

Anaconda Prompt or Command Prompt:

    cd /d "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6D\20260913T195357Z\application\late_clock_followup_v1"
    "C:\Users\amiri\anaconda3\python.exe" Analyze.py

For a repeat, copy this directory's two source files into a fresh sibling directory under application, then run there. Requires Python standard library and the existing psutil package solely to constrain CPU affinity. No GPU, USB, network or exclusive inference allocation is used. A failed audit raises an exception and retains partial evidence.

Interpretation: publication-minus-cursor is not an exact input-commit timestamp or isolated disk cost. It includes pacing, writes, waits and publication timing. ASR modeled availability is not actual delivery latency. Cursor-relative freshness is descriptive and cannot retroactively qualify rejected calibration. Pointwise clock components and means add; separate medians generally do not. Paired host differences are observational and do not isolate causal naming cost.

Publication and source origin use the saved pilot publication monotonic timestamp when present, matching the accepted host scorer. The later native publication timestamp offset is retained per event. Consumer time is the actual top-level receipt timestamp. PLAN_FAILED_01.json and PLAN_FAILED_02.json preserve two initial schema/clock-convention checks that stopped before any result was written; the final run pins this corrected analyzer.
