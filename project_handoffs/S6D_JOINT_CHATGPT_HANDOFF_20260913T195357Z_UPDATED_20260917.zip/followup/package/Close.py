"""Update local S6D pointers after verified follow-up delivery. See README.md."""
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

D = Path(__file__).resolve().parent
R = D.parent


def bind(path):
    p = Path(path)
    data = p.read_bytes()
    return {"path": str(p), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def check(binding):
    if bind(binding["path"]) != binding:
        raise RuntimeError("Binding changed: " + binding["path"])


def dump(path, value, exclusive=False):
    with Path(path).open("x" if exclusive else "w", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")


def main():
    receipt = json.loads((D / "BUILD_RECEIPT.json").read_bytes())
    for key in ["archive", "external_closure", "original_archive_preserved", "original_closure_preserved", "master_unchanged"]:
        check(receipt[key])
    if (D / "CURRENT_POINTER_UPDATE.json").exists():
        raise RuntimeError("Current pointers already updated")
    now = datetime.now(timezone.utc)
    backup = R / "progress" / ("current_documents_before_followup_" + now.strftime("%Y%m%dT%H%M%SZ"))
    backup.mkdir()
    names = ["S6D_CHECKPOINT.json", "CONTINUE_S6D.md", "S6D_PHASE_OVERVIEW.md"]
    before = {}
    for name in names:
        path = R / name
        before[name] = bind(path)
        shutil.copyfile(path, backup / name)
        if bind(backup / name)["sha256"] != before[name]["sha256"]:
            raise RuntimeError("Backup mismatch")
    checkpoint = json.loads((R / names[0]).read_bytes())
    if checkpoint.get("whole_study_complete") is not True:
        raise RuntimeError("Expected already complete S6D")
    checkpoint["original_final_delivery"] = checkpoint["final_delivery"]
    checkpoint["final_delivery"] = receipt["external_closure"]
    checkpoint["updated_utc"] = now.isoformat()
    checkpoint["current_work"] = "S6D and requested saved-data follow-up complete; revised handoff delivered. No further S6D compute pending."
    checkpoint["late_followup"] = {
        "status": "COMPLETE", "archive": receipt["archive"], "members": receipt["members"],
        "results": receipt["followup_results"], "build_receipt": bind(D / "BUILD_RECEIPT.json"),
        "no_new_phase_started": True, "no_model_or_hardware_runs": True, "backup": str(backup)}
    dump(R / names[0], checkpoint)
    old_zip = receipt["original_archive_preserved"]["path"]
    old_closure = receipt["original_closure_preserved"]["path"]
    new_zip = receipt["archive"]["path"]
    new_closure = receipt["external_closure"]["path"]
    old_report = str(R / "handoff_final_v2/package/S6D_REPORT.md")
    new_report = str(D / "package/S6D_REPORT.md")
    notice = (
        "\nSaved-data follow-up delivered " + now.isoformat() + ". The revised complete handoff adds "
        "18-log clock decomposition, all-960-job label stability and scene-omission lexical robustness. "
        "Read " + str(D / "package/LATE_FOLLOWUP_FINDINGS.md") + " and "
        + str(D / "package/NEXT_PHASE_PIPELINE_PRIORITIES.md") + ". "
        "No new models/hardware, default changes or next-phase execution. Original delivery remains preserved "
        "in the follow-up receipt. No computation remains pending.\n\n"
    )
    for name in names[1:]:
        text = (backup / name).read_text(encoding="utf-8")
        text = text.replace(old_zip, new_zip).replace(old_closure, new_closure).replace(old_report, new_report)
        text = text.replace(receipt["original_archive_preserved"]["sha256"], receipt["archive"]["sha256"])
        text = text.replace("50/50members verified", f"{receipt['members']}/{receipt['members']}members verified")
        text = text.replace("487458bytes", str(receipt["archive"]["bytes"]) + "bytes")
        heading, rest = text.split("\n", 1)
        text = heading + "\n" + notice + rest.lstrip("\n")
        (R / name).write_text(text, encoding="utf-8")
    after = {name: bind(R / name) for name in names}
    dump(D / "CURRENT_POINTER_UPDATE.json", {
        "status": "COMPLETE_CURRENT_POINTERS_UPDATED", "utc": now.isoformat(),
        "before": before, "backup": str(backup), "after": after,
        "external_closure": receipt["external_closure"],
        "scientific_results_changed": False, "whole_study_complete": True,
        "automation_started": False, "models_or_hardware_started": 0}, exclusive=True)
    print(json.dumps({"status": "COMPLETE_CURRENT_POINTERS_UPDATED", "backup": str(backup)}, indent=2))


if __name__ == "__main__":
    main()
