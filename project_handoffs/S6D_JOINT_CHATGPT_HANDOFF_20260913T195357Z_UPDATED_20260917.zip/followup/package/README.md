# Build the S6D handoff follow-up

Purpose: create a complete revised compact handoff with the finished clock, label-stability and lexical-concentration analyses while preserving the original delivered ZIP and closure.

Inputs: the original 50-member S6D ZIP, its delivery closure, unchanged V20 Word master, both completed late-analysis directories and the two authored Markdown documents here. All original member hashes and included analysis output bindings are checked. Outputs: package/, the new UPDATED_20260917.zip, its external DELIVERY_CLOSURE.json and BUILD_RECEIPT.json. The package contains reference copies of analysis code; use each original local analysis directory and its README to rerun, not an arbitrary extracted location.

Build once from PowerShell:

    Set-Location -LiteralPath 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6D\20260913T195357Z\handoff_followup_v1'
    & 'C:\Users\amiri\anaconda3\python.exe' .\Build.py

Build once from Anaconda Prompt or Command Prompt:

    cd /d "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6D\20260913T195357Z\handoff_followup_v1"
    "C:\Users\amiri\anaconda3\python.exe" Build.py

No arguments are needed. Python standard library only. Existing output paths are refused. This script does not rerun experiments, load models, use audio hardware, change defaults, write the master Word document, restart an automation or modify current checkpoint documents. A separate Close.py updates current local pointers only after the archive has been verified.

After review, update the current pointers once:

    & 'C:\Users\amiri\anaconda3\python.exe' .\Close.py

For Anaconda Prompt / Command Prompt:

    "C:\Users\amiri\anaconda3\python.exe" Close.py

Close.py inputs are BUILD_RECEIPT.json, the verified external closure and the three existing current status documents. It backs up those documents to a fresh progress directory, then adds the revised handoff pointer while retaining the original delivery reference. Output is CURRENT_POINTER_UPDATE.json with before/after bindings. It does not change scientific metrics or S6D completion status.

Validation includes ZIP CRC, every member SHA256, every JSON parse, original archive/closure hashes, unchanged master workbook and storage floors C >= 50 GiB / G >= 75 GiB. The revised package must remain under 80 members and 10 MiB compressed, with no audio payloads. Failed attempts remain inspectable; prepare a fresh namespace for a revision.
