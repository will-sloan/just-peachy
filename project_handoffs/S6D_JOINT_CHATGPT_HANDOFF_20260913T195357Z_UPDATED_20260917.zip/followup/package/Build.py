"""Create and verify a new S6D follow-up handoff. See README.md."""
import hashlib
import json
import shutil
import zipfile
from datetime import datetime, timezone
from pathlib import Path

D = Path(__file__).resolve().parent
R = D.parent
SIM = R.parents[2]
OLD = SIM / "handoffs/S6D_JOINT_CHATGPT_HANDOFF_20260913T195357Z.zip"
OLD_CLOSURE = OLD.with_name(OLD.stem + "_DELIVERY_CLOSURE.json")
ZIP = OLD.with_name(OLD.stem + "_UPDATED_20260917.zip")
OUT = D / "package"
CLOCK = R / "application/late_clock_followup_v1"
META = R / "application/late_followup_independent_v1"


def need(ok, why):
    if not ok:
        raise RuntimeError(why)


def read(path):
    return json.loads(Path(path).read_bytes())


def blob(obj):
    return (json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def bind(path):
    p = Path(path)
    before = p.stat()
    value = sha(p.read_bytes())
    after = p.stat()
    need((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns), "Source changed")
    return {"path": str(p), "bytes": after.st_size, "sha256": value}


def check(binding):
    actual = bind(binding["path"])
    need(actual["sha256"] == binding["sha256"] and actual["bytes"] == binding["bytes"],
         "Binding mismatch: " + actual["path"])
    return actual


def write_new(path, data):
    with Path(path).open("xb") as stream:
        stream.write(data)


def main():
    need(not OUT.exists() and not ZIP.exists(), "Fresh output paths required")
    free = {v: shutil.disk_usage(v + ":/").free / 2**30 for v in ["C", "G"]}
    need(free["C"] >= 50 and free["G"] >= 75, "Storage floor")
    old = bind(OLD)
    need(old["sha256"] == "ae51182f9fa12e54c762e12f30218dbc6f83cb9fc8893f71b69715fc2ae5963f", "Original ZIP changed")
    old_closure = bind(OLD_CLOSURE)
    need(old_closure["sha256"] == "f7e8228c192a0c922552455838452a40c08544c9dd4c2418ba43ca3f637ab77c", "Original closure changed")
    master = bind(Path("C:/Users/amiri/Downloads/XVF_Measurement_V20.docx"))
    need(master["sha256"] == "f84fabaa874b5527c4231e4553f8fd13b0beee5ea46a5c11979fc9e6ecb09f21", "Master changed")
    clock = read(CLOCK / "RESULT.json")
    meta = read(META / "run_01/RESULT.json")
    need(clock["status"] == "COMPLETE_SAVED_CLOCK_FOLLOWUP" and clock["jobs"] == 18
         and clock["unique_C_events"] == 1296, "Clock population")
    need(meta["status"] == "COMPLETE_SAVED_METADATA_ONLY_FOLLOWUP", "Metadata incomplete")
    for b in clock["outputs"]:
        check(b)
    check(clock["plan"])
    plan = read(CLOCK / "PLAN.json")
    check(plan["script"])
    check(plan["readme"])
    for b in read(META / "run_01/CHECKSUMS.json")["files"]:
        check(b)
    for b in meta["source_bindings"]:
        check(b)
    with zipfile.ZipFile(OLD) as z:
        need(z.testzip() is None and len(z.namelist()) == 50 and len(set(z.namelist())) == 50, "Original archive readback")
        members = {name: z.read(name) for name in z.namelist()}
    old_members = {k: sha(v) for k, v in members.items()}
    checks = json.loads(members["CHECKSUMS.json"])["members"]
    need(set(checks) == set(members) - {"CHECKSUMS.json"}
         and all(sha(members[k]) == v for k, v in checks.items()), "Original member checksum")
    sources = {}
    def include(name, path):
        need(name not in members, "Unexpected member replacement")
        binding = bind(path)
        data = Path(path).read_bytes()
        need(sha(data) == binding["sha256"], "Included source changed")
        members[name] = data
        sources[name] = binding
    for name in ["LATE_FOLLOWUP_FINDINGS.md", "NEXT_PHASE_PIPELINE_PRIORITIES.md"]:
        include(name, D / name)
    for name in ["Analyze.py", "README.md", "PLAN.json", "RESULT.json", "PER_JOB_CLOCKS.json",
                 "HOST105_PAIRED_CLOCKS.json", "CLOCK_SUMMARY.csv"]:
        include("followup/clock/" + name, CLOCK / name)
    for name in ["Analyze.py", "README.md"]:
        include("followup/metadata/" + name, META / name)
    for path in sorted((META / "run_01").iterdir()):
        if path.is_file():
            include("followup/metadata/" + path.name, path)
    include("followup/package/Build.py", D / "Build.py")
    include("followup/package/README.md", D / "README.md")
    include("followup/package/Close.py", D / "Close.py")
    update = (
        "Updated 17 September 2026: read LATE_FOLLOWUP_FINDINGS.md and "
        "NEXT_PHASE_PIPELINE_PRIORITIES.md before interpreting the original measured results below. "
        "The added 18-log clock audit distinguishes source-progress discrepancy from evidence backlog "
        "and consumer delivery; it does not establish causal naming/model cost or reverse failed freshness gates. "
        "The 960-job label audit and scene-omission beam analysis add stability and robustness evidence. "
        "No default, waveform, model or gate changed. The original delivered ZIP remains preserved. "
        "Use the UPDATED_20260917_DELIVERY_CLOSURE.json external receipt for this revision.\n\n"
    )
    for name in ["START_HERE.md", "S6D_REPORT.md", "WORKBOOK_UPDATE.md"]:
        old_text = members[name].decode("utf-8")
        first, rest = old_text.split("\n", 1)
        members[name] = (first + "\n\n" + update + rest.lstrip("\n")).encode("utf-8")
    result_bindings = {"late_clocks": bind(CLOCK / "RESULT.json"),
                       "late_stability_and_lexical": bind(META / "run_01/RESULT.json")}
    for name, key in [("FINAL_METRICS_INDEX.json", "evidence"), ("LOCAL_ARTIFACT_INDEX.json", "artifacts")]:
        data = json.loads(members[name])
        data[key].update(result_bindings)
        members[name] = blob(data)
    inventory = json.loads(members["CHANGED_CODE_INVENTORY.json"])
    inventory["late_followup_metadata_only"] = {k: v for k, v in sources.items()
                                               if k.endswith((".py", "README.md"))}
    members["CHANGED_CODE_INVENTORY.json"] = blob(inventory)
    scope = json.loads(members["PACKAGE_SCOPE.json"])
    scope["late_followup"] = {"utc": datetime.now(timezone.utc).isoformat(), "model_calls": 0, "hardware_calls": 0,
                             "prior_archive_preserved": old, "results": result_bindings,
                             "current_receipt": ZIP.stem + "_DELIVERY_CLOSURE.json"}
    members["PACKAGE_SCOPE.json"] = blob(scope)
    members["FOLLOWUP_PROVENANCE.json"] = blob({
        "original_archive": old, "original_closure": old_closure, "master_unchanged": master,
        "added_sources": sources, "results": result_bindings,
        "original_member_sha256": old_members,
        "changed_original_members": [k for k in old_members if sha(members[k]) != old_members[k] and k != "CHECKSUMS.json"],
        "scope": "Measured metrics untouched; report framing, indices and new saved-data evidence added.",
        "automation": bind(R / "handoff_final_v2/AUTOMATION_CLOSURE.json"),
    })
    members["CHECKSUMS.json"] = blob({"algorithm": "sha256", "excludes_self": True,
                                     "members": {k: sha(v) for k, v in sorted(members.items()) if k != "CHECKSUMS.json"}})
    need(len(members) <= 80 and all(not n.lower().endswith((".wav", ".pcm16", ".docx")) for n in members), "Compact metadata only")
    OUT.mkdir()
    for name, data in members.items():
        path = OUT / name
        path.parent.mkdir(parents=True, exist_ok=True)
        write_new(path, data)
    with zipfile.ZipFile(ZIP, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name in sorted(members):
            z.writestr(name, members[name])
    with zipfile.ZipFile(ZIP) as z:
        need(z.testzip() is None and set(z.namelist()) == set(members), "ZIP CRC/member readback")
        for name, expected in json.loads(z.read("CHECKSUMS.json"))["members"].items():
            actual = z.read(name)
            need(sha(actual) == expected, "ZIP hash: " + name)
            if name.endswith(".json"):
                json.loads(actual)
    archive = bind(ZIP)
    need(archive["bytes"] <= 10 * 2**20, "Compact size target")
    check(old)
    check(old_closure)
    check(master)
    receipt = {
        "status": "S6D_COMPLETE_WITH_VERIFIED_SAVED_DATA_FOLLOWUP",
        "utc": datetime.now(timezone.utc).isoformat(), "archive": archive,
        "members": len(members), "uncompressed_bytes": sum(len(x) for x in members.values()),
        "CRC_passed": True, "all_member_hashes_verified": True, "all_JSON_parsed": True,
        "original_archive_preserved": old, "original_closure_preserved": old_closure,
        "master_unchanged": master, "followup_results": result_bindings,
        "build_source": bind(__file__), "readme": bind(D / "README.md"),
        "storage_free_GiB": free, "model_calls": 0, "hardware_calls": 0,
        "application_default_gate_or_gallery_changes": False, "S6D_compute_remaining": 0,
        "automation_restarted": False, "new_phase_started": False,
        "scientific_limits": "Original adverse/unavailable results retained; see LATE_FOLLOWUP_FINDINGS.md."
    }
    closure = ZIP.with_name(ZIP.stem + "_DELIVERY_CLOSURE.json")
    write_new(closure, blob(receipt))
    receipt["external_closure"] = bind(closure)
    write_new(D / "BUILD_RECEIPT.json", blob(receipt))
    print(json.dumps({"archive": archive, "members": len(members), "external_closure": receipt["external_closure"],
                      "storage_free_GiB": free}, indent=2))


if __name__ == "__main__":
    main()
