# Saved-data follow-up findings

This adds descriptive evidence without changing the S6D handoff, models, application, policies or captures.

## Lexical concentration

| Pass / candidate | Extra / lost tokens | Gain scenes | Top3 scene gains | Leave-one-scene-out net range |
|---|---:|---:|---:|---:|
| P_MAIN6 / focus0_asr_raw | 10 / 50 | 7/31 | 6 | -42 to -31 |
| P_MAIN6 / focus1_asr_raw | 14 / 24 | 7/31 | 10 | -13 to -1 |
| P_SCAN6 / focus0_asr_raw | 13 / 22 | 8/31 | 8 | -12 to -4 |
| P_SCAN6 / focus1_asr_raw | 11 / 33 | 8/31 | 6 | -25 to -12 |
| P_SCAN6 / scan_asr_raw | 15 / 6 | 9/31 | 8 | 6 to 10 |

All five contrasts retain the same63 actor-scene rows /31 scenes /881 actor-exclusive reference tokens. Contribution tables include losses, zero gains, actor totals and every leave-one-scene-out result. Redundancy uses count-bounded intersections within each pass, never a stitched transcript.

## Online label activity

All960 jobs verified; 2642 latest transcript rows, including 38 jobs with no rows. Ongoing label changes total 6826 across 2373 rows; separately bounded revisions total 1450 across 1073 rows. 1412 rows have ongoing changes while revision_count is zero.

| Comparison | Same | Different | Eligible |
|---|---:|---:|---:|
| first_to_final_display | 254 | 710 | 964 |
| final_to_latest_display | 1665 | 29 | 1694 |
| first_to_latest_display | 252 | 733 | 985 |
| first_to_latest_explicit_anonymous | 310 | 854 | 1164 |

Numbered anonymous endpoints are compared only within one saved utterance. Missing, Unknown, named and unavailable-final endpoints remain explicit. Counters measure separate source-defined update mechanisms, not proven wrong-speaker switches or actual Tk exposure.

## Initial text versus final text

- LAST_INITIAL_TOKEN_EXTENDED: 584
- PREFIX_GROWTH: 2032
- SAME_TOKEN_SEQUENCE: 26

These are token-prefix classifications, not WER. Partial-token completion is separate; same-start and nested spans are required. Initial text can differ from final text without either being correct. Intermediate revisions and word times are not inferred.

## Limits

- Descriptive saved-data analysis; no models, hardware, policy replay, selector fitting, Q threshold fitting or default change.
- Lexical opportunities are actor-exclusive token-type/count evidence, not acoustic origin, source separation, time localization or a deployable stitched transcript.
- MAIN and SCAN remain separate physical passes. Their candidate redundancy is measured only within each pass. Actor rows and four native cells per scene are not independent trials.
- ongoing_display_label_changes counts changes on subsequent ASR observations; revision_count counts separately bounded reconciliation. Either can concern names or Unknown, and neither proves a wrong-person change.
- Anonymous label comparison requires numbered Speaker_N values on both endpoints of the same utterance; Unknown, named labels, absent/null fields and missing final timestamps remain explicit exclusions. No first-final anonymous identity is invented when first_final_label is a name.
- Headless saved scheduler labels are not actual Tk exposure. Final label equality cannot establish stable intermediate labels, correct identity or useful diarization.
- Initial-prefix differences use punctuation-insensitive casefolded word tokens, not WER or correctness. Growing first spans are not scored as missing future words. Partial final-token extension is separated. Intermediate text revisions are not reconstructed.
- No ambiguity, incomplete-reference or scoring-disallowed native rows are removed. Those strata remain descriptive and cannot establish reference-conditioned correctness.
