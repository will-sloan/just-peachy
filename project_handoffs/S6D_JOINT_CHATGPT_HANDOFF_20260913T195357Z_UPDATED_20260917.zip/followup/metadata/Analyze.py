"""Bounded metadata-only follow-up. See README.md for commands and interpretation."""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import hashlib
import itertools
import json
import math
from pathlib import Path
import re
import time

R = Path(__file__).resolve().parents[2]
LEX = R / 'application/beam_remaining_diagnostics_v1/ACTOR_LEXICAL_OPPORTUNITIES.json'
CELLS = R / 'application/native960_assembly_v1/run_01/CELLS960.json'
PINS = {LEX: 'dfce360d9a44a12f9d6947b4b6c008c355e4e411e08d9b15ed719e557c806808',
        CELLS: '88bef9a88ce3ddec3f4935d7d65525f54507607d6c17adfc175b563e897b7f13'}
STRATA = ('candidate', 'tap', 'family', 'split', 'room', 'has_overlap', 'complete_reference', 'scoring_allowed', 'provenance')
PAIRS = {'first_to_final_display': ('first_display_label', 'first_final_label'),
         'final_to_latest_display': ('first_final_label', 'latest_label'),
         'first_to_latest_display': ('first_display_label', 'latest_label'),
         'first_to_latest_explicit_anonymous': ('first_anonymous_label', 'latest_anonymous_label')}
LABELS = sorted({f for pair in PAIRS.values() for f in pair})
LIMITS = [
    'Descriptive saved-data analysis; no models, hardware, policy replay, selector fitting, Q threshold fitting or default change.',
    'Lexical opportunities are actor-exclusive token-type/count evidence, not acoustic origin, source separation, time localization or a deployable stitched transcript.',
    'MAIN and SCAN remain separate physical passes. Their candidate redundancy is measured only within each pass. Actor rows and four native cells per scene are not independent trials.',
    'ongoing_display_label_changes counts changes on subsequent ASR observations; revision_count counts separately bounded reconciliation. Either can concern names or Unknown, and neither proves a wrong-person change.',
    'Anonymous label comparison requires numbered Speaker_N values on both endpoints of the same utterance; Unknown, named labels, absent/null fields and missing final timestamps remain explicit exclusions. No first-final anonymous identity is invented when first_final_label is a name.',
    'Headless saved scheduler labels are not actual Tk exposure. Final label equality cannot establish stable intermediate labels, correct identity or useful diarization.',
    'Initial-prefix differences use punctuation-insensitive casefolded word tokens, not WER or correctness. Growing first spans are not scored as missing future words. Partial final-token extension is separated. Intermediate text revisions are not reconstructed.',
    'No ambiguity, incomplete-reference or scoring-disallowed native rows are removed. Those strata remain descriptive and cannot establish reference-conditioned correctness.'
]

def require(ok, message):
    if not ok:
        raise ValueError(message)

def binding(path, raw=None):
    path = Path(path)
    raw = path.read_bytes() if raw is None else raw
    return {'path': str(path.resolve()), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def read_bound(ref, limit=16 * 1024 * 1024):
    path = Path(ref['path'])
    require(path.stat().st_size <= limit, f'Unexpected metadata size: {path}')
    raw = path.read_bytes()
    actual = binding(path, raw)
    require(actual['bytes'] == ref['bytes'] and actual['sha256'] == ref['sha256'], f'Binding mismatch: {path}')
    return raw, actual

def pinned(path):
    raw = path.read_bytes()
    ref = binding(path, raw)
    require(ref['sha256'] == PINS[path], f'Pinned authority changed: {path}')
    return json.loads(raw), ref

def integer(value):
    return type(value) is int and value >= 0

def number(value):
    return type(value) in (int, float) and math.isfinite(value)

def field_state(row, field):
    if field not in row:
        return 'MISSING'
    if row[field] is None:
        return 'NULL'
    return 'VALID' if integer(row[field]) else 'INVALID'

def label_kind(value):
    if value is None:
        return 'NULL'
    if not isinstance(value, str):
        return 'INVALID'
    if re.fullmatch(r'Speaker_[0-9]+', value):
        return 'NUMBERED_ANONYMOUS'
    if value in ('Unknown', 'Speaker_?', ''):
        return 'UNKNOWN_OR_EMPTY'
    return 'OTHER_DISPLAY_LABEL'

def compare(row, left, right):
    for field in (left, right):
        if field not in row:
            return 'EXCLUDED_MISSING_FIELD'
        if label_kind(row[field]) != 'NUMBERED_ANONYMOUS':
            return 'EXCLUDED_NON_NUMBERED_ENDPOINT'
    if 'first_final_label' in (left, right) and not number(row.get('first_final_time')):
        return 'EXCLUDED_NO_FINAL_TIME'
    return 'SAME' if row[left] == row[right] else 'DIFFERENT'

def tokens(text):
    return re.findall(r'[^\W_]+', text.casefold(), flags=re.UNICODE)

def prefix(first, final):
    a, b = tokens(first), tokens(final)
    if not a:
        return 'EMPTY_INITIAL', 0, 0
    common = 0
    for left, right in zip(a, b):
        if left != right:
            break
        common += 1
    if common == len(a):
        return ('SAME_TOKEN_SEQUENCE' if len(a) == len(b) else 'PREFIX_GROWTH'), common, 0
    if common == len(a) - 1 and len(b) > common and b[common].startswith(a[-1]):
        return 'LAST_INITIAL_TOKEN_EXTENDED', common, 1
    return 'INITIAL_NOT_FINAL_PREFIX', common, len(a) - common

def csv_write(path, rows):
    fields = list(dict.fromkeys(k for row in rows for k in row))
    with path.open('x', encoding='utf-8', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False, sort_keys=True) if isinstance(v, (dict, list)) else v for k, v in row.items()})

def save(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2, allow_nan=False)
        handle.write('\n')

def counts(rows):
    keys = ('actor_exclusive_reference_tokens', 'candidate_extra_reference_tokens', 'candidate_lost_reference_tokens')
    result = {key: sum(row[key] for row in rows) for key in keys}
    result['net_tokens'] = result[keys[1]] - result[keys[2]]
    result['net_per_reference_token'] = result['net_tokens'] / result[keys[0]] if result[keys[0]] else None
    return result

def lexical(data, metadata):
    rows = data['rows']
    require(len(rows) == 315, 'Expected five contrasts by 63 actor-scene rows')
    seen = set()
    grouped = defaultdict(list)
    for row in rows:
        key = (row['capture_profile'], row['stream'], row['case_id'], row['actor'])
        require(key not in seen, 'Duplicate lexical row'); seen.add(key)
        require(row['case_id'] in metadata, 'Unknown scene')
        for measure in ('actor_exclusive_reference_tokens', 'candidate_extra_reference_tokens', 'candidate_lost_reference_tokens'):
            require(integer(row[measure]), 'Invalid lexical count')
        for field, measure in [('extra_tokens', 'candidate_extra_reference_tokens'), ('lost_tokens', 'candidate_lost_reference_tokens')]:
            require(all(integer(v) for v in row[field].values()), 'Invalid token count')
            require(sum(row[field].values()) == row[measure], 'Token/count mismatch')
        grouped[key[:2]].append(row)
    require(len(grouped) == 5 and all(len(x) == 63 for x in grouped.values()), 'Contrast population changed')
    summaries, contributions, loso, cases, redundancy = [], [], [], [], []
    common_population = None
    for (profile, stream), group in sorted(grouped.items()):
        population = {(x['case_id'], x['actor']) for x in group}
        if common_population is None:
            common_population = population
        require(common_population == population, 'Actor-scene population differs')
        total = counts(group)
        summary = {'capture_profile': profile, 'stream': stream, 'actor_scene_rows': len(group), 'scenes': len({x['case_id'] for x in group}), **total}
        for axis in ('case_id', 'actor'):
            units = defaultdict(list)
            for row in group:
                units[row[axis]].append(row)
            unit_counts = [(key, counts(value)) for key, value in sorted(units.items())]
            for key, value in unit_counts:
                contributions.append({'capture_profile': profile, 'stream': stream, 'axis': axis, 'unit': key, **value,
                    'share_of_all_extra_tokens': value['candidate_extra_reference_tokens'] / total['candidate_extra_reference_tokens'] if total['candidate_extra_reference_tokens'] else None,
                    'share_of_all_lost_tokens': value['candidate_lost_reference_tokens'] / total['candidate_lost_reference_tokens'] if total['candidate_lost_reference_tokens'] else None})
                if axis == 'case_id':
                    cases.append({'capture_profile': profile, 'stream': stream, 'case_id': key, **metadata[key], **value})
                    loso.append({'capture_profile': profile, 'stream': stream, 'excluded_case_id': key, 'remaining_scenes': len(units) - 1, **counts([x for x in group if x['case_id'] != key])})
            extras = sorted((v['candidate_extra_reference_tokens'] for _, v in unit_counts), reverse=True)
            losses = sorted((v['candidate_lost_reference_tokens'] for _, v in unit_counts), reverse=True)
            summary[axis + '_concentration'] = {'units': len(units), 'units_with_extra': sum(x > 0 for x in extras), 'units_with_loss': sum(x > 0 for x in losses),
                'top1_extra': sum(extras[:1]), 'top3_extra': sum(extras[:3]), 'top1_loss': sum(losses[:1]), 'top3_loss': sum(losses[:3])}
        leave = [x for x in loso if x['capture_profile'] == profile and x['stream'] == stream]
        summary['leave_one_scene_out'] = {'n': len(leave), 'min_net_tokens': min(x['net_tokens'] for x in leave), 'max_net_tokens': max(x['net_tokens'] for x in leave),
            'min_net_per_reference_token': min(x['net_per_reference_token'] for x in leave), 'max_net_per_reference_token': max(x['net_per_reference_token'] for x in leave),
            'positive': sum(x['net_tokens'] > 0 for x in leave), 'zero': sum(x['net_tokens'] == 0 for x in leave), 'negative': sum(x['net_tokens'] < 0 for x in leave)}
        summaries.append(summary)
    for profile in sorted({key[0] for key in grouped}):
        streams = sorted(key[1] for key in grouped if key[0] == profile)
        for left, right in itertools.combinations(streams, 2):
            for field in ('extra_tokens', 'lost_tokens'):
                maps = []
                for stream in (left, right):
                    maps.append(Counter({(row['case_id'], row['actor'], token): n for row in grouped[(profile, stream)] for token, n in row[field].items()}))
                a, b = maps
                overlap = sum((a & b).values())
                redundancy.append({'capture_profile': profile, 'left': left, 'right': right, 'measure': field,
                    'left_total': sum(a.values()), 'right_total': sum(b.values()), 'shared_count_bounded': overlap,
                    'left_exclusive': sum((a-b).values()), 'right_exclusive': sum((b-a).values()), 'union_count_bounded': sum((a|b).values()),
                    'interpretation': 'Counter min/max on identical case, actor and token type; not aligned token occurrences or a merged transcript.'})
    return {'contrasts': summaries, 'redundancy': redundancy, 'eligible_actor_scene_rows_per_contrast': 63, 'source_eligibility': data['eligibility']}, contributions, loso, cases

def native(cells, output):
    grouped = defaultdict(Counter)
    rows, case_rows, bindings = [], [], []
    schemas = Counter()
    for index, cell in enumerate(cells):
        raw, score_ref = read_bound(cell['score_ref'])
        score = json.loads(raw)
        require(score['job_id'] == cell['job_id'], 'Score/job mismatch')
        require(score['schema'] == 's6d-native-correctness.v1', 'Unknown score schema')
        raw, latest_ref = read_bound(score['inputs']['latest'], 4 * 1024 * 1024)
        latest = [json.loads(line) for line in raw.decode('utf-8-sig').splitlines() if line.strip()]
        ids = [x['utterance_id'] for x in latest]
        require(len(set(ids)) == len(ids), 'Duplicate latest utterance ID')
        first_rows = score['names']['first_text_rows']
        require(len({x['utterance_id'] for x in first_rows}) == len(first_rows), 'Duplicate first text ID')
        first = {x['utterance_id']: x for x in first_rows}
        final_names = {x['utterance_id']: x for x in score.get('final_name_rows', [])}
        current = Counter({'jobs': 1, 'rows': 0, 'first_text_rows_without_latest': len(set(first)-set(ids))})
        strata = [('all', 'ALL')] + [(key, str(cell.get(key, 'MISSING'))) for key in STRATA] + [('candidate_tap', cell['candidate'] + '/' + cell['tap'])]
        for axis, key in strata:
            grouped[(axis, key)]['jobs'] += 1
            grouped[(axis, key)]['first_text_rows_without_latest'] += current['first_text_rows_without_latest']
        for row in latest:
            schemas[row.get('schema_version', 'MISSING')] += 1
            require(row.get('schema_version') == 'edge-latest-labelled-transcript.v3', 'Unknown latest schema')
            record = {key: cell.get(key) for key in ('job_id', 'scene_id', *STRATA)}
            record.update(utterance_id=row['utterance_id'], source_start_sec=row.get('source_start_sec'), source_end_sec=row.get('source_end_sec'),
                          is_final=row.get('is_final'), final_reference_status=final_names.get(row['utterance_id'], {}).get('reference_status', 'NOT_IN_CONDITIONED_FINAL_NAME_ROWS'))
            increments = Counter({'rows': 1})
            for field in ('ongoing_display_label_changes', 'revision_count'):
                state = field_state(row, field)
                record[field] = row.get(field)
                record[field + '_state'] = state
                increments[field + '_' + state] += 1
                if state == 'VALID':
                    increments[field + '_total'] += row[field]
                    increments[field + '_positive_rows'] += int(row[field] > 0)
            if all(record[f + '_state'] == 'VALID' for f in ('ongoing_display_label_changes', 'revision_count')):
                increments['both_counters_valid'] += 1
                increments['ongoing_positive_revision_zero'] += int(row['ongoing_display_label_changes'] > 0 and row['revision_count'] == 0)
                increments['both_counters_positive'] += int(row['ongoing_display_label_changes'] > 0 and row['revision_count'] > 0)
            for field in LABELS:
                record[field] = row.get(field)
                state = label_kind(row[field]) if field in row else 'MISSING'
                record[field + '_kind'] = state
                increments[field + '_' + state] += 1
            for name, (left, right) in PAIRS.items():
                status = compare(row, left, right)
                record[name] = status
                increments[name + '_' + status] += 1
            initial = first.get(row['utterance_id'])
            if initial is None:
                pstatus = 'NO_FIRST_TEXT_ROW'
            elif not isinstance(initial.get('raw_text'), str) or not isinstance(row.get('text'), str):
                pstatus = 'MISSING_TEXT'
            elif row.get('is_final') is not True:
                pstatus = 'NOT_FINAL'
            elif not all(number(x) for x in (initial.get('source_start_sec'), initial.get('source_end_sec'), row.get('source_start_sec'), row.get('source_end_sec'))):
                pstatus = 'MISSING_SPAN'
            elif abs(initial['source_start_sec'] - row['source_start_sec']) > 1/16000 or initial['source_end_sec'] > row['source_end_sec'] + 1/16000:
                pstatus = 'CHANGED_OR_NON_NESTED_SPAN'
            else:
                pstatus, common, tail = prefix(initial['raw_text'], row['text'])
                record.update(initial_words=len(tokens(initial['raw_text'])), final_words=len(tokens(row['text'])), initial_common_prefix_words=common, initial_suffix_outside_common_prefix=tail)
            record['initial_prefix_status'] = pstatus
            record['first_reference_status'] = initial.get('reference_status', 'MISSING') if initial else 'NO_FIRST_TEXT_ROW'
            increments['prefix_' + pstatus] += 1
            rows.append(record)
            current.update(increments)
            for axis, key in strata:
                grouped[(axis, key)].update(increments)
        case_rows.append({key: cell.get(key) for key in ('job_id', 'scene_id', *STRATA)} | dict(current))
        bindings.append({'job_id': cell['job_id'], 'score': score_ref, 'latest': latest_ref, 'latest_rows': len(latest)})
        if (index + 1) % 240 == 0:
            print(f'verified metadata {index+1}/960', flush=True)
    csv_write(output / 'NATIVE_ROWS.csv', rows)
    csv_write(output / 'NATIVE_CASES.csv', case_rows)
    save(output / 'NATIVE_INPUT_BINDINGS.json', bindings)
    aggregate = [{'axis': a, 'stratum': b, **dict(count)} for (a,b), count in sorted(grouped.items())]
    csv_write(output / 'NATIVE_STRATA.csv', aggregate)
    save(output / 'NATIVE_STRATA.json', aggregate)
    return {'jobs': len(cells), 'rows': len(rows), 'schemas': dict(schemas), 'overall': dict(grouped[('all', 'ALL')]),
            'candidate_tap': [x for x in aggregate if x['axis'] == 'candidate_tap'],
            'empty_latest_jobs': sum(x['rows'] == 0 for x in case_rows),
            'counter_semantics': 'Separate ongoing ASR-display label changes and bounded reconciliation, which may occur during active text or after final. Neither is a text revision count or proof of incorrect identity.'}

def self_check():
    require(not integer(True) and not integer(-1) and integer(0), 'Counter guard')
    require(compare({'first_display_label':'Speaker_1','first_final_label':'Alice','first_final_time':1}, 'first_display_label','first_final_label').startswith('EXCLUDED'), 'Named label exclusion')
    require(compare({'first_display_label':'Speaker_1','first_final_label':'Speaker_2','first_final_time':1}, 'first_display_label','first_final_label') == 'DIFFERENT', 'Anonymous transition')
    require(prefix('HELLO', 'Hello world')[0] == 'PREFIX_GROWTH', 'Prefix growth')
    require(prefix('I recog', 'I recognize this')[0] == 'LAST_INITIAL_TOKEN_EXTENDED', 'Token completion')
    require(prefix('Hello all', 'Hello world')[0] == 'INITIAL_NOT_FINAL_PREFIX', 'Prefix withdrawal')
    a,b = Counter({'x':2,'y':1}),Counter({'x':1,'z':3})
    require(sum((a&b).values()) == 1 and sum((a|b).values()) == 6, 'Count-bounded redundancy')
    return {'status': 'PASS', 'checks': 7, 'scope': 'Small arithmetic/semantic guards only; no original suite or runtime calls.'}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True, help='Fresh output directory; refuses overwrite')
    args = parser.parse_args()
    start = time.monotonic()
    require(not args.output.exists(), 'Output must be fresh')
    args.output.mkdir(parents=True)
    checks = self_check()
    cells, cells_ref = pinned(CELLS)
    data, lexical_ref = pinned(LEX)
    require(len(cells) == 960 and len({x['job_id'] for x in cells}) == 960, 'Expected unique 960 jobs')
    require(len({(x['scene_id'], x['candidate'], x['tap']) for x in cells}) == 960, 'Scientific matrix duplicates')
    require({x['candidate'] for x in cells} == {'C065','C088'} and {x['tap'] for x in cells} == {'O0','O1'}, 'Unexpected native conditions')
    metadata = {}
    for cell in cells:
        m = {k: cell[k] for k in ('family','split','room','has_overlap','complete_reference','scoring_allowed')}
        require(cell['scene_id'] not in metadata or metadata[cell['scene_id']] == m, 'Inconsistent scene strata')
        metadata[cell['scene_id']] = m
    require(len(metadata) == 240, 'Expected240 scenes')
    lex, contributions, loso, cases = lexical(data, metadata)
    save(args.output/'LEXICAL_RESULT.json', lex)
    csv_write(args.output/'LEXICAL_CONTRIBUTIONS.csv', contributions)
    csv_write(args.output/'LEXICAL_LEAVE_ONE_SCENE_OUT.csv', loso)
    csv_write(args.output/'LEXICAL_CASES.csv', cases)
    nat = native(cells, args.output)
    sources = [Path(__file__), Path(__file__).with_name('README.md')]
    source_root = R/'source_epochs/application_direction_gui_v3/edge_speech_pipeline'
    sources += [source_root/f for f in ('research_scheduler.py','research_scheduler_v3.py','research_s6d.py')]
    result = {'status':'COMPLETE_SAVED_METADATA_ONLY_FOLLOWUP', 'utc':datetime.now(timezone.utc).isoformat(),
        'source_bindings':[binding(p) for p in sources], 'inputs':{'cells':cells_ref,'lexical':lexical_ref},
        'lexical':lex, 'native':nat, 'self_checks':checks, 'limits':LIMITS,
        'model_calls':0,'hardware_calls':0,'application_changed':False,'prior_reports_changed':False,
        'elapsed_seconds':time.monotonic()-start}
    # Recheck the two small authoritative indexes at the end; each loaded score/latest
    # was checked against its own exact authority before parsing.
    require(binding(CELLS)==cells_ref and binding(LEX)==lexical_ref, 'Authority changed during analysis')
    save(args.output/'RESULT.json', result)
    all_counts = nat['overall']
    lines = ['# Saved-data follow-up findings', '', 'This adds descriptive evidence without changing the S6D handoff, models, application, policies or captures.', '',
        '## Lexical concentration', '', '| Pass / candidate | Extra / lost tokens | Gain scenes | Top3 scene gains | Leave-one-scene-out net range |', '|---|---:|---:|---:|---:|']
    for c in lex['contrasts']:
        s = c['case_id_concentration']; lo = c['leave_one_scene_out']
        lines.append(f"| {c['capture_profile']} / {c['stream']} | {c['candidate_extra_reference_tokens']} / {c['candidate_lost_reference_tokens']} | {s['units_with_extra']}/{s['units']} | {s['top3_extra']} | {lo['min_net_tokens']} to {lo['max_net_tokens']} |")
    lines += ['', 'All five contrasts retain the same63 actor-scene rows /31 scenes /881 actor-exclusive reference tokens. Contribution tables include losses, zero gains, actor totals and every leave-one-scene-out result. Redundancy uses count-bounded intersections within each pass, never a stitched transcript.', '', '## Online label activity', '',
        f"All960 jobs verified; {nat['rows']} latest transcript rows, including {nat['empty_latest_jobs']} jobs with no rows. Ongoing label changes total {all_counts.get('ongoing_display_label_changes_total',0)} across {all_counts.get('ongoing_display_label_changes_positive_rows',0)} rows; separately bounded revisions total {all_counts.get('revision_count_total',0)} across {all_counts.get('revision_count_positive_rows',0)} rows. {all_counts.get('ongoing_positive_revision_zero',0)} rows have ongoing changes while revision_count is zero.", '', '| Comparison | Same | Different | Eligible |', '|---|---:|---:|---:|']
    for name in PAIRS:
        same, different = all_counts.get(name+'_SAME',0), all_counts.get(name+'_DIFFERENT',0)
        lines.append(f'| {name} | {same} | {different} | {same+different} |')
    lines += ['', 'Numbered anonymous endpoints are compared only within one saved utterance. Missing, Unknown, named and unavailable-final endpoints remain explicit. Counters measure separate source-defined update mechanisms, not proven wrong-speaker switches or actual Tk exposure.', '', '## Initial text versus final text', '']
    for key,value in sorted(all_counts.items()):
        if key.startswith('prefix_'):
            lines.append(f'- {key[7:]}: {value}')
    lines += ['', 'These are token-prefix classifications, not WER. Partial-token completion is separate; same-start and nested spans are required. Initial text can differ from final text without either being correct. Intermediate revisions and word times are not inferred.', '', '## Limits', '']
    lines += ['- '+x for x in LIMITS]
    (args.output/'FINDINGS.md').write_text('\n'.join(lines)+'\n', encoding='utf-8')
    save(args.output/'CHECKSUMS.json', {'files':[binding(p) for p in sorted(args.output.iterdir()) if p.is_file()]})
    print(json.dumps({'status':result['status'],'rows':nat['rows'],'seconds':result['elapsed_seconds'],'result':str(args.output/'RESULT.json')}), flush=True)

if __name__ == '__main__':
    main()
