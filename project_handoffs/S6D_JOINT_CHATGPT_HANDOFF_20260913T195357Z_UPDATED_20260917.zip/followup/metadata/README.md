# Saved-data lexical concentration and native label activity

`Analyze.py` performs two bounded, standard-library analyses of existing S6D metadata. It does not import the application, run inference, replay policies, read audio or full event journals, access devices, acquire an exclusive neural-workload allocation, or change the prior handoff. Concurrent read-only metadata analysis was explicitly authorized.

## Inputs

The script locates its S6D report root relative to itself, so keep this folder in its current location.

- `application/beam_remaining_diagnostics_v1/ACTOR_LEXICAL_OPPORTUNITIES.json`, pinned SHA256 `dfce360d9a44a12f9d6947b4b6c008c355e4e411e08d9b15ed719e557c806808`. All five contrasts, each63 actor-scene rows over31 scenes, are retained. Its eligibility table retains all48 panel cases and their exclusions.
- `application/native960_assembly_v1/run_01/CELLS960.json`, pinned SHA256 `88bef9a88ce3ddec3f4935d7d65525f54507607d6c17adfc175b563e897b7f13`. All240 scenes × C065/C088 × O0/O1 are required.
- Each cell's bound score JSON and each score's `inputs.latest` JSONL. Bytes and SHA256 are verified before parsing. No result corpus, audio or event journal scan is needed. Scores are read sequentially; per-file size guards are16MiB for scores and4MiB for latest transcripts.
- Three small frozen source files explain field semantics: `research_scheduler.py`, `research_scheduler_v3.py`, and `research_s6d.py` under `source_epochs/application_direction_gui_v3/edge_speech_pipeline`. Their actual hashes are included in the result; application code is not imported.

The single argument is `--output`, a **fresh** directory. Existing output is refused so a failed or successful epoch cannot be overwritten. A failed run may leave an incomplete directory, preserved for inspection; use a new name for a reviewed retry.

## Outputs

- `RESULT.json`: compact source/input bindings, all five lexical summaries, native totals and candidate/tap summaries, limits, runtime and seven internal arithmetic/semantic checks.
- `LEXICAL_RESULT.json`: scene/actor concentration, leave-one-scene-out ranges and pairwise candidate redundancy. `LEXICAL_CONTRIBUTIONS.csv`, `LEXICAL_CASES.csv`, and `LEXICAL_LEAVE_ONE_SCENE_OUT.csv` preserve every unit and omission sensitivity.
- `NATIVE_ROWS.csv`: one row per actual latest utterance, original labels/counters, explicit missing/null/invalid states, comparisons, source spans, first/final reference status and initial-prefix classification. It does not duplicate transcript text.
- `NATIVE_CASES.csv`: all960 jobs, including jobs with zero transcript rows. `NATIVE_STRATA.json`/`.csv`: separate candidate, tap, family, split, room, overlap, reference completeness, scoring permission, provenance and candidate/tap strata.
- `NATIVE_INPUT_BINDINGS.json`: exact score/latest bindings for every job, including the68 retained credits through the accepted assembly index.
- `FINDINGS.md` and `CHECKSUMS.json`: concise interpretation and exact output bindings. CHECKSUMS excludes itself to avoid a circular digest.

## Run in PowerShell

```powershell
$taskDir = 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6D\20260913T195357Z\application\late_followup_independent_v1'
& 'C:\Users\amiri\anaconda3\python.exe' -B "$taskDir\Analyze.py" --output "$taskDir\run_01"
Get-Content -LiteralPath "$taskDir\run_01\FINDINGS.md"
Get-FileHash -Algorithm SHA256 -LiteralPath "$taskDir\run_01\RESULT.json"
```

## Run in Anaconda Prompt or Windows Command Prompt

No installation or environment change is required. The absolute interpreter pins the existing Anaconda Python; only its standard library is used.

```cmd
set "TASK_DIR=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6D\20260913T195357Z\application\late_followup_independent_v1"
"C:\Users\amiri\anaconda3\python.exe" -B "%TASK_DIR%\Analyze.py" --output "%TASK_DIR%\run_01"
type "%TASK_DIR%\run_01\FINDINGS.md"
certutil -hashfile "%TASK_DIR%\run_01\RESULT.json" SHA256
```

For a later reproduction use `run_02` or another fresh directory. The script prints progress only at240-job intervals and never starts workers or subprocesses.

## Interpretation and exclusions

Lexical gain/loss concentration uses all63 actor-scene rows per contrast and881 actor-exclusive token occurrences. Leaving out a scene removes that scene's numerator **and denominator**, not just its gain. Candidate redundancy uses Counter minimum/maximum on identical case, actor and token type, respecting repeated-token multiplicity. It does not align occurrences, combine MAIN and SCAN passes, synthesize text, select a stream, fit a threshold or establish acoustic source attribution.

`ongoing_display_label_changes` counts label changes on subsequent ASR observations. `revision_count` counts a separate bounded reconciliation path, which can update an active utterance or an already-final one. It is **not** a generic text-revision count or an exclusively post-final counter. Names, Unknown and anonymous labels can participate; counts alone do not establish incorrect person changes. `first_anonymous_label` versus `latest_anonymous_label` uses dedicated anonymous fields. Display endpoints are compared only when both are numbered `Speaker_N`; named labels, Unknown, absent/null values and missing final timestamps remain explicit exclusions. No unrecorded first-final anonymous identity is derived from a name. Intermediate churn may exist even when endpoints match. Headless scheduler labels do not establish actual Tk visibility or scanout.

Initial-prefix analysis joins exactly by job and utterance ID, requires the same source start within one16k sample and an initial span nested in the final span, and keeps changed-span rows excluded. It uses casefolded Unicode word tokens with punctuation removed; the last initial token extending into a final token has its own category. `INITIAL_NOT_FINAL_PREFIX` means an initial sequence differs from the final prefix, **not** that the initial text was wrong or the final text correct. This is not WER, latency, a complete revision count, word-time inference or a penalty for future words missing from a short initial partial.

All native rows are retained regardless of incomplete reference or scoring permission. Strata are descriptive; four conditions per scene are paired, not independent repetitions. The existing source-bound final scores and scientific denominators remain unchanged. The original runtime limits, cap, deadline and hardware policy are not changed by this analysis.
