# Revision20 insertion draft — preserve the supplied master

Updated 17 September 2026: read LATE_FOLLOWUP_FINDINGS.md and NEXT_PHASE_PIPELINE_PRIORITIES.md before interpreting the original measured results below. The added 18-log clock audit distinguishes source-progress discrepancy from evidence backlog and consumer delivery; it does not establish causal naming/model cost or reverse failed freshness gates. The 960-job label audit and scene-omission beam analysis add stability and robustness evidence. No default, waveform, model or gate changed. The original delivered ZIP remains preserved. Use the UPDATED_20260917_DELIVERY_CLOSURE.json external receipt for this revision.


Master: C:/Users/amiri/Downloads/XVF_Measurement_V20.docx.
Original SHA256: f84fabaa874b5527c4231e4553f8fd13b0beee5ea46a5c11979fc9e6ecb09f21.
No Word file was rewritten. Preserve styles, user edits, strikethroughs, earlier revision history and all original measurements. Add this material as a dated S6D results addendum with light-yellow highlighting. Do not replace historical planning counts with results without marking the change.

## Suggested insertion

S6D execution and scientific analysis are closed for the declared bounded populations when the external delivery closure verifies this package. MAIN240/240 andSCAN48/48 provide accepted new six-stream same-pass evidence within each separate profile pass. C12 association captures,60enrollment captures,360native templates,4repeat controls and two uninterrupted900-second physical conversations were completed. Full application960cells comprise892new and68retained; original/repaired176, beam core96, stream diagnostics528+48controls,4continuous-native,62uniqueGUI and2long-host jobs are complete for their declared technical scopes. Counts overlap where credits are explicit.

Manual ±5° acquisition uncertainty is retained. Hypothetical2°/0° overlays change evaluation intervals only and leave nominal179/768stable-but-wrong result unchanged. All8narrower operational-width variants were rejected as replacements for their25°parents.

New application T0/T1/T2 and V0–V3 research hooks preserve complete raw text and bound display/event queues. Selected-person filtering misses substantial target speech: actual target-present T1matches38/85(O0),46/85(O1), with5/9and4/9target turns never visible. No acoustic speaker extraction or useful person-associated direction benefit is established. Supported arrows remain unavailable; silence is not perfect direction performance.

Calibrated beam selection is disabled: all5,882physical C candidate observations violate the original0.75s source-age rule, and unambiguous negative calibration support is absent. Fixed focused streams show occasional lexical recovery but usually greater total loss. Scanner has a modest panel-only opportunity. No Q-fitted selector, device gallery replacement or default promotion occurred. Dynamic extra-ASR switching and fixed-table steering are explicitly unqualified/deferred branches with reasons in the handoff.

Enrollment quality remains56PASS/304REVIEW, not silently upgraded by later counterfactual analysis. Clean/device comparison over96conditional timed query cells ×26C-calibrated galleries shows mixed correctness and false-known changes; all source-turn/no-event denominators are retained. E/C/Q remain disjoint; probes were never enrollment.

Each physical900sconversation contains18complete-reference speech blocks and two45s digital-zero gaps. The gaps are not missing speech references. All4pause episodes yield subsequent caption text in both native modes. Automatic/beam-ID words are identical, while anonymous attribution worsens with unavailable beam association. Continuous physical state is distinguished from the separate historical-capture host concatenation.

Two30minute host sessions preserve words and full input/drain, with18.50%conditioned lexical error but119.92%anonymous cpWER. Naming adds median1.261s/p951.585s consumer delay, failing the provisional engineering goal. Native C105 second repaired O0 repeat retains1→21cp edits/41words despite stable saved-event fixtures. These negative results prevent a claim of general delivery/identity resolution.

The desktop opt-in research conditions remain C065anonymous and C088/A15naming with exact frozen profiles/galleries. No CM5 execution, total2GB qualification, eMMC endurance test, field trial or general-use default promotion has occurred. Pinned ARM64 manifests and a small future workload are preparation only. S7–S9 do not start automatically.

All240original playable mono pairs and transcripts/scenario descriptions remain in the local listening index, with1,728new same-pass raw mono links. The roughly45s scene format contains substantial designed gaps; estimated source-speech support is1,851.6585s over10,967scene seconds(16.88%), not a certified silence fraction. Long duration is not a minimum RIR length. Keep original timings for the evaluated comparisons.

Attach the handoff ZIP and its external delivery closure; refer to exact local paths/hashes for large evidence. Retain acquisition exclusions, corrected1.00m values, R13restriction and canonical RIRv1 without alteration. No new acquisitions or retakes were admitted by S6D.
