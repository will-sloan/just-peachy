# Inputs for the next planning discussion

Use the completed S6C findings, acceptance and exact coverage tables for the next planning discussion. Four conditional research conditions are retained; this document does not start S6D or change the application default.

The next ChatGPT planning prompt should begin with START_HERE.md, S6C_JOINT_REPORT.md, OPERATING_ENVELOPES.md, EXECUTION_COVERAGE.csv and PACED_NATIVE_RESULTS.md from the completed package. Use the exact candidate/profile, ASR tap, identity tap, gallery roster/tier, cue mode and source epoch as one condition. Do not assemble the lowest value in each table into an untested combined configuration.

Decisions to make from the completed evidence:

1. Choose an anonymous fallback and any conditional naming/spatial option using word errors, Unknown and return behavior, false-known exposure, first/final display behavior and measured runtime together. Retain an explicit fallback when a cue is missing or unreliable. A shuffled-cue result is a control, not an operating profile.
2. Decide whether further controlled device-domain enrollment is worthwhile. Current clean-source templates are a deliberate domain mismatch to processed XVF probes. Their 5/15/30-second tiers approximate an amount of usable read speech; they are not a newly recorded enrollment paragraph. Missing Common Voice duration tiers and low-consistency templates remain visible.
3. Plan a separate CM5 deployment qualification. Desktop CPU/RAM measurements and source-paced files do not establish ARM64 performance within 2 GB total RAM and 32 GB eMMC. Carry complete profiles, model hashes, bounded journals/state and full-system cost evidence into that stage.
4. Defer real-user enrollment and acoustic/field validation to a later explicit project decision. Do not request human recordings, rooms, walking trials or a new measurement campaign as prerequisites for finishing S6C.
5. Review transcript attribution under nearly coincident observation arrivals. The completed C105/S45_08_07/O0 diagnosis has identical neural vectors and discrete speaker choices, yet a 1.1398 ms modeled ordering margin changes an ongoing label from committed Speaker_2 to provisional Speaker_4. The current correction horizon and final evidence expiry retain that label. Use the exact native/cached pair and all subsequent paced repeats as a regression case before proposing later changes to evidence preference, clock semantics or reconciliation. This is a documented S6C failure path, not authorization to alter its frozen implementation during this study.

For any later Codex prompt, state the exact allowed change, inputs, expected output and acceptance criteria; require a maintained README with copy/paste PowerShell and Anaconda/CMD commands. Preserve frozen S6A/S6B/S6C evidence and unsuccessful attempts. Keep opt-in execution separate from an explicit later decision to promote a production default.

Measurement constraints still apply: use admitted PASS/REVIEW material, exclude RETAKE and early test measurements, preserve the two user-confirmed 1.00 m corrections as overlays, retain prior acquisition/clock exclusions, and do not regenerate or reinterpret the canonical RIR library silently. The current direction convention has internal sign consistency checks, not physical angle calibration. The retained 50 ms RIR timing convention and O0 gain must each be applied only once.

The Word master is XVF_Measurement_V17.docx for this invocation. WORKBOOK_UPDATE.md provides insertion text and captions for review; the master itself is preserved. A later edited successor must be explicitly resolved before a new stage.
