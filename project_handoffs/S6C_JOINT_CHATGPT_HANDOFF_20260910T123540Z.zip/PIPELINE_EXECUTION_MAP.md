# S6C pipeline and execution map

Execution paths for the completed S6C offline study. Final execution/disposition tables distinguish implementation, actual native work, cache reuse, policy replay and diagnostics.

The canonical inputs come from the existing physical XVF captures of synthesized multichannel microphone scenes. S6C consumes their paired mono O0/O1 recordings; it does not regenerate the RIRs or pretend that convolution alone is XVF processing. The 240 scenes and 480 prepared views retain their source, capture and gain history. O0 already contains its prescribed +3 dB adapter gain; both current file inputs are consumed at unity. The retained 50 ms RIR convention is not added again.

Use each indexed file's actual duration, not its scene-ID prefix. Of the 240 paired cases, 236 have 44.6954375-second views, S45_03_11 has 46.6954375-second views, and S45_06_01/06/11 have 99.6954375-second views. The full bank totals 10,893.905 seconds per output. These retained extents are already consumed by native inference and scoring. The separately executed runtime panel uses its own exact selected lengths. The additive source_duration_scope_v1/RESULT.json binds this metadata clarification; no source was cropped or reclassified.

The four longer files also match their original scene and physical-capture metadata: S45_03_11 was planned/captured at 47 seconds, and S45_06_01, S45_06_06 and S45_06_11 at 100 seconds. Each of those framing receipts records 14,619 excluded startup native frames, equivalent to 0.3045625 seconds at 48 kHz. Decoding the remaining native frames at the recorded 3:1 ratio gives the exact consumed 16 kHz frame counts. The three F06 schedules include a 48-second gap from B1's scheduled stop to A2's scheduled start, so the bank contains extended return-memory opportunities. The metadata does not state the builder's rationale for precisely 47 or 100 seconds. The exact original-plan, capture, framing and consumed-journal metadata are bound in source_duration_provenance_v1/RESULT.json; this supplement adds no new payload audit or timing adjustment.


## Representative N01 data flow

```mermaid
flowchart TD
    prior["Prior physical XVF processing"] --> files["Existing captured O0 and O1 files"]
    files --> journals["Paired journals with a common committed sample boundary"]
    journals --> asr["Sherpa recognition: raw partial and final words"]
    journals --> evidence["Pyannote support estimates and scheduled voice windows"]
    evidence --> embedding["One ReDimNet instance: short and mature evidence"]
    embedding --> tracks["Incremental anonymous speaker hypotheses"]
    telemetry["Optional delivered XVF observations"] --> tracks
    tracks --> labels["Anonymous labels and optional post-association names"]
    gallery["Explicit isolated research gallery"] --> labels
    asr --> scheduler["Causal transcript attribution and bounded revisions"]
    labels --> scheduler
    scheduler --> exports["Punctuation, emitted rows and first/latest exports"]
    exports --> scorer["Separate reference-based scoring"]
    truth["Reference words, identities and eligibility"] --> scorer
```

This diagram shows the N01 dual-evidence path and the tested post-association naming direction. Names do not feed back into anonymous association or recognition. The shared scheduler uses actual delivered availability and lane watermarks; the arrows do not promise simultaneous completion. O0's prescribed gain is already present and both runtime inputs stay at unity. Other registered recipes change the admitted evidence and ASR schedule.

Ordinary cue-enabled conditions consume recorded observations. The separately declared nominal-geometry diagnostic supplies evaluator-derived angle content on the recorded availability/missingness schedule; that oracle-like exception is outside the ordinary flow above and is never a deployable input. No reference person or word is used to choose a runtime identity.

| Step | Actual implementation or evidence | Meaning |
|---|---|---|
| Paired file input | research_audio_v3.py and PipelineEngine.start_paired_files | Same capture sample zero, equal mono 16 kHz frame counts, separate ASR/identity PCM journals and one shared committed-sample barrier. |
| Speech recognition | Existing Sherpa-ONNX Giga assets and ASR lane | Continuous raw partial/final word observations. Decoder, endpoints and host dispatch are explicitly configured; dispatch interval is not encoder chunk length. |
| Speaker evidence | research_evidence_v3.py with existing Pyannote/ReDimNet model instances | Fixed ten-second segmentation graph, separately scheduled short/mature contiguous waveforms, online estimated support/purity/RMS and logged real model calls. |
| Anonymous association | research_tracking_v3.py | Bounded live/archive state, separate existing/new/unresolved hypotheses in the applicable modes, evidence commitment, prototype protection and explicit lineage. |
| Optional names | research_identity_v3.py with existing ProfileStore | An explicitly bound isolated gallery is actually loaded and scored after anonymous association. Names do not feed back into this post-association tracker. |
| Causal integration | research_scheduler_v3.build_s6c_policy | One implementation shared by native application and policy replay; released observations, lane watermarks, revisions and bounded naming state. |
| Display/export | Existing application event sink plus v3 corrections | Raw words, immutable first labels, first-final display and latest revised labels remain separate. Correctness is assigned only by the scorer. |
| Durable closure | session_finalization_v3.json plus run receipt | Lane joins, released resident lease, closed event/transcript writers and complete journal hashes must pass before native completion. |

The installed Pyannote graph accepts [1,1,160000] and produces seven powerset log-score classes. Ten-second context and update hop are separate parameters. ReDimNet receives contiguous float32 audio and returns a normalized 192-dimensional float32 vector. Short and mature opportunities use the same resident model; overlapping windows do not count as independent unique speech. Supported study windows are explicitly validated; no extra person is inferred from a local segmentation slot or an XVF beam.

| Execution category | What really runs now | What cannot be inferred |
|---|---|---|
| NEW_NATIVE_INFERENCE | Admitted waveform journals, unchanged model weights, actual model requests, shared tracker/resolver and application exports | Accelerated desktop time is not live, board or CM5 latency. |
| VERIFIED_NATIVE_CACHE plus INCREMENTAL_REPLAY | Bound original model observations plus fresh incremental shared policy and optional gallery calculations | A replay is not another model run, another physical capture or paced runtime proof. |
| PACED_NATIVE | Actual full file pipeline at source speed, with source cursors, queues, events and closure | The producer publishes a block before sleeping; wall-minus-block-cursor is not phonetic latency. |
| MODEL_FREE_DIAGNOSTIC | Constructed vectors, preserved source-control replays or bounded metadata/trace inspection | Reachability or counterfactual activation alone is not speech accuracy or new model inference. |

Cache admission binds waveform/tap/gain/origin, model files and package versions, frontend/context/window/cadence, policy-dependent inference selection, ASR state and extraction code. Changing an upstream dependency requires affected native inference. A fixed evidence schedule permits fresh downstream association/name policies; state-dependent cadence requires the relevant policy/cue/gallery dependencies to match. Equal score tables do not establish cache compatibility.

The native prefix test used identical first twelve seconds with different later content and verified actual embedding/segmentation/ASR prefix equality. Per-panel own-source native/replay comparisons check all nested speaker decisions and shared transcript/name event fields while excluding the listed execution-timing fields. Final-export and cross-source accuracy comparisons are separate checks. These checks do not replace later source-paced acceptance.

That distinction matters empirically. The 408 enrollment integration cells retain identical normalized ASR words against cached-policy counterparts, but five O0 cells on S45_08_07 change latest attribution error from one to 21 over 41 words. The detailed C105 pair has identical vector archives and 39 discrete speaker/name choices. A 1.1398 ms modeled ASR-before-mature-evidence crossing selects a provisional label; the two-second ongoing correction horizon and 0.75-second final evidence expiry retain it. Own-source logical parity therefore does not establish cross-execution transcript-label invariance. The exact diagnosis and independent review are preserved in native_timing_diagnosis_v1 and independent_review/NATIVE_TIMING_ROOT_REVIEW_V1.json; the added paced sentinel is separate from the original balanced panel.

Spatial packets enter only the declared cue route with their actual host availability. The core physical logs do not provide native DSP source-span timestamps; host poll age cannot establish DSP freshness. Real/null/nominal conditions retain their explicit provenance. Nominal folded geometry is evaluator-derived diagnostic input, never a production observation.

The authoritative scientific sources include the immutable EPOCH2_EXECUTION_MANIFEST.json, EPOCH4_EXECUTION_MANIFEST.json and additive EPOCH5/EPOCH6_EXECUTION_MANIFEST.json files, source-bound native results and policy plans. Epoch4 changes registered profiles/galleries/helpers while retaining exact epoch2 native worker, common module, application and model bytes. Epoch5 adds four explicitly registered cadence-floor neighbors; epoch6 adds the endpoint-only and combined tracking/endpoint pair. Both preserve those same native/application dependencies and all prior profile routes. Endpoint advice requires the full profile and cues in native dependency admission because it can change recognition boundaries and words. Epoch preparation is not execution: completed native receipts determine which conditions ran. Separate coordinator overlays accelerate current filesystem enumeration; they preserve native worker code and job identities. Machine inventory distinguishes physical executions, repeated attempts, unique dependencies and reused index references.

No S6D, training, model replacement, default promotion or new human measurement is part of this study. Exact candidate file commands are in the application README_RESEARCH_S6C.md and the maintained per-run helpers; final operating commands must use the selected complete profile and its exact gallery/cue condition.



## Final accounting boundary

All596 paced cells have completed native execution, actual analysis, metadata normalization and64 separate-repetition core/name score commands:520 main-panel,24 cadence,12 arrival and40 cross cells. The13 main conditions each have16 first-repetition scenes and four repeats per output. Appropriate native/shared parity passed for556 cells; B00's40 controls retain exact original native-event attribution with shared/vector parity unavailable.

Five further uninterrupted host sessions completed on September12 at16:40:58 UTC: C065 O0/NONE control, C067 O0/NONE, C088 O0/originalA15, C091 O0/originalB15 and historical B36 O0/NONE. Each consumed1,827.426625 source seconds (30min27.426625sec) from38 prior captures with74 seconds of inserted silence. All five original parent exits were0; full source cursors, journals, tail/drain and scheduler closure were observed. These are five dependent-input host sessions, not continuous hidden XVF state or additional physical-XVF captures.

The fresh final machine census observed5,891 physical attempts:5,289 legacy and602 fast. Row statuses are5,889 COMPLETE, one STARTED without a confirmed session, and one failed outer C065 attempt whose native body completed. Thus5,890 observed native-body completions are not5,890 accepted attempts. The fast scope is596 accepted paced cells, five accepted long sessions and that failed C065 attempt. All5,284 prior native-index bindings were found; six late pools have zero coverage gaps. All7,411 concrete owner observations are closed. One virtual failed-C065 observer flag remains unverified with no recorded identity. Preserve the original INCOMPLETE_WITH_FLAGS/CLOSURE_UNVERIFIED inventory labels and unknown historical exits. Acceptance of completed successful scope does not rewrite failed-attempt facts.
