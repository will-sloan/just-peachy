# S6C workbook insertion draft

Completed-results insertion text for review and yellow highlighting in XVF_Measurement_V17.docx or the user's later edited master. The original Word workbook has not been overwritten. Use the final acceptance and exact execution/disposition tables with this interpretation.

## What the experiment tests

S6C tests whether better handling of short and mature voice evidence, bounded speaker memory, directional observations and disjoint enrollment can improve the existing full speech pipeline. It uses the unchanged Sherpa-ONNX Giga, Pyannote ONNX and ReDimNet weights. The application performs recognition and speaker analysis in parallel, then creates anonymous speaker hypotheses and, when an isolated research gallery is explicitly enabled, attaches names through the actual identity resolver. Ground-truth transcripts and speaker identities remain scorer inputs. Nominal geometry is supplied only to the explicitly oracle-like diagnostic cue condition; it is not deployable telemetry or ordinary predictor knowledge.

The study retains all 240 canonical synthetic scenes, both captured XVF output recipes and every scheduled probe occurrence. The outputs are paired observations of the same scenes; they are not independent replications. Existing material was digitally processed through the physical XVF in earlier stages. Current S6C offline inference uses those genuine captures. New physical-XVF enrollment and continuous HIL are separate optional branches and have not executed in this invocation.

Prepared file extents are not uniformly 45 seconds: 236 cases have 44.6954375 seconds per output, one has 46.6954375 seconds, and three have 99.6954375 seconds. Native jobs preserve those complete indexed inputs, totaling 10,893.905 seconds per output across the bank. The S45 identifier is not a duration instruction. The source-duration supplement records the four longer cases and exact integer frame counts.

The four longer files also match their original scene and physical-capture metadata: S45_03_11 was planned/captured at 47 seconds, and S45_06_01, S45_06_06 and S45_06_11 at 100 seconds. Each of those framing receipts records 14,619 excluded startup native frames, equivalent to 0.3045625 seconds at 48 kHz. Decoding the remaining native frames at the recorded 3:1 ratio gives the exact consumed 16 kHz frame counts. The three F06 schedules include a 48-second gap from B1's scheduled stop to A2's scheduled start, so the bank contains extended return-memory opportunities. The metadata does not state the builder's rationale for precisely 47 or 100 seconds. The exact original-plan, capture, framing and consumed-journal metadata are bound in source_duration_provenance_v1/RESULT.json; this supplement adds no new payload audit or timing adjustment.


The original measurement audit remains the source of RIR and geometry eligibility. No new RIR extraction or angle correction is performed here. The two originally recorded 100 m values use the operator-confirmed 1.00 m overlay; retained analysis distances are 0.46–4.07 m. The 121-entry canonical library includes 95 extracted responses and 26 entries with recorded limitations. Manual angle uncertainty is ±5 degrees; it is not a calibration accuracy for the XVF direction estimates.

## Evidence and scoring populations

| Population | Current meaning |
|---|---|
| 240 scenes / 480 output views | All authorized canonical scenes and both O0/O1 views; no synthetic reserve is presented as untouched validation. |
| 777 scheduled probe occurrences | Naming/source-support evaluation, with reference eligibility kept separately for each metric. |
| 693 complete and 84 limited-reference occurrences | Complete-reference and limited-reference scoring stay separate. |
| 203 complete-reference scenes / 6,016 words | Complete-population lexical/attribution aggregates per output for the full bank. |
| 156 primary scenes / 4,560 words | Primary complete-word population; overlap and limited references have separate results. |
| 40 complete subsecond turns | The complete short-turn population per output; a long evidence window is not credited as contained in such a turn. |
| 11 strict empty/music controls | Insertions and false assignments remain included; no speech transcript is invented for a control. |

The attribution word-error measure and raw ASR word error answer different questions. Reusing the same recognized words while changing labels can alter attribution scores without changing recognition. First-display attribution uses the final recognized words paired with their first displayed labels; it is not the word error of every partial transcript. Modal short-turn correctness uses an evaluator's retrospective scene mapping, not identity knowledge available to the online tracker.

Cached neural evidence plus fresh policy replay is distinguished from new native inference, paced execution and model-free diagnostics. Logical prediction rows, repeat references and aliases are not additional model runs. The working candidate-support snapshot reconciles all 240 registered labels: 196 new C labels and the 44 original historical B labels. C083/C084 are explicitly carried aliases, not extra executions. Final counts and preserved exceptions are summarized below from the fresh machine census.

## Speaker tracking and direction

The new tracker separates live hypotheses, archived records and lifetime IDs, with explicit commitment and prototype-update rules. Increasing the capacity alone did not exercise a meaningful limit in the full N01 comparison: the tested 16/32/64/128/256 variants reached a maximum of 13 live tracks and recorded no capacity rejection there. This says the cap was inactive in that material. It does not establish indefinite-session safety or resolve the earlier S6B allocation behavior.

On the full bank, real directional observations sometimes improved latest attribution under the matched new association rules. The benefit was conditional. Room-level changes and different null-control seeds were not uniformly favorable, and several new configurations remained worse than the historical B36 fallback on first-display attribution. For example, C065 had 264/191 additional first-display attribution edits on O0/O1 versus B36; C079 had 255/161 additional edits. The C079 pooled latest score improved by 33 edits on O0 but worsened by 110 on O1, and equal-room changes were worse on both outputs. These are dependent within-material comparisons.

Directional cues cannot be treated as calibrated person locations. The existing physical telemetry has no native DSP source-span timestamp. Stable estimates can be persistently wrong; a recent host packet is not proof of fresh acoustic evidence. The measured cue diagnostics include 179 turn-level comparisons in 124 scenes among 768 usable selected-direction turns, using standard deviation at most 10 degrees and mean absolute nominal-angle error at least 35 degrees. This is an evaluator-only diagnostic against nominal geometry, not calibrated physical angle truth. The final handoff retains their exact denominators and unfavorable examples.

The original uncertainty-triggered cadence pair C071/C082 and its 0.5/1/2-second floor neighbors had mixed attribution outcomes. Lowering the floor from one to half a second improved latest attribution by 49/22 edits for the cue-off pair on the 1,030-word panel, but the real-cue pair changed by −10/+9 edits. Actual model-call savings were much smaller than the change in due flags. Direct cue-trigger flags remained zero in these accelerated traces. A logged due flag is not proof that the specific voice needing evidence received it. The original pair remains a paced diagnostic; none of these panel findings is a full-bank recommendation.

The endpoint-only and combined endpoint/tracking conditions exercised the advisor and reset path in actual inference. They did not show a general gain: compared with the cue-off parent, first-display attribution increased by 6/33 edits on O0/O1, and complete-word edits increased by 2/6 on the panel. Native endpoint, advice-only, coincident and reset counts remain distinct. An accepted reset cannot be assigned responsibility for a particular word error without further evidence.

## Longer mature voice evidence: the completed N03 tradeoff

The three-second mature-evidence condition improves the latest attribution score but weakens first-display and return continuity. The comparison retains all 240 scenes and both outputs; the table uses the 203 complete-reference scenes and 6,016 words per output, with 292 returning-speaker opportunities.

| N01 parent to N03 | O0 | O1 |
|---|---:|---:|
| Latest-label attribution errors | 3,732 -> 3,547 | 3,865 -> 3,710 |
| First-display-label attribution errors | 3,955 -> 4,052 | 3,971 -> 4,042 |
| Consistent returns, out of 292 | 41 -> 18 | 37 -> 17 |
| Unknown samples, out of 25,304,912 sole-active samples | 9,032,568 -> 9,616,060 | 8,797,718 -> 9,388,051 |

Raw final text and lexical counts are unchanged in all 480 paired native outputs. Fewer embedding calls did not yield a proportional measured embedding-compute reduction. Longer voice evidence therefore remains a conditional attribution tradeoff. This result does not establish paced acceptance, early-label improvement or a new default.

## Full segmentation and decoder confirmation

Hard-argmax segmentation (C072/N08) and two-path modified beam search (C074/N10) have now completed all 240 scenes on both outputs. All 960 cells have exact own-source native/replay agreement; 736 were newly executed and 224 reused completed panel evidence.

The following are changes from the matched C065/N01 parent. Lower cp errors are better, but cp combines word and anonymous-label errors. The first-display measure uses final words with their original displayed label and does not measure partial-word accuracy or wall latency.

| Change from C065 | First-display cp change O0 / O1 | Latest cp change O0 / O1 | Separate adverse observation |
|---|---:|---:|---|
| C072 hard-argmax segmentation | −80 / −85 | +65 / −47 | Inconsistent returns 49/57 → 62/64; correct mapped subsecond turns 12/12 → 9/9 |
| C074 two-path decoding | −100 / −44 | 0 / −45 | O1 empty-control insertions 2 → 19, across four nonempty outputs instead of two |

The cp denominator is 203 complete-reference scenes and 6,016 words per tap; return and subsecond denominators are 292 and 40. C072's final words are unchanged in all 480 cells. C074 reduces primary serialized word errors by 21/5 on O0/O1 over 156 scenes and 4,560 words, but both conditional 95% intervals include zero. Its separate complete-population word totals decrease by 15/16; those totals combine primary serialized errors and 47 complete-overlap MIMO results and are not one serialized alignment. Eleven empty controls are retained separately without a zero-denominator WER.

These findings retain useful tradeoffs and adverse cases. Both candidates still have higher latest-label cp errors than original B36 on both taps; that comparison spans different complete pipeline generations. Cross-routing and paced/continuous evidence are complete and reported below; neither candidate becomes an operating preset.

## Shorter fixed ASR endpoints: completed N12 confirmation

C076 keeps the existing greedy decoder, voice-evidence schedule, tracker and cue-off/no-gallery condition while shortening the two silence rules from 2.4/1.2 seconds to 1.6/0.8. All 240 scenes on both outputs have closed native/replay/scored evidence, with eleven fixed comparisons and independent review.

| N01 parent to C076/N12 | O0 | O1 |
|---|---:|---:|
| First-display-label cp errors / 6,016 words | 3,955 → 3,696 | 3,971 → 3,822 |
| Latest-label cp errors / 6,016 words | 3,732 → 3,731 | 3,865 → 3,792 |
| Complete-overlap latest cp errors / 1,456 words | 895 → 903 | 920 → 928 |
| Primary serialized word errors / 4,560 words | 656 → 657 | 705 → 705 |
| Strict-empty insertions across eleven cases | 1 → 1 | 2 → 2 |
| Consistent returns out of 292 | 41 → 40 | 37 → 37 |

The first-display measure uses finalized words and their first displayed labels; it is not partial-transcript accuracy or wall-clock latency. Latest attribution worsens on complete overlap despite the pooled point improvement. Both primary-word uncertainty intervals include zero, and return consistency does not improve. C076 improves first-display attribution relative to the longer-mature C067 condition while giving up some later-attribution benefit. B36 remains better on pooled first/latest point totals on both outputs. These are useful separate tradeoffs, not permission to combine shorter endpoints, longer voice windows and naming into an untested preset. C076 remains a completed scientific paced representative outside the four retained operating conditions.

## Enrollment and naming

Enrollment uses disjoint existing CMU ARCTIC, HiFiTTS and older Common Voice recordings. L2 ARCTIC remains excluded. The frozen E/C/Q split separates enrollment clips, threshold-calibration clips and the 777 probe occurrences. Corpus-qualified labels are research pseudonyms; they are not an identification of contributors or proof of unique people across datasets. Existing rights restrictions and same-book/session limitations remain explicit.

The closest available proxy for a future paragraph is a deterministic set of independent read utterances with estimated usable speech. Clips are not looped or time-stretched to reach a tier. Clean-source templates are deliberately mismatched to the processed XVF probes; no device-matched enrollment claim follows.

The implementation actually loads an isolated gallery, computes scores/margins and emits names in the application path. Correct-reference, absent-person, distractor and conflicting-voice checks establish that this branch executes. Names are attached after association in the tested formulation. They do not separate a mono overlap mixture or automatically repair anonymous fragmentation.

Longer enrollment improved correctly named speech among people with material at every matched tier, but did not eliminate false known names. The matched-duration comparison keeps the same eligible people in each frozen roster and all probe rows, including withheld voices. Each roster contains 14 people: nine CMU ARCTIC and five HiFiTTS identities. The two disjoint rosters contain 28 people combined. Common Voice probes remain in the study even though its available references do not meet all common tiers. Whole-clip material, native evidence-window counts and resulting templates change alongside estimated duration, so this comparison does not isolate duration alone.

| Change from 5 to 30 seconds | Roster A O0 / O1 | Roster B O0 / O1 |
|---|---:|---:|
| Additional correctly named source samples | +372,359 / +284,065 | +299,408 / +296,731 |
| Additional wrong-known source samples, all probe roles | +27,284 / +77,772 | +17,655 / +4,800 |
| Additional wrong-known samples on withheld speech | +17,646 / +70,816 | +12,294 / 0 |

Counts use a 16 kHz source-support clock. They are not actual wall-clock name exposure. First and stable correct-name availability retain observed/never-observed denominators; most occurrences did not reach the strict stable criterion. A conditional median among named turns does not describe the unnamed majority.

Cold and warm naming state were also compared using the executed cached-policy queries. Correct assignment was more frequent among identifiable enrolled warm queries on all 24 profile/output routes; for example, C088 O0 was 186/225 (82.67%) for cold and 439/467 (94.00%) for warm. Query selection and accumulated evidence differ, so this is a conditional association, not proof of a causal warming benefit or naming coverage over all speech. First query for a track and first query for a reference person are different events. Actual paced naming timing is separate in PACED_NATIVE_RESULTS.md and RUNTIME_RESULTS.md.

Threshold calibration on disjoint known calibration material increased correct naming in some conditions, while also increasing wrong-known exposure. That material does not supply an independent stranger population for open-set calibration. No lower threshold or longer tier is a universal recommendation.

Suggested figure: figures/enrollment_duration_v2/enrollment_duration.png, with its supplied CAPTION.md. It shows the four roster/output series separately and includes both correct coverage and withheld-voice errors.

## Why native timing still matters

An observed native/cache discrepancy demonstrates why matching embeddings and policy decisions alone is insufficient. In the selected C105 case, the vector archive and 39 discrete speaker/name decisions matched. Mature speaker evidence arrived 24.1741 ms before a modeled ASR availability boundary in the cached execution, but 1.1398 ms after it in the fresh native execution. The current revision horizon and evidence-expiry rule retained a provisional transcript label. Latest attribution changed from one to 21 edits over 41 words in the affected cell, without a raw-word change.

This is a specific arrival-order counterexample, not a general estimate of latency or hardware variability. The study retains every completed run. The separately declared12-cell source-paced sentinel has completed actual analysis and three separately scored repetitions; it does not replace the main balanced runtime panel. The driver publishes blocks before sleeping, so a negative wall-minus-source-cursor value must not be called negative phonetic latency.

Suggested figure: figures/arrival_boundary_v2/ARRIVAL_BOUNDARY.png, with its supplied caption. The plotted rows use their own ASR availability origin.

## Completed runtime and operating interpretation

All596 paced cells have completed native execution, actual analysis, metadata normalization and64 separate-repetition core/name score commands:520 main-panel,24 cadence,12 arrival and40 cross cells. The13 main conditions each have16 first-repetition scenes and four repeats per output. Appropriate native/shared parity passed for556 cells; B00's40 controls retain exact original native-event attribution with shared/vector parity unavailable.

Five further uninterrupted host sessions completed on September12 at16:40:58 UTC: C065 O0/NONE control, C067 O0/NONE, C088 O0/originalA15, C091 O0/originalB15 and historical B36 O0/NONE. Each consumed1,827.426625 source seconds (30min27.426625sec) from38 prior captures with74 seconds of inserted silence. All five original parent exits were0; full source cursors, journals, tail/drain and scheduler closure were observed. These are five dependent-input host sessions, not continuous hidden XVF state or additional physical-XVF captures.

The four retained research conditions are historical B36 O0/NONE as fallback, C067 O0/NONE when later revised anonymous attribution is the priority, and C088 O0/originalA15 plus C091 O0/originalB15 for controlled naming with the exact predefined rosters. C065 remains the matched anonymous control. Each retained complete condition has its own main paced and continuous evidence. None is a universal winner, an untested mixture or a new production default. Enrollment improves some correct-name support while allowing false-known exposure and materially longer observed output delays. See OPERATING_ENVELOPES.md and OPERATING_COMMANDS.md.

On the16-scene O0 first-repetition panels, partial-event source-cursor lag p50/p95 was0.180/0.331s for B36,0.375/0.695s for C065,0.585/1.210s for C067,2.767/6.112s for C088 and2.437/4.812s for C091 (377 partial emissions per condition). This is emitted-event lag, not phonetic or GUI latency. Long-session sampled RSS maxima ranged from466.0 to549.9MiB, with observation gaps of51.2–63.3s. C event-consumer queue peaks were2,697–3,405 events; terminal scheduler pending counts and recorded audio-drop counters were zero. Sparse samples do not establish continuous worst-case memory, absence of leaks or CM5 suitability. RUNTIME_RESULTS.md preserves clocks, denominators and generation-specific instrumentation.

The fresh final machine census observed5,891 physical attempts:5,289 legacy and602 fast. Row statuses are5,889 COMPLETE, one STARTED without a confirmed session, and one failed outer C065 attempt whose native body completed. Thus5,890 observed native-body completions are not5,890 accepted attempts. The fast scope is596 accepted paced cells, five accepted long sessions and that failed C065 attempt. All5,284 prior native-index bindings were found; six late pools have zero coverage gaps. All7,411 concrete owner observations are closed. One virtual failed-C065 observer flag remains unverified with no recorded identity. Preserve the original INCOMPLETE_WITH_FLAGS/CLOSURE_UNVERIFIED inventory labels and unknown historical exits. Acceptance of completed successful scope does not rewrite failed-attempt facts.

A 30-minute uninterrupted host file session built from prior captures tests continuous host state. Its 38 independently captured pieces do not become continuous hidden XVF adaptive state. Desktop CPU/memory results do not qualify the 2 GB CM5 target. Human paragraph enrollment, actual rooms/voices, device-domain generalization and later CM5 qualification remain future validation rather than prerequisites to completing the authorized offline study.

## Full cross-output confirmation and current runtime status

C085 uses O0 for recognition and O1 for speaker identity; C086 uses O1 for recognition and O0 for identity. All480 full-bank cells, their frozen replay checks and the11 declared comparisons are complete. Each cross route retains all240 normalized final transcripts of its same-recognition-tap C065 control. Across203 complete scenes/6,016 words, latest attribution changes by+22 errors for C085 and-84 for C086. Both wins and losses are preserved; neither is a general winner. The first-final attribution changes are+20/-86. This is a different field from final words paired with first displayed labels. The three contrasts switching recognition O0 to O1 add49 primary word errors over156 scenes/4,560 words; the existing conditional95% word-error interval is+0.3726 to+1.8075 percentage points. No cp interval or independent-scene claim is implied. See FULL_CROSS_RESULTS_SUMMARY_V2.md, its unchanged V1 JSON, and independent_review/FIRST_CP_FIELD_CLARIFICATION_V1.json.

The fixed descriptive token-boundary and strata analyses have run and passed independent compact-result review. They cover18routes/4,320 token cells and28routes/30contrasts respectively. Incomplete references and strict-empty recordings keep separate denominators and unavailable boundary values. Stratum maxima are descriptive overlapping subgroups, often with small support; token serialization over overlap is not MIMO scoring or phonetic evidence.

The first C065 attempt processed one44.6954375-second source and produced a COMPLETE native body before its outer integrity check failed, contributing zero accepted paced cells. A model-free reproduction exposed the unstable marshal-based guard; a separately reviewed structural guard supported the later successful generation. Original dispatcher telemetry failures, unknown orphan exits, and the controls cross-volume lease archive failure remain preserved. The separately reviewed exact-byte controls lease recovery added zero native sessions. See RUNTIME_REPAIRS_AND_EVIDENCE_CONTINUITY.md.

The user reports that the XVF3800 is now disconnected from the desktop. Current work uses existing files and recorded telemetry; it does not require or open the device. No new physical playback, capture or HIL validation is claimed. This updates current connection context while preserving earlier hardware evidence; see HARDWARE_DISCONNECTION_USER_UPDATE_V1.json.
