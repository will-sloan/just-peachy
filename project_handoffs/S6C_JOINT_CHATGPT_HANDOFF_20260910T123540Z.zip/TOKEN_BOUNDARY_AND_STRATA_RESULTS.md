# First/last tokens and adverse strata

Completed offline diagnostics. They do not themselves establish timed operation or an operating preset; separate actual runtime and disposition evidence supply those scopes.

The token diagnostic covers 18 routes and all 240 scenes per route (4,320 cells). Each route keeps 156 primary nonoverlap, 47 complete overlap, 26 incomplete-reference and 11 strict-empty scenes separate. Sixteen predeclared paired contrasts retain 3,840 paired scene rows (16 contrasts x 240 scenes, with repeated use of the same scenes). The published result and independent review bind every selected route and source table.

The table counts scenes whose first or last reference token is a deletion in the fixed lexical alignment. It does not count acoustic onset or offset loss, measure phonetic latency, or explain which endpoint caused a change. Repeated words can have ambiguous alignments; the documented deterministic tie order resolves the export consistently.

| Route pattern | Primary first / last deleted, out of 156 | Overlap first / last deleted, out of 47 |
| --- | ---: | ---: |
| Original-search O0 routes | 4 / 3 | 3 / 0 |
| Original-search O1 routes | 2 / 4 | 4 / 1 |
| C074, modified beam 2, O0 | 1 / 3 | 3 / 0 |
| C074, modified beam 2, O1 | 2 / 4 | 3 / 0 |

The original-search patterns are shared by B00, B01, B36, C065, C067, C072 and C076 on their corresponding taps. C085 follows its O0 ASR source and C086 its O1 ASR source. In this diagnostic, the shorter C076 endpoint settings have the same first/last deletion totals as C065. Modified beam 2 has fewer first-token deletion scenes on primary O0 and fewer boundary deletions on overlap O1, but the separate full comparison also records its O1 strict-empty insertion increase from 2 to 19 words over the same 11 controls. Those findings remain a tradeoff; boundary counts alone cannot select the decoder.

Incomplete references have null full-transcript alignment/error/boundary values. Empty scenes retain hypothesis insertions without a WER denominator. The overlap token diagnostic uses serialized reference alignment and must not be substituted for the main scorer's overlap MIMO or speaker-attributed cp metric. First-token deletion, first-final cp error and first-displayed-label cp error are distinct measurements.

The adverse-strata analysis covers 28 routes, 30 declared contrasts, 2,912 original selected stratum/group rows and 18,720 paired metric rows. It verifies the original scene memberships before comparing room, family, split, corpus, source quality, source level, noise, SNR, orientation and obstruction. Groups can overlap; their counts must not be added or interpreted as independent trials.

Useful qualifications to the pooled results include:

- C067 versus C065 on O1 improves pooled latest attribution, but at source level -6 dB in complete overlap, latest cp errors increase from 161 to 182 over 282 reference words across 10 eligible scenes.
- C076 versus C065 on O1 improves pooled first-display attribution, but in the Library Conference Room overlap group, first-display cp errors increase from 76 to 85 over 139 words across 5 scenes.
- C067 versus B36 on O1 leaves more primary F03 support Unknown: 1,127,079 versus 577,639 samples out of the same 2,579,520 reference-support samples across 20 scenes.
- C121 versus C065 on O0 in the Arise Floor 2 Kitchen incomplete-reference group increases inconsistent classified returns from 2/6 to 5/6 across 5 eligible scenes. This supported return metric is available despite unavailable full-reference WER/cp.
- Some larger proportional changes have tiny support. For example, C067 versus B36 on O0 has latest cp errors 53 versus 23 over 87 primary words in the 10 dB SNR group, but only 3 eligible scenes. The export flags that limitation.

These examples are descriptive positive maxima from a fixed analysis scope, selected after results, with all ties and count maxima preserved locally. They are not new confidence intervals, a causal decomposition or an independent candidate ranking. Zero differences are not called harm. Naming correctness requires the separate enrollment/name authorities; core strata cannot supply it.

Primary local authorities:
- full_token_boundaries_v1/results_v1/RESULT.json and ROUTE_POPULATIONS.json.
- strata_adverse_v1/actual_v1/RESULT.json, NARRATIVE.md and complete paired CSV/adverse JSON.
- independent_review/token_strata_design_v1/REVIEW_RECEIPT.json.
- full_n08_n10_results_v1/INTERPRETATION_BINDING_V2.json for the decoder/empty-control qualification.

Full per-scene diagnostics and overlapping paired strata stay local under those bindings. Compact packaging must retain the aggregate table, limitations and a complete local index rather than implying that these examples exhaust adverse behavior.
