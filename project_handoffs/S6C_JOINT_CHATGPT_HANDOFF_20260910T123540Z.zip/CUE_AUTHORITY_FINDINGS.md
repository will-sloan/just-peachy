# What the spatial evidence can establish

The carried physical audit, full anonymous comparison, three-seed/nominal comparisons, endpoint-advice execution and paced cadence diagnostic are complete. This does not establish a spatial accuracy specification or force a spatial operating recommendation.

## Physical observations and their clocks

The 240 carried XVF traces contain 175,500 sanitized telemetry rows and no native
DSP source-span timestamps. The trace records host polling/delivery, which is
useful for reconstructing when the application received a cue. Host poll age
does not establish the age of the DSP estimate itself. Source-support alignment,
processed-output sample clocks and modeled application availability remain
separate from that missing timestamp.

The corrected physical summary reports usable `selected_processed` direction on
about 92.27% of sole-active support; `selected_auto` coverage is about 49.31%.
That coverage is not accuracy. The `selected_processed` channel produced active
direction indications for about 371.989 of 450.038 seconds in ten music
captures, while the single digital-silence control did not. Stable direction is also
not sufficient evidence of correctness: 179 of 768 usable selected-direction turns, spanning 124 cases, had standard deviation at most 10 degrees and mean absolute nominal-angle error at least 35 degrees. These are nominal-geometry diagnostics, not an independently calibrated angle-error bound. The documented S45_11_16 example
has a selected direction near 21.23 degrees against a nominal 170-degree source.

The nominal labels derive from the measurement geometry. They retain signed
angles, the two user-confirmed 100-to-1.00-metre distance overlays, and the
manual-angle uncertainty convention. They are not a new physical calibration of
the board. The folded comparison convention does not turn 0 and 180 degrees
into identical endpoints. Fixed RIRs and these traces cannot validate walking,
IMU behavior, or general front/rear disambiguation.

## Experimental controls

Off, real, three seeded shuffled-angle controls and nominal-geometry controls
have explicit registered identities. The shuffled controls preserve delivery,
validity and energy fields while changing angle assignments; they are controls
for this association question, not complete physical fault simulations. Every
seed is retained. Choosing the least favorable shuffle after seeing a result
would exaggerate the evidence for real cues.

Nominal geometry uses the known sole-supported source where its restricted
definition permits it. That condition is an experimental reference with access
to measurement labels. It is not presented as information available to an
ordinary deployed predictor.

## Actual influence on attribution

The full eight-policy N01 anonymous comparison uses 240 scenes per output and
the same native ASR source. Within-family real-minus-off latest attribution
error differences on the 203 complete nonempty scenes are -97/-14 for normalized
joint, -61/-61 for reliability joint, -16/-35 for hypothesis joint, and -26/+29
for the old voice gate, on O0/O1 respectively. The denominator is 6,016 words per
output. These are paired point differences; they are not independent acoustic
trials or a spatial-error confidence interval.

Continuity and Unknown support do not improve uniformly with these attribution
counts. One independently reviewed normalized O1 example, S45_02_10, changes from
2 to 22 attribution errors over 36 words while Unknown support decreases from
50,119 to 42,582 samples. An unresolved return becomes inconsistent. More
assigned speech therefore does not by itself establish more correct identity.

The full three-seed comparison narrows the claim. Real cues produce fewer
pooled latest-attribution errors than all three shuffled seeds on both outputs
for the normalized and reliability families. The hypothesis family does not
meet that pattern: seed 47 has five fewer errors than real cues on O0. Room
effects remain heterogeneous. For example, normalized real cues improve pooled
O0 error rate by about 0.831 percentage points against seed 47, while worsening
it by about 1.125 points in Arise 5th floor and 1.020 points in the kitchen.
The normalized and hypothesis real-cue O0 routes also have 11 correctly mapped
subsecond turns versus 12 with cues off. Neither pooled assignment nor a
favorable shuffled-control contrast establishes uniform short-turn benefit.

The 96 declared full follow-up comparisons preserve every seed, nominal route,
matched parent, commitment setting and capacity condition. Their primary-word
bootstrap intervals are all zero because these policy conditions retain the
same ASR words; these are not confidence intervals for attribution error. No
declared seed or route for these retained families was dropped. Family retention
and follow-ups were outcome-informed; these exploratory comparisons support
conditional findings within the material, not independent family selection or
untouched validation.

## Cadence and endpoint boundaries

The native cadence audit covers C065/C071/C082 on the same 56 scenes and both
outputs. The uncertainty/debt schedules reduce embedding calls, but the direct
qualified direction-change trigger records zero admissions in C082. Its
per-track due ledgers are operative. A globally admitted waveform acknowledges
all due ledger entries; the log does not identify a particular debtor voice
served by that waveform. Target-voice and sole-cue causal counts are therefore
not invented.

The largest observed released-context age, about 39.9 seconds, includes dispatches
without active speech. It is not a measured active-speech latency or the age of
every track. The completed paced C071/C082 diagnostic records released
context, debt and runtime behavior at source speed; its24cells retain their own scope. Pacing alone is not expected
to activate a direct cue trigger whose provider is defined by source spans.

The native floor neighborhood is complete on all 448 new cells. Off/real embedding
calls are 2,485/2,485 at a 0.5-second floor, 2,409/2,401 at the original 1-second
floor and 2,330/2,322 at 2 seconds. Due-entry acknowledgments change accordingly,
but the direct cue trigger remains zero. Latest-label cp improves for the
0.5-second cue-off condition on both taps and is mixed with real cues; both
2-second conditions worsen it on both taps. First-display results largely
remain unchanged. These panel effects support a conditional numeric companion,
with the original 1-second paced diagnostic preserved. They do not establish
target-voice scheduling or a measured speedup.

C195/C196 have completed the 56-scene, both-output native endpoint factorial.
Each child recorded 49,952 advisor observations, 42 proposals, 36 accepted
advice-only resets and six rate-limited proposals. Total resets increased by
26 because native-only resets also changed; no coincident resets occurred.
Advice adds 6/33 first-display-label cp errors on O0/O1 with either tracking
condition. Latest-label changes are +24/+2 without real-cue tracking and
+24/−7 with it, per 1,030 complete-reference words. This proves activation
and mixed effects. It does not establish a causal link from a particular reset
to a word error or justify a general endpoint-advice recommendation.
Incomplete-reference word metrics remain null; empty/music insertions and all
source scopes remain visible in the original audit.

## Local authorities

The local artifact index binds the corrected physical audit in cue_audit_v2,
the action audit in cue_decisions_v2, cadence_audit_v1/RESULT.json, the full
anonymous INTERPRETATION_BINDING_V1.json, full_n01_followups_comparisons_v1
and its receipt (SHA256 `4fe25f329b4ab238310905b98f14c4dea3b20dc4f73caac7d25659dfea3d5683`), and the independent adverse examples
in full_anonymous_component_review_v1. Completed endpoint authorities are
endpoint_advice_native_core_v3, endpoint_factorial_comparisons_v1 and
endpoint_audit/actual_factorial_v1 (including its corrected SUMMARY_V2.json).
Completed floor authorities are cadence_floor_native_core_v3,
cadence_floor_comparisons_v1 and cadence_floor_audit_v3, with their exact
interpretation bindings. Actual paced receipts are bound in fast_post_analysis/remaining116_actual_v1 and paced_scoring/remaining116_actual_v1; no direct-trigger efficacy is inferred from pacing.
