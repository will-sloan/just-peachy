# Paced native results

All 596 completed cells have original native post-analysis, typed runtime normalization and separate core/name score authorities. This document compares existing aggregate score rows; it does not rerun a model, policy, alignment or scorer, pool repetitions, or select an operating preset. [RUNTIME_RESULTS.md](RUNTIME_RESULTS.md) supplies measured timing, sample gaps, memory and queue interpretation.

The main panel has 13 exact conditions, each with 16 first-pass scenes and four repeated scenes per output: 520 cells. The cadence gate contributes 24 cells, the exploratory arrival sentinel 12, and cross routes 40. Repetition-specific results remain separate. The complete supplemental selection retains every supplied table and original empty CSV; adverse results are not filtered.

Each main first pass contains 11 PRIMARY_NONOVERLAP scenes (300 reference words), two COMPLETE_OVERLAP scenes (59 words), one INCOMPLETE_REFERENCE scene (24 available words), and two STRICT_EMPTY_REFERENCE controls per output. ALL_COMPLETE_NONEMPTY combines the first two complete populations (13 scenes, 359 words). These populations overlap with that aggregate and must not be summed. The repeated four-scene subset has its own denominators, printed below; it is not an independent second 16-scene sample.

Word entries below are original PRIMARY_NONOVERLAP errors/reference words. Anonymous cp entries use ALL_COMPLETE_NONEMPTY, showing original first-final and latest-revised errors with their reference-word denominator. The distinct cp_first_display_label_final_words metric remains in the supplied tables and is not relabeled first-final. Unknown percentage is the original complete-population sole-speech Unknown fraction. Return entries are consistent/inconsistent/Unknown counts. Missing populations or values remain NA; no zero is imputed.

## Word and anonymous attribution results

### Main panel

| Candidate | ASR→ID | Rep | Cells | Primary word errors / ref | Complete first / latest cp errors / ref | Unknown % | Return C/I/U |
|---|---|---:|---:|---:|---:|---:|---:|
| B00 | O0→O0 | 1 | 16 | 60 / 300 | 212 / 212 / 359 | 18.5 | 10/7/7 |
| B00 | O1→O1 | 1 | 16 | 58 / 300 | 239 / 239 / 359 | 17.8 | 7/10/7 |
| B00 | O0→O0 | 2 | 4 | 3 / 31 | 33 / 33 / 52 | 21.2 | 1/3/2 |
| B00 | O1→O1 | 2 | 4 | 1 / 31 | 32 / 32 / 52 | 15.9 | 0/4/2 |
| B01 | O0→O0 | 1 | 16 | 60 / 300 | 227 / 227 / 359 | 27.1 | 3/10/11 |
| B01 | O1→O1 | 1 | 16 | 58 / 300 | 235 / 235 / 359 | 28.8 | 1/8/15 |
| B01 | O0→O0 | 2 | 4 | 3 / 31 | 32 / 32 / 52 | 25.2 | 0/2/4 |
| B01 | O1→O1 | 2 | 4 | 1 / 31 | 18 / 18 / 52 | 18.2 | 0/4/2 |
| B36 | O0→O0 | 1 | 16 | 60 / 300 | 225 / 225 / 359 | 20.9 | 10/6/8 |
| B36 | O1→O1 | 1 | 16 | 58 / 300 | 225 / 225 / 359 | 20.1 | 7/9/8 |
| B36 | O0→O0 | 2 | 4 | 3 / 31 | 32 / 32 / 52 | 23.6 | 1/3/2 |
| B36 | O1→O1 | 2 | 4 | 1 / 31 | 18 / 18 / 52 | 17.9 | 0/4/2 |
| C065 | O0→O0 | 1 | 16 | 60 / 300 | 220 / 220 / 359 | 34.1 | 3/5/16 |
| C065 | O1→O1 | 1 | 16 | 58 / 300 | 256 / 256 / 359 | 36.7 | 4/4/16 |
| C065 | O0→O0 | 2 | 4 | 3 / 31 | 22 / 22 / 52 | 39.4 | 1/2/3 |
| C065 | O1→O1 | 2 | 4 | 1 / 31 | 32 / 32 / 52 | 46.8 | 0/1/5 |
| C067 | O0→O0 | 1 | 16 | 60 / 300 | 202 / 202 / 359 | 36.8 | 1/3/20 |
| C067 | O1→O1 | 1 | 16 | 58 / 300 | 220 / 220 / 359 | 38.0 | 2/2/20 |
| C067 | O0→O0 | 2 | 4 | 3 / 31 | 33 / 33 / 52 | 41.6 | 0/0/6 |
| C067 | O1→O1 | 2 | 4 | 1 / 31 | 30 / 30 / 52 | 50.7 | 0/0/6 |
| C076 | O0→O0 | 1 | 16 | 60 / 300 | 218 / 218 / 359 | 34.2 | 3/5/16 |
| C076 | O1→O1 | 1 | 16 | 58 / 300 | 239 / 239 / 359 | 36.7 | 4/4/16 |
| C076 | O0→O0 | 2 | 4 | 3 / 31 | 20 / 20 / 52 | 39.4 | 0/2/4 |
| C076 | O1→O1 | 2 | 4 | 1 / 31 | 28 / 28 / 52 | 46.7 | 0/1/5 |
| C079 | O0→O0 | 1 | 16 | 60 / 300 | 222 / 222 / 359 | 33.8 | 3/6/15 |
| C079 | O1→O1 | 1 | 16 | 58 / 300 | 249 / 249 / 359 | 37.0 | 4/6/14 |
| C079 | O0→O0 | 2 | 4 | 3 / 31 | 22 / 22 / 52 | 39.3 | 1/2/3 |
| C079 | O1→O1 | 2 | 4 | 1 / 31 | 18 / 18 / 52 | 46.6 | 0/1/5 |
| C088 | O0→O0 | 1 | 16 | 60 / 300 | 220 / 220 / 359 | 34.4 | 2/5/17 |
| C088 | O1→O1 | 1 | 16 | 58 / 300 | 246 / 246 / 359 | 37.4 | 4/4/16 |
| C088 | O0→O0 | 2 | 4 | 3 / 31 | 22 / 22 / 52 | 39.5 | 1/2/3 |
| C088 | O1→O1 | 2 | 4 | 1 / 31 | 32 / 32 / 52 | 46.9 | 0/1/5 |
| C091 | O0→O0 | 1 | 16 | 60 / 300 | 210 / 210 / 359 | 34.3 | 3/5/16 |
| C091 | O1→O1 | 1 | 16 | 58 / 300 | 246 / 246 / 359 | 37.1 | 4/4/16 |
| C091 | O0→O0 | 2 | 4 | 3 / 31 | 22 / 22 / 52 | 39.6 | 1/2/3 |
| C091 | O1→O1 | 2 | 4 | 1 / 31 | 32 / 32 / 52 | 46.8 | 0/1/5 |
| C117 | O0→O0 | 1 | 16 | 60 / 300 | 256 / 256 / 359 | 33.3 | 2/8/14 |
| C117 | O1→O1 | 1 | 16 | 58 / 300 | 256 / 256 / 359 | 37.0 | 2/8/14 |
| C117 | O0→O0 | 2 | 4 | 3 / 31 | 22 / 22 / 52 | 39.6 | 0/2/4 |
| C117 | O1→O1 | 2 | 4 | 1 / 31 | 32 / 32 / 52 | 44.8 | 0/2/4 |
| C118 | O0→O0 | 1 | 16 | 60 / 300 | 254 / 254 / 359 | 32.9 | 2/7/15 |
| C118 | O1→O1 | 1 | 16 | 58 / 300 | 256 / 256 / 359 | 36.4 | 2/8/14 |
| C118 | O0→O0 | 2 | 4 | 3 / 31 | 22 / 22 / 52 | 39.7 | 1/2/3 |
| C118 | O1→O1 | 2 | 4 | 1 / 31 | 32 / 32 / 52 | 43.5 | 0/2/4 |
| C121 | O0→O0 | 1 | 16 | 60 / 300 | 248 / 248 / 359 | 29.6 | 3/9/12 |
| C121 | O1→O1 | 1 | 16 | 58 / 300 | 256 / 256 / 359 | 34.3 | 4/7/13 |
| C121 | O0→O0 | 2 | 4 | 3 / 31 | 33 / 33 / 52 | 36.2 | 1/3/2 |
| C121 | O1→O1 | 2 | 4 | 1 / 31 | 32 / 32 / 52 | 44.1 | 0/2/4 |
| C122 | O0→O0 | 1 | 16 | 60 / 300 | 250 / 250 / 359 | 29.6 | 3/9/12 |
| C122 | O1→O1 | 1 | 16 | 58 / 300 | 261 / 261 / 359 | 34.1 | 4/7/13 |
| C122 | O0→O0 | 2 | 4 | 3 / 31 | 33 / 33 / 52 | 36.3 | 1/3/2 |
| C122 | O1→O1 | 2 | 4 | 1 / 31 | 32 / 32 / 52 | 42.8 | 0/2/4 |

### Cadence gate

| Candidate | ASR→ID | Rep | Cells | Primary word errors / ref | Complete first / latest cp errors / ref | Unknown % | Return C/I/U |
|---|---|---:|---:|---:|---:|---:|---:|
| C071 | O0→O0 | 1 | 6 | 6 / 94 | 63 / 63 / 115 | 37.1 | 0/1/7 |
| C071 | O1→O1 | 1 | 6 | 4 / 94 | 63 / 63 / 115 | 38.7 | 1/1/6 |
| C082 | O0→O0 | 1 | 6 | 6 / 94 | 65 / 65 / 115 | 36.4 | 1/2/5 |
| C082 | O1→O1 | 1 | 6 | 4 / 94 | 51 / 51 / 115 | 37.4 | 1/2/5 |

### Exploratory arrival sentinel

| Candidate | ASR→ID | Rep | Cells | Primary word errors / ref | Complete first / latest cp errors / ref | Unknown % | Return C/I/U |
|---|---|---:|---:|---:|---:|---:|---:|
| C088 | O0→O0 | 1 | 1 | 1 / 41 | 1 / 1 / 41 | 28.8 | 1/0/0 |
| C088 | O1→O1 | 1 | 1 | 1 / 41 | 21 / 21 / 41 | 30.7 | 0/1/0 |
| C088 | O0→O0 | 2 | 1 | 1 / 41 | 1 / 1 / 41 | 28.9 | 1/0/0 |
| C088 | O1→O1 | 2 | 1 | 1 / 41 | 21 / 21 / 41 | 30.7 | 0/1/0 |
| C088 | O0→O0 | 3 | 1 | 1 / 41 | 1 / 1 / 41 | 28.8 | 1/0/0 |
| C088 | O1→O1 | 3 | 1 | 1 / 41 | 21 / 21 / 41 | 30.2 | 0/1/0 |
| C105 | O0→O0 | 1 | 1 | 1 / 41 | 1 / 1 / 41 | 29.0 | 1/0/0 |
| C105 | O1→O1 | 1 | 1 | 1 / 41 | 21 / 21 / 41 | 29.3 | 0/1/0 |
| C105 | O0→O0 | 2 | 1 | 1 / 41 | 1 / 1 / 41 | 28.9 | 1/0/0 |
| C105 | O1→O1 | 2 | 1 | 1 / 41 | 21 / 21 / 41 | 29.0 | 0/1/0 |
| C105 | O0→O0 | 3 | 1 | 1 / 41 | 21 / 21 / 41 | 31.2 | 0/1/0 |
| C105 | O1→O1 | 3 | 1 | 1 / 41 | 21 / 21 / 41 | 29.0 | 0/1/0 |

### Cross routes

| Candidate | ASR→ID | Rep | Cells | Primary word errors / ref | Complete first / latest cp errors / ref | Unknown % | Return C/I/U |
|---|---|---:|---:|---:|---:|---:|---:|
| C085 | O0→O1 | 1 | 16 | 60 / 300 | 249 / 249 / 359 | 37.1 | 4/4/16 |
| C085 | O0→O1 | 2 | 4 | 3 / 31 | 33 / 33 / 52 | 46.9 | 0/1/5 |
| C086 | O1→O0 | 1 | 16 | 58 / 300 | 224 / 224 / 359 | 34.3 | 3/5/16 |
| C086 | O1→O0 | 2 | 4 | 1 / 31 | 18 / 18 / 52 | 39.4 | 1/2/3 |

The tables are descriptive matched-panel totals for the exact routes, not newly estimated cross-candidate confidence intervals. Existing PAIRED_COMPARISONS files keep their original comparison definitions. In particular, exploratory sentinel repeats are retained after the observed arrival-boundary discrepancy; they do not establish an unseen-population effect. Cross-route changes move the ASR and identity taps explicitly and cannot be pooled with same-tap results.

## Naming and Unknown controls

Naming is evaluated separately from anonymous cp attribution. The complete PROFILE_NAME_RESULTS tables retain ALL, ENROLLED, withheld/unavailable and other original roster-status rows. The next table shows the ALL row for conditions with an actual gallery, using exact sole-active-sample denominators. Counts are samples, not people or turns. First-correct observed/missing values are turn counts; their conditional waits remain separately recorded and must not be interpreted as successful identification for missing turns.

| Cohort / candidate | ASR→ID | Rep | Gallery | Correct / wrong-known / Unknown samples | Sole-active samples | First-correct observed / missing turns |
|---|---|---:|---|---:|---:|---:|
| arrival / C088 | O0→O0 | 1 | FIXED_ROTATION_A | 0 / 0 / 175040 | 175040 | 0 / 3 |
| arrival / C088 | O1→O1 | 1 | FIXED_ROTATION_A | 0 / 0 / 175040 | 175040 | 0 / 3 |
| arrival / C088 | O0→O0 | 2 | FIXED_ROTATION_A | 0 / 0 / 175040 | 175040 | 0 / 3 |
| arrival / C088 | O1→O1 | 2 | FIXED_ROTATION_A | 0 / 0 / 175040 | 175040 | 0 / 3 |
| arrival / C088 | O0→O0 | 3 | FIXED_ROTATION_A | 0 / 0 / 175040 | 175040 | 0 / 3 |
| arrival / C088 | O1→O1 | 3 | FIXED_ROTATION_A | 0 / 0 / 175040 | 175040 | 0 / 3 |
| arrival / C105 | O0→O0 | 1 | FIXED_ROTATION_A | 0 / 0 / 175040 | 175040 | 0 / 3 |
| arrival / C105 | O1→O1 | 1 | FIXED_ROTATION_A | 0 / 0 / 175040 | 175040 | 0 / 3 |
| arrival / C105 | O0→O0 | 2 | FIXED_ROTATION_A | 0 / 0 / 175040 | 175040 | 0 / 3 |
| arrival / C105 | O1→O1 | 2 | FIXED_ROTATION_A | 0 / 0 / 175040 | 175040 | 0 / 3 |
| arrival / C105 | O0→O0 | 3 | FIXED_ROTATION_A | 0 / 0 / 175040 | 175040 | 0 / 3 |
| arrival / C105 | O1→O1 | 3 | FIXED_ROTATION_A | 0 / 0 / 175040 | 175040 | 0 / 3 |
| main / C088 | O0→O0 | 1 | FIXED_ROTATION_A | 85623 / 0 / 1719049 | 1804672 | 5 / 48 |
| main / C088 | O1→O1 | 1 | FIXED_ROTATION_A | 92390 / 0 / 1712282 | 1804672 | 5 / 48 |
| main / C088 | O0→O0 | 2 | FIXED_ROTATION_A | 0 / 0 / 244032 | 244032 | 0 / 12 |
| main / C088 | O1→O1 | 2 | FIXED_ROTATION_A | 0 / 0 / 244032 | 244032 | 0 / 12 |
| main / C091 | O0→O0 | 1 | FIXED_ROTATION_B | 111313 / 22890 / 1670469 | 1804672 | 10 / 43 |
| main / C091 | O1→O1 | 1 | FIXED_ROTATION_B | 89011 / 14139 / 1701522 | 1804672 | 7 / 46 |
| main / C091 | O0→O0 | 2 | FIXED_ROTATION_B | 27780 / 0 / 216252 | 244032 | 3 / 9 |
| main / C091 | O1→O1 | 2 | FIXED_ROTATION_B | 16520 / 0 / 227512 | 244032 | 3 / 9 |

NONE-gallery conditions retain their original no-gallery name-score controls and empty query files. Those rows do not demonstrate a C naming API in historical B00/B01/B36 or successful stranger identification. Unknown-name samples and absent first-correct observations stay explicit; zero wrong-known samples alone is not useful naming coverage.

The complete NAME_REVISIONS, RETAINED_ROWS, TURNS, PEOPLE, QUERIES and EMPTY_CONTROL_RESULTS files retain both successful and adverse outcomes. Name revision counts do not equal corrected identities, and anonymous transcript-label revisions do not equal name revisions. The modeled source/availability score clock is separate from actual emitted naming-clock observations in RUNTIME_RESULTS.md and the original post-analysis.

## Short replies, returns and empty controls

Every core authority's SHORT_REPLY_RESULTS preserves <1 s and 1–<2 s bins, source-turn and known-support denominators, Unknown/mapping ambiguity and contained-evidence observed/missing waits. A contained-window wait is a restricted evidence event, not full pipeline response latency. The main first pass includes seven subsecond and 11 one–<2-second turns, with scene dependence retained. Source-specific missing mappings remain unavailable.

Per-scene SCENE_RESULTS, the complete population rows and original EMPTY_CONTROL_RESULTS/COVERAGE tables are included, including original headerless empty outputs. No table is removed because a comparison or query set is empty. False merge, Unknown, inconsistent-return and wrong-known outcomes remain available beside wins. Strict-empty word insertions and false-name controls must be read with their own source/cast/reference denominators; zero saved-input drops is not evidence of zero recognition errors.

## Native proof and limits

Of 596 cells, 556 have the appropriate actual native/shared parity PASS; B00's 40 preserve exact original native-event attribution while shared/vector parity is unavailable. The original B00/B01 cleanup failure and separate verified archive recovery remain in the source chain; the recovery created no new physical cell. Typed normalization creates no additional physical execution.

The five continuous sessions—C065, C067, C088, C091 and B36 on O0—supply their own source/tail/drain and owner/scheduler closure evidence. Continuous diagnostics did not run shared replay or lexical/reference-name correctness scoring. They cannot be added to this paced score population. See RUNTIME_RESULTS.md for their separate original elapsed boundaries and large observed sample gaps.

Full-bank confirmation, cohort eligibility, operating selection and desktop/device transfer remain in their own evidence. These finite paced panels do not establish general live-acoustic enrollment, sustained XVF adaptive-state behavior, GUI timing or CM5 performance.

## Source lookup

PACED_NATIVE_RESULTS_SOURCE_BINDINGS.json binds all 64 completed repetition-specific score authorities and each original table. Supplemental selection maps their exact report paths to archive paths under tables/paced_scoring/. PROFILE_RESULTS and PROFILE_NAME_RESULTS supply the displayed values; no aggregate was recomputed. The other tables retain all original scalar metrics, scopes, states and nested statistics.

The five original score execution ledgers are c065_c067_actual_v1, six_closed_candidates_actual_v1, c088_c091_actual_v1, controls_recovered_actual_v1 and remaining116_actual_v1 under paced_scoring/. Their maintained actual-command READMEs and receipt bindings remain the execution authority. The main runtime timing projection is paced_compact_timing/full596_v1; continuous observations are fast_post_analysis/five_long_actual_v1.
