# S6C: start here

The offline integrated study and its native runtime measurements are complete. The package's final acceptance record is **ACCEPTANCE.json**; use it together with the execution and candidate-disposition tables. This is a controlled research result with limitations. It does not qualify live acoustic use, enroll a real user, change the production default, or start S6D.

The study used the existing 240 synthetic scenes and both previously captured XVF outputs. The XVF3800 was disconnected during this offline stage. The model weights, H2 work and canonical RIR library were preserved. CMU ARCTIC, HiFiTTS and the admitted Common Voice material were used; L2 ARCTIC was excluded.

## The decision this evidence supports

Retain four complete, explicit research conditions. Choose by the required behavior rather than mixing favorable parameters from different experiments.

| Condition | Useful role | Main constraint |
|---|---|---|
| Historical B36, O0 for recognition and identity, no gallery | Anonymous fallback and historical comparison | Its original application generation is part of the condition. It does not identify people by name. |
| C067, O0/O0, N03, cues off, no gallery | A conditional option when later revised anonymous attribution matters most | Better final attribution comes with worse initial-label attribution, less consistent classified returns and more Unknown support. |
| C088, O0/O0, N01, cues off, original A15 gallery | Controlled naming with the predefined A roster | False-known exposure, unsupported identities and delayed updates remain. |
| C091, O0/O0, N01, cues off, original B15 gallery | Controlled naming with the separate B roster | It is a different known/unknown condition, not a repeat of A or an automatic alternative. |

C065 O0 with no gallery is the matched anonymous control. It completed its own long session even though it is not one of the four operating selections. The original A15/B15 galleries each contain 15 profiles; they are not the later common-duration rosters of 14 people each.

OPERATING_ENVELOPES.md explains the tradeoffs. OPERATING_COMMANDS.md gives separate PowerShell and Anaconda/CMD commands, complete generation/profile/gallery bindings and model-free validation. The four validation commands actually ran. Optional file examples are reproduction instructions, not additional measured study sessions.

## The strongest positive and negative findings

There is no clean overall winner. On the 203 complete-reference scenes with 6,016 words, C067 O0 has 3,547 latest-label attribution edits versus 3,732 for C065 and 3,668 for B36. Its first-displayed-label attribution edits are worse: 4,052 versus 3,955 and 3,691. These attribution measures combine recognition and speaker assignment; they are not standalone speaker-identification accuracy.

“First displayed” here means final ASR words paired with their first displayed speaker labels. It is different from first-final attribution, partial-transcript accuracy and GUI latency. METRIC_READING_GUIDE.md explains these distinctions.

Directional evidence has conditional benefits and real counterexamples. It can improve pooled latest attribution under some matched new methods, while room-specific harm, shuffled-control exceptions, false cues on music and poor short-turn behavior remain. No spatial preset is forced into the final selection.

Enrollment is implemented in the actual research pipeline. Disjoint enrollment/calibration/probe material and known/withheld roster conditions are retained. More correct-name support can coexist with more false known names. Clean-source templates versus processed XVF probes remain a domain mismatch; this is not real-user or stranger-safety qualification.

Measured output delay is a material constraint. On the 16-scene O0 first pass, partial-event source-cursor lag p50/p95 was:

| Condition | p50 / p95, seconds |
|---|---:|
| B36 | 0.180 / 0.331 |
| C065 control | 0.375 / 0.695 |
| C067 | 0.585 / 1.210 |
| C088 A15 | 2.767 / 6.112 |
| C091 B15 | 2.437 / 4.812 |

Each row contains 377 original partial emissions over the same panel. These are descriptive event delays, not phonetic or GUI latency. The enrolled conditions are research options where delayed naming and abstention are acceptable; their observed delays do not support a low-latency live naming recommendation.

## What actually finished

- All 240 registered candidate labels remain accounted for: 196 C labels and 44 historical B labels. Candidate labels, policy scores, reused evidence and physical inference attempts are different counts. C083/C084 remain unexecuted aliases.
- The full confirmation pools and all required separate analyses are complete. Final candidate rows preserve panel-only, full-bank, native, reused and diagnostic scopes.
- The paced grid contains 596 completed cells: 520 main-panel, 24 cadence, 12 arrival-sentinel and 40 cross-route cells. Each of the 13 main conditions has 16 first-pass scenes and four repeated scenes per output. All 64 separate core/name scoring commands completed; repetitions are not pooled.
- Appropriate native/shared parity passed for 556 paced cells. B00's 40 retain exact original native-event attribution; shared/vector parity is unavailable.
- Five uninterrupted host sessions completed for the four retained conditions plus C065. Each consumed 1,827.426625 seconds of the same composition: 38 prior captures and 74 seconds of inserted silence. All five reached complete source cursors and closed their recorded scheduler, tail/drain and owners. Terminal recorded audio-drop counters were zero.
- Continuous lexical/name correctness was not scored. Name-event counts are not correct-name counts. Concatenated prior captures establish continuous host operation, not continuous hidden XVF adaptive state.

Long-session sampled RSS maxima ranged from 466.0 to 549.9 MiB, but resource-observation gaps reached 51.2–63.3 seconds. C event-consumer queues reached 2,697–3,405 events. These observations do not establish continuous worst-case memory, absence of leaks, low latency or CM5 performance.

The fresh machine census observes 5,891 physical attempts: 5,889 COMPLETE rows, one STARTED attempt without a confirmed session, and one failed outer C065 attempt whose native body completed. Thus 5,890 observed native-body completions are not 5,890 accepted attempts. All 7,411 concrete owner observations were closed. A virtual failed-C065 observer flag and historical unknown exits remain explicit. Successful later runs do not erase these failures.

## Read the package in this order

1. S6C_JOINT_REPORT.md and OPERATING_ENVELOPES.md for the integrated interpretation.
2. TRACK_AND_GALLERY_EXPLAINER.md, METRIC_READING_GUIDE.md and RECIPE_IDENTIFIER_GUIDE.md for concepts and identifiers.
3. PACED_NATIVE_RESULTS.md and RUNTIME_RESULTS.md for actual scores, timing, naming, repetitions and runtime limits.
4. CANDIDATE_COVERAGE_AND_DISPOSITION.csv, EXECUTION_COVERAGE.csv and the requirement-resolution evidence for complete scope accounting.
5. ENROLLMENT_RESULTS.md, CUE_AUTHORITY_FINDINGS.md and TOKEN_BOUNDARY_AND_STRATA_RESULTS.md for the controlled studies and adverse cases.
6. WORKBOOK_UPDATE.md for proposed yellow-highlighted insertion into Revision 17; the Word master itself is unchanged.
7. NEXT_STAGE_INPUTS.md and OPERATING_COMMANDS.md when preparing a later, explicitly bounded implementation prompt.

The tables retain all 207 original compact working tables, all late full-bank results, all paced repetitions and naming/empty controls, complete paired-stratum metrics, harm examples and token products. Original headerless empty CSVs are preserved as empty outputs. Byte-identical members can be stored once with explicit aliases. All 33 broad STRATA companion aggregate copies are uniformly indexed locally rather than selected by outcome. Full per-score authority bodies, template proof chains, material-review bodies, duplicate route provenance and superseded packaging/documentation reviews are also uniformly indexed locally. Their distinct numerical results, actual settings, compact execution facts and final reviews remain in the package. Raw journals, vectors, audio and models remain local with exact bindings.

PACKAGE_CONTENT_SELECTION.json is the final map of stored members, byte aliases and exactly indexed local dependencies; it supersedes earlier packaging plans. LOCAL_ARTIFACT_INDEX.json maps the local evidence and required deliverables. PACKAGE_MANIFEST.json and CHECKSUMS_SHA256.txt identify actual archive members. The full local physical projection preserves verbose provenance behind the compact all-attempt execution CSV.

## Resources and measurement constraints

At the final September 12, 17:49 UTC snapshot, C: had 65.73 GiB free, G: 313.76 GiB free, and available RAM was 35.33 GiB. Both SSDs were reported Healthy/OK by Windows; this was not a surface or endurance test. Counted S6C report/staging/payload files occupied 71.61 GiB. One shared Codex node_modules junction was deliberately not traversed; its scope classification and the original snapshot's unknown flag are both retained.

Use admitted PASS/REVIEW measurements only. Early tests and RETAKE recordings remain excluded. The two operator-confirmed 100 m metadata errors retain the 1.00 m correction overlays. Retained distances are 0.46–4.07 m. Angle sign checks are internal consistency checks with manual uncertainty, not physical calibration. Apply the retained RIR timing convention and O0 gain only once.

Stop here. Real-user enrollment, new acoustic/room collection, continuous-device behavior and CM5 deployment require a later explicit stage. This handoff supplies context and evidence for that decision.

