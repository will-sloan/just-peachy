# S6C recipe identifier guide

The N00–N14 identifiers in the executable recipe registry are distinct from similarly numbered ideas in the supplied planning pack. Use the registered purpose and exact changes below. A candidate ID such as C072 names a concrete configuration; it is not a second interpretation of an idea number.

| Recipe | Registered purpose | Changed settings relative to N01, unless noted |
|---|---|---|
| N00 | Historical short fixed evidence and continuous original ASR; v3 policy only | See registered source/control |
| N01 | Simultaneous .5s short and 1.5s mature, .25/.5s hops, full-window RMS, fraction purity | {} |
| N02 | N02 context refresh rescue | {"segmentation.hop_sec":0.25,"embedding.window_sec":1.0} |
| N03 | Long mature context 3s | {"embedding.window_sec":3.0} |
| N04 | Short .75s interaction | {"embedding.short_window_sec":0.75} |
| N05 | Gate-only purity companion | {"embedding.purity_policy":"gate_only"} |
| N06 | N06 clipped-window protection rescue | {"embedding.clipping_fraction_max":0.001} |
| N07 | Per-track uncertainty/evidence debt cadence | {"embedding.cadence_policy":"uncertainty"} |
| N08 | Hard powerset post-policy companion | {"segmentation.post_policy":"hard_argmax_fraction"} |
| N09 | Dispatch RMS companion | {"embedding.rms_policy":"dispatch"} |
| N10 | ASR decoder isolated at original 100ms host read | {"asr.decoding_method":"modified_beam_search","asr.max_active_paths":2} |
| N11 | ASR host dispatch isolated with greedy | {"asr.journal_read_ms":50} |
| N12 | Endpoint isolated with continuous greedy | {"asr.endpoint_rule1_silence_sec":1.6,"asr.endpoint_rule2_silence_sec":0.8} |
| N13 | Decoder plus host dispatch interaction | {"asr.decoding_method":"modified_beam_search","asr.max_active_paths":2,"asr.journal_read_ms":50} |
| N14 | Decoder/host/endpoint interaction | {"asr.decoding_method":"modified_beam_search","asr.max_active_paths":2,"asr.journal_read_ms":50,"asr.endpoint_rule1_silence_sec":1.6,"asr.endpoint_rule2_silence_sec":0.8} |

N00 is the preserved historical neural-evidence recipe reused with explicitly different v3 tracking/commit semantics. It is not an S6B-equivalent tracker baseline. N01 is the common simultaneous short/mature native recipe.

Recipe N08/C072 is the hard powerset segmentation post-policy. The planning idea N08 clean-shadow gallery is implemented as the distinct structural C129/C130 cue-off/on family.

N07 is per-track uncertainty/evidence-debt cadence, with C071 cue-off and C082 real-cue runtime variants. N13/C077 and N14/C078 are ASR decoder/dispatch/endpoint interactions; their embedding schedule stays fixed.

The additive N07 neighborhood retains the original 1.0-second voice-observation floor in C071/C082. C191/C192 change only that floor to 0.5 seconds, respectively cue-off/real; C193/C194 use 2.0 seconds. All eight concrete tap profiles preserve the exact parent settings apart from their ID and this one field. They require their own state-dependent native observations. The floor governs observation scheduling, not an embedding waveform duration or proof that an admitted mixed waveform belongs to the particular indebted track.

C083/C084 are explicit same-tap N01 aliases; C085/C086 are the two actual split routes. C195/C196 retain recipe N01 but add endpoint-only and combined tracking/endpoint advice, respectively; they are distinct from N12 fixed endpoint timings. Their native dependency is FULL_PROFILE_AND_CUES because advice can change ASR boundaries and words. Other gallery/tracking reuse still requires the exact admitted upstream dependencies.

This table is a configuration map, not completed execution or a claim that every field is activated on the bank. The native and scored coverage receipts govern those claims.
