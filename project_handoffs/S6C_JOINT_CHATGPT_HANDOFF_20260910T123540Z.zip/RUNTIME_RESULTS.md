# Measured runtime and continuous-session findings

Actual runtime observations are complete. Retained-condition selection and final acceptance are bound separately. These results establish complete saved-input delivery and process/scheduler closure for admitted conditions; accuracy, useful response time and hardware suitability remain separate judgments.

## What ran

The completed paced grid contains596 cells, including additional scientific diagnostics:520 main-panel,24 cadence-gate,12 arrival-sentinel and40 cross-route cells. The main panel covers B00, B01, B36, C065, C067, C076, C079, C121, C122, C117, C118, C088 and C091. Each main condition has16 first-repetition scenes per output and four repeated scenes per output. The diagnostic populations retain their own scopes and repetitions.

All596 have actual analysis, typed runtime normalization and separate core/name scoring. Appropriate native/shared parity passes for556. B00's40 controls retain exact original native-event attribution with shared/vector parity unavailable. This is not a failed shared-parity test. The normalization creates zero additional physical sessions.

Five further uninterrupted host sessions exercised C065 O0/NONE, C067 O0/NONE, C088 O0/original A15, C091 O0/original B15 and historical B36 O0/NONE. They reuse one1,827.426625-second composition:38 existing captures and74 seconds of inserted silence. Each covers30 minutes27.426625 seconds of source audio. These are five host sessions over dependent inputs, not190 independent scenes or a continuous XVF hidden-state experiment. The full study's physical inventory is reported separately.

All original long parent exits were0; original native, observer and released-lease records agree, and all recorded owners are closed. The dispatcher ended at2026-09-12T16:40:58.180701Z. No source was regenerated and the disconnected XVF3800 was not opened.

## Short-panel timing: O0/O0

These are descriptive observations for exact original conditions. The first repetition has16 cells and377 transcript_partial emission records per row below. Ratios are per-cell UTC source-start to session-completion duration divided by source duration. Event lag is the original emission time relative to the event's source cursor; it is not phonetic latency, a word-boundary timing score or a measured GUI refresh.

| Exact condition | Median UTC duration/source ratio | Partial-event cursor lag p50/p95, seconds | Maximum sampled RSS sum, MiB |
|---|---:|---:|---:|
| B36 historical, no gallery |1.007|0.180 /0.331|446.6|
| C065 N01, no gallery control |1.020|0.375 /0.695|490.1|
| C067 N03, no gallery |1.037|0.585 /1.210|528.9|
| C088 N01, original A15 |1.237|2.767 /6.112|491.8|
| C091 N01, original B15 |1.201|2.437 /4.812|493.3|

The four-case repeated subset remains separate. Each row below contains54 partial-emission records. It is not a second16-case sample, and combining it with the first repetition would overweight those four scenes.

| Exact condition, repetition2 | Median UTC duration/source ratio | Partial-event cursor lag p50/p95, seconds |
|---|---:|---:|
| B36 historical, no gallery |1.007|0.154 /0.310|
| C065 N01, no gallery control |1.027|0.353 /0.674|
| C067 N03, no gallery |1.057|0.668 /1.435|
| C088 N01, original A15 |1.204|1.805 /5.199|
| C091 N01, original B15 |1.202|1.853 /4.517|

The enrolled conditions show materially longer recorded event-cursor lags than the anonymous control in this panel. Their successful completion therefore does not justify describing them as low-latency live naming. These are observed whole-condition differences, not an isolated causal cost of a particular threshold or gallery operation. The historical B36 generation also differs in pipeline and instrumentation; its favorable observations do not identify one interchangeable setting.

The ratio includes source-paced waiting and observed scheduling. It is not algorithm-only real-time factor. Model loading, native interval, historical full-worker interval and complete outer invocation have different boundaries. Their nested durations must not be added. Full outer validation can be much longer than the processed source.

The complete72-group projection retains both taps, exact conditions, repetitions and all three diagnostic populations. Scalar metric observed/missing counts denote cells; event-lag counts denote emissions; name-delay counts denote turn occurrences within declared roster/reference/attainability and censoring bins. No confidence interval over independent speakers or rooms is inferred from emission quantiles.

## Continuous-session observations

Every session reached the full1,827.426625-second ASR and speaker source cursors, retained complete source journals and tail/drain proof, and closed its scheduler with zero pending events. All recorded terminal audio-drop, input-overflow and capture-reserve-failure counters are zero. Complete source delivery does not establish first/last-word or person-name correctness.

The first four elapsed values below are the original C native interval. B36 supplies its original full-worker interval, which includes different admission/loading boundaries. They are shown separately by that definition and are not an algorithm-speed ranking.

| Session | Original C native seconds / B36 full-worker seconds | Resource samples | Largest observed sampling gap, seconds | Sampled RSS sum maximum, MiB | Sampled USS maximum, MiB |
|---|---:|---:|---:|---:|---:|
| C065 O0/NONE |1987.752|338|59.385|512.7|454.1|
| C067 O0/NONE |1970.247|319|63.305|549.9|492.3|
| C088 O0/A15 |1993.139|330|51.186|517.9|459.3|
| C091 O0/B15 |1993.045|319|59.462|517.5|458.9|
| B36 O0/NONE |1875.202|586|56.109|466.0|406.3|

C resource counts include the terminal observation. B36's586 are periodic resource observations; its separate child-exit terminal record contains no resource sample. C model startup is separately recorded at approximately1.98 to 2.29 seconds. The source diagnostics retain native versus total observed-worker boundaries. B36's coordinator memory observations remain separate from its worker-tree series.

RSS is the sampled process-tree sum upper bound; USS is the recorded private-resident metric. Neither is a continuously measured peak or a complete device memory budget. Large sampling gaps limit conclusions about transient maxima, growth rates and memory leaks. The results do not establish a CM5/Pi memory or latency guarantee.

The C event-consumer queue reached sampled maxima of3,033,3,405,2,697 and3,157 events for C065/C067/C088/C091 respectively. These are not scheduler-internal pending events or lane cursor lag. A terminal scheduler count of zero does not imply the event-consumer queue was always empty. B36 does not expose the same C queue series; its original lane-lag instrumentation remains separate. The cause of a particular backlog excursion is not established by a sparse resource sample.

All five sessions emitted105 final-transcript events. C065/C088/C091 recorded999 voice decisions each; C067 recorded795 and B36 recorded1,134. C088/C091 each recorded419 identity-decision events. These are activation counts, not counts of correct words, correct names or distinct people. A lifetime count of track IDs likewise does not describe the simultaneous live population. The held continuous diagnostics do not run shared replay, lexical scoring or reference-name correctness scoring, so those fields stay unavailable.

## Clock, observation and environment limits

The596 paced analyses preserve30 raw wall-timestamp reversals. All476 applicable C naming clocks are valid under their declared naming-clock checks;120 historical rows have no equivalent C naming-clock value. Raw log ordering and the narrower naming-clock test are different properties.

The four C continuous diagnostics preserve1,0,1 and4 raw wall-timestamp reversals respectively. The historical long diagnostic does not provide an equivalent reversal count. Do not report all original event timestamps as monotonic or silently repair recorded clocks.

All study model/analysis processes were stopped for native execution. The existing H2 storage guardian remained unchanged and can introduce periodic storage IO. The desktop was not asserted to be globally idle. Source/asset/storage observations and their sampling gaps remain part of the experiment's environment; a temporal association alone does not establish that H2 or one observer caused a particular delay.

## Consequence for the retained conditions

B36 remains the material historical fallback. C067 provides a conditional final-attribution tradeoff rather than a broad improvement: its full-bank latest-label errors improve while initial-label, Unknown and return behavior can worsen. C088/C091 preserve two controlled known/unknown rosters with actual native enrollment activity, alongside false-known exposure and recorded naming-path delay. None receives a default promotion or an untested mixture of another candidate's settings.

The operating table must bind each retained exact condition to both its own balanced paced evidence and its own continuous session. These results support reproducible desktop research conditions; live acoustic/device-domain enrollment, stranger rejection, GUI timing, sustained XVF adaptive state and CM5 execution remain separate validation boundaries.

## Evidence

- paced_compact_timing/full596_v1/RESULT.json:758bc7d437e7eacfca95ea56524d3c9236e86c7a38e526be436f8978ad87d9b2; GROUP_SUMMARIES.json:5878092024723097cf2d7484e84aeada6ca63e78de0ad2fde5ea296491e61a81.
- Root paced actual review:fff62a086a51586e45cd757e9ecaaf3048fc3789f1edb8a59d8819489c3fd894.
- fast_post_analysis/five_long_actual_v1/ACTUAL_EXECUTION_RESULT.json:f7b16109b06eb8eae59c4522f12a718d11da17e0d4924766b0d902292b0d429b.
- COMPACT_LONG_OBSERVATIONS_V1.json:fc59e34e8767353374af3b0f1266ff3faa7299aca90a13ec3af1869fdc7a6244; normalization RESULT:6c20c932bac2b01a55ad7b894f5adbc0bd1da53484aad681c185a1aa1b0eda3c.
- runtime_progress/FIVE_LONG_CURRENT_CLOSURE_V1.json:ac45f315c2172598082202257197074f955e5fe5a4aa0e40a33a9ccd715315a3; independent closure review:b0fd6ce13486394783214ea3e669caabeac1d2bd444446939bf0d8896bf51d11.
- Maintained actual-command READMEs accompany both projections. Original detailed event/trajectory artifacts remain locally indexed; no raw journal is required to read this comparison.
