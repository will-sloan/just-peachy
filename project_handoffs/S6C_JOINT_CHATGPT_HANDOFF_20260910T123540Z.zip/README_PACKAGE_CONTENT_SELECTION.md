# Compact package-facing content map

PACKAGE_CONTENT_SELECTION.json supplies the final package membership rules, complete byte-alias map and exact indexed-local source bindings. The actual PACKAGE_MANIFEST.json is the stored-member authority. The compact map deliberately refers to that filename without a self-hash or duplicated stored-member path/hash list. The complete local V3 planning authority is separately bound for review.

All distinct numerical tables, uncertainty arrays, adverse rows, actual settings, compact rosters/ECQ/template metadata, all240 candidates and all5891 attempts remain represented. Only the declared uniform proof-metadata roles are local-indexed. Final acceptance belongs to the root-owned ACCEPTANCE.json. All historical selection maps remain unchanged.

## Inputs and outputs

Input is the bound complete V3 selection and its existing per-member measurements. Outputs are this compact map/README and PACKAGE_FACING_BUDGET_V1.json. The compact map and README are each measured once. The already measured final START cost is reused; no scientific input or original metadata is recompressed.

## PowerShell

    $report = 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z'
    Get-Content -LiteralPath "$report\compact_score_tables\analysis_first_v3\package_facing_v1\PACKAGE_FACING_BUDGET_V1.json"
    Get-FileHash -Algorithm SHA256 -LiteralPath "$report\compact_score_tables\analysis_first_v3\package_facing_v1\PACKAGE_CONTENT_SELECTION.json"

## Anaconda Prompt or CMD

    set "REPORT=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z"
    type "%REPORT%\compact_score_tables\analysis_first_v3\package_facing_v1\PACKAGE_FACING_BUDGET_V1.json"
    certutil -hashfile "%REPORT%\compact_score_tables\analysis_first_v3\package_facing_v1\PACKAGE_CONTENT_SELECTION.json" SHA256

No installation, model, scoring or new persistent executable helper is involved. Actual packaging must verify the full content/alias plan, exact source bytes and final size. New root metadata and ZIP-specific overhead remain outside the partial budget.
