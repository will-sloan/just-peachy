# Actual endpoint-advice activation and limits

The endpoint branches were exercised on genuine native inputs. The completed audit verifies448 logical views using336 distinct native receipts/event logs:112 C065 native sources reused for both C065/C079 logical policies,112 new C195 sources, and112 new C196 sources. All56 registered cases/both taps remain present, including11 strict-empty/music cases per route. It made no model calls or new native sessions and scanned each distinct native log once.

| Native branch or shared parent | Tap | Cells | Advisor observations | Proposals | Accepted advice-only resets | Rate-limited proposals | Native-only resets | Total resets | Cases with accepted advice |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| C065, also source for C079 | O0 | 56 | 0 | 0 | 0 | 0 | 802 | 802 | 0 |
| C065, also source for C079 | O1 | 56 | 0 | 0 | 0 | 0 | 807 | 807 | 0 |
| C195 | O0 | 56 | 24976 | 23 | 20 | 3 | 797 | 817 | 14 |
| C195 | O1 | 56 | 24976 | 19 | 16 | 3 | 802 | 818 | 11 |
| C196 | O0 | 56 | 24976 | 23 | 20 | 3 | 797 | 817 | 14 |
| C196 | O1 | 56 | 24976 | 19 | 16 | 3 | 802 | 818 | 11 |

There are no coincident native/advice resets in these actual cells. Both endpoint branches have36 accepted advice-only resets and six rate-limited proposals; the other49,910 advisor observations report no proposal. The total reset increase is26 per endpoint profile, not36, because native-only reset counts decrease by10. Exactly one reset corresponds to each native/advice OR request, and accepted-advice totals match the dispatch flags. C195/C196 activation counts match on each tap; this does not imply their anonymous label outcomes match.

All admitted source spans, PCM receipt counters/hashes, final ASR cursor, tail counts and nonobserved EOF drain checks pass. The largest remaining unanalyzed short speaker tail is0.1954375 seconds; complete ASR coverage does not mean every speaker-lane tail produced an embedding. Scheduler-reported maximum pending counts are28/29 for the parent O0/O1 sources,28/30 for C195 and29/31 for C196. Continuous journal backlog peaks remain unavailable.

Per56 cells, measured advisor compute sums are1.071094/1.054584 seconds for C195 and1.046566/1.048562 for C196. These are nested native costs, not extra terms to add to full ASR dispatch time. Independently executed accelerated worker totals do not establish a source-paced speedup or a CM5 budget.

The deterministic token alignment has the same first/last reference-token deletion counts in all four branches: primary O0 first1/last0, primary O1 first0/last1 (34 scenes each), and first0/last0 on each six-scene serialized-overlap subset. This narrow observation does not exclude interior errors or prove that endpoint advice avoided phonetic clipping. Primary errors are100/101 for the parents and100/103 for the endpoint branches; serialized-overlap errors are49/47 versus51/51. Official MIMO/cp scores remain in the separate frozen scorer. Incomplete full-reference token metrics are null. Individual empty reset returns are unlogged and remain unavailable; strict-empty decoded insertions are1/2 per11 cases on O0/O1.

The score-table interpretation remains `endpoint_factorial_comparisons_v1/INTERPRETATION_V1.md`; its earlier wording that an event audit was pending is a preserved snapshot now resolved by this completed audit. `SUMMARY_V2.json` is the current compact projection. It explicitly corrects V1's empty-sum zero fields for entirely unscored incomplete-reference token populations to null, with V1 preserved and bound. No raw audit, prediction, metric or source was changed. These observed adverse/conditional results support retaining endpoint advice as a tested failure boundary, not promoting a general benefit.
