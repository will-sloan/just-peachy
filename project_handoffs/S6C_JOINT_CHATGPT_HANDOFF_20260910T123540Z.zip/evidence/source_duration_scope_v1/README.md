# Canonical source duration clarification

This metadata audit preserves the exact 480 prepared input extents. It does not reopen audio, change a file, rerun inference or infer duration from an S45 scene identifier.

There are 236 cases at 44.6954375 seconds per output, one case (S45_03_11) at 46.6954375 seconds, and three cases (S45_06_01, S45_06_06, S45_06_11) at 99.6954375 seconds. Every case has matching O0/O1 frame counts. The complete bank totals 174,302,480 samples, or 10,893.905 seconds, per output. Using 240 times the modal duration would omit 167 seconds of retained input extent per output.

RESULT.json binds the exact input-index buffer, integer frame counts, declared original journal sizes and all four exceptions. This is a clarification of existing input metadata, not a fresh verification of PCM bytes, an audio-quality finding or permission to trim a tail. Scoring and native jobs retain their own exact source durations. The balanced source-paced main panel contains the separately bound selected views; its 40-cell duration is not multiplied to estimate the whole bank.

Inspect using PowerShell:

    Get-Content -LiteralPath 'RESULT.json' -Raw

Or Anaconda Prompt / Windows Command Prompt, from this folder:

    type RESULT.json

This folder contains data and a reading guide, with no new executable helper. The original input index and earlier source audit remain unchanged.
