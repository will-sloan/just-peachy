# Clean-source enrollment and calibration result

The completed source audit provides 385 E clips and 367 disjoint C clips while retaining all777 canonical Q occurrences and43 metadata people. Nested5/15/30-second estimated usable tiers cover37/30/28 people. C material exists for36;34 have an available E tier used by this experiment. All declared E/C/Q parent, waveform, text and native prompt-ID intersections are empty.

Actual native enrollment produced95 templates:73 PASS and22 REVIEW_LOW_CONSISTENCY, all retained. The fixed and explicit-setup conditions resolve2,169 case/tier/condition rows to176 real ProfileStore manifests, including344 explicit empty rows. One shared ReDim model made1,976 calls (1,274 unique E windows and702 C windows), with855 exact E-window cache hits. No Q embedding, hardware pass or model training occurred.

All seven predeclared C-only grid fits selected score0.45 and margin0.10. Their C queries contain only that condition's known gallery people; withheld strangers are absent. Zero wrong-known acceptances on these calibration queries is a fitting result, not a stranger or Q validation result. The native field `unknown_rejected` counts unresolved known-C queries.

The actual-C branch proof uses original identity thresholds and qualified evidence with a native gallery and frozen v3 scheduler. Six present-person observations produce one tentative and five confirmed correct names; absent-person and distractor-only conditions each leave all six unresolved. A second conflicting voice forms anonymous track2 and stays unnamed. This proves that the chosen gallery branch executes; it does not demonstrate same-track name revocation, native ASR integration or Q accuracy.

Independent reviews verified8,183 material conditions and20,905 native enrollment/gallery/calibration conditions with zero reviewer model calls. A separate183-check review bound all30 C vectors and actual name decisions in the branch proof. Exact receipt/source hashes are in the adjacent JSON.

Enrollment remains a clean-source read-clip proxy with domain mismatch. Three HiFiTTS E/C splits share a non-Q book across different chapters. Sparse Common Voice tiers, metadata identity limits, low-consistency templates and unavailable conditions remain explicit. No private gallery is used or modified.
