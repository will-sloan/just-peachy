# Fixed-scope strata/adverse synthesis

This report compares existing score aggregates after verifying exact per-scene memberships. All four populations and ten dimensions remain separate. Multi-memberships overlap; do not sum them. Core strata do not measure actual known-name accuracy. No confidence interval, new score, reset/timing causality or final operating selection is produced.

28 routes, 30 explicit contrasts, 2912 original selected strata and 18720 paired metric rows are retained.
Full word/first-display/latest cp values are unavailable on incomplete and strict-empty populations. Unknown support, classified returns and empty insertions use their own observed denominators. Primary word errors use serialized WER; complete overlap word errors use the inherited MIMO scope.

The following compact rate maxima are post-result descriptive examples within this predeclared analysis. Strictly positive differences only; zero is not harm. Tiny-support groups are retained and flagged. Count maxima and all tied groups are in the companion JSON.

| Contrast | Positive metric/population rate maxima | Count maxima |
| --- | ---: | ---: |
| C065_C067_O0 | 9 | 9 |
| C065_C067_O1 | 8 | 8 |
| C065_C076_O0 | 10 | 10 |
| C065_C076_O1 | 9 | 9 |
| C065_C079_O0 | 9 | 9 |
| C065_C079_O1 | 6 | 6 |
| C065_C121_O0 | 7 | 7 |
| C065_C121_O1 | 6 | 6 |
| C121_C122_O0 | 4 | 4 |
| C121_C122_O1 | 4 | 4 |
| C079_C122_O0 | 6 | 6 |
| C079_C122_O1 | 6 | 6 |
| C117_C118_O0 | 5 | 5 |
| C117_C118_O1 | 5 | 5 |
| C117_C065_O0 | 7 | 7 |
| C117_C065_O1 | 7 | 7 |
| C117_C121_O0 | 5 | 5 |
| C117_C121_O1 | 6 | 6 |
| C118_C079_O0 | 8 | 8 |
| C118_C079_O1 | 6 | 6 |
| C118_C122_O0 | 5 | 5 |
| C118_C122_O1 | 5 | 5 |
| B36_C065_O0 | 10 | 10 |
| B36_C065_O1 | 9 | 9 |
| B36_C067_O0 | 9 | 9 |
| B36_C067_O1 | 7 | 7 |
| B36_C076_O0 | 11 | 11 |
| B36_C076_O1 | 10 | 10 |
| C065_C085_O0_cross | 9 | 9 |
| C065_C086_O1_cross | 9 | 9 |

These are descriptive flags across overlapping groups, not independent failures or an accuracy ranking. Every per-contrast maximum and all ties are retained in DESCRIPTIVE_HARM_EXAMPLES.json. The brief examples below take the largest positive rate delta per metric and original population across these already-selected per-contrast maxima, then contrast ID/dimension/value lexically; metrics and populations are never compared to one another.

- B36_C076_O0, word / PRIMARY_NONOVERLAP: family=F06; left 67/562, right 69/562 (fraction); right-left 0.00355872. Eligible scenes 20/20; flags none.
- B36_C065_O0, cp_first_display_label_final_words / PRIMARY_NONOVERLAP: source_level_db=-6; left 171/215, right 247/215 (fraction); right-left 0.353488. Eligible scenes 7/7; flags none.
- C065_C076_O1, cp_first_display_label_final_words / COMPLETE_OVERLAP: room=Library Conference Room; left 76/139, right 85/139 (fraction); right-left 0.0647482. Eligible scenes 5/5; flags none.
- B36_C067_O0, cp_latest_revised / PRIMARY_NONOVERLAP: snr_db=10; left 23/87, right 53/87 (fraction); right-left 0.344828. Eligible scenes 3/3; flags ['fewer_than_5_eligible_scenes'].
- C065_C067_O1, cp_latest_revised / COMPLETE_OVERLAP: source_level_db=-6; left 161/282, right 182/282 (fraction); right-left 0.0744681. Eligible scenes 10/10; flags none.
- B36_C067_O1, unknown_support / PRIMARY_NONOVERLAP: family=F03; left 577639/2579520, right 1127079/2579520 (fraction); right-left 0.213001. Eligible scenes 20/20; flags none.
- B36_C067_O1, unknown_support / COMPLETE_OVERLAP: room=Library Conference Room; left 126567/450320, right 229486/450320 (fraction); right-left 0.228546. Eligible scenes 5/5; flags none.
- B36_C076_O1, unknown_support / INCOMPLETE_REFERENCE: room=Arise Floor 2 Kitchen; left 106456/668800, right 257960/668800 (fraction); right-left 0.226531. Eligible scenes 5/5; flags none.
- C065_C067_O1, inconsistent_returns / PRIMARY_NONOVERLAP: snr_db=20; left 0/4, right 2/4 (fraction); right-left 0.5. Eligible scenes 4/4; flags ['fewer_than_5_eligible_scenes', 'small_classified_return_turns'].
- C065_C121_O0, inconsistent_returns / COMPLETE_OVERLAP: room=Upper Loeb; left 0/4, right 1/4 (fraction); right-left 0.25. Eligible scenes 4/4; flags ['fewer_than_5_eligible_scenes', 'small_classified_return_turns'].
- C065_C121_O0, inconsistent_returns / INCOMPLETE_REFERENCE: room=Arise Floor 2 Kitchen; left 2/6, right 5/6 (fraction); right-left 0.5. Eligible scenes 5/5; flags none.

N08/N10 adverse qualifications remain in the separately bound completed report; they are not added to this grid. Future package scope must retain access to every original paired row and unavailable result.
