# Exact-route metadata coverage snapshot

190 candidates /376 declared routes; 372 have all56 panel cases in completed indices; 0 partial and 4 absent.
368 routes have completed core-score declarations for all56 panel cases. This is not a physical-run count or a payload audit.

| Candidate | ASR / identity | Recipe | Predicted /56 | Core scored /56 |
|---|---|---|---:|---:|
| C083 | O0 / O0 | N01 | 0 | 0 |
| C084 | O1 / O1 | N01 | 0 | 0 |
| C085 | O0 / O1 | N01 | 0 | 0 |
| C086 | O1 / O0 | N01 | 0 | 0 |

C083 O0/O0 and C084 O1/O1 exactly alias C065 on the corresponding same tap after removing only executable profile_id; actual condition settings and tap declarations match in currentV5 and frozenepoch2. Their raw candidate coverage remains separate above.

The enrollment manifest has28 naming candidates ×6 cases ×2 taps =336 jobs. Its policy panel adds C065/C079 NONE-gallery controls:30 candidates ×56 ×2 =3360. No naming candidate from that panel is omitted from enrollment_v1.

Coverage presence from exact read buffers of COMPLETE non-fixture prediction indices; score presence only from matching completed analysis-receipt declarations. No waveform/vector/model/prediction/score payload hash or metric recomputation. Multiple artifacts for a candidate/case/route are references, not extra coverage or physical attempts. Mutable study snapshot, not final completion. Raw labels and aliases remain separate.
