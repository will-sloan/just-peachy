# Continuous host-policy lifecycle diagnostic

The prospectively registered family round-robin contains 38 complete paired
captures from all 12 families. It lasts 1,827.426625 seconds, including 74 seconds
of explicit inter-capture silence. The earlier canonical-order alternative was
previewed as metadata only and was never composed or executed.

C001 and C002 each processed the same 4,514 actual historical R0 observations in
one shared v3 policy session, with no policy reset at capture boundaries. Both
used O0, cap 16, old_voice_gate, no cues and no naming gallery. C001 disables
retirement; C002 uses retire_archive with an archive cap of 128. There were zero
neural invocations. Original within-capture gaps and neural reset boundaries
remain; added silence does not invent cached neural events.

| Observed measure | C001, no retirement | C002, retire/archive |
|---|---:|---:|
| Speaker decisions | 1,116 | 1,116 |
| Unknown decisions | 1,041 | 736 |
| Audio clean-support gate rejections | 724 | 724 |
| Peak live tracks | 16 | 10 |
| Peak archived tracks | 0 | 128 |
| Lifetime external IDs allocated | 16 | 253 |
| Retirement events | 0 | 282 |
| Archive reactivations / evictions | 0 / 0 | 35 / 119 |
| Capacity rejection events | 314 | 0 |
| Unique clean evidence seconds rejected at capacity | 141.8251875 | 0 |
| Final live / archived tracks | 16 / 0 | 6 / 128 |
| Partial / final transcript events | 980 / 103 | 980 / 103 |
| Forward transcript label revision events | 238 | 488 |

The first C001 capacity rejection arrived at modeled time 145.4054085 seconds.
Blocked seconds measure clean-support union rejected at full capacity; they are
neither wall time nor continuous Unknown duration. Retirement counts can exceed
allocated IDs because a track can return from the archive and later retire again.
Both schedulers closed with no pending events and retained 103 utterances. Every
observed live/archive count stayed within its configured bound.

These results demonstrate capacity and retirement behavior on the supplied
evidence. They do not validate voice recognition, cue benefit, naming or family
rankings. N00's reconstructed clean-support path rejects much historical
evidence: 724 of 1,116 decisions were rejected by that gate in each run. C001 also
saturates. The later selected continuous native test must use its separately
admitted fresh recipe; it must not inherit an accuracy claim from this diagnostic.

The final tracker array/shallow-object estimates were 36,864/7,296 bytes for C001
and 127,488/61,104 bytes for C002. These are not recursive heap or process RSS.
Measured policy-loop times were 2.565 and 2.641 seconds, excluding historical
source loading and verification; these are not native throughput estimates.

The authoritative JSON summary binds the composition, sequence registration,
independent helper reviews, fixtures, both actual results, snapshots and events.
Exact execution commands and input/output contracts are maintained in
`simulation/scripts/README_S6C_LONG_SESSION.md`. The whole paired WAVs are ready,
but prolonged native inference has **not started**. Their construction preserves
continuous host input, not continuous hidden XVF adaptive state.
