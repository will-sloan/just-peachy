# Cold and warm naming queries — working full-bank supplement

This supplement describes executed **cached policy naming queries over actual native evidence**. It uses the completed full-bank naming-six and common-duration-six authorities separately. It adds no neural execution, policy replay, rescoring, native-log reading or prediction reading. Actual native-gallery integration, source-paced wall queries, retained transcript exposure and confirmed-name timing remain separate results.

The enrolled, identifiable executed queries have a higher correct-assigned-name percentage in the warm group than in the cold group on all 24 profile/tap routes below. This is a conditional association among admitted queries: the later queries can have more evidence, different support and selection, and retained state. It does not isolate a causal effect of warming, measure recall over all speech, or establish that the assigned name was confirmed or stable.

## Exact populations and definitions

Each authority retains all 2,880 requested case/routes: six configurations × 240 scenes × two same-tap routes. CASE_QUERY_COUNTS.csv retains zero-query cases explicitly. Each authority has 66 zero-query case/routes; these are not all strict-empty cases. The original immutable query tables retain every exported query row and status, and RESULT.json binds them by exact bytes and SHA-256. The aggregate CSVs partition all rows, including unidentifiable references and unavailable flags.

- **Cold query:** the original scorer reports a first executed query for this lifetime tracker ID, or a query after a recorded retirement of its naming state. This is a naming-state/query-history classification.
- **Warm query:** a subsequent executed query with retained naming state and sufficient exported history. Missing or truncated history is unavailable, rather than warm by assumption.
- **First identifiable person query:** the first executed query attributed to this reference metadata identity within a fresh scene/profile/tap. This is distinct from a first track query, first speech, first encounter across the bank, or a person's lifetime.
- **Identifiable query:** the inherited reference mapper finds one metadata identity intersecting the query support. It does not require that person's speech to fill the whole support interval. Incomplete, multiple-person, no-active-support and other unavailable reference states retain their own categories.
- **Correct / wrong-known / unknown:** these partition identifiable executed queries. Unidentifiable rows are retained separately and cannot be treated as correct, wrong or unknown against a person. QUERIES.csv does not export assigned-name confirmation state.
- **Unique-clean seconds and disjoint count:** these are cumulative state observations at a query. The tables retain observed/missing counts and min/median/max; they do not sum these fields as newly observed speech.

The inventory totals below repeat the same scenes across configurations and taps. They describe retained rows, not unique speech, elapsed time, people or independent trials. O0 and O1 share captures.

| Retained row inventory | Original naming six | Common-duration six |
|---|---:|---:|
| All executed query rows | 31,846 | 31,878 |
| Identifiable reference | 25,978 | 26,010 |
| Unidentifiable reference | 5,868 | 5,868 |
| Correct assigned name | 7,005 | 6,173 |
| Wrong known name | 52 | 7 |
| Unknown name on identifiable reference | 18,921 | 19,830 |
| Cold | 10,798 | 10,872 |
| Warm | 21,048 | 21,006 |
| Exported unavailable cold/warm history | 0 | 0 |
| First identifiable person query | 4,170 | 4,170 |
| Subsequent identifiable person query | 21,808 | 21,840 |
| Unavailable person-first flag | 5,868 | 5,868 |

These two authorities have different configurations, gallery intents and query populations. Their totals are not an estimate of a duration intervention or an error-rate comparison between the authorities.

Every observed cold query in these tables is also a first query for its lifetime tracker ID. There are **zero observed post-retirement cold queries after a prior query for that same ID**. This limits the empirical retirement comparison; it does not establish that no retirements occurred. Conversely, 160 original-naming and 162 common-duration first identifiable person queries occur on a warm track. Track coldness therefore cannot stand in for first-time reference-person exposure.

No exported row reports unavailable cold/warm history. The supplement honors exported history classifications; it does not reopen raw retirement journals. Missing raw-ledger information that the original exporter did not expose cannot be independently detected by this table aggregation.

## Enrolled cold versus warm queries

Each cell is correct assigned names / identifiable **enrolled executed queries**, followed by its percentage. All listed enrolled groups have zero wrong-known query rows; the remaining identifiable rows are unknown. Wrong-known outcomes on withheld people and all unidentifiable rows remain in the separate roster/status tables.

| Configuration | Tap | Cold | Warm |
|---|---|---:|---:|
| C088 | O0 | 186/225 (82.67%) | 439/467 (94.00%) |
| C088 | O1 | 171/217 (78.80%) | 417/444 (93.92%) |
| C091 | O0 | 146/197 (74.11%) | 407/444 (91.67%) |
| C091 | O1 | 142/201 (70.65%) | 380/422 (90.05%) |
| C105 | O0 | 181/219 (82.65%) | 443/469 (94.46%) |
| C105 | O1 | 166/215 (77.21%) | 419/444 (94.37%) |
| C106 | O0 | 147/198 (74.24%) | 403/441 (91.38%) |
| C106 | O1 | 142/197 (72.08%) | 372/411 (90.51%) |
| C111 | O0 | 202/225 (89.78%) | 451/467 (96.57%) |
| C111 | O1 | 194/217 (89.40%) | 433/444 (97.52%) |
| C114 | O0 | 174/197 (88.32%) | 423/444 (95.27%) |
| C114 | O1 | 170/201 (84.58%) | 397/422 (94.08%) |
| C141 | O0 | 142/209 (67.94%) | 379/433 (87.53%) |
| C141 | O1 | 131/199 (65.83%) | 374/412 (90.78%) |
| C142 | O0 | 175/209 (83.73%) | 405/433 (93.53%) |
| C142 | O1 | 158/199 (79.40%) | 387/412 (93.93%) |
| C143 | O0 | 178/209 (85.17%) | 415/433 (95.84%) |
| C143 | O1 | 166/199 (83.42%) | 396/412 (96.12%) |
| C144 | O0 | 112/178 (62.92%) | 350/401 (87.28%) |
| C144 | O1 | 108/181 (59.67%) | 318/385 (82.60%) |
| C145 | O0 | 134/178 (75.28%) | 371/401 (92.52%) |
| C145 | O1 | 128/181 (70.72%) | 347/385 (90.13%) |
| C146 | O0 | 138/178 (77.53%) | 376/401 (93.77%) |
| C146 | O1 | 131/181 (72.38%) | 354/385 (91.95%) |

C088/C091 use original fixed A/B 15-second-tier galleries with cues off; C105/C106 are their real-cue companions. C111/C114 are the corresponding calibrated, cues-off 15-second-tier conditions. Original intended rosters contain people with unavailable enrollment material, which remain INTENDED_BUT_UNAVAILABLE. These six are not zero-template controls.

C141–C143 use common roster A at nominal 5/15/30-second tiers; C144–C146 use common roster B. **Each roster contains 14 people (9 CMU and 5 HiFi), 28 people combined.** The common rosters are fixed across tiers. Whole-clip material, native enrollment windows and templates also change with the tier; the comparison is not a duration-only intervention or an exact-duration crop experiment. No Common Voice duration effect is established by these common-roster controls.

The higher conditional percentages must be read beside the full source-support, unknown, withheld exposure and observed/censored naming-delay results. Query admission and reference identifiability omit many possible speech opportunities from these denominators; a high percentage here is compatible with low coverage over all speech.

## Separate first-reference-person exposure view

FIRST_REFERENCE_PERSON_QUERY_SUMMARY.csv retains every profile/tap/roster and first/subsequent/unavailable group. The examples below make the different denominators concrete. They are table illustrations, not new candidate selection or independent experiments. All fractions refer only to first identifiable person queries in a fresh scene/profile/tap.

| Configuration / tap | Enrolled correct / queries | Withheld wrong-known / queries | Intended-unavailable unknown / queries |
|---|---:|---:|---:|
| C088 O0 | 112/129 | 1/167 | 52/52 |
| C088 O1 | 111/131 | 1/163 | 53/53 |
| C111 O0 | 118/129 | 3/167 | 52/52 |
| C111 O1 | 120/131 | 2/163 | 53/53 |
| C141 O0 | 86/121 | 0/227 | No such query group |
| C141 O1 | 89/122 | 0/225 | No such query group |
| C143 O0 | 107/121 | 0/227 | No such query group |
| C143 O1 | 107/122 | 1/225 | No such query group |

The C088/C111 examples preserve the improvement in enrolled first-person-query assignment alongside additional withheld wrong-known assignments. They do not establish that calibration is preferable overall. The common-roster examples preserve a withheld error alongside higher enrolled assignment at the longer tier. Assigned-query outcomes are distinct from later retained-row name exposure, stable/confirmed-name timing and source-paced emissions.

## Artifacts and review

- RESULT.json binds the helper, maintained README, both completed naming authorities and compact outputs, and records inline fixture results. The independent review separately binds the original fixture receipt.
- CASE_QUERY_COUNTS.csv covers all 5,760 case/routes, including zero-query cases.
- PROFILE_QUERY_COUNTS.csv gives all 24 profile/tap totals.
- COLD_WARM_QUERY_SUMMARY.csv, FIRST_REFERENCE_PERSON_QUERY_SUMMARY.csv and REFERENCE_STATUS_QUERY_SUMMARY.csv retain their separate denominator partitions.
- ALL_EXPORTED_STATUS_COUNTS.csv retains counts for every exported categorical value, including blank values.
- INTERPRETATION_BINDING_V2.json binds this prose, the completed result and the independent review.

Independent review passed nine owner fixtures plus nine independent cases and 13,489 source/compact checks. It reconciled the CASE, PROFILE and six compact aggregate views without reopening original QUERIES/COVERAGE, predictions or native logs. Medians and contributing-row membership hashes were source-reviewed rather than independently recomputed from the original query rows.

The helper and original result remain unchanged. This interpretation adds no final operating recommendation, new threshold, new configuration, empirical paced finding or inference about deployment performance.

