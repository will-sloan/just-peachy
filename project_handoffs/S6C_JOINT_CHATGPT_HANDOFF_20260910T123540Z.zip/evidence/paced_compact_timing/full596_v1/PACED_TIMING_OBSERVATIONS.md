# Actual paced timing observations

Denominators: grouped scalar metric observed/missing counts refer to cells; event lag counts refer to original emissions of that type; name-delay counts refer to turn occurrences in each declared status bin. Per-cell observation_counts retains original process/telemetry sample counts separately for each observer and metric. Unavailable counts remain null; overlapping observer sample counts are never added.

All596 original paced cells are projected from bound completed scientific analyses and normalized native rows. Main520, cadence24, arrival12 and cross40 stay separate; each exact condition/tap/repetition stays separate. Repeats are not independent scenes. This is descriptive observation, not selection or final S6C acceptance.

UTC source-to-completion includes pacing, scheduling and finalization. Its ratio to source duration is not pure algorithm RTF or device latency. Canonical native and outer-cell intervals and historical worker/admission intervals are separately defined and are never added. Event lag means UTC emission minus that event’s source cursor; it is not phonetic onset, GUI latency or partial-transcript accuracy. Missing metrics remain null. Percentiles use linear interpolation and are descriptive, especially for tiny repeated panels.

RSS sums are sampled upper bounds with possible shared-page double counting; USS and Windows private commit remain different measures. Maxima use the maximum available recorded observer peak, never a sum of observer maxima. Sampling gaps and wall timestamp reversals remain reported. Raw buffers stay locally bound.

Name delays are grouped by exact roster/reference/attainability and original censoring status. Unavailable or censored turns are not zero-delay successes. Historical generations have no C actual-name metric. Source/tail completeness is not word accuracy.

| Input / candidate / taps / repetition | Cells | Source→complete UTC ratio p50 / p95 | Event cursor lag: partial p50 / p95 (s) | RSS sampled peak max (MiB) |
| --- | ---: | ---: | ---: | ---: |
| arrival_boundary_fast_v2 / C088 / O0→O0 / r1 | 1 | 1.146 / 1.146 | 0.735 / 1.305 | 492.352 |
| arrival_boundary_fast_v2 / C088 / O0→O0 / r2 | 1 | 1.235 / 1.235 | 2.653 / 4.304 | 490.031 |
| arrival_boundary_fast_v2 / C088 / O0→O0 / r3 | 1 | 1.244 / 1.244 | 3.400 / 5.024 | 490.387 |
| arrival_boundary_fast_v2 / C088 / O1→O1 / r1 | 1 | 1.211 / 1.211 | 2.806 / 4.506 | 490.191 |
| arrival_boundary_fast_v2 / C088 / O1→O1 / r2 | 1 | 1.197 / 1.197 | 2.870 / 4.253 | 490.438 |
| arrival_boundary_fast_v2 / C088 / O1→O1 / r3 | 1 | 1.200 / 1.200 | 2.159 / 4.076 | 490.066 |
| arrival_boundary_fast_v2 / C105 / O0→O0 / r1 | 1 | 1.183 / 1.183 | 2.470 / 4.064 | 491.219 |
| arrival_boundary_fast_v2 / C105 / O0→O0 / r2 | 1 | 1.238 / 1.238 | 2.432 / 4.738 | 490.836 |
| arrival_boundary_fast_v2 / C105 / O0→O0 / r3 | 1 | 1.211 / 1.211 | 3.011 / 4.930 | 490.699 |
| arrival_boundary_fast_v2 / C105 / O1→O1 / r1 | 1 | 1.245 / 1.245 | 3.122 / 5.165 | 490.867 |
| arrival_boundary_fast_v2 / C105 / O1→O1 / r2 | 1 | 1.224 / 1.224 | 2.436 / 4.007 | 490.766 |
| arrival_boundary_fast_v2 / C105 / O1→O1 / r3 | 1 | 1.258 / 1.258 | 2.772 / 6.065 | 490.699 |
| b00_main / B00 / O0→O0 / r1 | 16 | 1.007 / 1.008 | -0.013 / 0.060 | 446.609 |
| b00_main / B00 / O0→O0 / r2 | 4 | 1.007 / 1.007 | -0.032 / 0.043 | 445.777 |
| b00_main / B00 / O1→O1 / r1 | 16 | 1.007 / 1.008 | -0.011 / 0.058 | 446.812 |
| b00_main / B00 / O1→O1 / r2 | 4 | 1.007 / 1.007 | -0.030 / 0.044 | 445.770 |
| b01_main / B01 / O0→O0 / r1 | 16 | 1.007 / 1.007 | 0.184 / 0.335 | 448.355 |
| b01_main / B01 / O0→O0 / r2 | 4 | 1.007 / 1.007 | 0.152 / 0.313 | 447.250 |
| b01_main / B01 / O1→O1 / r1 | 16 | 1.007 / 1.007 | 0.181 / 0.335 | 448.312 |
| b01_main / B01 / O1→O1 / r2 | 4 | 1.007 / 1.007 | 0.173 / 0.308 | 447.879 |
| b36_fast_v2 / B36 / O0→O0 / r1 | 16 | 1.007 / 1.008 | 0.180 / 0.331 | 446.582 |
| b36_fast_v2 / B36 / O0→O0 / r2 | 4 | 1.007 / 1.007 | 0.154 / 0.310 | 446.305 |
| b36_fast_v2 / B36 / O1→O1 / r1 | 16 | 1.007 / 1.007 | 0.182 / 0.329 | 447.262 |
| b36_fast_v2 / B36 / O1→O1 / r2 | 4 | 1.007 / 1.007 | 0.169 / 0.305 | 445.891 |
| c065_main / C065 / O0→O0 / r1 | 16 | 1.020 / 1.027 | 0.375 / 0.695 | 490.121 |
| c065_main / C065 / O0→O0 / r2 | 4 | 1.027 / 1.032 | 0.353 / 0.674 | 488.984 |
| c065_main / C065 / O1→O1 / r1 | 16 | 1.020 / 1.030 | 0.363 / 0.736 | 489.375 |
| c065_main / C065 / O1→O1 / r2 | 4 | 1.028 / 1.031 | 0.397 / 0.742 | 488.688 |
| c067_main / C067 / O0→O0 / r1 | 16 | 1.037 / 1.050 | 0.585 / 1.210 | 528.859 |
| c067_main / C067 / O0→O0 / r2 | 4 | 1.057 / 1.065 | 0.668 / 1.435 | 526.172 |
| c067_main / C067 / O1→O1 / r1 | 16 | 1.041 / 1.055 | 0.543 / 1.112 | 529.289 |
| c067_main / C067 / O1→O1 / r2 | 4 | 1.056 / 1.067 | 0.614 / 1.152 | 526.926 |
| c076_main / C076 / O0→O0 / r1 | 16 | 1.073 / 1.094 | 1.019 / 2.217 | 490.023 |
| c076_main / C076 / O0→O0 / r2 | 4 | 1.098 / 1.104 | 1.092 / 2.107 | 489.559 |
| c076_main / C076 / O1→O1 / r1 | 16 | 1.077 / 1.097 | 0.968 / 2.028 | 489.727 |
| c076_main / C076 / O1→O1 / r2 | 4 | 1.104 / 1.111 | 0.939 / 2.166 | 488.977 |
| c079_main / C079 / O0→O0 / r1 | 16 | 1.147 / 1.182 | 1.677 / 3.695 | 490.199 |
| c079_main / C079 / O0→O0 / r2 | 4 | 1.202 / 1.584 | 1.625 / 3.751 | 490.227 |
| c079_main / C079 / O1→O1 / r1 | 16 | 1.123 / 1.153 | 1.619 / 3.220 | 490.859 |
| c079_main / C079 / O1→O1 / r2 | 4 | 1.159 / 1.199 | 1.563 / 3.717 | 489.258 |
| c088_main / C088 / O0→O0 / r1 | 16 | 1.237 / 1.293 | 2.767 / 6.112 | 491.777 |
| c088_main / C088 / O0→O0 / r2 | 4 | 1.204 / 1.222 | 1.805 / 5.199 | 491.473 |
| c088_main / C088 / O1→O1 / r1 | 16 | 1.226 / 1.269 | 2.783 / 5.779 | 492.340 |
| c088_main / C088 / O1→O1 / r2 | 4 | 1.199 / 1.225 | 2.020 / 4.971 | 491.230 |
| c091_main / C091 / O0→O0 / r1 | 16 | 1.201 / 1.216 | 2.437 / 4.812 | 493.312 |
| c091_main / C091 / O0→O0 / r2 | 4 | 1.202 / 1.211 | 1.853 / 4.517 | 490.594 |
| c091_main / C091 / O1→O1 / r1 | 16 | 1.202 / 1.223 | 2.557 / 5.105 | 492.109 |
| c091_main / C091 / O1→O1 / r2 | 4 | 1.192 / 1.201 | 1.734 / 3.958 | 491.594 |
| c117_main / C117 / O0→O0 / r1 | 16 | 1.211 / 1.255 | 2.691 / 5.126 | 489.559 |
| c117_main / C117 / O0→O0 / r2 | 4 | 1.271 / 1.283 | 2.394 / 6.194 | 490.023 |
| c117_main / C117 / O1→O1 / r1 | 16 | 1.218 / 1.266 | 2.555 / 4.917 | 489.891 |
| c117_main / C117 / O1→O1 / r2 | 4 | 1.260 / 1.272 | 2.504 / 5.810 | 489.180 |
| c118_main / C118 / O0→O0 / r1 | 16 | 1.243 / 1.292 | 2.877 / 5.851 | 491.609 |
| c118_main / C118 / O0→O0 / r2 | 4 | 1.253 / 1.281 | 2.456 / 6.436 | 493.641 |
| c118_main / C118 / O1→O1 / r1 | 16 | 1.242 / 1.275 | 2.748 / 6.084 | 492.062 |
| c118_main / C118 / O1→O1 / r2 | 4 | 1.263 / 1.291 | 2.410 / 5.337 | 490.223 |
| c121_main / C121 / O0→O0 / r1 | 16 | 1.198 / 1.259 | 2.754 / 5.936 | 489.773 |
| c121_main / C121 / O0→O0 / r2 | 4 | 1.264 / 1.291 | 2.541 / 5.810 | 488.734 |
| c121_main / C121 / O1→O1 / r1 | 16 | 1.195 / 1.220 | 2.227 / 4.589 | 489.484 |
| c121_main / C121 / O1→O1 / r2 | 4 | 1.256 / 1.302 | 2.522 / 6.689 | 489.520 |
| c122_main / C122 / O0→O0 / r1 | 16 | 1.225 / 1.286 | 3.005 / 6.086 | 490.145 |
| c122_main / C122 / O0→O0 / r2 | 4 | 1.241 / 1.280 | 1.944 / 4.252 | 489.250 |
| c122_main / C122 / O1→O1 / r1 | 16 | 1.235 / 1.327 | 2.797 / 5.386 | 490.379 |
| c122_main / C122 / O1→O1 / r2 | 4 | 1.205 / 1.238 | 1.949 / 4.124 | 489.820 |
| cross_panel_fast_v2 / C085 / O0→O1 / r1 | 16 | 1.209 / 1.217 | 2.595 / 5.261 | 488.594 |
| cross_panel_fast_v2 / C085 / O0→O1 / r2 | 4 | 1.202 / 1.203 | 1.722 / 4.352 | 487.676 |
| cross_panel_fast_v2 / C086 / O1→O0 / r1 | 16 | 1.196 / 1.215 | 2.267 / 4.932 | 493.500 |
| cross_panel_fast_v2 / C086 / O1→O0 / r2 | 4 | 1.207 / 1.212 | 1.989 / 5.136 | 487.398 |
| uncertainty_gate6_fast_v2 / C071 / O0→O0 / r1 | 6 | 1.200 / 1.225 | 2.183 / 4.278 | 488.883 |
| uncertainty_gate6_fast_v2 / C071 / O1→O1 / r1 | 6 | 1.204 / 1.207 | 2.050 / 4.763 | 490.824 |
| uncertainty_gate6_fast_v2 / C082 / O0→O0 / r1 | 6 | 1.200 / 1.221 | 2.086 / 4.467 | 489.703 |
| uncertainty_gate6_fast_v2 / C082 / O1→O1 / r1 | 6 | 1.196 / 1.213 | 2.212 / 4.596 | 489.668 |
