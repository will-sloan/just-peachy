# Full N03 confirmation: a conditional later-label tradeoff

N03/C067 improves later anonymous label scores relative to N01/C065 on this bank, while worsening first-display label scores, consistent returns and Unknown source support. This supports retaining it as a conditional tradeoff, not replacing N01 on every criterion. The full confirmation follows panel-informed selection; it is not a new independent holdout.

The actual N03 native pool completed all480 cells (368new and112 reused), followed by480 exact same-native shared-replay parity checks. Core scoring completed480/480 without failures, and all nine requested comparisons retain240 matched cases per route. The compact summary reproduces19,537 field/grid/aggregate checks from bound completed tables; it does not read native events, model artifacts, PCM or prediction payloads. Native closure and parity are separately recorded evidence.

## Complete-reference headline

Each row below has203 complete nonempty scenes,6016 reference words,693 source turns,25,304,912 sole-active support samples and292 return opportunities. The26 incomplete-reference scenes retain84 additional turns and32 returns in their separate source tables;11 strict-empty scenes remain separate. The headline is not all777 occurrences. Raw final text and raw word error counts are identical between C065 and C067 for every one of the480 same-tap case pairs.

| Tap | Metric | N01 C065 | N03 C067 |
|---|---|---:|---:|
|O0|Raw word errors /6016|1142|1142|
|O1|Raw word errors /6016|1207|1207|
|O0|First-display label, final-word cp errors /6016|3955|4052|
|O1|First-display label, final-word cp errors /6016|3971|4042|
|O0|First-final cp errors /6016|3724|3544|
|O1|First-final cp errors /6016|3824|3706|
|O0|Latest-revised cp errors /6016|3732|3547|
|O1|Latest-revised cp errors /6016|3865|3710|
|O0|Unknown sole-support samples|9,032,568 (35.695%)|9,616,060 (38.001%)|
|O1|Unknown sole-support samples|8,797,718 (34.767%)|9,388,051 (37.100%)|
|O0|Mixed-label sole-support samples|236,425|206,601|
|O1|Mixed-label sole-support samples|201,788|228,575|
|O0|Consistent / inconsistent / Unknown returns, total292|41 /49 /202|18 /28 /246|
|O1|Consistent / inconsistent / Unknown returns, total292|37 /57 /198|17 /40 /235|

The latest cp changes are−185 errors (−3.075 percentage points) on O0 and−155 (−2.576 points) on O1. The first-display metric worsens by97 and71 errors. First-display here assigns the eventual final ASR words their first displayed anonymous labels; it does not measure partial-text accuracy or wall-clock display latency. Global per-scene cp permutation assignment, duration-mapped live support and return consistency measure different behavior and can move in opposite directions. Anonymous tracks are not known person names.

## Short turns and lifecycle

The contained-evidence counts stay exactly19/40 (O0) and24/40 (O1) for subsecond turns, and32/34 (O0) and34/34 (O1) for one-to-less-than-two-second turns. This is not evidence of unchanged tracking quality:

| Tap / duration | Any known support, C065→C067 | Correct duration-mapped modal label, C065→C067 |
|---|---:|---:|
|O0 /<1s,40 turns|26→25|12→9|
|O1 /<1s,40 turns|32→32|12→12|
|O0 /1–<2s,34 turns|33→31|10→8|
|O1 /1–<2s,34 turns|33→32|8→7|

Contained evidence, any-known support and retrospective modal correctness remain separate counts; none is a fresh-voice wall latency. Across all240 scenes per tap, both recipes reach at most13 live anonymous tracks and record zero capacity-blocked clean-evidence seconds. Aggregate per-scene retirement counts rise562→688 on O0 and720→851 on O1. These sums are scene-local lifecycle observations, not unique identities across the whole bank. Capacity saturation does not explain the observed N03 tradeoff in these runs.

## Source costs and clocks

Each tap covers10,893.905 source seconds over240 cells. Actual source durations are retained; the full bank is not uniformly44.6954375 seconds per scene. Native N03 closure comprises368 new sessions plus112 reused panel sessions. The scorer's cost table describes the underlying240 native source cells per route, separately from replay/scoring time and from the later pool's elapsed wall time.

Across all240 cells, observed embedding-call totals fall6417→5127 on O0 and6589→5255 on O1. The corresponding observed embedding compute sums are186.121→185.962 seconds and189.548→186.059 seconds: fewer calls do not imply a proportional compute reduction. On the203 complete-reference population, summed embedding input-window duration rises5214.5→5456.0 seconds on O0 and5245.0→5396.5 on O1 despite fewer calls.

The observed speaker full-dispatch sums are1366.566→1337.114 seconds (O0) and1369.710→1331.070 (O1), with240 reported cells each. Embedding cost sections are present for235/240 O0 and237/240 O1 cells under both recipes; the compact result explicitly retains the absent sections, rather than manufacturing measured durations. API, compute and full-dispatch timings are inclusive nested values. Concurrent lane costs cannot be added into whole-pipeline wall time, and separate batches, reuse and scheduling conditions preclude an isolated speed claim. These accelerated source observations do not qualify source-paced behavior or CM5 performance.

## Historical controls, uncertainty and adverse cases

Latest-revised cp point differences below are C067 minus the stated historical control, each over203 scenes/6016 words. They compare complete pipeline generations rather than isolate one parameter.

| Historical control | O0 error delta | O1 error delta |
|---|---:|---:|
|B00|+14|−4|
|B01|−166|−357|
|B36|−121|−31|

Within C067, fixed O1 has163 more latest cp errors than fixed O0 on the complete-reference population. No per-scene tap choice is made. For primary words alone, O1 has49 more errors over4560 words across156 primary scenes (+1.075 points), with the inherited2000-resample conditional95% interval [0.373,1.807] points. The other eight same-tap primary-word contrasts have [0,0] intervals because their actual primary word counts are equal. All use156 primary scenes,116 matched blocks and five observed rooms. Shared speakers, sources, text and acoustic materials cross blocks; these conditional intervals do not provide cp confidence intervals, establish equivalence, or repair outcome-informed selection.

Eight deterministic extremes are preserved in RESULT.json: the two largest positive and two largest negative scene cp-rate differences per tap, ranked by exact fraction then case ID. They are selected after results and are not typical examples. S45_02_03 is the largest adverse scene on both taps: latest cp changes4→24 errors on O0 and5→25 on O1 over29 words; raw words remain unchanged. Its one return changes from consistent to inconsistent under both taps, and Unknown support rises45,391→52,608 samples on O0 and29,052→38,925 on O1. Benefits are retained too, including S45_01_01 on O0 and S45_01_12 on O1. This heterogeneity is a reason to retain the full multicriterion evidence rather than promote a global winner from the pooled latest cp value.

The first compact-summary attempt failed before publication because it expected a core-style `tables` field in a comparison receipt whose actual field is `artifacts`. Its exact helper/README bytes are preserved and resolved in RESULT.json. No score, comparison, native source or model computation changed during the report-only repair.
