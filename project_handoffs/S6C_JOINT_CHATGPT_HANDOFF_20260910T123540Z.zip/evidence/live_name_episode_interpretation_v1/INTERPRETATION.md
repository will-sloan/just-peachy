# Live-name episodes: two separate full-bank groups

Each group contains six profiles,2,880 prediction outputs and9,324 source-occurrence outputs. Each route has777 occurrences and28,612,432 sole-active samples. The naming and common-roster supplements independently reproduce37,296 sample-partition assertions each. The first group has10,004 assigned-name episodes; the common group has8,873. These totals include correct and wrong episodes and cannot be pooled across reused scenes, taps or profiles.

Episodes are contiguous intervals of one assigned metadata identity within one occurrence’s sole-active support. Identity changes, Unknown/expiry, silence/overlap and occurrence boundaries split them; confirmation alone does not. Their modeled availability timeline and0.75second expiry are distinct from wall-paced latency and retained transcript-row exposure. All777 occurrences per route are mapped with positive sole support and available activity metadata. Undeclared-identity exposure is zero in these inputs.

## Original and calibrated fifteen-second rosters

This table counts WITHHELD_OR_UNSELECTED exposure only, as O0 / O1. Rotation A has368 source turns and13,991,288 sole-active samples; B has409 turns and14,621,144 samples. Intended-but-unavailable people remain separate (A129 source turns; B110); their wrong-known exposure is zero here.

| Profile | Condition | Wrong samples | Wrong episodes | Affected turns | Affected metadata people |
|---|---|---:|---:|---:|---:|
| C088 | A original off | 63701 / 115365 | 15 / 20 | 10 / 13 | 5 / 6 |
| C091 | B original off | 41815 / 42996 | 16 / 21 | 12 / 10 | 7 / 7 |
| C105 | A original real | 56759 / 115365 | 13 / 20 | 9 / 13 | 5 / 6 |
| C106 | B original real | 41815 / 42996 | 16 / 21 | 12 / 10 | 7 / 7 |
| C111 | A calibrated off | 186521 / 264139 | 51 / 57 | 22 / 24 | 6 / 7 |
| C114 | B calibrated off | 100971 / 69827 | 33 / 31 | 19 / 15 | 11 / 8 |

Calibration increases both duration and incidence of withheld exposure: A episodes15/20→51/57 and affected turns10/13→22/24; B episodes16/21→33/31 and affected metadata people7/7→11/8. The original correct-name improvements remain in the separate naming results. Counts are per route and do not sum to unique people across rotations or taps.

## Fixed common rosters across duration tiers

All tiers use the same14 people per rotation:9CMU and5HiFi. A has510 withheld/unselected occurrences and19,750,392 sole-active samples; B has531 and20,200,472. Intended-but-unavailable E people are absent from these common rosters. Thus these denominators differ from the original roster table.

| Profile | Rotation / tier | Wrong samples O0 / O1 | Wrong episodes O0 / O1 | Affected turns O0 / O1 | Affected metadata people O0 / O1 |
|---|---|---:|---:|---:|---:|
| C141 | A5s | 38334 / 59127 | 10 / 10 | 7 / 7 | 4 / 4 |
| C142 | A15s | 63701 / 115045 | 15 / 19 | 10 / 12 | 5 / 5 |
| C143 | A30s | 55980 / 129943 | 13 / 23 | 9 / 13 | 5 / 5 |
| C144 | B5s | 33159 / 42036 | 14 / 20 | 10 / 9 | 6 / 6 |
| C145 | B15s | 40855 / 42036 | 15 / 20 | 11 / 9 | 6 / 6 |
| C146 | B30s | 45453 / 42036 | 19 / 20 | 12 / 9 | 7 / 6 |

A O1 withheld episodes increase10→19→23 across5/15/30seconds; B O1 remains20 with identical withheld wrong sample totals at all tiers. A O0 is nonmonotonic (10→15→13). More enrollment material is not uniformly favorable for stranger exposure, even at fixed eligibility. It also changes the material contributing to each actual template.

## Observed endings and limits

Every withheld wrong episode in both groups ends in either Unknown/expiry abstention or a censored support boundary; no correct-name ending is available for these people outside the loaded roster. Across ALL roster statuses, C111 O1 and C114 O1 each have one immediate observed correct-name ending. The common group has one each for C144 O1 and C146 O1. These four route-level occurrences concern enrolled people and may reuse the same source material; they are not four independent correction experiments. Other wrong episodes end at Unknown/expiry or support boundaries. No another-wrong-identity replacement ending is observed. A boundary or abstention does not establish a correct name.

All132 empty-control cells per group are preserved separately, each with zero assigned-name samples. They are not converted into stranger source turns. Retained-row name exposure remains a separate original metric. These descriptive results do not estimate unseen-stranger failure probability, physical identity count, continuous-session correction rates or source-paced latency. The frozen Q bank, source reuse and enrollment/probe domain gap remain the applicable limits.
