# S6C foundation findings: source reachability and actual S6B incidence

The bounded audit completed on all 240 canonical scenes and both taps for B09, B10, B16, B17, B24 and B25. All **65,150 original tracker decisions and 2,880 final tracker snapshots matched exactly** after replaying the original native vectors at their preserved source support and modeled availability. No models, audio processing, enrollment, hardware or evaluator identity labels were used. Six supplied numerical controls also reproduced exactly.

This establishes original-code action reachability and the incidence of observable engineering conditions. It does not establish which alternate assignment would be correct, turn any idealized fixture into an empirical speaker error, or validate a new S6C predictor.

## Reproduction and preserved source

The frozen tracker SHA256 is d5feddc193a84afd613b5fad2f1ed037609631cca543d3db160990c5775dbd1a. The supplied script was copied unchanged with that exact tracker into a new output directory and executed there. Its six case dictionaries equal the supplied receipt exactly; the pack and original snapshot were not modified.

The actual trace audit verifies the sealed S6B index, each selected prediction, matching native run receipt/vector binding, and delivered cue file. It calls the unchanged tracker through an observer of the original selector. It checks the entire regenerated decision dictionary, including scores, cue summary and lineage, plus the final snapshot. Large native ASR/segmentation JSON, audio and models remain transitively bound and are not reread. This is targeted tracker inspection, not a rerun of ASR, the scheduler's transcript attribution or the S6B scorer.

Use audit_v1/FOUNDATION_AUDIT_RECEIPT.json and audit_v1/TRACE_AUDIT_RECEIPT.json as the completed authority. smoke_v1 is the earlier 24-cell implementation check (692 exact decisions), not the empirical study.

## What the six idealized controls establish

Static, adaptive and dual-memory modes create a new track for voice cosine 0.34 below the 0.35 eligibility threshold even with the idealized matching bearing. Their original-track combined engineering scores are approximately 0.460, 0.416 and 0.416. At cosine 0.40 with a 120-degree conflict and only one voice-eligible track, they retain that track even though the combined score falls to approximately 0.280, 0.331 and 0.331.

The original selector does not define a general competing new/unresolved hypothesis on that combined scale. Consequently, comparing a combined score to the numerical cosine gate is a descriptive probe of where information is blocked, not an assertion that the implementation violates its declared threshold. These vectors have no known-person truth.

## Lifecycle: dormant, retired, stored and lifetime are different

The original _active() means “not retired”; it includes dormant dual-memory tracks. There is no automatic assignment to retired and no list compaction/removal path in this frozen module. All observed retired counts are zero. Throughout these six profiles, stored records and the code's active pool therefore coincide; either can include dormant records. All six reach 16 stored records in at least one cell. Dual-memory cells can reach 16 dormant records as well.

An explicit model-free control creates one track under capacity 1, marks that record retired, then supplies an incompatible vector. The stored count is 1, the active pool is 0, and allocation still rejects because it checks len(tracks). The next lifetime ID stays 2; no ID is recycled. This is a real reachable state restriction under the intervention, but it is NOT the cause of any automatic retirement observed in S6B: none occurs.

Dormancy uses more than five source seconds since a track's evidence and raises its eligibility gate from 0.35 to max(0.35,0.55). B10 has 1,610 O0 and 1,709 O1 track-by-observation comparisons with voice at least 0.35 but below the dormant 0.55 gate. These are candidate-comparison counts, not necessarily distinct decision events. Such exclusions occur in 193/240 and 197/240 cells. The matched B09 values are 1,609 and 1,709.

Capacity counts below are per tap; union seconds are unique rejected embedding support within each scene, then summed across scenes. They are not missing ASR duration or labeled person-error duration.

| Profile | O0 capacity hits / affected cells | O1 capacity hits / affected cells | O0 / O1 blocked support union seconds |
|---|---:|---:|---:|
| B09 | 667 / 63 | 1,003 / 100 | 205.75 / 309.50 |
| B10 | 667 / 63 | 1,003 / 100 | 205.75 / 309.50 |
| B16 | 1 / 1 | 8 / 2 | 1.00 / 6.00 |
| B17 | 1 / 1 | 8 / 2 | 1.00 / 6.00 |
| B24 | 7 / 2 | 8 / 2 | 3.25 / 4.00 |
| B25 | 7 / 2 | 15 / 5 | 3.25 / 8.25 |

Each tap has 240 cells. B10's total 1,670 hits across 163 cells reproduces the earlier mechanism audit. B17 is 9/3 and B25 is 22/7. Capacity creates a possible confound; increasing it has not been shown here to cure fragmentation or improve accuracy.

At 16 one-prototype records, actual NumPy prototype payload is 12,288 bytes. This excludes Python containers, revision vectors, queues, loaded models and the rest of the engine. It must not be equated with per-track resident memory or a CM5 resource qualification.

## Actual cue authority and blocked opportunities

The registered audit band is within 0.05 below each track's applicable voice gate, with voice above the severe-conflict floor and a positive spatial contribution. The band is a descriptive bin, not a proposed calibrated threshold.

| Profile / tap | Decisions | Qualified cue decisions | Nonzero spatial score decisions | No eligible track, borderline positive cue | Of those, combined score crosses numerical voice gate | Sole eligible retained below numerical combined gate |
|---|---:|---:|---:|---:|---:|---:|
| B10 O0 | 7,502 | 2,819 | 2,242 | 225 | 170 | 8 |
| B10 O1 | 8,147 | 3,155 | 2,502 | 270 | 177 | 17 |
| B17 O0 | 4,142 | 1,639 | 1,197 | 88 | 63 | 10 |
| B17 O1 | 4,393 | 1,728 | 1,283 | 100 | 72 | 15 |
| B25 O0 | 4,082 | 1,555 | 1,099 | 80 | 54 | 9 |
| B25 O1 | 4,397 | 1,729 | 1,247 | 86 | 54 | 10 |

The borderline-positive events affect 122/136 cells for B10, 68/77 for B17 and 62/65 for B25 (O0/O1, each denominator 240). They are plentiful enough to justify an actual matched hypothesis test, but do not show that location should override voice in those cells.

Only one voice-eligible candidate is retained despite a qualified direction conflict greater than the configured 35 degrees in 48/51 B10 decisions, 92/93 B17 and 83/82 B25. A changed bearing is not a true new person; silent relocation and stable wrong angle remain counterexamples to any new rule.

There are multiple voice-eligible candidates with nonzero cue scoring in 283/287 B10, 235/274 B17 and 216/260 B25 decisions. On the same current state, removing only the score contribution would change selection or abstention in 35/28, 38/32 and 25/37 decisions respectively. This local comparison does not undo earlier cue-driven state updates; it is not a full end-to-end counterfactual.

Cue-disabled parents report zero cue usage by construction. The original severe voice floor suppresses spatial score contribution below 0.20; the selected trace audit observes no nonzero contribution to such candidates.

## Matched parent comparisons: internal equality is not cpWER equality

| Pair | O0 / O1 common spans | O0 / O1 ID-or-state differences on common spans | O0 / O1 cells with different latest-label sequences |
|---|---:|---:|---:|
| B09 / B10 | 7,502 / 8,147 | 35 / 28 | 2 / 3 |
| B16 / B17 | 4,142 / 4,393 | 38 / 35 | 7 / 7 |
| B24 / B25 | 3,813 / 4,080 | 218 / 358 | 49 / 67 |

Every paired raw final-word sequence matches. B09/B10 have identical source spans, yet lineage differs on 2,487/2,629 decisions and prototype-version counters on 35/35. Their previously identical pooled latest cpWER therefore does not establish identical operation. Likewise B16/B17 are matched on native support, but their trace states and displayed outcomes differ.

B24/B25 has 193/217 parent-only spans and 269/317 cue-branch-only spans. Across both taps this is 410 versus 586, a net 176 extra observed embeddings, consistent with the earlier native mechanism accounting. Their union is not a matched fixed-evidence test. Differences include cue-driven cadence, track state and availability; common-span comparisons also retain those differing histories. A paired pipeline-bundle comparison is valid, but attribution to association mathematics alone is not.

The bounded excerpts include a B17 O1 decision in S45_01_01 at source 21.5–22.5 seconds: an old track has cosine 0.323781, positive spatial contribution 0.050596 and combined score 0.374378, yet the original rule creates provisional track 5. Another B17 O0 decision at 14–15 seconds changes from a clear voice ranking (margin about 0.0331) to combined-score ambiguity (margin about 0.0172), yielding Unknown. Neither example has been labeled correct or wrong in this audit. They demonstrate both blocked rescue and a possible abstention effect, with exact original source bindings.

## Required C1/C2 tests and interpretation guardrails

C1 should first preserve these original results as baseline invariants, then compare capacities 16/32/64/128/256 with identical evidence, gates and commitment. Report actual saturation and blocked support for each setting. Only call a comparison unconstrained after its own rejection count is absent or explained. Follow with separately bounded active, dormant, archived-prototype and history budgets; lifetime visible IDs must remain monotone and never be assigned to a different identity.

The new lifecycle needs tests for retirement releasing the intended allocation budget, dormant re-entry recovering an archived identity, expired provisional records not poisoning later evidence, and missing gallery state not changing anonymous decisions. A chronological long trace must show finite retained prototype/history bytes while lifetime IDs may grow. It is not continuous XVF adaptive state if built from separate captures.

C2 should preserve the voice-first parent and add explicit existing/new/unresolved competition with separately defined score scales and a severe voice safeguard. Test a positive borderline cue, a severe voice contradiction at the same bearing, a single eligible voice candidate with a large direction conflict, and strong matching voice after silent relocation. A method must be able to fail these tests without the expected answers being silently changed.

Use matched CUES_OFF, real delivered cues, several frozen uninformative angle-content controls that actually break source correspondence, and separately labeled nominal-geometry diagnostics. Preserve packet timing, missingness, reliability schedules and the native linear 0–180 degree endpoints. A global constant rotation is insufficient as a null; it can preserve between-source discrimination. Oracle geometry never becomes a runtime input or independent accuracy result.

Add stable-but-wrong angle, delayed/redelivered old packets, same-bearing different voices, invalid/zero energy, overlap mixtures, short provisional versus mature commitment, and prefix-future invariance. Count each complete chain from eligible observation to score/action/prototype change and actual display/name event. Do not infer correctness from internal activation alone.

The machine-readable prospective cases are in C1_C2_FALSIFYING_TESTS.json. They are recommendations for the new implementation, not completed S6C results. Independent review of the new implementation and actual unfavorable cases remains required.

## Column semantics and limits

Detailed tables retain all selected rows, including cells with no embeddings. Candidate comparison sums differ from decision-event counts; affected-cell columns use 240 per tap. “Active” in the source means not retired and can include dormant records. The unused raw_words_untouched zero column is a reserved placeholder, not a word-accuracy or parity metric; the actual paired raw_final_words_equal field is the tested lexical invariant.

The audit does not compute cpWER, reference identity correctness, true angular error or enrollment benefit. Existing S6B scores remain authoritative. It does not establish acoustic, CM5, real-world or new runtime performance. A code restriction, absent branch, observation failure, exhausted capacity and harmful inference are distinct dispositions.

