# Actual paced repetition scoring

Purpose: execute eight existing core and modeled-name score commands for the two candidates in RUN_SPEC.json. Inputs, exact240-label registry extensions, gallery-map bindings, producer receipts and command arrays are frozen there. Outputs are eight separate score folders and original score receipts. No models, native playback or policy predictions are regenerated. Repetition1 has32 cells; repetition2 has8 dependent repeat cells per candidate. They are not pooled and do not establish full240-scene scope.

The exact commands below use the existing analysis environment. Outputs are immutable once executed: do not rerun them. No Conda installation or activation is needed. Historical B00/B01 have no gallery and no actual C name-resolution API; name-control metrics preserve that absent-gallery condition. B00 original unlogged causal/vector traces remain unavailable.

## C088 repetition 1 core

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py' '--index' 'paced_analysis\c088_main_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/c088_r1_core_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py" --index paced_analysis\c088_main_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json --output-subdir paced_scoring/c088_r1_core_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240
```

## C088 repetition 1 name

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py' '--index' 'paced_analysis\c088_main_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/c088_r1_name_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240' '--gallery-map-extension' 'enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json' '674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db' 'enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json' '3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py" --index paced_analysis\c088_main_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json --output-subdir paced_scoring/c088_r1_name_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240 --gallery-map-extension enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json 674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json 3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7
```

## C088 repetition 2 core

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py' '--index' 'paced_analysis\c088_main_analysis_fast_v2\REPETITION_2_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/c088_r2_core_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py" --index paced_analysis\c088_main_analysis_fast_v2\REPETITION_2_PREDICTION_INDEX.json --output-subdir paced_scoring/c088_r2_core_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240
```

## C088 repetition 2 name

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py' '--index' 'paced_analysis\c088_main_analysis_fast_v2\REPETITION_2_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/c088_r2_name_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240' '--gallery-map-extension' 'enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json' '674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db' 'enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json' '3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py" --index paced_analysis\c088_main_analysis_fast_v2\REPETITION_2_PREDICTION_INDEX.json --output-subdir paced_scoring/c088_r2_name_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240 --gallery-map-extension enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json 674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json 3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7
```

## C091 repetition 1 core

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py' '--index' 'paced_analysis\c091_main_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/c091_r1_core_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py" --index paced_analysis\c091_main_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json --output-subdir paced_scoring/c091_r1_core_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240
```

## C091 repetition 1 name

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py' '--index' 'paced_analysis\c091_main_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/c091_r1_name_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240' '--gallery-map-extension' 'enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json' '674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db' 'enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json' '3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py" --index paced_analysis\c091_main_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json --output-subdir paced_scoring/c091_r1_name_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240 --gallery-map-extension enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json 674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json 3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7
```

## C091 repetition 2 core

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py' '--index' 'paced_analysis\c091_main_analysis_fast_v2\REPETITION_2_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/c091_r2_core_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py" --index paced_analysis\c091_main_analysis_fast_v2\REPETITION_2_PREDICTION_INDEX.json --output-subdir paced_scoring/c091_r2_core_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240
```

## C091 repetition 2 name

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py' '--index' 'paced_analysis\c091_main_analysis_fast_v2\REPETITION_2_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/c091_r2_name_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240' '--gallery-map-extension' 'enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json' '674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db' 'enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json' '3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py" --index paced_analysis\c091_main_analysis_fast_v2\REPETITION_2_PREDICTION_INDEX.json --output-subdir paced_scoring/c091_r2_name_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240 --gallery-map-extension enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json 674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json 3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7
```
