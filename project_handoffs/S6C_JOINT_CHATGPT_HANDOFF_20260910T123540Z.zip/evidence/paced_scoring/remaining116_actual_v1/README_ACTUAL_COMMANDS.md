# Actual remaining116 paced scoring

Purpose: execute16 held V3 core/name commands for eight separately retained original repetition indexes. RUN_SPEC.json freezes all input producers/indexes, exact240-label and gallery-map admission, and the actual commands. Outputs are16 original score folders and receipts;116 core and116 modeled-name score rows. B36/cadencegate/arrival sentinel/cross populations remain separate. Sentinel repetitions are exploratory/dependent, and cross routes retain actual ASR and identity taps. No full240-scene scope is inferred.

These are the actual commands; completed output namespaces must not be overwritten or rerun. The absolute analysis interpreter selects the existing environment without installation or Conda activation.

## b36_fast_v2 repetition 1 core

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py' '--index' 'historical_paced_analysis\b36_v2_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/b36_v2_r1_core_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py" --index historical_paced_analysis\b36_v2_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json --output-subdir paced_scoring/b36_v2_r1_core_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240
```

## b36_fast_v2 repetition 1 name

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py' '--index' 'historical_paced_analysis\b36_v2_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/b36_v2_r1_name_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240' '--gallery-map-extension' 'enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json' '674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db' 'enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json' '3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py" --index historical_paced_analysis\b36_v2_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json --output-subdir paced_scoring/b36_v2_r1_name_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240 --gallery-map-extension enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json 674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json 3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7
```

## b36_fast_v2 repetition 2 core

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py' '--index' 'historical_paced_analysis\b36_v2_analysis_fast_v2\REPETITION_2_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/b36_v2_r2_core_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py" --index historical_paced_analysis\b36_v2_analysis_fast_v2\REPETITION_2_PREDICTION_INDEX.json --output-subdir paced_scoring/b36_v2_r2_core_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240
```

## b36_fast_v2 repetition 2 name

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py' '--index' 'historical_paced_analysis\b36_v2_analysis_fast_v2\REPETITION_2_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/b36_v2_r2_name_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240' '--gallery-map-extension' 'enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json' '674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db' 'enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json' '3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py" --index historical_paced_analysis\b36_v2_analysis_fast_v2\REPETITION_2_PREDICTION_INDEX.json --output-subdir paced_scoring/b36_v2_r2_name_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240 --gallery-map-extension enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json 674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json 3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7
```

## uncertainty_gate6_fast_v2 repetition 1 core

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py' '--index' 'paced_analysis\uncertainty_gate6_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/uncertainty_gate6_r1_core_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py" --index paced_analysis\uncertainty_gate6_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json --output-subdir paced_scoring/uncertainty_gate6_r1_core_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240
```

## uncertainty_gate6_fast_v2 repetition 1 name

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py' '--index' 'paced_analysis\uncertainty_gate6_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/uncertainty_gate6_r1_name_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240' '--gallery-map-extension' 'enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json' '674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db' 'enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json' '3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py" --index paced_analysis\uncertainty_gate6_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json --output-subdir paced_scoring/uncertainty_gate6_r1_name_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240 --gallery-map-extension enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json 674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json 3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7
```

## arrival_boundary_fast_v2 repetition 1 core

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py' '--index' 'paced_arrival_analysis\arrival_boundary_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/arrival_boundary_r1_core_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py" --index paced_arrival_analysis\arrival_boundary_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json --output-subdir paced_scoring/arrival_boundary_r1_core_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240
```

## arrival_boundary_fast_v2 repetition 1 name

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py' '--index' 'paced_arrival_analysis\arrival_boundary_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/arrival_boundary_r1_name_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240' '--gallery-map-extension' 'enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json' '674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db' 'enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json' '3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py" --index paced_arrival_analysis\arrival_boundary_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json --output-subdir paced_scoring/arrival_boundary_r1_name_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240 --gallery-map-extension enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json 674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json 3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7
```

## arrival_boundary_fast_v2 repetition 2 core

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py' '--index' 'paced_arrival_analysis\arrival_boundary_analysis_fast_v2\REPETITION_2_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/arrival_boundary_r2_core_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py" --index paced_arrival_analysis\arrival_boundary_analysis_fast_v2\REPETITION_2_PREDICTION_INDEX.json --output-subdir paced_scoring/arrival_boundary_r2_core_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240
```

## arrival_boundary_fast_v2 repetition 2 name

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py' '--index' 'paced_arrival_analysis\arrival_boundary_analysis_fast_v2\REPETITION_2_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/arrival_boundary_r2_name_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240' '--gallery-map-extension' 'enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json' '674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db' 'enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json' '3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py" --index paced_arrival_analysis\arrival_boundary_analysis_fast_v2\REPETITION_2_PREDICTION_INDEX.json --output-subdir paced_scoring/arrival_boundary_r2_name_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240 --gallery-map-extension enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json 674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json 3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7
```

## arrival_boundary_fast_v2 repetition 3 core

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py' '--index' 'paced_arrival_analysis\arrival_boundary_analysis_fast_v2\REPETITION_3_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/arrival_boundary_r3_core_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py" --index paced_arrival_analysis\arrival_boundary_analysis_fast_v2\REPETITION_3_PREDICTION_INDEX.json --output-subdir paced_scoring/arrival_boundary_r3_core_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240
```

## arrival_boundary_fast_v2 repetition 3 name

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py' '--index' 'paced_arrival_analysis\arrival_boundary_analysis_fast_v2\REPETITION_3_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/arrival_boundary_r3_name_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240' '--gallery-map-extension' 'enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json' '674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db' 'enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json' '3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py" --index paced_arrival_analysis\arrival_boundary_analysis_fast_v2\REPETITION_3_PREDICTION_INDEX.json --output-subdir paced_scoring/arrival_boundary_r3_name_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240 --gallery-map-extension enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json 674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json 3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7
```

## cross_panel_fast_v2 repetition 1 core

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py' '--index' 'paced_cross_analysis\cross_panel_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/cross_panel_r1_core_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py" --index paced_cross_analysis\cross_panel_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json --output-subdir paced_scoring/cross_panel_r1_core_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240
```

## cross_panel_fast_v2 repetition 1 name

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py' '--index' 'paced_cross_analysis\cross_panel_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/cross_panel_r1_name_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240' '--gallery-map-extension' 'enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json' '674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db' 'enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json' '3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py" --index paced_cross_analysis\cross_panel_analysis_fast_v2\REPETITION_1_PREDICTION_INDEX.json --output-subdir paced_scoring/cross_panel_r1_name_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240 --gallery-map-extension enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json 674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json 3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7
```

## cross_panel_fast_v2 repetition 2 core

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py' '--index' 'paced_cross_analysis\cross_panel_analysis_fast_v2\REPETITION_2_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/cross_panel_r2_core_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_analysis_v3.py" --index paced_cross_analysis\cross_panel_analysis_fast_v2\REPETITION_2_PREDICTION_INDEX.json --output-subdir paced_scoring/cross_panel_r2_core_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240
```

## cross_panel_fast_v2 repetition 2 name

PowerShell:

```powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py' '--index' 'paced_cross_analysis\cross_panel_analysis_fast_v2\REPETITION_2_PREDICTION_INDEX.json' '--output-subdir' 'paced_scoring/cross_panel_r2_name_v3' '--require-complete' '--registry-extension' 'design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json' 'b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d' '--registry-extension' 'design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json' 'b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75' '--registry-extension' 'design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json' '69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5' '--registry-extension' 'design/ENDPOINT_ADVICE_FACTORIAL_V1.json' 'f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91' '--expected-candidates' '240' '--gallery-map-extension' 'enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json' '674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db' 'enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json' '3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7'
```

Anaconda Prompt / CMD:

```bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
"C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\staging\s5_text_metrics\analysis_env\Scripts\python.exe" -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_name_analysis_v3.py" --index paced_cross_analysis\cross_panel_analysis_fast_v2\REPETITION_2_PREDICTION_INDEX.json --output-subdir paced_scoring/cross_panel_r2_name_v3 --require-complete --registry-extension design/COMMON_ROSTER_DURATION_AMENDMENT_V1.json b8d25fc00366242bd38bb1e56f16cd30dd1aa78262b8a1eda9e2a2fe4068671d --registry-extension design/FRESH_EVIDENCE_FOLLOWUP_AMENDMENT_V1.json b899191bccf897689b5ea543b05367f2b62d60fb481e7e2f3255246a7afe2b75 --registry-extension design/CADENCE_FLOOR_NEIGHBORHOOD_V1.json 69046b327908410cc7d291c23b7d77205f7cdacd7ca19ac03caf52307ed5d9d5 --registry-extension design/ENDPOINT_ADVICE_FACTORIAL_V1.json f44ecb1960585420956ab34aab2dfa43126e48742372cf9e801503e0de30da91 --expected-candidates 240 --gallery-map-extension enrollment/common30_v1/SCORER_GALLERY_MAP_EXTENSION.json 674180273a59660c8dd7b7c22070d7f2bb13e14fecda8e020070011c948692db enrollment/common30_v1/COMMON30_GALLERY_COMPLETION.json 3acdf09a67893e74d2d85d7d80704f9e63301b89f8d29d3294aea057f20c2ed7
```
