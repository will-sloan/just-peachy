# Actual native cadence-floor mechanisms

The448 new native event files passed the unchanged original admission/call/parser
and compact arithmetic checks. The old336-cell C065/C071/C082 audit is reused as
bound compact evidence, without rescanning its logs. All new cells and all parent
cells remain; this audit did not infer, rescore or read waveform/model payloads.

The floor changes actual behavior. Each candidate has112 native sessions,56 scenes
per tap. Each tap contains2502.9445 source seconds and9968 shared speaker dispatches
(19936 short/mature role opportunities). Counts below pool the two taps but not
independent scenes across configurations.

| Candidate | Floor/cues | Actual embedding calls /112 sessions | Due entries acknowledged on globally admitted roles | Shared dispatches with any due /19936 | Direct cue-event dispatches /19936 |
|---|---|---:|---:|---:|---:|
| C071 |1s/off|2409|4923|17703|0|
| C191 |.5s/off|2485|8227|17773|0|
| C193 |2s/off|2330|2982|17216|0|
| C082 |1s/real|2401|4749|17490|0|
| C192 |.5s/real|2485|7884|17694|0|
| C194 |2s/real|2322|2895|16961|0|

Changing1s→.5s adds76 calls with cues off and84 with real cues; changing1s→2s
removes79 calls on either route. This supplies an actual numeric neighborhood of
the due-ledger mechanism. It does not prove that a due person's voice was sampled:
the frozen implementation acknowledges every due entry on a global admitted role.
Target-person selection remains unobserved. Direct cue-event scheduling is zero
in these accelerated runs, while other indirect tracker/context effects can exist.

Each adaptive candidate has3490 empty/missing-context dispatches out of19936,
with7999 observed ages on O0 and8447 on O1. Observed mean context age is between
10.3666 and10.4978 seconds across the new four candidates/taps; maximum age is
between39.8777 and39.9462 seconds. This is source cursor minus the newest released
snapshot stamp among returned context rows, not every track's state age. Empty
context is not filled with zero. The earlier1s parents have the same missing counts
and similarly stale observed ages. These accelerated measurements cannot establish
source-paced scheduling ineffectiveness; the separately planned C071/C082 paced
diagnostic still addresses a material unanswered condition.

Costs below are **sums of observed native-session/whole-worker/CPU seconds across
112 sessions**, not coordinator elapsed or wall latency. Model/API/gate/dispatch
phases are nested, and concurrent lanes are not additive wall time. Parent and
new-neighbor batches occurred at different times, so their lower measured worker
cost cannot be assigned causally to a parameter change. Even within the new batch,
these are host observations rather than CM5 or quiet paced timing.

| Candidate | Native seconds | Whole-worker seconds | Process CPU seconds |
|---|---:|---:|---:|
| C071 |649.885|721.596|1136.672|
| C191 |595.662|665.704|1035.156|
| C193 |596.481|662.789|1017.063|
| C082 |638.610|729.881|1109.500|
| C192 |602.372|670.466|1024.906|
| C194 |591.558|658.669|1012.469|

New scheduler maintained pending-event peaks range29–34 across candidate/tap
aggregates; these are internal high-water counts. Peak journal lag and a targeted
voice-service count remain unavailable. They must not be substituted with final
lag, scheduler pending count or the number of debt acknowledgments.

The separate18-contrast quality receipt shows .5s/off C191 improves latest-label
cp by49 errors O0 and22 O1 relative to C071 on40 complete scenes/1030 words per
tap, but first-display cp and contained short-turn counts are unchanged. Its mixed
sole support increases, and real-cue C192's O1 latest cp worsens by9. The2s settings
reduce calls while worsening aggregate latest cp on both taps. Exact populations,
returns, incomplete/empty controls and conditional primary-word uncertainty remain
in `cadence_floor_comparisons_v1/INTERPRETATION_V1.md` and its bound tables.

Retain this as a conditional native mechanism/quality tradeoff. It supports keeping
C191 as a possible numeric companion, not replacing all other evidence with its
best cp total. Preserve the original1s C071/C082 paced diagnostic to test fresh
released-state behavior; no additional tuning or universal parameter-range claim
is justified by this panel alone.

V2's incorrect job-folder containment guard failed before any event file was read;
its source, plan and0-cell failure remain preserved. V3 admits the exact frozen
worker-owned session layout, with an independent repair review. The original
incidence/parser and aggregation arithmetic are unchanged.
