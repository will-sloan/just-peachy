# S6C strata companion V1

Purpose: copy all existing strata aggregates from the 31 core authorities in the approved working 38-authority scope, plus completed full N03 and N08/N10, without repeating the earlier 207-table export. This is a working companion, not the final handoff or a new score. Source histories and namespaces remain distinct, including both historical S6B sources.

Inputs: `APPROVED_STRATA_COMPANION_SPEC_V1.json`, SHA256 `f1d7161da4f657287d4f502a79798d2aaa270b176d2e5d68bdd00112643565ac`, explicitly binds 33 completed receipts and their original `STRATA_RESULTS.csv` table pointers. Every table uses `copy_intact`, no omissions, no filtering and no new row key. The earlier draft is preserved under `requirement_gap_review_v2`.

Execution uses the held `scripts/s6c_score_tables.py` (SHA256 `2c9bd02ec318a34fc2f7a0d07004a5b099c2afd5f404a6a362e3302bca747406`) and its maintained README (SHA256 `623fb62b57110c7e86141d37fa0c64d431c588ce7c7b53814d3382d3789be1cc`). No new code, package installation, score computation or model execution is involved.

Actual output: `strata_companion_v1/COLLECTION_MANIFEST.json`, SHA256 `f13bae96e3001ceb317ec0c9a7d544598ebf4169fe818099faa84ac1f8673f0a`, records 33 CSVs, 66,064 aggregate rows and 56,857,225 CSV bytes. CSVs plus collection manifest total 56,974,575 bytes, excluding this README and verification supplements. `strata_companion_v1/COPY_VERIFICATION.json` rehashes every copied output and confirms original-source byte-count/hash equality. There are no omission ledgers. No compression measurement or final ZIP was performed.

Whole-scene stratum memberships overlap; the row count is neither a unique scene count nor a physical execution count. Preserve original population, membership and word-pool fields. The core tables do not establish actual known-name accuracy, relocation causality or final-study completeness. All original source files remain unchanged. Full N12, cross and eventual paced outputs are excluded until their required score authorities are complete and separately admitted.

## Exact executed PowerShell command

```powershell
$s6cRepo = 'C:\Users\amiri\Documents\GitHub\just-peachy'
$s6cSim = Join-Path $s6cRepo 'XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
$s6cReport = Join-Path $s6cSim 'reports\S6C\20260910T123540Z'
$s6cPython = Join-Path $s6cRepo '.edge-speech-env\python.exe'
$s6cSpec = Join-Path $s6cReport 'compact_score_tables\APPROVED_STRATA_COMPANION_SPEC_V1.json'
$s6cHash = 'f1d7161da4f657287d4f502a79798d2aaa270b176d2e5d68bdd00112643565ac'
if ((Get-FileHash -LiteralPath $s6cSpec -Algorithm SHA256).Hash.ToLowerInvariant() -ne $s6cHash) { throw 'Approved specification changed' }
& $s6cPython -B (Join-Path $s6cSim 'scripts\s6c_score_tables.py') export --spec $s6cSpec --spec-sha256 $s6cHash --output (Join-Path $s6cReport 'compact_score_tables\strata_companion_v1')
```

Before the actual invocation, the held helper and README hashes were also checked and no active `PACED_QUIET_OWNER.json` was present. Root explicitly authorized this bounded copy while ordinary native work continued.

## Anaconda Prompt or Windows CMD equivalent

```bat
set "S6C_REPO=C:\Users\amiri\Documents\GitHub\just-peachy"
set "S6C_SIM=%S6C_REPO%\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
set "S6C_REPORT=%S6C_SIM%\reports\S6C\20260910T123540Z"
set "S6C_SPEC=%S6C_REPORT%\compact_score_tables\APPROVED_STRATA_COMPANION_SPEC_V1.json"
set "S6C_HASH=f1d7161da4f657287d4f502a79798d2aaa270b176d2e5d68bdd00112643565ac"
"%S6C_REPO%\.edge-speech-env\python.exe" -B "%S6C_SIM%\scripts\s6c_score_tables.py" export --spec "%S6C_SPEC%" --spec-sha256 "%S6C_HASH%" --output "%S6C_REPORT%\compact_score_tables\strata_companion_v1"
```

The existing explicit Python already supplies all standard-library dependencies; `conda activate` is unnecessary. The commands above document the completed invocation and now fail closed because the output exists. For an explicitly requested reproduction, choose a fresh output suffix such as `strata_companion_reproduction_v1`; never delete or overwrite the completed directory. A changed scope needs a new approved specification and supplied hash. Consult `scripts/README_S6C_SCORE_TABLES.md` for schema, strict source-buffer admission, partial-output behavior and copy semantics.
