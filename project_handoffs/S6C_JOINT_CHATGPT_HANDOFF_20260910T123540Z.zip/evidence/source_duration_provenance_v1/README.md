# Original duration provenance for four nonmodal inputs

The original scene bank scheduled47 seconds for S45_03_11 and100 seconds for S45_06_01, S45_06_06 and S45_06_11. Their bound physical-capture receipts record exactly the same capture extents. The longer inputs therefore predate H2 and S6B/S6C preparation.

| Case | Original scene / physical capture (s) | Decoded / consumed H2 input (s) | Scheduled source supports |
|---|---:|---:|---|
| S45_03_11 |47 /47|46.6954375|Six whole clips,3.000–40.622s, five0.25s source-support gaps|
| S45_06_01 |100 /100|99.6954375|A1, B1, A2; B1 ends12.520s, A2 starts60.520s|
| S45_06_06 |100 /100|99.6954375|A1, B1, A2; B1 ends12.380s, A2 starts60.380s|
| S45_06_11 |100 /100|99.6954375|A1, B1, A2; B1 ends13.616s, A2 starts61.616s|

All four original framing receipts declare14,619 startup native frames excluded, zero trailing frames, and native-frame extents2,256,000 or4,800,000. Their frame/capture-duration fields imply48,000 native frames/s. The exact metadata relation `(native_frames -14619)/3 = decoded_frames` gives747,127 or1,595,127 decoded samples at16kHz. Thus the0.3045625s capture-to-decoded difference is accounted for by the recorded startup framing exclusion. The original adapters, completed H2 journals and retained S6B/S6C input index agree exactly on those decoded counts. This is distinct from the separately reported0.1954375s speaker sub-hop tail: H2 ASR/speaker cursors reached the complete input duration while analysis ended on its own grid.

The three F06 schedules belong to the declared silent-relocation/long-paused-return family and contain an exact48s gap between B1 source support and A2 return support. Those are source-schedule facts, not measured silence in the captured output. The metadata does not explicitly state the builder rule choosing exactly100s, or the rule selecting47s around the six F03 clips. We do not label the remaining extent as silence, drain, duplicate playback, missing speech or a bug.

The physical receipt asserts all nonzero source payload captured, zero missing/duplicate active payload samples, and boundary-padding-only exclusions (7,578 source frames in its aligned comparison). Those assertions are inherited from its previously accepted verification; this review did not reopen packed data, audio, expected arrays, capture/event logs or models. The capture offset2,705 source samples and the14,619 excluded native frames describe different boundaries and are retained separately.

Inputs: sealed INPUT_INDEX L0119, the source-audit-bound SCENE_MANIFEST, eight directly bound historical H2 receipt chains/summaries and four directly referenced case_result metadata files. Outputs: RESULT.json, this note and exact metadata snapshots under staging/s6c/20260910T123540Z/source_duration_provenance_v1. No score/input/profile/draft changed; no inference, remeasurement or historical rerun.

To inspect in PowerShell from this directory: `Get-Content -LiteralPath .\RESULT.json`. In Anaconda Prompt/CMD: `type RESULT.json`. These commands read the supplement; no model environment activation or package installation is required.
