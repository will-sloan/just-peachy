# Source and transcript evidence for the S6C handoff

Sealed metadata and inherited validation only; no audio/model reread, prediction quality, live runtime or final S6C completion claim.

The canonical bank contains **240 scenes, 480 tap views, 777 scheduled source occurrences, 449 unique source clips and 43 corpus-qualified metadata identities**. Corpus identifiers do not prove unique biological people across datasets.

| Population | Scenes | Reference words | Valid interpretation |
|---|---:|---:|---|
| Primary nonoverlap |156|4560|Primary WER/CER|
| Complete overlap |47|1456|Inherited MIMO/cp text diagnostics|
| Incomplete environmental reference |26|Not pooled|Target-only text diagnostic|
| Intentional empty reference |11|0|Insertion counts/rates; WER undefined|

The complete nonempty union is **203 scenes / 6016 reference words**. Counts are once per source scene; O0/O1 and repeated candidates do not create independent reference material. Old development/reserve tags are preserved, and all240 use is explicitly authorized for this research.

| Corpus | Q occurrences | Unique Q clips | Metadata IDs | E clips | C clips |
|---|---:|---:|---:|---:|---:|
|CMU ARCTIC|245|206|18|230|230|
|Common Voice|264|121|15|32|16|
|HiFiTTS|268|122|10|123|121|

E is enrollment, C is calibration, and Q is the unchanged query bank. **752 whole E/C clips (385 E, 367 C)** passed the inherited source preparation. E tiers have **37/30/28 available identities at 5/15/30 seconds**. CMU contributes18 and HiFiTTS10 at every tier; Common Voice contributes9/2/0. C has28 identities with30seconds,8 with less, and7 with none. Unavailable material is not filled with another speaker.

Native enrollment produced95 templates:73 PASS and22 REVIEW_LOW_CONSISTENCY retained. The original2,169 gallery condition/tier/case rows include344 explicit empty rows. Six additive fixed common-cohort assignments reuse templates. The inherited1976 ReDim calls belong to enrollment/C fitting, not new work by this collector. C fitting uses known members of each roster; it is not unknown-stranger validation.

The two excluded E/C candidates are CV26_common_voice_en_18596 and HIFI_11614_littleminister_40_barrie_0071 (source rail/overrange). L2 ARCTIC remains excluded. All777 Q occurrences remain. Exact checked E/C/Q source-ID, byte, normalized-text and prompt intersections are empty. Three HiFiTTS identities (11697,6671,9136) use different chapters of the same non-Q book for E and C. This is shared-book dependence, not independent-session evidence. Transformed aliases, unknown crops and cross-corpus biological identity were not exhaustively ruled out.

Rights statements below are inherited local audit assertions, with exact notice/source bindings in the JSON; this appendix performs no new legal clearance. CMU ARCTIC is recorded as permissive with attribution/notices and missing per-voice notices disclosed. HiFiTTS is recorded as CC-BY-4.0 with NVIDIA/authors and LibriVox/Gutenberg source attribution. Common Voice is recorded as CC0 with its release binding and prohibition on contributor identification. Training, redistribution and voice-synthesis consent are not automatically cleared by this study.

Enrollment uses clean source clips; Q uses simulated room convolution followed by captured XVF outputs. This is a clean-to-processed domain mismatch. The33 optional reference clips used are source material; no optional physical reference capture was performed. No private/default profile gallery is used.

The inherited canonical RIR library has121 records (95 EXTRACTED,26 EXTRACTED_WITH_LIMITATIONS), acquired only from PASS/REVIEW formal measurements.52 historical pilot/diagnostic/ineligible measurements and6 later scope exclusions stay excluded. Effective distances are0.46–4.07m. The two +20-degree low-table R05 records retain raw100m alongside the user-confirmed1.00m effective correction. Signed angle centers are unchanged. Manual +/-5-degree labels and nominal native-angle transforms are not independent acoustic calibration; front/rear ambiguity remains.

The machine-readable CSV has one row per scene. Identifiers, family and historical split/source partition come from the canonical bank; population/word counts use the unchanged inherited normalization/reference-layout functions. `normalized_reference_words` is observed annotated text even when incomplete; only `primary_word_denominator` and `complete_word_denominator` enter their stated populations. Zero in either denominator means ineligible for that pool, not error-free recognition. Blank `target_only_reference_words` means not applicable. List fields are JSON strings; booleans are literal True/False. `reference_problems` and `inherited_coverage_limitations` retain actual exclusions. Nominal source duration and measured O0/O1 capture durations are separate. PCM hashes/gains are inherited bindings, not a new audio hash audit. `support_sha256` binds the exact source support/offset; activity remains estimated. `canonical_rir_ids` lists scheduled utterance RIRs.

Source bindings form a finite DAG: this audit binds its CSV/summary and consumed metadata/code; it does not bind itself or final S6C results. Raw sources, WAVs, models and native journals are not opened. No accuracy, runtime-finalist, full-campaign completion or new physical validation is asserted.
