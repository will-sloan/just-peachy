# Full N12 endpoint-recipe confirmation — working interpretation V1

C076 preserves N12's useful first-display-label tradeoff across the full bank. Against its C065 parent, first-display-label cp errors fall by259 on O0 and149 on O1, while latest cp changes by−1 and−73. This is a change in the labels attached to finalized words at first display, not evidence of a measured display-latency or partial-word accuracy improvement. Word errors are essentially unchanged, complete-overlap latest attribution worsens, and return consistency does not improve. C076 is a useful fifth paced representative, pending actual runtime and adverse-condition review; it is not an automatic operating selection.

## Exact scope and settings

The closed native index contains480 C076 cells: all240 cases on each fixed same-tap O0/O0 and O1/O1 route. Its execution reports368 new cells and112 reused panel cells, and the frozen native/shared replay parity reports480 passes with no mismatch. The existing V3 scorer completed480/480 with no unscored cells. No model, native run or policy replay was started for this interpretation.

C076 changes the two N01 ASR endpoint silence rules from2.4/1.2 seconds to1.6/0.8 seconds. The20-second utterance rule, greedy decoder, short/mature evidence, anonymous tracker and cue-off/no-gallery settings are retained. This is the fixed endpoint-rule bundle N12, not the separate C195/C196 cue-advice factorial. The C067 comparator instead changes the mature evidence window; C067 versus C076 is a complete-condition comparison with multiple settings different.

The11 fixed contrasts are C065, B00, B01, B36 and C067 each on both same taps to C076, plus C076 O0 to O1. The scope and deterministic example-selection rule were written before inspecting these full N12 scores, after the earlier panel findings were known. These are outcome-informed full-bank confirmations, not an independent holdout. Historical controls compare whole pipeline generations. O0 and O1 share captures.

## Complete-reference outcomes

Every row below has203 complete nonempty scenes,6016 reference words,693 source turns,25,304,912 sole-active samples and292 return groups. The word-error column combines156 primary scenes scored with serialized WER (4560 words) and47 complete-overlap scenes scored with inherited MIMO edits (1456 words). It is not one serialized raw-word alignment over203 scenes. The26 incomplete-reference scenes and11 strict-empty scenes remain separate.

| Profile | Tap | Mixed complete word errors /6016 | First-display-label cp errors /6016 | Latest cp errors /6016 | Unknown sole samples % | Return consistent / inconsistent / unknown |
|---|---|---:|---:|---:|---:|---:|
| C065 | O0 | 1142 | 3955 | 3732 | 35.695 | 41 /49 /202 |
| C065 | O1 | 1207 | 3971 | 3865 | 34.767 | 37 /57 /198 |
| C067 | O0 | 1142 | 4052 | 3547 | 38.001 | 18 /28 /246 |
| C067 | O1 | 1207 | 4042 | 3710 | 37.100 | 17 /40 /235 |
| C076 | O0 | 1143 | 3696 | 3731 | 35.673 | 40 /51 /201 |
| C076 | O1 | 1207 | 3822 | 3792 | 34.705 | 37 /58 /197 |

C076 minus C065 first-display cp is−4.305pp O0 and−2.477pp O1. Latest cp is−0.017pp and−1.213pp. Lower first-display cp does not guarantee lower latest cp on each scene, nor a more consistent returning-person identity. Unknown exposure changes only slightly. Mixed-reference sole-sample fractions likewise change from0.934% to0.931% O0 and0.797% to0.795% O1.

The population split matters. On primary scenes, first-display cp changes3059→2813 O0 and3058→2954 O1; latest changes2837→2828 and2945→2864. On complete-overlap scenes, first-display cp changes896→883 and913→868, but latest worsens895→903 and920→928: eight additional errors on each tap. A single complete-population latest headline conceals that adverse overlap result.

The complete-reference word S/D/I counts are C076544/519/80 O0 versus C065545/519/78, and579/547/81 O1 versus579/548/80. Only3 of240 O0 normalized final texts and6 of240 O1 texts differ; among the203 complete scenes the O1 changed-text count is5. Equal total errors do not mean identical words.

B36 remains better than C076 on the complete first-display and latest cp point totals: C076 has5/42 additional first-display errors and63/51 additional latest errors on O0/O1. B36 is a cross-generation fallback comparator, not an isolated endpoint control. Against C067, C076 has356/220 fewer first-display errors but184/82 more latest errors; it also has less Unknown exposure and more consistent returns. That distinction supports keeping both scientific tradeoffs visible.

The fixed O0 C076 route has64 fewer complete word errors,126 fewer first-display errors and61 fewer latest errors than fixed O1. These source-bank point results do not authorize per-scene tap selection or establish behavior outside these captures.

## Word uncertainty, incomplete references and strict-empty controls

The primary serialized word totals are656→657 O0 and705→705 O1 for C065→C076. The unchanged2000-resample paired procedure uses156 primary scenes in116 matched blocks across five rooms. Its primary-word right-minus-left95% percentile intervals are[−0.04555,+0.10407]pp O0 and[−0.06559,+0.06649]pp O1; both include zero. They are not cp intervals. The C076 fixed O1-minus-O0 primary-word interval is[+0.34842,+1.79798]pp. This is the declared conditional block resampling, not independent capture replications.

The26 incomplete-reference scenes contain84 source turns,3,307,520 sole-active samples and32 return groups per route. C076's return partitions4/3/25 O0 and4/2/26 O1 equal C065's in this limited population. Its Unknown sample counts are1,234,260 and1,288,338, versus1,230,959 and1,286,398 for C065. These available tracking diagnostics are preserved without promoting incomplete lexical references into complete-score evidence.

All11 strict-empty cases remain in each route. C076 and C065 have the same insertion totals1 O0 and2 O1, with1 and2 cases producing nonempty final text. There is no zero-reference WER. This rules out a new aggregate strict-empty insertion problem in this finite comparison; it is not proof against future hallucination.

## Short speech, lifecycle and observed work

| Profile | Tap | Subsecond40: contained / any known / correct modal | 1–under2s34: contained / any known / correct modal |
|---|---|---:|---:|
| C065 | O0 | 19 /26 /12 | 32 /33 /10 |
| C065 | O1 | 24 /32 /12 | 34 /33 /8 |
| C067 | O0 | 19 /25 /9 | 32 /31 /8 |
| C067 | O1 | 24 /32 /12 | 34 /32 /7 |
| C076 | O0 | 19 /26 /12 | 32 /33 /11 |
| C076 | O1 | 24 /32 /12 | 34 /33 /8 |

Containment is not naming, and any duration-mapped correct support differs from a correct modal identity over a whole turn. C076's subsecond contained-evidence waits have19/40 observations on O0 and24/40 on O1, with medians0.799/0.792 seconds;21/16 turns have no such observed contained evidence. These inherited source/evidence-time quantities are not actual paced wall-time display latencies. Known-support and correct-mapped-support waits, with their separate observed/missing sets, remain in RESULT.json.

Across all240 fresh scene sessions per route, C076 and C065 both peak at13 live anonymous tracks and report zero blocked unique-evidence seconds. They have the same aggregate retirement sums562/720 and lifetime-ID sums1931/2161. This is not a continuous-session capacity stress result. Qualified tracking-cue decision counts are zero as expected for cue-off settings; those counters do not measure fixed-ASR endpoint activations.

C076 produces610/624 final utterances across complete scenes versus573/584 for C065. This supplies direct exported-boundary evidence consistent with the shorter endpoint-rule bundle. Complete partial counts are5547/5510 versus5547/5511. The final-count change is not a phonetic end-latency estimate; no claim about the number of particular endpoint-rule triggers is made from this compact table.

Each all240 route accounts for10893.905 source seconds using the actual nonuniform durations. Observed nested cost sums are:

| Profile | Tap | Embedding calls | Embedding compute sec | Full speaker-dispatch sec | Full ASR-dispatch sec |
|---|---|---:|---:|---:|---:|
| C065 | O0 | 6417 | 186.121 | 1366.566 | 820.559 |
| C065 | O1 | 6589 | 189.548 | 1369.710 | 814.258 |
| C067 | O0 | 5127 | 185.962 | 1337.114 | 817.159 |
| C067 | O1 | 5255 | 186.059 | 1331.070 | 802.804 |
| C076 | O0 | 6417 | 184.265 | 1345.321 | 812.867 |
| C076 | O1 | 6589 | 185.987 | 1340.814 | 783.338 |

Embedding cost records are observed for235 O0 and237 O1 cells per profile; the other5/3 remain unavailable in that cost section, not zero-cost imputations. Full-dispatch fields are observed for all240. Nested compute/API/dispatch timings overlap and must not be summed as whole-pipeline wall time. The native cells span different batches and reused panel work. Equal call and lifecycle sums do not prove identical vectors, event order or every per-cell decision. These numbers do not establish source-paced latency or deployment speed.

## Deterministic counterexamples

The predeclared rule retains two largest and two smallest signed scene error-rate differences for C076 versus C065, on each tap for latest cp and word errors, breaking ties by case ID. These are descriptive extremes, not typical cases or a selection rule. Zero differences are ties.

On O0, S45_01_15 worsens latest cp23→36/30 words despite word errors staying7 and first-display cp staying36. S45_09_20 worsens latest7→15/26 with word errors7 unchanged. Conversely S45_05_19 improves latest14→0/29 while first-display cp stays20 and word errors stay0; improved latest attribution does not establish a better first display.

On O1, S45_11_03 worsens latest12→20/29 and first-display20→24 with word errors12 unchanged. S45_04_11 worsens latest17→24/31 while word-error count14 stays constant, although its S/D composition changes. S45_07_06 improves latest31→6/33 while its first-final and first-display counts are both6 in both conditions: the difference is in the retained latest attribution, not a raw transcription gain. S45_07_03 improves latest23→7/29 and first-display28→7 with word errors7 unchanged.

The selected word harms include S45_06_01: O0 word errors3→4/27 while first-display cp improves19→17, and O1 word errors2→3 while latest cp improves19→17 but first-display worsens19→20. This is one of the99.6954375-second captures, not a44.695-second case. S45_12_17 has one fewer word error on each tap. The zero-difference S45_01_01 rows selected by the fixed two-row rule are ties, not claimed word benefits or harms.

## Authority and remaining decisions

RESULT.json binds the exact completed C065/C067/C076 tables and all11 comparison outputs, with53,375 compact checks. ANALYSIS_RECEIPT.json records C076480/480 completion. COMPARISON_RECEIPT.json binds the unchanged paired arithmetic and primary-only uncertainty. The separate pure-check receipt records five numeric/selection guards. INTERPRETATION_BINDING_V1.json links this prose, code/README, finite scope, actual registry settings, native closure/parity and those completed numerical authorities.

C076 merits the distinct fifth scientific paced condition because its first-display-label result survives full confirmation while the latest/overlap/return tradeoffs remain visible. C065 is the matched recipe control, C067 the different retrospective-evidence alternative, and B36 the whole-generation comparator. No new combined named/cue/window/endpoint profile is implied. Actual paced, long-session and remaining fixed-cross results are still needed before choosing operating profiles or fallback.

