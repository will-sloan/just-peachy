# Research gallery handoff alias

RESEARCH_GALLERIES.json is a byte-for-byte copy of the completed RESEARCH_GALLERY_INDEX_V2.json. It satisfies the requested handoff filename while preserving the complete original logical roster index, local gallery manifest paths, sizes and hashes. No gallery, template, waveform, vector or native outcome is regenerated.

There are 2,175 logical condition/case/tier references and 180 distinct manifest hashes. Neither count represents people, templates, runtime model loads or inference calls. The inherited COMPLETE status describes index creation only; S6C remains in progress. Actual loaded-gallery receipts and later paced results have separate execution authorities. The alias receipt verifies only the exact small index buffer and copy, not every transitive asset again.

Inputs are the existing immutable V2 index and its exact SHA256, 4fa672f9c8f770974c8bcb17dec808427f3a5b49c8b64e1ee30ca9cfbb7aa9c3. Outputs are RESEARCH_GALLERIES.json and ALIAS_RECEIPT.json. Keep the original index and all referenced source files unchanged.

## Verify in PowerShell

```powershell
$s6cReport = 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z'
Get-FileHash -LiteralPath (Join-Path $s6cReport 'RESEARCH_GALLERY_INDEX_V2.json') -Algorithm SHA256
Get-FileHash -LiteralPath (Join-Path $s6cReport 'handoff_aliases_v1\RESEARCH_GALLERIES.json') -Algorithm SHA256
```

## Verify in Anaconda Prompt or Windows CMD

```bat
set "S6C_REPORT=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z"
certutil -hashfile "%S6C_REPORT%\RESEARCH_GALLERY_INDEX_V2.json" SHA256
certutil -hashfile "%S6C_REPORT%\handoff_aliases_v1\RESEARCH_GALLERIES.json" SHA256
```

Both commands should show the SHA256 above. No inference or audio-device access occurs. The existing alias is immutable; a changed source requires a fresh alias/version and provenance receipt, never an overwrite of this result.

