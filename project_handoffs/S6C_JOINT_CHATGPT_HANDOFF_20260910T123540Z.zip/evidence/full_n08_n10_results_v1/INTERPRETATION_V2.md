# Full N08/N10 confirmation — working interpretation

C072 and C074 completed all 240 scenes on both same-tap routes: 960 actual native cells with exact shared replay parity and 960/960 core scores. The native batch includes 736 new cells and 224 preserved panel cells, rather than 960 new independent executions. Eighteen fixed full-population comparisons completed. The compact summary reconciles 58,304 table checks and preserves every comparison and population.

These results describe conditional tradeoffs. C072 improves first-display attribution and reduces Unknown support, but increases inconsistent returns and has opposite latest-cp directions across taps. C074 produces a modest complete-reference word-error reduction with a material O1 empty-control insertion regression. Neither result establishes overall dominance or a final operating choice. N12, fixed cross-route confirmation and source-paced/continuous results remain separate pending inputs.

## What changed and what is being measured

C072 is recipe **N08**, changing N01 segmentation post-processing from posterior hysteresis to hard-argmax fraction decisions. It is not the separately registered clean-shadow tracking family. C074 is recipe **N10**, changing N01 greedy ASR decoding to modified beam search with two active paths. The algorithm/path setting is a declared decoder condition; this is not an isolated active-path-count experiment. Both use cues off and no naming gallery, with the registered N01 tracking/evidence settings.

First-display-label cp uses the finalized words with the label first displayed. Latest cp includes permitted retrospective attribution revisions. Neither is partial-transcript WER or actual wall-clock display latency. cp includes both lexical and anonymous attribution error. C074 changes words, so its cp changes cannot all be attributed to tracking.

The complete-reference headline population is **203 scenes, 6,016 words, 693 source turns, 25,304,912 sole-active samples and 292 return groups per route**. The 26 incomplete-reference scenes and 11 strict-empty scenes remain separate in all_profile_population_rows and the original score tables. This is not a denominator of all 777 source occurrences. O0 and O1 share captures.

The headline inherited word-error total combines two metric scopes: 156 primary nonoverlap scenes with 4,560 words use serialized primary WER, while 47 complete-overlap scenes with 1,456 words use overlap MIMO edit counts. Their summed numerators and reference counts are the inherited descriptive complete-population aggregate, not one serialized raw-word alignment over all 203 scenes. The complete-population substitution/deletion/insertion breakdown has the same mixture. The separate primary-only comparisons below retain the serialized-word uncertainty scope.

| Profile | Tap | Inherited word errors (mixed scopes) / 6016 | First-display-label cp errors / 6016 | Latest cp errors / 6016 | Unknown sole support |
|---|---|---:|---:|---:|---:|
| C065 N01 | O0 | 1142 | 3955 | 3732 | 35.695% |
| C065 N01 | O1 | 1207 | 3971 | 3865 | 34.767% |
| C072 N08 | O0 | 1142 | 3875 | 3797 | 33.396% |
| C072 N08 | O1 | 1207 | 3886 | 3818 | 33.238% |
| C074 N10 | O0 | 1127 | 3855 | 3732 | 35.662% |
| C074 N10 | O1 | 1191 | 3927 | 3820 | 34.720% |

Against C065, C072 first-display cp changes by -80/-85 errors (O0/O1); latest cp changes by +65/-47. Its normalized final text is exactly equal to C065 in all 480 cells. The word-error contrast is consequently zero on both complete and primary populations. This is a source-backed distinction between changed attribution and unchanged final words, not evidence that every internal timing or label decision is unchanged.

C074 first-display cp changes by -100/-44 errors; latest cp changes by 0/-45. Normalized final text changes in 113/240 O0 cases and 121/240 O1 cases. On complete-reference scenes, O0 word substitutions/deletions/insertions change from 545/519/78 to 546/490/91; O1 changes from 579/548/80 to 582/522/87. The total reductions of 15 and 16 errors include fewer deletions with more substitutions and insertions. The separate positional token-boundary diagnostic is required to locate first/last-token deletions; these totals do not establish their positions.

## Returns, short support and lifecycle

Return consistency is an anonymous tracking measure, not recognition of a person's enrolled name. All return triplets below partition the same 292 complete-reference return groups.

| Profile | Tap | Consistent | Inconsistent | Unknown |
|---|---|---:|---:|---:|
| C065 | O0 | 41 | 49 | 202 |
| C065 | O1 | 37 | 57 | 198 |
| C072 | O0 | 47 | 62 | 183 |
| C072 | O1 | 42 | 64 | 186 |
| C074 | O0 | 41 | 51 | 200 |
| C074 | O1 | 39 | 57 | 196 |

C072 resolves more returns into assigned anonymous tracks, with both additional consistent and additional inconsistent returns. The lower Unknown fraction therefore does not by itself establish better identity continuity. Its mixed-identity support over all sole-active samples also rises from 0.934% to 1.001% on O0 and 0.797% to 0.840% on O1. C074's changes in these support measures are small, and its complete lifecycle totals match C065; equal totals do not prove every individual state/decision is identical.

The subsecond denominator is 40 turns and the one-to-under-two-second denominator is 34 turns. “Contained” means a contained embedding exists; “known support” means some assigned anonymous support; “mapped correct modal” uses the inherited retrospective duration mapping. These are different conditions and are not actual known-name correctness.

| Profile / tap | Subsecond contained / 40 | Subsecond known support / 40 | Subsecond mapped-correct modal / 40 | 1–<2 s contained / 34 | 1–<2 s mapped-correct modal / 34 |
|---|---:|---:|---:|---:|---:|
| C065 O0 | 19 | 26 | 12 | 32 | 10 |
| C065 O1 | 24 | 32 | 12 | 34 | 8 |
| C072 O0 | 23 | 30 | 9 | 33 | 11 |
| C072 O1 | 22 | 31 | 9 | 34 | 9 |
| C074 O0 | 19 | 26 | 12 | 32 | 10 |
| C074 O1 | 24 | 32 | 12 | 34 | 8 |

C072 subsecond mapped-correct modal turns fall from 12 to 9 on both taps despite O0 containment increasing. Observed/censored waits are retained in short_turns. For example, C072 subsecond contained-evidence waits are observed for 23/40 O0 and 22/40 O1 turns, with conditional medians about 0.697/0.703 seconds. The remaining 17/18 turns are missing for this criterion; they are not zero-wait observations. These source/evidence-clock waits are not phonetic, GUI or paced wall latency.

Across all 240 cases per route, maximum live anonymous tracks are C065 13/13, C072 14/13 and C074 13/13. Recorded blocked unique evidence is zero in all six routes. Thus these full comparisons do not exhibit live-capacity exhaustion. They do not establish endurance behavior in continuous sessions. C072 summed retirements are 605/707 versus C065 562/720; C074 has 562/720. These are sums across fresh scenes, not one continuous lifecycle. Logged activation and lineage counters remain in RESULT.json; missing or unlogged activation is not an empirical accuracy failure.

## Strict-empty controls and decoder exposure

All 11 strict-empty cases are retained per tap. C072 has the same insertions as C065: 1 on O0 and 2 on O1. C074 also has 1 on O0, but **19 on O1**, across four nonempty outputs instead of C065's two. No WER is calculated against a zero reference-word denominator.

The four nonempty C074/O1 empty-control outputs, from the exact bound SCENE_RESULTS.csv, are:

| Case | Inserted normalized words | Count |
|---|---|---:|
| S45_12_09 | um | 1 |
| S45_12_16 | and law and and um | 5 |
| S45_12_18 | um um um and | 4 |
| S45_12_20 | and and and and and and and and um | 9 |

These outputs document the O1 empty-scene regression and remain separate from the 6,016-word complete-reference comparison. The table alone does not identify a phonetic cause or claim that the same effect will occur under every input condition.

## Native resource observations and uncertainty

The exact full source duration is 10,893.905 seconds per tap across 240 cells. Full-bank durations are nonuniform: 472 views are 44.6954375 seconds, two S45_03_11 views are 46.6954375 seconds, and six views from S45_06_01/06/11 are 99.6954375 seconds. The scorer uses each actual duration; the separate prepared paced panel has a different duration scope.

| Profile / tap | Observed embedding calls | Cells with embedding cost record / 240 | Embedding compute seconds | Full speaker-dispatch seconds | Full ASR-dispatch seconds |
|---|---:|---:|---:|---:|---:|
| C065 O0 | 6417 | 235 | 186.121 | 1366.566 | 820.559 |
| C065 O1 | 6589 | 237 | 189.548 | 1369.710 | 814.258 |
| C072 O0 | 6520 | 235 | 184.087 | 1337.755 | 808.704 |
| C072 O1 | 6506 | 236 | 185.277 | 1346.220 | 789.437 |
| C074 O0 | 6417 | 235 | 184.384 | 1340.321 | 819.449 |
| C074 O1 | 6589 | 237 | 188.365 | 1346.251 | 814.446 |

These are observations from distinct native batches with preserved panel reuse. Absent embedding-cost records retain explicit unavailable counts; they are not imputed zero-cost measurements. Full speaker and ASR dispatch fields are observed in all 240 cells per route. Model/API/full-dispatch times are nested and concurrent lanes overlap; the columns must not be added to estimate whole-pipeline wall time. The native N08/N10 pool elapsed 6,391.430 seconds for 736 new executions plus reuse/admission work, while all 960 core rows include reused cells. None of these measurements is a source-paced or CM5 performance claim.

Primary-word conditional resampling uses 156 scenes, 4,560 words, 116 matched blocks, five observed rooms and 2,000 replicates. C072 same-tap word intervals against C065 and the historical controls are [0,0], reflecting identical word errors in this paired population. They are not cp intervals or proof of tracker equivalence.

For C074 minus C065, the primary-word point changes are -21/4560 errors (-0.461 percentage points) on O0 and -5/4560 (-0.110 points) on O1. Conditional 95% intervals are approximately [-1.016, 0.047] and [-0.549, 0.355] points, respectively. Both include zero. These are distinct from the complete-population changes of -15/-16 errors and from all cp point deltas.

All eighteen fixed contrasts remain in PAIRED_COMPARISONS.csv. Against original B36, latest cp is higher for both new candidates on both taps: C072 +129/+77 errors and C074 +64/+79 errors over 6,016 words. B36 is an original cross-generation full-pipeline comparator, not a tracker-only control. Historical B00/B01 outcomes and fixed-tap contrasts remain in the complete comparison table; no favorable comparison is substituted for another.

## Bounded examples and scientific disposition

The example rule was fixed before outcome inspection: two largest signed harms and benefits per candidate/tap for latest cp and raw words, tied by case ID. These are descriptive extremes. A zero-valued row under the helper's “largest_observed_harm” or “largest_observed_benefit” label is a tied zero, not an actual harm or benefit; this applies to C072's unchanged word rows.

- C072/O0 S45_02_18 retains one raw word error while latest cp rises 11→24 over 26 reference words. C072/O0 S45_08_07 retains one raw word error while latest cp rises 1→21 and first-display-label cp falls 21→1. Early and revised attribution can move in opposite directions. This is not a rerun or causal confirmation of the separate native/cache timing diagnosis on that case.
- C072/O1 S45_06_09 retains one raw word error while latest cp improves 26→1 over 37 words. The adverse and beneficial examples both remain.
- C074/O0 S45_01_19 improves raw errors 12→10 while latest cp worsens 28→40. A lexical gain does not guarantee an attribution gain.
- C074/O1 S45_03_11 retains four raw word errors while latest cp worsens 24→45 over 69 words. This case's actual longer source duration is retained.

The full results qualify the panel findings without erasing them. C072 supplies a segmentation/support tradeoff rather than uniformly better identity continuity. C074 supplies a small word-error tradeoff with extra insertion exposure, particularly on O1 empty controls. Complete-word accuracy, early/latest attribution, returns, short support, empty-scene behavior, native cost and eventual paced/continuous behavior must be considered together. Final operating retention remains pending; no new configuration or inference run is requested by this interpretation.

## Evidence

RESULT.json SHA a3d0baab3c7e8e54435a5b99ee228ef22af2c4b362fcd63a4d296aa11ea75902 binds the exact source tables and held summary code. The new core receipt is bd19ed5f87b07b82b5c7fb9f095437603b20261f1d8944bb9767e8b7d99fbdae; the completed eighteen-comparison receipt is 9db7ca29da8604778cf97ed42b3bfeb396cf40c7b1d44755a41a11685cfb6cd2. The native closure and 960-cell parity remain separately bound in INTERPRETATION_BINDING_V2.json. The interpretation does not claim that the compact table reader reopened native receipts or raw evidence. Independent compact numerical review is recorded separately when complete.
