# Five closed continuous-session post-analysis

Purpose: run the held original long C and B36 diagnostic converters on exactly the five closed sessions, then normalize their actual completion metadata. Inputs are RUN_SPEC.json, its exact original admissions/manifests, the finite five-receipt observer index, and the reviewed working registration. Outputs are fresh original long diagnostic families, one five-row normalization, per-command exit/log receipts and ACTUAL_EXECUTION_RESULT.json. Original sessions and prior596 paced results remain unchanged. No new models, policy replay, source correctness or shared-parity claim.

Use the exact EDGE interpreter in RUN_SPEC.json; no environment installation. Every concrete PowerShell and Anaconda Prompt/CMD command is appended below before it runs. A failed command stops this finite execution; preserve its receipt before any separately authorized repair. Commands use JP_S6C_SIM for the exact shared simulation path.

## C065_prepare

PowerShell:
~~~powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_fast_observer_analysis_v1.py' 'prepare' '--kind' 'long_c' '--namespace' 'c065_continuous_analysis_fast_v2' '--observer-index' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\fast_post_analysis\observer_indices\FIVE_LONG_CLOSED_OBSERVER_INDEX_V1.json' 'd57d952b98db1c543965d2fe6c4b38871e651f1290c9f7b8fd930d298bf396ee' '--admission' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\long_native_epoch4\epoch4_long_c065_o0_fast_v2\invocations\016fb56c1305425ca8db058e065a2a15\ADMISSION.json' 'fb98dde49f9619c32548e36401762ca541070146f59ec692244ee81ae043ce2b'
~~~

Anaconda Prompt / CMD:
~~~bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_fast_observer_analysis_v1.py" prepare --kind long_c --namespace c065_continuous_analysis_fast_v2 --observer-index "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\fast_post_analysis\observer_indices\FIVE_LONG_CLOSED_OBSERVER_INDEX_V1.json" d57d952b98db1c543965d2fe6c4b38871e651f1290c9f7b8fd930d298bf396ee --admission "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\long_native_epoch4\epoch4_long_c065_o0_fast_v2\invocations\016fb56c1305425ca8db058e065a2a15\ADMISSION.json" fb98dde49f9619c32548e36401762ca541070146f59ec692244ee81ae043ce2b
~~~

## C065_diagnostics

PowerShell:
~~~powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_fast_observer_analysis_v1.py' 'run' '--request' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\fast_post_analysis_admission\long_c\c065_continuous_analysis_fast_v2\REQUEST.json' '5a480dabc760c62ac97e72732154c01e512f20da638cfd3eb433d09d908d18a4' '--plan' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\long_diagnostics\c065_continuous_analysis_fast_v2\PLAN.json' '2f986e2eb395894e386d7dab35e7498b41e0a7a167813afce0c61f5a19557b91'
~~~

Anaconda Prompt / CMD:
~~~bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_fast_observer_analysis_v1.py" run --request "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\fast_post_analysis_admission\long_c\c065_continuous_analysis_fast_v2\REQUEST.json" 5a480dabc760c62ac97e72732154c01e512f20da638cfd3eb433d09d908d18a4 --plan "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\long_diagnostics\c065_continuous_analysis_fast_v2\PLAN.json" 2f986e2eb395894e386d7dab35e7498b41e0a7a167813afce0c61f5a19557b91
~~~

## C067_prepare

PowerShell:
~~~powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_fast_observer_analysis_v1.py' 'prepare' '--kind' 'long_c' '--namespace' 'c067_continuous_analysis_fast_v2' '--observer-index' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\fast_post_analysis\observer_indices\FIVE_LONG_CLOSED_OBSERVER_INDEX_V1.json' 'd57d952b98db1c543965d2fe6c4b38871e651f1290c9f7b8fd930d298bf396ee' '--admission' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\long_native_epoch4\epoch4_long_c067_o0_fast_v2\invocations\05a441f720d54cdcaf0f1a22502541c0\ADMISSION.json' '53788c680d8f067b06fbb319021784b7e2ecaf6cab7873afe43fed0a61c9a8ba'
~~~

Anaconda Prompt / CMD:
~~~bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_fast_observer_analysis_v1.py" prepare --kind long_c --namespace c067_continuous_analysis_fast_v2 --observer-index "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\fast_post_analysis\observer_indices\FIVE_LONG_CLOSED_OBSERVER_INDEX_V1.json" d57d952b98db1c543965d2fe6c4b38871e651f1290c9f7b8fd930d298bf396ee --admission "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\long_native_epoch4\epoch4_long_c067_o0_fast_v2\invocations\05a441f720d54cdcaf0f1a22502541c0\ADMISSION.json" 53788c680d8f067b06fbb319021784b7e2ecaf6cab7873afe43fed0a61c9a8ba
~~~

## C067_diagnostics

PowerShell:
~~~powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_fast_observer_analysis_v1.py' 'run' '--request' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\fast_post_analysis_admission\long_c\c067_continuous_analysis_fast_v2\REQUEST.json' 'bcfe8febb484bcf3b4cd7138fe20e44b224a5bb4bb00393eef58af9792ee6a85' '--plan' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\long_diagnostics\c067_continuous_analysis_fast_v2\PLAN.json' 'b39161731a3fe644a42d0e8c34a4f5650375f58dcb13506c54cfb62feb609a7a'
~~~

Anaconda Prompt / CMD:
~~~bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_fast_observer_analysis_v1.py" run --request "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\fast_post_analysis_admission\long_c\c067_continuous_analysis_fast_v2\REQUEST.json" bcfe8febb484bcf3b4cd7138fe20e44b224a5bb4bb00393eef58af9792ee6a85 --plan "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\long_diagnostics\c067_continuous_analysis_fast_v2\PLAN.json" b39161731a3fe644a42d0e8c34a4f5650375f58dcb13506c54cfb62feb609a7a
~~~

## C088_prepare

PowerShell:
~~~powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_fast_observer_analysis_v1.py' 'prepare' '--kind' 'long_c' '--namespace' 'c088_continuous_analysis_fast_v2' '--observer-index' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\fast_post_analysis\observer_indices\FIVE_LONG_CLOSED_OBSERVER_INDEX_V1.json' 'd57d952b98db1c543965d2fe6c4b38871e651f1290c9f7b8fd930d298bf396ee' '--admission' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\long_native_epoch4\epoch4_long_c088_o0_fast_v2\invocations\d565682d13bf43f6bf0257d0ae40c431\ADMISSION.json' 'cb5fd196facce6b24fdb1c1fcb8fbdf78cb7f83556912f0d691774ed051ecb9c'
~~~

Anaconda Prompt / CMD:
~~~bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_fast_observer_analysis_v1.py" prepare --kind long_c --namespace c088_continuous_analysis_fast_v2 --observer-index "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\fast_post_analysis\observer_indices\FIVE_LONG_CLOSED_OBSERVER_INDEX_V1.json" d57d952b98db1c543965d2fe6c4b38871e651f1290c9f7b8fd930d298bf396ee --admission "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\long_native_epoch4\epoch4_long_c088_o0_fast_v2\invocations\d565682d13bf43f6bf0257d0ae40c431\ADMISSION.json" cb5fd196facce6b24fdb1c1fcb8fbdf78cb7f83556912f0d691774ed051ecb9c
~~~

## C088_diagnostics

PowerShell:
~~~powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_fast_observer_analysis_v1.py' 'run' '--request' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\fast_post_analysis_admission\long_c\c088_continuous_analysis_fast_v2\REQUEST.json' '4848f2c439da77010d2a5e130d3fc427fa1235869b6e9c0337ae165826ee8f39' '--plan' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\long_diagnostics\c088_continuous_analysis_fast_v2\PLAN.json' '39e2464b45a263bcb128f5e63467206bf0cc026cbf6ce9e34d8ba5587223bb7c'
~~~

Anaconda Prompt / CMD:
~~~bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_fast_observer_analysis_v1.py" run --request "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\fast_post_analysis_admission\long_c\c088_continuous_analysis_fast_v2\REQUEST.json" 4848f2c439da77010d2a5e130d3fc427fa1235869b6e9c0337ae165826ee8f39 --plan "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\long_diagnostics\c088_continuous_analysis_fast_v2\PLAN.json" 39e2464b45a263bcb128f5e63467206bf0cc026cbf6ce9e34d8ba5587223bb7c
~~~

## C091_prepare

PowerShell:
~~~powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_fast_observer_analysis_v1.py' 'prepare' '--kind' 'long_c' '--namespace' 'c091_continuous_analysis_fast_v2' '--observer-index' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\fast_post_analysis\observer_indices\FIVE_LONG_CLOSED_OBSERVER_INDEX_V1.json' 'd57d952b98db1c543965d2fe6c4b38871e651f1290c9f7b8fd930d298bf396ee' '--admission' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\long_native_epoch4\epoch4_long_c091_o0_fast_v2\invocations\382fc7473007484093459bb7258ea29d\ADMISSION.json' '16c17f874cd2d51e111322527bb365ddbc211ecb3a99fefdcc5e054feb172ef8'
~~~

Anaconda Prompt / CMD:
~~~bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_fast_observer_analysis_v1.py" prepare --kind long_c --namespace c091_continuous_analysis_fast_v2 --observer-index "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\fast_post_analysis\observer_indices\FIVE_LONG_CLOSED_OBSERVER_INDEX_V1.json" d57d952b98db1c543965d2fe6c4b38871e651f1290c9f7b8fd930d298bf396ee --admission "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\long_native_epoch4\epoch4_long_c091_o0_fast_v2\invocations\382fc7473007484093459bb7258ea29d\ADMISSION.json" 16c17f874cd2d51e111322527bb365ddbc211ecb3a99fefdcc5e054feb172ef8
~~~

## C091_diagnostics

PowerShell:
~~~powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_fast_observer_analysis_v1.py' 'run' '--request' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\fast_post_analysis_admission\long_c\c091_continuous_analysis_fast_v2\REQUEST.json' 'eda8aa4e537b9400b28c8e5142681a38eba3703c96528f213ab2c6eef35dab72' '--plan' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\long_diagnostics\c091_continuous_analysis_fast_v2\PLAN.json' '4b7ca25e575acb2cfef0a491516c3a87eae1c73749a677e4280ee16b941902b2'
~~~

Anaconda Prompt / CMD:
~~~bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_fast_observer_analysis_v1.py" run --request "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\fast_post_analysis_admission\long_c\c091_continuous_analysis_fast_v2\REQUEST.json" eda8aa4e537b9400b28c8e5142681a38eba3703c96528f213ab2c6eef35dab72 --plan "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\long_diagnostics\c091_continuous_analysis_fast_v2\PLAN.json" 4b7ca25e575acb2cfef0a491516c3a87eae1c73749a677e4280ee16b941902b2
~~~

## B36_prepare

PowerShell:
~~~powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_fast_observer_analysis_v1.py' 'prepare' '--kind' 'long_b36' '--namespace' 'b36_continuous_analysis_fast_v1' '--observer-index' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\fast_post_analysis\observer_indices\FIVE_LONG_CLOSED_OBSERVER_INDEX_V1.json' 'd57d952b98db1c543965d2fe6c4b38871e651f1290c9f7b8fd930d298bf396ee' '--manifest' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\long_b36\b36_o0_continuous_fast_v1\MANIFEST.json' '853499c10f3ea80de4cf5ab4e8569a9cf1c8008d6dcdb47ed486dd4d0528ffa7'
~~~

Anaconda Prompt / CMD:
~~~bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_fast_observer_analysis_v1.py" prepare --kind long_b36 --namespace b36_continuous_analysis_fast_v1 --observer-index "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\fast_post_analysis\observer_indices\FIVE_LONG_CLOSED_OBSERVER_INDEX_V1.json" d57d952b98db1c543965d2fe6c4b38871e651f1290c9f7b8fd930d298bf396ee --manifest "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\long_b36\b36_o0_continuous_fast_v1\MANIFEST.json" 853499c10f3ea80de4cf5ab4e8569a9cf1c8008d6dcdb47ed486dd4d0528ffa7
~~~

## B36_diagnostics

PowerShell:
~~~powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_fast_observer_analysis_v1.py' 'run' '--request' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\fast_post_analysis_admission\long_b36\b36_continuous_analysis_fast_v1\REQUEST.json' '77dde5a8785729d5470de4049cc0c76c811179fe5f05eed520c4dc95ec3d2377' '--plan' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\long_b36_diagnostics\b36_continuous_analysis_fast_v1\PLAN.json' '57f7658aed0f9bb709b6ca27ee0d851b94d42ca445fb7b9ecf4864d3a0ddab24'
~~~

Anaconda Prompt / CMD:
~~~bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_fast_observer_analysis_v1.py" run --request "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\fast_post_analysis_admission\long_b36\b36_continuous_analysis_fast_v1\REQUEST.json" 77dde5a8785729d5470de4049cc0c76c811179fe5f05eed520c4dc95ec3d2377 --plan "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\long_b36_diagnostics\b36_continuous_analysis_fast_v1\PLAN.json" 57f7658aed0f9bb709b6ca27ee0d851b94d42ca445fb7b9ecf4864d3a0ddab24
~~~

## five_long_normalization

PowerShell:
~~~powershell
$env:JP_S6C_SIM='C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
& 'C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe' '-B' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_runtime_metadata_normalizer_v1.py' 'run' '--spec' 'C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\fast_post_analysis\five_long_actual_v1\NORMALIZATION_SPEC.json' '--spec-sha256' '77cc536213a285233bb37f0d3e260bf2274ed0a842d618eb745a141ac8c46e96' '--namespace' 'five_long_closed_metadata_v1'
~~~

Anaconda Prompt / CMD:
~~~bat
set "JP_S6C_SIM=C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
C:\Users\amiri\Documents\GitHub\just-peachy\.edge-speech-env\python.exe -B "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\scripts\s6c_runtime_metadata_normalizer_v1.py" run --spec "C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S6C\20260910T123540Z\fast_post_analysis\five_long_actual_v1\NORMALIZATION_SPEC.json" --spec-sha256 77cc536213a285233bb37f0d3e260bf2274ed0a842d618eb745a141ac8c46e96 --namespace five_long_closed_metadata_v1
~~~

