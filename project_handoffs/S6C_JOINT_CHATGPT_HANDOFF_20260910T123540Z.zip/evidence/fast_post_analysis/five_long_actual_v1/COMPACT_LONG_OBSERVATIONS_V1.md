# Five actual continuous-session observations

All five original sessions completed their held diagnostics and metadata normalization, with zero unresolved runtime rows. Each used the same 1,827.426625-second composition (30.4571 source minutes); C and historical B36 generations remain distinct. No model, policy replay, PCM read or correctness scorer ran in this post-analysis.

| Candidate | Gallery | Tail / owner / drain | Transcript finals | Voice decisions | C native seconds / B36 worker seconds | Samples | Largest observed sample gap (s) |
|---|---|---|---:|---:|---:|---:|---:|
| C065 | NONE | True / True / True | 105 | 999 | 1987.752 | 338 | 59.385 |
| C067 | NONE | True / True / True | 105 | 795 | 1970.247 | 319 | 63.305 |
| C088 | FIXED_ROTATION_A | True / True / True | 105 | 999 | 1993.139 | 330 | 51.186 |
| C091 | FIXED_ROTATION_B | True / True / True | 105 | 999 | 1993.045 | 319 | 59.462 |
| B36 | NONE | True / True / True | 105 | 1134 | 1875.202 | 586 | 56.109 |

All recorded terminal audio-drop/overflow/reserve-failure counters are zero; terminal ASR and speaker cursors equal the full source duration, and every scheduler is closed with zero pending events. Source completion is not word accuracy.

The C event-consumer queue has sampled peaks of2,697–3,405 events and51.19–63.31s sampling gaps. These are a different queue from scheduler-internal pending events and lane cursor lag. B36’s original sampler records lane cursor lag and has a56.11s maximum gap; it does not supply the C event-consumer queue series. Large gaps limit peak and memory-growth interpretation.

Known-name activity is preserved only as original native counters/events. Continuous name correctness, lexical accuracy and shared replay parity remain unavailable. A lifetime count of track IDs is not the simultaneous live population. Four C sessions and one B36 session over the same composition do not establish independent population confidence intervals.

Exact commands and exits are in README_ACTUAL_COMMANDS.md and ACTUAL_EXECUTION_RESULT.json. COMPACT_LONG_OBSERVATIONS_V1.json binds the original diagnostics and normalization. Full original event/name/debt projections remain local under their bound analysis outputs.
