# Working comparison-work and state observations

The completed report retains 48,952 original lifecycle rows from 31 authorities, grouped into 602 authority/candidate/actual-route groups and 13,846 metric rows. These are scored-output references across several experiments, not 48,952 independent native sessions. No repeated authority is pooled, and no candidate is selected from these work values. The report is separate from future paced RSS and continuous/native resource measurements.

`GROUP_METRICS.csv` contains all groups and all maximum ties. Each group has its own declared case count; full-bank and panel totals must not be compared as equal-duration workloads. `SOURCE_ADMISSION.json` binds the original scope, case list and route declarations. Every original lifecycle cell is retained under its source namespace in `SOURCE_CELLS.csv`, with exact source hashes and logical row provenance.

There are no missing source rows or absent metric columns in this admitted report. All 48,952 rows have prototype-comparison, maximum-live-comparison, decision and blocked-duration values. Each of the eight `peak_observed_*` fields has 2,374 unavailable values, retained as missing rather than zero. The summed 18,992 missing metric-value observations must not be reported as 18,992 missing scenes. Within each metric, `value_observed_rows` and `value_missing_rows` give the actual group denominator.

The following descriptive extrema make high-work conditions visible; they are not accuracy comparisons, estimates of CPU cost or a recommendation. All other groups and tied cases remain in the table.

| Observation | Source authority | Candidate/route | Case | Recorded value |
| --- | --- | --- | --- | ---: |
| Largest per-scene total prototype comparisons | n02_panel_core_v2 | C066 O1/O1 | S45_12_12 | 1,682 |
| Equal largest per-scene total, separately retained | n02_n06_real_companions_panel_core_v3 | C080 O1/O1 | S45_12_12 | 1,682 |
| Largest live comparisons per observation | n02_panel_core_v2 | C066 O1/O1 | S45_12_12 | 31 |
| Largest tracker-maintained live peak | n02_panel_core_v2 | C066 O1/O1 | S45_11_15 | 19 |
| Largest tracker-maintained archive peak | n00_clean_rescue_core_v2 | C131 O1/O1 | S45_12_12 | 28 |
| Largest decision-observed prototype count | n02_n06_real_companions_panel_core_v3 | C080 O1/O1 | S45_11_15 | 42 |

These extrema may occur in different scenes and authorities. Prototype slots, live tracks and archive entries are distinct quantities. Maximum live comparisons can exceed the number of live tracks because a track can carry multiple prototype slots; total comparisons can also include archive work. This report preserves recorded values rather than claiming those mechanisms caused a quality change. All admitted lifecycle rows report zero blocked unique-evidence seconds; this describes these per-scene outputs and does not erase the separate chronological diagnostic's capacity behavior.

`CHRONOLOGICAL_STATE_ONLY.json` preserves two prior-reviewed model-free snapshots. C001 has 36,864 array-payload bytes and a 7,296-byte shallow-object estimate; C002 has 127,488 and 61,104 bytes. Their final live/archive counts are 16/0 and 6/128, and recorded total comparisons are 5,982 and 29,165. These final chronological snapshots are not the same population as the per-scene lifecycle CSVs. The N00 clean-support reconstruction rejects much of the legacy evidence, so these state diagnostics do not establish voice recognition accuracy or finalist endurance.

Array payload and shallow object estimates exclude recursive heap, models, queues and process RSS. Per-track heap and native RSS remain null. No division of these global byte totals into per-track memory is valid. The pure snapshot projection interface is available for a future separately admitted closed-native adapter, but this run discovered or read no pending native files.

Reproduction uses the held standard-library helper and exact commands in `scripts/README_S6C_WORK_STATE_REPORT_V1.md`. Twelve small model-free guards precede this actual table pass. The result and source/README are held for root's independent review. Final report/package acceptance remains pending.
