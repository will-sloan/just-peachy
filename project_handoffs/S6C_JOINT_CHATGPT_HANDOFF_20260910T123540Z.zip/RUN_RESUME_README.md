# Run and resume the S6C research integration

Instructions for completed S6C evidence and optional reproduction. The original native queues,596 paced cells and five continuous sessions are closed; do not rerun them to read the handoff. C065 below is the matched empty-gallery control. Exact retained-condition commands are in OPERATING_COMMANDS.md.

## Purpose and where to start

The versioned S6C code runs the existing recognition, segmentation and voice models, incremental anonymous tracking, and an explicitly supplied research identity gallery. The campaign adds exact input/configuration admission, owned worker supervision, native/shared-policy comparisons and scored results. It uses the existing physically processed XVF scene outputs. File execution consumes the recordings without playing them through an audio output.

Use the existing Python executable directly. Anaconda activation or package installation is unnecessary. Scripts live in `simulation/scripts`; report directories contain data and receipts. Frozen execution copies live in `simulation/staging/s6c/20260910T123540Z/epochN`.

| Work | Existing entry point and maintained instructions |
|---|---|
| Read the running state | `S6C_CHECKPOINT.json` and `NATIVE_QUEUE_EXECUTOR_CHECKPOINT.json` in this report |
| New native recipe jobs and exact completed reuse | `design/README_NATIVE_EXECUTION_QUEUE_V5.md`; each listed admission pins its actual wrapper and immutable epoch |
| Native/shared incremental replay and core/name scoring | `scripts/README_S6C_ANALYSIS_V3.md`, `README_S6C_SCORING_EXTENSIONS.md` and each completed analysis receipt |
| Source-paced canonical conditions | `scripts/README_S6C_PACED_EPOCH4.md` |
| Original controls, sentinel and cross routes | Their separate `README_s6c_paced_*.md` / `README_S6C_PACED_*.md` files and exact prepared manifests; these are distinct schemas |
| Continuous host sessions | `scripts/README_s6c_long_native_epoch4.md` and `README_s6c_long_b36_v1.md` |
| Closed execution accounting | `scripts/README_s6c_execution_inventory_v6.md`; explicitly bind actual canonical/historical/sentinel/cross and B36-long manifests; epoch4 C long invocations are discovered from their own admissions |
| Compact score tables | `scripts/README_S6C_SCORE_TABLES.md` and `compact_score_tables/README_WORKING_EXPORT_V1.md` |
| Reviewed final archive | `scripts/README_S6C_PACKAGE_HANDOFF.md`; final acceptance and an explicit hash-bound manifest are required |

Read the exact receipt for an executed condition. A script filename, valid profile or prepared job list is not evidence that models ran. The scorer's original 184-label declaration and earlier 234-label examples describe their original explicit scopes; the current registry has 240 labels after the separately bound cadence and endpoint amendments. Do not silently change expected counts or substitute a latest registry.

## Read progress without starting another worker

PowerShell:

```powershell
$s6cRepo = 'C:\Users\amiri\Documents\GitHub\just-peachy'
$s6cSim = Join-Path $s6cRepo 'XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
$s6cReport = Join-Path $s6cSim 'reports\S6C\20260910T123540Z'
Get-Content -LiteralPath "$s6cReport\S6C_CHECKPOINT.json" -Raw
Get-Content -LiteralPath "$s6cReport\NATIVE_QUEUE_EXECUTOR_CHECKPOINT.json" -Raw
```

Anaconda Prompt / Windows CMD:

```bat
set "S6C_REPO=C:\Users\amiri\Documents\GitHub\just-peachy"
set "S6C_SIM=%S6C_REPO%\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
set "S6C_REPORT=%S6C_SIM%\reports\S6C\20260910T123540Z"
type "%S6C_REPORT%\S6C_CHECKPOINT.json"
type "%S6C_REPORT%\NATIVE_QUEUE_EXECUTOR_CHECKPOINT.json"
```

The native executor has one coordinator owner, identified by PID **and process creation time**. A prior tool session ID is only a handle for that existing process, not a command that creates a replacement. Let an active owner continue. An interrupted native admission requires verified closure of its coordinator/children and a fresh named admission with exact eligible completed-job reuse; the original attempt and any failure remain preserved. Do not rerun a closed admission, edit active/frozen code or manually remove a quiet lease.

The current allowance stops new work by 2026-09-13 11:35:40 UTC and reserves the following hour for closure and packaging. A later restart must resolve the actual checkpoint and time allowance; elapsed time never authorizes extending this deadline.

## Validate a registered control in the working application

The following command was actually run successfully with the current working application and exact C065/O0 profile. It validates and prints the effective profile without opening audio or loading model instances. `command_examples/empty_control_validation_v1/RECEIPT.json` records exit 0. Its source supplement verifies that all 29 working application Python files match the epoch6 source copies and that the printed effective profile and digest exactly match the registered control.

PowerShell, in a fresh terminal so these process-local settings do not affect another task:

```powershell
$s6cRepo = 'C:\Users\amiri\Documents\GitHub\just-peachy'
$s6cSim = Join-Path $s6cRepo 'XVF 3800 Testing\XVF Integration Real World RIRs\simulation'
$s6cReport = Join-Path $s6cSim 'reports\S6C\20260910T123540Z'
$s6cPython = Join-Path $s6cRepo '.edge-speech-env\python.exe'
$env:PYTHONPATH = Join-Path $s6cRepo 'Software Validation from Datasets\Evaluation Tool\app'
$env:EDGE_SPEECH_DATA_ROOT = 'G:\Just_Peachy_S6C\20260910T123540Z\user_invocations\c065_example'
$env:EDGE_SPEECH_ASSET_ROOT = $null
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:OMP_NUM_THREADS = '1'
$env:MKL_NUM_THREADS = '1'
$env:OPENBLAS_NUM_THREADS = '1'
$env:NUMEXPR_NUM_THREADS = '1'
& $s6cPython -B -m edge_speech_pipeline research-profile "$s6cReport\profiles\C065\O0_ASR_O0_ID.json"
```

Anaconda Prompt / CMD:

```bat
set "S6C_REPO=C:\Users\amiri\Documents\GitHub\just-peachy"
set "S6C_SIM=%S6C_REPO%\XVF 3800 Testing\XVF Integration Real World RIRs\simulation"
set "S6C_REPORT=%S6C_SIM%\reports\S6C\20260910T123540Z"
set "S6C_PYTHON=%S6C_REPO%\.edge-speech-env\python.exe"
set "PYTHONPATH=%S6C_REPO%\Software Validation from Datasets\Evaluation Tool\app"
set "EDGE_SPEECH_DATA_ROOT=G:\Just_Peachy_S6C\20260910T123540Z\user_invocations\c065_example"
set "EDGE_SPEECH_ASSET_ROOT="
set "PYTHONDONTWRITEBYTECODE=1"
set "OMP_NUM_THREADS=1"
set "MKL_NUM_THREADS=1"
set "OPENBLAS_NUM_THREADS=1"
set "NUMEXPR_NUM_THREADS=1"
"%S6C_PYTHON%" -B -m edge_speech_pipeline research-profile "%S6C_REPORT%\profiles\C065\O0_ASR_O0_ID.json"
```

These working-application commands depend on the recorded source hashes. A future edit requires a new source check. Pointing PYTHONPATH at a relocated frozen application does not automatically recreate its model paths: that module derives default asset roots from its own location. The reviewed campaign workers construct explicit AssetSpec values from the frozen epoch manifest. Use those workers for exact campaign reproduction; do not copy weights or guess a bundle directory to work around the distinction.

## File inference and its outputs

After the campaign's quiet measurements have finished, the same working-application environment can run this existing **empty-gallery control** at source speed. This is an optional reproduction command, not a claim of an additional study execution. Confirm fresh disk/RAM reserves before starting a new session.

PowerShell:

```powershell
& $s6cPython -B -m edge_speech_pipeline file 'G:\Just_Peachy_S6B\20260909T230840Z\inputs\S45_01_06\O0.wav' --identity-wav 'G:\Just_Peachy_S6B\20260909T230840Z\inputs\S45_01_06\O0.wav' --research-profile "$s6cReport\profiles\C065\O0_ASR_O0_ID.json"
```

Anaconda Prompt / CMD:

```bat
"%S6C_PYTHON%" -B -m edge_speech_pipeline file "G:\Just_Peachy_S6B\20260909T230840Z\inputs\S45_01_06\O0.wav" --identity-wav "G:\Just_Peachy_S6B\20260909T230840Z\inputs\S45_01_06\O0.wav" --research-profile "%S6C_REPORT%\profiles\C065\O0_ASR_O0_ID.json"
```

The CLI's default file route is source-paced; `--accelerated` explicitly changes that behavior. Positional audio supplies ASR and `--identity-wav` supplies the identity lane. This example sends the same complete O0 file to both. Its prescribed gain is already present; the runtime gain remains one. O1 and cross routes require their exact registered profiles and corresponding complete paired inputs. Names require the exact explicit `--research-gallery`; real-cue conditions require corresponding sanitized `--research-telemetry`. Leaving these out is not a valid way to reproduce an enrolled or cue-enabled condition.

Session output is under `EDGE_SPEECH_DATA_ROOT/edge_speech_sessions`. It includes the paired PCM journals, events, first/latest labelled transcripts, summary and finalization record. The working control does not load or change the user's private gallery. Full-pipeline completion and writer/lane closure must be established from the actual finalization record and CLI exit status, not a transcript file alone. Raw transcripts and person-name correctness remain separate.

OPERATING_COMMANDS.md binds the four retained complete conditions and explicit invocations. OPERATING_ENVELOPES.md states their measured tradeoffs; this C065 control example is not a substitute.

## Cooperative stop and rollback

For a campaign coordinator, a report-root STOP_REQUEST.json requests its documented bounded stop procedure. Native pools may drain active jobs; paced/long guards may close an interrupted owned child. Preserve partial outcomes and the original stop request, and establish closure from PID+creation and durable receipts. The direct file CLI does not read STOP_REQUEST.json: Ctrl+C calls engine.stop() and then its bounded wait_for_completion path. An interrupted file is not proof of complete source delivery. Do not delete checkpoints, sessions, source audio or quiet leases.

The ordinary application branch remains the fallback when no S6C research profile is supplied. Close this fresh terminal to discard its environment overrides. The pre-S6C source snapshot is indexed by `INTAKE_AND_SNAPSHOT.json`; no Git reset, stash, checkout-overwrite or wholesale restoration is part of rollback. No production default has been promoted by these research commands.

Physical packed-XVF playback is a separate optional branch with its own fresh-session output-disconnection requirement and endpoint/settings restoration. None of the read/profile/file commands above sends packed data to the board or requires unplugging other PC devices.
