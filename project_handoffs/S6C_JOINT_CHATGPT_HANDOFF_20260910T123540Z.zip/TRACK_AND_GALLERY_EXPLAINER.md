# Tracks, evidence and enrolled names

Explanation of the implemented and exercised system. Examples explain mechanisms; measured tradeoffs and retained conditions are in the joint report and operating envelopes.

A speaker track is a temporary software hypothesis that a series of voice observations belongs together. It is not an audio channel, an XVF beam, a separate neural network or a confirmed human. The same person can be fragmented across several tracks, and a wrong merge can combine different people. More capacity can remove an allocation restriction without fixing either error.

| State or count | Exact interpretation |
|---|---|
| Live tracks | Records currently in the allocation pool; active plus dormant. |
| Active | Live records that are not dormant. |
| Dormant | Live records awaiting re-entry or retirement under the configured time rules. |
| Provisional | Live records that have not met commitment. This overlaps active/dormant counts and must not be added to them. |
| Archive | Separately bounded retired records/prototypes that can be considered for re-entry. |
| Lifetime IDs | Monotonically allocated externally visible identifiers. A released slot does not recycle its former ID into another person. |
| Prototypes | Retained voice vectors, bounded separately from track and archive counts. |
| Revision records | Bounded history allowing declared corrections; changing a displayed label is not necessarily a structural track merge or split. |
| Enrolled people | Explicit gallery templates/pseudonyms. They are separate from anonymous tracks and allocation capacity. |

The tracker can retire a live record and free its allocation slot while retaining an eligible archived identity. Archive eviction, provisional retirement, time decay and comparison work have separate limits and counters. Array payload and shallow Python-object estimates exclude the complete heap, models and queues; native process memory is measured separately. Historical S6B uses different lifecycle behavior and must retain its own control label.

A short observation can support a provisional association before a longer mature window becomes available. The system records actual waveform support, estimated clean subintervals, availability and evidence identity. Overlap between windows is unioned for unique duration; disjoint-count rules are separate. No reference turn boundary is used to crop the online waveform or force a reset. A one-second waveform cannot be claimed wholly contained in a subsecond reference turn.

Units matter. The tracker's minimum_clean_fraction compares estimated clean seconds divided by waveform duration; 0.5 means fifty percent, not half a second. The evidence frontend separately has a minimum_contiguous_clean_sec setting. Track commit_evidence_sec and identity minimum_unique_sec are duration requirements, each distinct from its disjoint-observation count. A supported vector can still be rejected downstream or remain provisional.

Association and naming answer different questions. Anonymous association asks which existing/new/unresolved track best explains the current voice evidence. Post-association naming then scores the accepted voice state against an explicitly admitted set of known templates. It can remain unresolved, show a tentative name, confirm one, retract it or revise a prior name under the bounded rules. No scorer truth is available to this resolver, and a seat or bearing cannot supply a name.

The research galleries use original permitted CMU ARCTIC, HiFiTTS and older local Common Voice speech. Enrollment E and calibration C clips are disjoint from the canonical conversation probes Q by the audited source/text/prompt criteria. A person may appear in both E and Q, which is necessary for enrollment evaluation, but the evaluation waveform or its disguised crop cannot be an enrollment template. Corpus-qualified metadata IDs are not proof of unique biological identity across corpora.

Actual native enrollment produced 95 templates at available nested estimated-usable tiers. Tier availability is 37 people at five seconds, 30 at fifteen and 28 at thirty; unavailable people remain in the probe evaluation. Independent read clips are a paragraph-duration proxy, not a newly recorded paragraph. Templates remain clean-source references facing processed XVF speech, so device-domain match has not been established. Low-consistency templates are retained and labeled.

Fixed A/B rosters rotate known and withheld roles. Other explicit setup conditions model expected people, selected participants and mistaken selection; their setup information is declared rather than silently inferred. The six common-roster duration controls keep fourteen eligible people per roster across five/fifteen/thirty seconds. They remove roster-availability confounding within that comparison; they provide no Common Voice duration result.

A correctly named segment does not prove good anonymous continuity. Conversely, a useful anonymous transcript can have unresolved names. Reports therefore keep correct-name speech, wrong-known speech, stranger false-known exposure, first/stable correct-name delay, never-named cases and anonymous returns separate. Unavailable enrollment, withheld strangers and incomplete truth have explicit denominators and censoring.

The C-only calibration alternatives selected score 0.45 and margin 0.10, while the historical threshold control is score 0.5128856897354127 and margin 0.03. Calibration queries contained known C people only. Their fitted rejection/acceptance results are not an open-set stranger validation. Probe results must carry any gain in correct naming together with increased wrong-known exposure.


The completed work report keeps 31 score authorities separate: 48,952 lifecycle rows form 602 authority/candidate/actual-route groups. These are scored-output references across overlapping experiments, not counts of physical inference sessions. All groups and maximum ties remain in work_state_reporting/working_v1/GROUP_METRICS.csv; the original per-scene cells and exact source bindings remain available. Eight decision-observed peak fields each have 2,374 unavailable values, so 18,992 is a count of missing metric observations, not missing scenes.

The following completed full-bank comparisons each cover 240 source scenes per tap. Prototype-comparison totals sum one condition's scene counters. State maxima are maxima across those scenes and are not added. These observations describe work/state behavior, not CPU seconds or accuracy.

| Exact condition | Total prototype comparisons O0 / O1 | Max live comparisons per observation O0 / O1 | Largest live count O0 / O1 | Largest archive count O0 / O1 |
|---|---:|---:|---:|---:|
| C065 N01, cues off | 44,338 / 48,067 | 19 / 17 | 13 / 13 | 11 / 19 |
| C067 N03, cues off | 30,636 / 33,522 | 16 / 15 | 13 / 13 | 11 / 21 |
| C079 N01, normalized real cues | 43,690 / 46,852 | 19 / 19 | 13 / 13 | 11 / 18 |
| C122 N01, hypothesis real cues | 43,795 / 47,562 | 21 / 20 | 14 / 14 | 10 / 19 |

Multiple prototype slots can make live comparisons exceed the live-track count; archive searches can add to total comparisons. N03's lower comparison work coexists with its worse early attribution and return/Unknown results, and does not establish a proportional full-pipeline speedup. The separate highest-work panel examples are C066/C080 O1, S45_12_12, at 1,682 comparisons each; their authorities and full ties remain distinct in FIELD_GUIDE.md.

Two already closed model-free chronological snapshots give explicit state representation estimates. C001 has 36,864 array-payload bytes and a 7,296-byte shallow-object estimate, with final live/archive counts 16/0. C002 has 127,488 and 61,104 bytes, with counts 6/128. These N00 chronological diagnostics reuse genuine native evidence but reject much of its reconstructed clean support; they do not establish recognition quality or native endurance. The byte estimates exclude recursive heap, models, queues and RSS. Per-track heap remains unavailable, and dividing global bytes by live tracks would invent a measurement. Actual paced/continuous process memory is separate in RUNTIME_RESULTS.md, with observed sample counts and gaps.

All current operation is an opt-in research file path. Neither enrollment accuracy, physical angle calibration, real-world conversational performance nor Raspberry Pi CM5 feasibility follows from synthetic desktop results alone.
