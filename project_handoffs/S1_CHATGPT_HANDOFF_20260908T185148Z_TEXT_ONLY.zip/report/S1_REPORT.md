# S1 RIR pilot review handoff

Run 20260908T185148Z. S1 is complete with review required. Exactly 12 selected recordings produced provisional four-channel candidates: four PROVISIONAL_LIMITED_BAND_TAIL and eight PROVISIONAL_TIMING_REVIEW, with zero input/processing failures. All remain qualified_rir_available=false and simulation_ready=false. S2 has not started.

## Scope and inherited measurement evidence

Historical acquisition audit: 127 eligible and 52 excluded. Current scope removes only six exact Loeb Caf candidates, retaining Upper Loeb: **121 active**, five room labels, 51 metadata geometry groups; 51 flat clear, 50 upright clear, 20 flat obstructed. Excluded measurements are forbidden for noise/stress/training use as well. Original capture/audit status is preserved. Every active source was originally REVIEW; early PASS diagnostics do not enter the campaign.

Active effective distances range 0.46–4.07 m; none exceeds 5 m. Both exact 100 m → 1.00 m user corrections remain bound to original identity/timestamp/hash. Signed angle centers remain unchanged with ±5 degrees user-estimated half-width. This is neither a percentage nor independently calibrated position accuracy. S0's sign evidence is inherited, not re-estimated or used to fit the recovered response; linear front/rear ambiguity remains. Unknown XYZ, heights, yaw and the library alias remain unknown.

Pilot entries 1–10 retain S0 order; entries 11/12 are the supplied Upper Loeb +30°/0.90 m and −90°/1.37 m paths. Full exact IDs, timestamps and hashes are in selected_pilot_manifest.json; selection_delta.json records the two substitutions. Only these 12 underwent numerical extraction.

## Results

| # | Room | Angle / m | Clock ppm (marker ± working half-width → selected) | Duration s | Worst residual dB | Result |
|---:|---|---|---|---:|---:|---|
| 1 | Library Conference Room | +75° / 0.74 | -9.92 ± 5.00 → -9.92 | 0.660 | -28.8 | Limited band/tail |
| 2 | Library Conference Room | -80° / 0.9 | -10.14 ± 9.34 → -10.14 | 0.681 | -27.3 | Limited band/tail |
| 3 | Library Conference Room | +0° / 1.7 | -8.07 ± 5.00 → 0.00 | 0.621 | -25.9 | Timing review |
| 4 | Library Conference Room | -179° / 0.65 | -10.64 ± 5.41 → 0.00 | 0.621 | -27.9 | Timing review |
| 5 | Library Conference Room | +75° / 0.74 | -10.39 ± 5.00 → -10.39 | 0.741 | -29.9 | Limited band/tail |
| 6 | Library Conference Room | +75° / 0.74 | -9.11 ± 5.00 → 0.00 | 0.701 | -28.0 | Timing review |
| 7 | Arise Kitchen Main Table | +65° / 0.65 | -9.79 ± 5.00 → -9.79 | 0.760 | -32.5 | Limited band/tail |
| 8 | Arise Kitchen Main Table | +40° / 4.07 | -10.18 ± 5.43 → 0.00 | 0.721 | -20.9 | Timing review |
| 9 | Arise 5th floor low table | +95° / 0.6 | -9.31 ± 5.00 → 0.00 | 0.781 | -33.6 | Timing review |
| 10 | Arise Floor 2 Kitchen | -170° / 0.67 | -10.10 ± 5.00 → 0.00 | 0.501 | -27.9 | Timing review |
| 11 | Upper Loeb | +30° / 0.9 | -10.95 ± 5.28 → 0.00 | 0.681 | -25.6 | Timing review |
| 12 | Upper Loeb | -90° / 1.37 | -9.05 ± 8.12 → 0.00 | 0.661 | -23.8 | Timing review |

All candidates are 16 kHz FLOAT32 WAV, channel order MIC0, MIC1, MIC2, MIC3, without peak normalization. Candidate duration is the stored common window, including about 20 ms before significant energy; it is not RT60. The raw untrimmed ESS convolution and the alternate-clock full diagnostic remain local with hashes. First significant band-limited energy is reported separately from strongest early energy; neither proves a direct path.

Across all 48 channels, common cropping/tapering removed at most 0.0600% of energy relative to the already band-limited 2.8-second core. This does **not** quantify energy outside the band or captured tail. Relative total-energy levels changed by at most 0.000568 dB. All six early-window GCC delay changes were zero because the shared early window was left intact; this is a preservation check, not independent angle validation. Fresh same-input numerical regeneration yielded identical FLOAT32 samples for all 12. No unchanged-condition acoustic repeat exists.

The regularized frequency-domain cross-check on entries 1 and 12 agreed to less than 0.075 dB at the 90th percentile of absolute magnitude difference across 300–6000 Hz for each channel. Both methods use the same capture and source. Reconstructed-sweep residuals are descriptive, band-matched internal consistency; do not report WER, DER or independent speech quality from them.

## Timing interpretation and review

Three separately templated markers, three common frequency bands and four channels suggest approximately −8.1 to −11.0 ppm reference-clock mismatch. Start and end marker waveforms differ and were not assumed interchangeable. Working intervals are heuristic uncertainty ranges, not calibrated confidence intervals. The acoustic bulk intercept includes capture/playback offset, device delay, propagation and filter/group-delay effects that cannot be separately identified here.

The pre-scoring policy requires marker evidence excluding zero, coherence ≥0.65, bounded uncertainty and at least 3% improvement in an early-energy concentration diagnostic before applying drift. Four records meet it. Eight retain zero drift and their marker-clock alternatives because concentration gain is insufficient. The code flag MARKER_SWEEP_CLOCK_DISAGREEMENT means failure of this conservative conjunction; it does not prove inconsistent marker measurements. Entry 9 improves by 2.96%, just below the gate; no threshold was retuned to change its status. Sensitivity is sometimes nonmonotonic, so concentration is not an independent clock estimator or a global optimization objective.

No microphone was independently resampled, aligned, normalized or corrected to match angle/distance labels. One reference-clock mapping is used for all four capture channels. The common crop removes an inseparable bulk origin; never add a guessed distance/speed-of-sound delay to these candidates.

## Method, scaling, noise and supported response

See METHOD_AND_LIMITATIONS.md for exact equations, numerical choices, units and caveats, and extraction_config.json for the processed configuration. The archived 48 kHz PCM16 source with SHA-256 cba5b09d4d3963d508340711210804d2dd80cf62741a60a2544120e60acbf488 is resampled through a documented antialias filter and multiplied by the recorded −6 dB software scalar exactly once. The estimated response maps post-software-gain numerical drive to recorded Category 3 full-scale samples. Gain 10, SYS_DELAY −32 and unknown analog transfer remain included; the common landmark anchor absorbs bulk latency without selectively undoing the device delay. KRK, room, table, objects and microphones remain part of the transfer.

The reverse-sweep, amplitude-weighted ESS inverse uses linear convolution and a known-source transfer calibration. Conceptual reference: [Farina, AES 2000](https://angelofarina.it/Public/Papers/134-AES00.PDF). Numerical accuracy here is supported by six independent-resampler known-FIR fixtures, passing 26/26 checks, plus 6 targeted tests.

Noise comes from a verified 1.25-second interval before the first acoustic marker; post-sweep audio is never assumed noise-only. No record triggered the 6 dB pre-noise stationarity or pre-sweep gap-excess warning. The short interval cannot establish long-duration stationarity. No unrelated quiet waveform was subtracted.

All selected records support the common nominal FIR cutoffs 160–6400 Hz under the development per-band ≥10 dB sweep-plus-noise/pre-noise power rule. Cutoffs are half-amplitude (about −6 dB); this filter alone is within ±0.1 dB over approximately **222.0–6338.0 Hz**. Neither figure certifies the acoustic transfer as flat or every narrow frequency as reliable. The 513-tap centered filter is shared across channels. A conservative response-noise floor combines propagated pre-noise power with late-core empirical power, which may include real decay. The common last-significant-block rule adds 40 ms margin and a 60 ms cosine taper. Weak late reflections may be lost. Full untrimmed diagnostics remain available for review. No RT60 is certified and no clean tail is invented.

## Context for later simulation

- Arise Kitchen Main Table: breakfast countertop/high-seated dining position in a kitchen, one open end leading to a hallway.
- Arise 5th floor low table: round low-seating coffee spot/table, one open end leading to a hallway.
- Upper Loeb: slightly high four-person booth at the side of a large restaurant with very high ceilings; perpendicular to a wall, window on one side and open restaurant on the other.
- Arise Floor 2 Kitchen: rectangular dining table in a kitchen/enclosed room, one open wall and a perpendicular hallway/wall arrangement described as T-shaped.
- Library Conference Room: square table in an enclosed conference-room-like setting with concrete/glass on most surrounding surfaces.

These qualitative user descriptions are context, not room dimensions, measured seating/ceiling heights, RT60 or isolation. No room model was fitted from them. The V5 Word workbook remains the design guide with its S0 hash, unchanged. Earlier planning instructions in documents do not authorize later execution.

## Resources, actual elapsed time and forecast

Existing Anaconda base scientific packages were used without installation or H2 changes. First real case: 9.36 s numerical processing; all real extraction invocations: 58.14 s wall time. The remaining 11 records ran with four workers in 47.42 s (13.92 records/min). Synthetic fixtures: 54.30 s; 13 plots: 16.11 s. End-to-report elapsed: 28.2 minutes, including implementation, analysis and review.

Maximum observed 15-second-sampled process-tree RSS was 0.782 GiB; minimum sampled available RAM was 33.45 GiB. These are sampled observations, not true instantaneous peaks. The legacy per-record worker_peak_rss_bytes field is a single end-of-processing observation and must not be interpreted as a peak. One inner numerical thread per worker; no GPU work.

Fresh free space: **C: 82.47 GiB free; D: 1741.22 GiB free; F: 46.24 GiB free; G: 449.30 GiB free**. C: is the WD_BLACK SN850X SSD; G: is the Kingston SNVS2000G SSD. G: now has substantially more free space than the S0 snapshot. D: is now mostly empty, but remains an HDD. No drive relocation was necessary. The exact byte snapshots and mapping evidence are in resource_before.json/resource_after.json.

Local full derivatives occupy 152.60 MiB, within the 5 GiB cap; C: remains above the 50 GiB reserve. A simple 121-record extrapolation is 8.7 minutes from measured batch throughput or 18.9 minutes using serial first-case cost, plus about 2.7 minutes of plotting. This is a forecast under similar load and unchanged method, not an executed S2 result. No multi-hour search was launched.

The worker pool closed cleanly. No unrelated process, cache or data was deleted. Two recoverable environment/API issues are documented in execution_issues.json; no real record failed. Main Git tracked state and H2 assets were not changed; no commit/push or nested repository repair occurred.

## Handoff and next gate

Report directory: C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S1\20260908T185148Z

Full local derivatives: C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\derivatives\S1\20260908T185148Z

Handoff: C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\handoffs\S1_CHATGPT_HANDOFF_20260908T185148Z.zip

The ZIP includes this report, detailed method, config/policy, active/selected manifests, per-record evidence, 13 plots, small code/test files and all 12 candidate WAVs. It excludes original captures, full diagnostic WAVs, NPZ intermediates, model weights, vendor bundles and enrollment data. Local full-output hashes remain in the manifest. FILE_INVENTORY.json lists payloads; SHA256SUMS.txt covers them and the inventory; an external receipt hashes the ZIP without a self-hash cycle.

S1 is ready for ChatGPT review. S2 requires a reviewed, frozen timing/band/tail policy, a decision about the eight timing-review cases and explicit separate authorization. No production simulation, physical replay, hardware control or full-121 expansion has been performed. See NEXT_PHASE_INPUTS.md for exact hashes and review questions.
