# S1 numerical method and interpretation

This is a development pilot. Parameters were written before real scoring; they are not a preregistered confirmatory protocol. Synthetic tolerances and saved results establish numerical recovery in the tested fixtures, not an acoustic ground-truth calibration. The current QC/configuration must be reviewed and frozen before a separately authorized S2.

## Source, capture and gain

Each selected input is the exact bound simultaneous four-channel recording: 16,000 Hz, 350,647 frames, 24-bit PCM, MIC0–MIC3. Samples are loaded as float64 normalized to recording full scale. They are Category 3 amplified/delayed pre-voice-DSP samples: mic gain 10 and SYS_DELAY −32 were present. Neither is selectively undone. Actual analog/system latency remains inseparable from playback/capture offset and acoustic propagation.

The archived mono 48 kHz PCM16 file is the only excitation source. Its SHA-256 is cba5b09d4d3963d508340711210804d2dd80cf62741a60a2544120e60acbf488. It contains distinct start/end marker waveforms: first marker at source 2 s, ESS at 3–13 s, end markers at 16 and 16.2 s. These are source times; they are not indices into the microphone file.

Source conversion is scipy.signal.resample_poly(up=1, down=3) with a supplied 385-tap symmetric Kaiser β=8.6 FIR, cutoff 7,400 Hz at 48 kHz. Its centered delay is compensated by resample_poly. The scalar 10**(−6/20) is then multiplied into the source exactly once. The response convention is:

    recorded Category-3 normalized samples ≈ convolution(post-software-gain numerical drive, h)

Unknown Windows-volume and speaker-volume transfer is retained. No calibrated SPL, unit-Pascal conversion or ideal omnidirectional source is inferred. The measured KRK loudspeaker, room/table/objects, microphone and capture chain remain included. There is no equalization, peak normalization, channel gain flattening or enhancement.

## Marker clock and one shared time origin

For each of three distinct marker templates, each of three shared bands (1–3, 2.5–4.5 and 4–6 kHz), and each microphone, a regularized marker inverse is used. FFT length is 4096; ridge is 0.001 times maximum template-bin power. The archived coarse marker location is only a bounded search hint. The local capture slice begins 35 ms before that hint and ends 95 ms after it. The inverse-response energy peak search spans 18–52 ms within that slice. A Hilbert-envelope peak with parabolic interpolation supplies an acoustic landmark.

Each band/microphone fits three landmark times to capture_time = intercept + ratio × source_time. The median of 12 slope estimates gives ppm = (ratio − 1) × 1e6. The working half-width is the maximum of 5 ppm, twice the 90th-percentile slope deviation, and a residual-derived 14-second-baseline term. It is heuristic and correlated across microphones/bands; it is not a statistically calibrated confidence interval. The close 16/16.2-second end pair mainly exposes inconsistency and has little independent drift leverage.

Aligned marker-response snippets are compared only to assess repeat-landmark coherence. This diagnostic alignment does not alter any recovered microphone response. One common bulk landmark intercept is subsequently taken across all observations for each tested clock.

The extractor compares four bounded variants: zero ppm, median marker ppm and the two working-interval bounds. It does not search a dense clock grid. A nonzero correction is selected only if the interval excludes zero, lies inside ±500 ppm, median marker-wavelet coherence is at least 0.65, and early-energy concentration improves by at least 3% against zero. Concentration is energy within ±0.5 ms of a common strong early-energy peak divided by energy in the first 0.35 s of the recovered core. It is a development heuristic that can vary nonmonotonically with clock, filtering and sub-sample peak location. It is not independent clock truth.

All 12 marker estimates suggest a small negative mismatch. Eight fail the 3% concentration condition and retain zero ppm plus a full marker-clock alternative. The code's MARKER_SWEEP_CLOCK_DISAGREEMENT flag denotes that failed conjunction, not proof of a contradictory clock measurement. Entry 9's 2.96% gain remains below the original threshold; no retuning was performed after seeing it.

For a chosen ratio a = 1 + ppm × 1e−6, only the mono reference is sampled on the common capture clock with a normalized 64-tap Kaiser-windowed sinc (β=8.6). All four microphone channels stay on their original 16 kHz grid; they are never independently warped or peak-aligned. Positive ppm lengthens the reference in capture samples. Signed ±200 ppm synthetic fixtures test this convention with an independent scipy rational resampler.

## ESS inverse, calibration, full estimate and time axes

The sweep portion at source 3–13 s is cut from the resampled archived source, then warped onto the chosen common clock. The inverse reverses that exact sweep and weights it by exp(−t/L), where L = (10 × a)/ln(7500/80). Its single scalar calibration uses the median real zero-phase source/self-inverse transfer in 300–6000 Hz. It does not normalize each microphone or each response peak. Calibration 1st/50th/99th-percentile evidence is in every metrics file.

The conceptual reverse-sweep inverse and linear-convolution approach follows [Farina, AES 2000](https://angelofarina.it/Public/Papers/134-AES00.PDF). The exact implementation choices are documented here and checked by the local fixtures. Synchronized higher-order harmonic identification is not claimed for this archived ordinary ESS.

The common capture crop starts at round((beta + 3a − 0.1) × 16000), and stops at round((beta + 16a − 0.08) × 16000), before end-marker onset. FFT-based **linear** convolution with sufficient padding produces all four full diagnostic responses. No circular wrap is substituted for linear convolution.

The full diagnostic time-zero sample is len(inverse) − 1. Thus:

    full_response_time_sec = (sample_index − time_zero_sample) / 16000

The first 2.8 s after that origin is the analysis core; early acoustic energy lies near 0.1 s because of the chosen common anchor. That 0.1 s is not measured sound travel time. The candidate removes a common leading region, documented by common_crop_start_sample and candidate_time_zero_relative_to_full_core_sec. To reproduce core-based convolution, place the candidate at that recorded common start within the core. Do not add a second guessed distance/c delay or independently shift channels.

The full untrimmed linear-convolution WAV includes negative-time/pre-response content and the source/inverse overlap extent. It is diagnostic evidence, not a causal production RIR. Alternate-clock full WAVs use their own clock-dependent inverse length; the manifest includes alternate_clock_full_response_origin computed from saved clock sensitivity/configuration and verified against WAV frame count. Selected full origin is explicit in full_response_origin. Harmonic artifacts and pre-arrival ringing are not automatically identified as physical reflections.

## Noise, band and finite tail

Pre-noise uses 1.25 s from −1.50 to −0.25 s relative to the first acoustic marker. It is checked to lie in the capture before excitation. Welch PSD uses 2048-sample segments, 1024 overlap and density scaling in recorded FS²/Hz. Three subwindow powers provide a coarse stationarity check. A separate 170 ms interval, 200–30 ms before predicted sweep onset, checks for excess relative to pre-marker noise; >6 dB flags possible marker decay or ambient change, without deciding which.

Sweep-plus-noise power and pre-noise power are integrated over 125–250, 250–500, 500–1000, 1000–2000, 2000–4000 and 4000–6400 Hz. A band is supported when the ratio is ≥10 dB in every microphone. It is not a noise-subtracted true SNR. The widest contiguous supported span is clipped to nominal candidate cutoff limits 160–6400 Hz and must span at least an octave. All pilot records selected the full cutoff span.

One common 513-tap Kaiser β=8.6 FIR is applied with centered linear convolution; its 256-sample nominal group delay is compensated. Its cutoff frequencies are half-amplitude points, approximately −6 dB, not a flat passband guarantee. plot_results.json records the filter-only ±0.1 dB span. This does not certify the loudspeaker/acoustic response or every frequency bin. There is no per-channel spectral subtraction, denoising or imposed room model.

Expected response-noise variance integrates measured pre-noise PSD through the squared magnitude of the inverse and shared band filter. The empirical floor is the median 20 ms block power in the final 20% of the 2.8-second core. The larger of the propagated and empirical floors is used per microphone. Real late decay may contribute to that floor; it is intentionally conservative and is never described as a proven noise-only post-sweep interval.

The last 20 ms block exceeding four times its floor in **any** microphone sets a shared significant-tail endpoint, capped at 2.4 s after first significant energy. Add 40 ms margin and a 60 ms cosine tail taper. The beginning uses a shared 20 ms pre-energy margin and a 3 ms fade. The tail_required_below_noise_sec=0.1 config field is unused: this implementation is the last-significant-block rule just described, not a 100 ms consecutive-block test. This discrepancy is disclosed for policy cleanup before S2.

Reported removed energy compares the tapered candidate against the band-limited finite core. It says nothing about energy outside the declared band, before/after the retained diagnostic crop or below the conservative floor. Weak late reflections may be lost. Full selected and alternate estimates remain local. The plotted block decay is descriptive; no RT60 fit is attempted because the finite capture/noise evidence does not support certification.

## Metrics and their limits

First significant energy is an 8-sample-smoothed squared-response threshold: greater of 2% of early peak energy and nine times the noise floor, searched before the strongest early peak within the first 0.3 s. Its confidence string explicitly denies calibrated direct-path identification. Pre-arrival energy is measured before that onset minus 2 ms relative to energy in the shared early comparison window.

Six pairwise GCC-PHAT delays use the same early window, starting 2 ms before the earliest energy and ending 30 ms after the latest early peak. Search is ±16 samples; positive j-minus-i means channel j lags channel i. This is a frequency-weighted early-response delay diagnostic, not calibrated direct-path TDOA, exact geometry or an arcsine angle. Strongest-energy peak differences are reported separately. Shared cropping/tapering leaves this early window intact, so zero pre/post delay change is expected.

Interchannel levels compare integrated core/candidate energy against MIC0; removed energy and relative-level changes are reported per microphone. Sensitivity shifts common crop start by ±10 ms and common end by ±50 ms; the sensitivity metric is untapered retained energy change, not a full spatial-performance test.

The same-sweep reconstruction convolves the chosen warped reference with the processed core and compares against the same band-filtered capture over a common interior window. Residual energy is 10 log10(error energy / observed energy). PSD plots show raw pre-noise and band-filtered sweep/residual; outside the filtered region their levels must not be interpreted as a measured noise-suppression claim. The residual does not separate noise, nonlinearity, clock mismatch and model error. No independent speech, WER/DER, diarization or physical replay validation occurs.

On pilot entries 1 and 12 only, a zero-padded frequency-domain estimate uses H = Y × conjugate(X) / (abs(X)² + λ), λ = 0.0001 × max(abs(X)²). It applies the same candidate filter and compares magnitudes over 300–6000 Hz. It is a bounded secondary cross-check using the same input, not an independent measurement. No broad algorithm or regularization search is run.

## Reproducibility, resources and review

Six synthetic fixtures use independent 48→capture-rate rational resampling, a known 5920-sample common offset, distinct four-channel FIR delays/gains, signed/zero drift, noise, a late reflection and marker contamination. Mutation checks cover channel reversal, double gain and independent alignment. Twenty-six checks passed. Synthetic equality and per-real-record regeneration concern deterministic code, not repeated physical takes.

The runtime uses at most four CPU workers with one inner numerical thread. The coordinator alone writes reports/WAVs and hash receipts. A 15-second monitor checks sampled process-tree RSS, available RAM and free disk; scratch size is checked after extraction. These are cooperative sampled guards, not OS-enforced hard resource limits. Memory between samples may be larger. Per-record worker_peak_rss_bytes is a misleading legacy field name for one end-of-processing RSS sample; the manifest annotates that fact. No GPU or device access is needed.

Resume binds selected input path/hash/stat receipts, extractor code, configuration, QC policy, scope overlay and every saved WAV. Matching successful results are skipped. A mismatch must not be treated as equivalent; preserve the former report and establish a new reviewed run for changed inputs or methods. No implicit S2 expansion is implemented.

Every candidate remains provisional. Before S2, review the clock rule, eight retained-zero cases, flat/support band interpretation and finite-tail policy; freeze a new clearly identified policy as needed. Physical XVF replay, hardware format qualification, independent speech/scene tests, model performance and CM5 readiness remain separate later stages.
