# Inputs for review before S2

S1 is complete, but the development policy is NOT frozen or independently confirmed. No automatic S2.

## Exact artifacts

- C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S1\20260908T185148Z\active_campaign_manifest.json
  SHA-256: 4a74f638535c20404105bf0e9fd363fca595e7e37b6dd8be3549158191e44166
- C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S1\20260908T185148Z\selected_pilot_manifest.json
  SHA-256: 517ef4fd5badf7a3f17a5bc0d381724c71a5782e4114686e6ca6e39b48820612
- C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S1\20260908T185148Z\scope_and_room_context.v3.json
  SHA-256: 64abbe4d9e5cba371bf9785dfd2d315d61aac2a025ed5094476a8e5d9ed9c638
- C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S1\20260908T185148Z\extraction_config.json
  SHA-256: 4f7fed22a57558a810729996475a1e39265b870688e2f7a0b53abd6ebcd2fd8f
- C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S1\20260908T185148Z\qc_policy.initial.json
  SHA-256: 74b126f110d5d5a6169157139a8e78c45911cf5a29b44089327ef34353baeebe
- C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S1\20260908T185148Z\qc_policy.json
  SHA-256: 0383ee4ad8fe1a63239ec87d3555437671306c1ebea1f7eec3ff7bd5a22c8a9a
- C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S1\20260908T185148Z\rir_pilot_manifest.json
  SHA-256: 93ff50eb15370ecff4d4b68586ae06238c0b95b942a518002787eb9cb8f25633
- C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S1\20260908T185148Z\synthetic_results.json
  SHA-256: 2ffd7d1a90d5c4c3d663596e8c3f0c2d1bbeda35fbaae476a118ff936918f9fa
- C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S1\20260908T185148Z\unit_test_results.json
  SHA-256: a91e495dce67130ec8c26085109ef5bcc9f5d716a22ce9d817e4b42b2a69c8b7
- C:\Users\amiri\Documents\GitHub\just-peachy\XVF 3800 Testing\XVF Integration Real World RIRs\simulation\reports\S1\20260908T185148Z\metrics.json
  SHA-256: 04813cca279528c0c151f24651b188788ac12c912b21f83d5cc30e9374dbcb1d

## Decisions required before a separately authorized expansion

1. Review the shared-clock acceptance rule against saved zero/marker/working-bound sensitivity. All marker estimates are near −10 ppm, but eight miss the 3% sweep concentration criterion. Preserve those classifications until a reviewed policy specifies their allowed use. Do not retune merely to turn this pilot green.
2. Freeze the declared band, conservative noise-floor/tail policy and uncertainty treatment. The unused tail_required_below_noise_sec field must be removed or explicitly implemented in a new reviewed configuration; it did not govern S1.
3. If any extractor behavior changes, assign a new configuration/code identity and revalidate synthetic recovery and affected pilot results before full expansion. This pilot is developmental, not a confirmatory holdout.
4. Keep active eligibility exactly 121; preserve six Loeb Caf and 52 historical exclusions, both 1.00 m corrections and ±5 degree labels. Do not use nominal distances/angles to adjust channel delays.
5. Continue marking physical replay, independent speech/scene validation, DoA/diarization performance and CM5 readiness as separate later gates. S0's H2 elapsed-time evidence issue and USB 16/16 status are deferred to their later authorized stages.

## Timing-review records

- 3: JPXVF_P1_R06_T01_D01_S01_F00_NAT_CU_R01
- 4: JPXVF_P1_R06_T01_D01_S01_F00_NAT_CU_R07
- 6: JPXVF_P1_R06_T01_D01_S01_F00_NAT_C2_R12
- 8: JPXVF_P1_R01_T01_D01_S01_F00_NAT_CU_R06
- 9: JPXVF_P1_R02_T01_D01_S02_F00_NAT_CU_R09
- 10: JPXVF_P1_R05_T01_D01_S01_F00_NAT_C2_R07
- 11: JPXVF_P1_R03_T01_D01_S01_F00_NAT_CU_R03
- 12: JPXVF_P1_R03_T01_D01_S01_F00_NAT_CU_R01

Use S1_README.md for exact PowerShell/CMD commands. Resume verifies code/config/input/output hashes. It never expands the selected manifest beyond 12.
The Word design guide remains C:\Users\amiri\Downloads\XVF_Measurement_V5.docx, SHA-256 c9a6badcd83065ae9f865de841c077f00668a480e1f0170c115c514e30a99db6.
Full local WAVs and all provenance paths are in rir_pilot_manifest.json. Candidate files in the ZIP can be inspected without the original recordings; reproducible extraction requires the original bound local inputs.
