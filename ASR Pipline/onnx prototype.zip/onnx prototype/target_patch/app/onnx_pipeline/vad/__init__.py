"""VAD backends."""
