"""Speaker embedding backends."""
